package app.komodje

import app.komodje.data.LibraryDto
import app.komodje.domain.Komoji
import app.komodje.domain.fitsHappy
import app.komodje.domain.isComplex
import java.io.File
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** CI-страж библиотеки: простой смайлик или грустный глиф в «весёлых» физически не пройдут. */
class LibraryTest {

    private val library = Json.decodeFromString<LibraryDto>(
        File("src/main/assets/komoji.json").readText()
    )
    private val all = library.categories.flatMap { it.items }

    @Test
    fun noSimpleSmileys() {
        all.forEach { assertTrue("Слишком простой: $it", Komoji(it).isComplex()) }
    }

    @Test
    fun noDuplicates() {
        assertEquals("Есть дубликаты", all.size, all.toSet().size)
    }

    @Test
    fun happyHasNoSadGlyphs() {
        library.categories.single { it.mood == "HAPPY" }.items.forEach {
            assertTrue("Грустный глиф в весёлых: $it", Komoji(it).fitsHappy())
        }
    }
}
