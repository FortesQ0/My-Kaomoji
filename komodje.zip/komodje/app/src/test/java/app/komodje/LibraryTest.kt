package app.komodje

import app.komodje.domain.Komoji
import app.komodje.domain.fitsHappy
import app.komodje.domain.isComplex
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class LibraryTest {

    private val library: Map<String, List<Komoji>> by lazy {
        val raw = File("src/main/assets/komoji.json").readText()
        Json.parseToJsonElement(raw).jsonObject["categories"]!!.jsonArray.associate {
            val o = it.jsonObject
            o["mood"]!!.jsonPrimitive.content to o["items"]!!.jsonArray.map { e -> Komoji(e.jsonPrimitive.content) }
        }
    }

    @Test
    fun hasFiveCategories() {
        assertEquals(setOf("HAPPY", "SAD", "NEUTRAL", "ANGRY", "TENDER"), library.keys)
    }

    @Test
    fun noPlainAsciiSmileys() {
        val bad = library.values.flatten().filterNot { it.isComplex() }
        assertTrue("Простые смайлики: $bad", bad.isEmpty())
    }

    @Test
    fun noDuplicates() {
        val all = library.values.flatten().map { it.text }
        assertEquals("Дубликаты", all.size, all.toSet().size)
    }

    @Test
    fun happyHasNoSadGlyphs() {
        val bad = library.getValue("HAPPY").filterNot { it.fitsHappy() }
        assertTrue("Грустные глифы в весёлых: $bad", bad.isEmpty())
    }
}
