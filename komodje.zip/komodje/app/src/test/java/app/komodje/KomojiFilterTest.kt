package app.komodje

import app.komodje.domain.KomojiFilter
import app.komodje.domain.dailyPicks
import app.komodje.domain.defaultFolders
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class KomojiFilterTest {

    private val allTexts: List<String> by lazy {
        val raw = File("src/main/assets/komoji.json").readText()
        Json.parseToJsonElement(raw).jsonObject["categories"]!!.jsonArray
            .flatMap { it.jsonObject["items"]!!.jsonArray.map { e -> e.jsonPrimitive.content } }
    }

    @Test
    fun allMatchesEverything() {
        assertTrue(allTexts.all { KomojiFilter.ALL.matches(it) })
    }

    @Test
    fun plainFaceIsSingleWithoutEffects() {
        val text = "( ˊ ᵕ ˋ )"
        assertTrue(KomojiFilter.SINGLE.matches(text))
        assertFalse(KomojiFilter.GROUP.matches(text))
        assertFalse(KomojiFilter.EFFECTS.matches(text))
    }

    @Test
    fun sadAuraIsAnEffect() {
        assertTrue(KomojiFilter.EFFECTS.matches("( ¯ ︵ ¯ )|||"))
        assertTrue(KomojiFilter.EFFECTS.matches("ʕ ¯ ︵ ¯ ʔ|||"))
    }

    @Test
    fun sparklesInsideTheFaceAreNotAnEffect() {
        assertFalse(KomojiFilter.EFFECTS.matches("(ﾉ✧ ‿‿ ✧)ﾉ"))
        assertFalse(KomojiFilter.EFFECTS.matches("✧ ᗜ ✧"))
    }

    @Test
    fun heartOutsideTheFaceIsAnEffect() {
        assertTrue(KomojiFilter.EFFECTS.matches("( ˊ ᴗ ˋ )♡"))
    }

    @Test
    fun twoFacesAreAGroup() {
        assertTrue(KomojiFilter.GROUP.matches("( ˙ ° ˙ )( ˙ ▲ ˙ )"))
        assertFalse(KomojiFilter.SINGLE.matches("( ˙ ° ˙ )( ˙ ▲ ˙ )"))
    }

    @Test
    fun everyKomojiIsEitherSingleOrGroup() {
        for (t in allTexts) {
            assertTrue(t, KomojiFilter.SINGLE.matches(t) != KomojiFilter.GROUP.matches(t))
        }
    }

    @Test
    fun picksAreStableWithinADayAndDistinct() {
        val list = (1..30).map { "k$it" }
        val a = dailyPicks(list, day = 20_000L)
        val b = dailyPicks(list, day = 20_000L)
        assertEquals(a, b)
        assertEquals(4, a.size)
        assertEquals(4, a.toSet().size)
        assertTrue(list.containsAll(a))
    }

    @Test
    fun tooShortListHasNoPicks() {
        assertTrue(dailyPicks(listOf("a", "b", "c", "d"), day = 1L).isEmpty())
    }

    @Test
    fun defaultFolderKomojiExistInLibrary() {
        val known = allTexts.toSet()
        for (f in defaultFolders()) {
            for (t in f.items) assertTrue("Нет в библиотеке: $t", t in known)
        }
    }

    @Test
    fun threeDefaultFolders() {
        assertEquals(3, defaultFolders().size)
        assertTrue(defaultFolders().first().items.isNotEmpty())
    }
}
