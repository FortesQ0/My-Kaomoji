// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.update

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.app.PendingIntent
import android.widget.Toast
import app.komodje.R
import java.io.File

/**
 * Переустановка самого приложения через сессионный установщик системы (PackageInstaller.Session).
 * Android 13+ ограничивает службы доступности у приложений, поставленных не сессионным способом
 * (скачанный APK из браузера или файлового менеджера). Установка через сессию снимает это ограничение,
 * поэтому служба «Плавающее облачко» включается обычным переключателем. Сеть не нужна: ставится тот же
 * самый APK, что уже лежит на телефоне, данные приложения сохраняются.
 */
object SelfInstaller {
    /** Разрешено ли приложению ставить пакеты (системная настройка «Установка неизвестных приложений»). */
    fun canInstall(context: Context): Boolean =
        runCatching { context.packageManager.canRequestPackageInstalls() }.getOrDefault(false)

    /** Экран, где человек разрешает это приложению. */
    fun openInstallPermission(context: Context) {
        runCatching {
            context.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        }
    }

    /** Запускает переустановку. Возвращает false, если сессию создать не удалось. */
    fun start(context: Context): Boolean = runCatching {
        val app = context.applicationContext
        val installer = app.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL).apply {
            setAppPackageName(app.packageName)
            if (Build.VERSION.SDK_INT >= 33) runCatching { setPackageSource(PackageInstaller.PACKAGE_SOURCE_STORE) }
        }
        val id = installer.createSession(params)
        installer.openSession(id).use { session ->
            val info = app.applicationInfo
            val files = listOf(File(info.sourceDir)) + (info.splitSourceDirs?.map { File(it) } ?: emptyList())
            files.forEachIndexed { index, file ->
                val name = if (index == 0) "base.apk" else file.name
                file.inputStream().use { input ->
                    session.openWrite(name, 0, file.length()).use { out ->
                        input.copyTo(out)
                        session.fsync(out)
                    }
                }
            }
            val callback = PendingIntent.getBroadcast(
                app, id,
                Intent(app, SelfInstallReceiver::class.java).setPackage(app.packageName),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE,
            )
            session.commit(callback.intentSender)
        }
        true
    }.getOrDefault(false)
}

/** Ответ системы: просит подтвердить установку или сообщает об ошибке. */
class SelfInstallReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                val confirm: Intent? = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION") intent.getParcelableExtra(Intent.EXTRA_INTENT)
                }
                confirm?.let { runCatching { context.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
            }
            PackageInstaller.STATUS_SUCCESS -> Unit
            else -> Toast.makeText(context, R.string.bubble_install_failed, Toast.LENGTH_LONG).show()
        }
    }
}
