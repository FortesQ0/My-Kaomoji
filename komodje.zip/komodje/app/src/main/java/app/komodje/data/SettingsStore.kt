package app.komodje.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import app.komodje.domain.AccentTheme
import app.komodje.domain.ThemeMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.runBlocking

/**
 * Настройки оформления. Хранятся в том же DataStore, что и любимые.
 *
 * Значения отдаются как StateFlow с уже прочитанным стартовым значением. Поэтому после
 * пересоздания Activity (например, при смене языка) экран сразу рисуется с настоящей темой,
 * а не «прыгает» со значения по умолчанию.
 */
class SettingsStore(private val context: Context) {

    private val themeKey = stringPreferencesKey("theme_mode")
    private val accentKey = stringPreferencesKey("accent_theme")
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val initial: Preferences = runBlocking { context.dataStore.data.first() }

    private fun Preferences.mode(): ThemeMode =
        this[themeKey]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: ThemeMode.LIGHT

    private fun Preferences.accentTheme(): AccentTheme =
        this[accentKey]?.let { runCatching { AccentTheme.valueOf(it) }.getOrNull() } ?: AccentTheme.PEACH

    val themeMode: StateFlow<ThemeMode> = context.dataStore.data
        .map { it.mode() }
        .stateIn(scope, SharingStarted.Eagerly, initial.mode())

    val accent: StateFlow<AccentTheme> = context.dataStore.data
        .map { it.accentTheme() }
        .stateIn(scope, SharingStarted.Eagerly, initial.accentTheme())

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[themeKey] = mode.name }
    }

    suspend fun setAccent(accent: AccentTheme) {
        context.dataStore.edit { it[accentKey] = accent.name }
    }
}
