package app.komodje.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import app.komodje.domain.AccentTheme
import app.komodje.domain.Mood
import app.komodje.domain.ThemeMode
import app.komodje.widget.refreshWidgets
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.runBlocking

/**
 * Настройки оформления. Хранятся в том же DataStore, что и любимые.
 *
 * Значения отдаются как StateFlow с уже прочитанным стартовым значением. Поэтому после
 * пересоздания Activity (например, при смене языка) экран сразу рисуется с настоящей темой,
 * а не «прыгает» со значения по умолчанию.
 */
class SettingsStore(private val context: Context) {

    private val themeKey = stringPreferencesKey("theme_mode")
    private val accentKey = stringPreferencesKey("accent_theme")
    private val languageKey = booleanPreferencesKey("language_chosen")
    private val autoReturnKey = booleanPreferencesKey("ime_auto_return")
    private val imeMoodKey = stringPreferencesKey("ime_mood")
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val initial: Preferences = runBlocking { context.dataStore.data.first() }

    private fun Preferences.mode(): ThemeMode =
        this[themeKey]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: ThemeMode.LIGHT

    private fun Preferences.accentTheme(): AccentTheme =
        this[accentKey]?.let { runCatching { AccentTheme.valueOf(it) }.getOrNull() } ?: AccentTheme.PEACH

    val themeMode: StateFlow<ThemeMode> = context.dataStore.data
        .map { it.mode() }
        .stateIn(scope, SharingStarted.Eagerly, initial.mode())

    val accent: StateFlow<AccentTheme> = context.dataStore.data
        .map { it.accentTheme() }
        .stateIn(scope, SharingStarted.Eagerly, initial.accentTheme())

    /** Показан ли уже экран выбора языка при первом запуске. */
    val languageChosen: StateFlow<Boolean> = context.dataStore.data
        .map { it[languageKey] ?: false }
        .stateIn(scope, SharingStarted.Eagerly, initial[languageKey] ?: false)

    /** После вставки в клавиатуре вернуться на прошлую клавиатуру. По умолчанию включено. */
    val autoReturn: StateFlow<Boolean> = context.dataStore.data
        .map { it[autoReturnKey] ?: true }
        .stateIn(scope, SharingStarted.Eagerly, initial[autoReturnKey] ?: true)

    suspend fun setAutoReturn(on: Boolean) {
        context.dataStore.edit { it[autoReturnKey] = on }
    }

    /** Последняя открытая категория клавиатуры. Читается один раз при создании клавиатуры. */
    fun imeMood(): Mood {
        val prefs = runBlocking { context.dataStore.data.first() }
        return prefs[imeMoodKey]?.let { runCatching { Mood.valueOf(it) }.getOrNull() } ?: Mood.HAPPY
    }

    suspend fun setImeMood(mood: Mood) {
        context.dataStore.edit { it[imeMoodKey] = mood.name }
    }

    /** Свежие значения прямо из хранилища: виджет не должен ждать, пока обновится StateFlow. */
    suspend fun readThemeMode(): ThemeMode = context.dataStore.data.first().mode()

    suspend fun readAccent(): AccentTheme = context.dataStore.data.first().accentTheme()

    suspend fun markLanguageChosen() {
        context.dataStore.edit { it[languageKey] = true }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[themeKey] = mode.name }
        refreshWidgets(context)
    }

    suspend fun setAccent(accent: AccentTheme) {
        context.dataStore.edit { it[accentKey] = accent.name }
        refreshWidgets(context)
    }
}
