package app.komodje.domain

import java.time.LocalDate

/**
 * Поиск по смыслу: человек пишет эмоцию словом («ура», «злюсь», «thanks», «ありがとう»), а приложение находит
 * подходящие каомодзи. Слова собраны по группам эмоций на десяти языках приложения.
 *
 * Как каомодзи попадают в группу: по настроению из библиотеки и по значкам внутри самого текста
 * (слёзы, румянец, взмах рукой и так далее). Группа с флагом [strict] показывает только те, где значок нашёлся;
 * если таких нет вовсе, берутся все каомодзи нужного настроения. Остальные группы показывают всё настроение,
 * а подходящие по значкам ставят выше.
 *
 * Слова записаны как основы: «рад» найдёт «рада» и «радость», «thank» найдёт «thanks». Короткие слова
 * (до двух букв) сравниваются целиком, чтобы не находить лишнего.
 */
enum class Feel(
    private val moods: Set<Mood>,
    private val strict: Boolean,
    private val chars: String,
    private val parts: List<String>,
    private val words: String,
) {
    JOY(
        setOf(Mood.HAPPY), false, "✧ᗜ◕ᵔ★☆♪", listOf("^ ^", "^_^"),
        "ура|рад|рада|радост|счастл|класс|супер|круто|ликую|здорово|отлично|весел|позитив|кайф|" +
            "yay|happy|joy|glad|great|awesome|cool|cheer|excited|hooray|woo|wonderful|delight|" +
            "feliz|alegr|genial|contento|yupi|fantástic|estupend|viva|" +
            "froh|freu|glücklich|toll|klasse|prima|juhu|hurra|wunderbar|" +
            "heureux|joie|content|youpi|chouette|formidable|ravi|" +
            "felice|gioia|evviva|bello|fantastic|grande|" +
            "legal|ótimo|oba|maravilh|contente|show|" +
            "やった|嬉しい|うれしい|楽しい|幸せ|最高|わーい|いえい|" +
            "기쁘|행복|신나|좋아|좋다|최고|야호|즐거|" +
            "开心|高兴|快乐|太好了|幸福|耶|太棒",
    ),
    LAUGH(
        setOf(Mood.HAPPY, Mood.TENDER, Mood.NEUTRAL), true, "DдxX∀▽wｗ笑", listOf("ᗜ"),
        "ха-ха|хаха|хах|ахах|ржу|ржак|смешно|смех|лол|хд|хихи|хехе|смеюсь|угар|прикол|" +
            "haha|lol|lmao|rofl|laugh|funny|lmfao|hehe|giggle|xd|joke|" +
            "jaja|jeje|risa|reír|gracioso|chiste|" +
            "lachen|lustig|witzig|kicher|hihi|" +
            "mdr|ptdr|rire|drôle|rigol|" +
            "ahah|ridere|divertente|risata|" +
            "kkk|rsrs|rir|engraçado|risada|" +
            "笑|ww|www|草|あはは|ふふ|くすくす|おもしろ|面白い|" +
            "ㅋㅋ|ㅎㅎ|웃음|웃겨|하하|재밌|재미있|" +
            "哈哈|嘻嘻|好笑|呵呵|搞笑|233|有趣",
    ),
    LOVE(
        setOf(Mood.TENDER), false, "♡♥❤ღ", emptyList(),
        "люблю|любов|нравишься|обним|обнимаш|целую|поцелу|милый|милая|мило|скучаю|сердечк|нежн|влюбл|обожаю|" +
            "love|hug|kiss|miss you|cute|sweet|heart|adore|darling|crush|cuddle|affection|" +
            "amor|te quiero|te amo|abrazo|beso|cariño|lindo|corazón|extraño|ternura|" +
            "liebe|lieb|umarm|küss|süß|herz|vermiss|knuddel|schatz|" +
            "amour|aime|câlin|bisou|mignon|coeur|cœur|tendre|manque|chéri|" +
            "ti amo|ti voglio bene|abbraccio|bacio|dolce|cuore|manchi|tenero|carino|" +
            "beijo|fofo|coração|saudade|carinho|amo|" +
            "好き|愛|大好き|ハグ|キス|かわいい|可愛い|恋|ぎゅー|会いたい|ラブ|" +
            "사랑|좋아해|보고싶|안아|뽀뽀|귀여|하트|애정|" +
            "爱|喜欢你|想你|抱抱|亲亲|可爱|心|爱你|宝贝|甜",
    ),
    SAD(
        setOf(Mood.SAD), false, "╥﹏︵◞◟", emptyList(),
        "грущу|грустн|печаль|тоскл|тоска|обидно|обидел|одиноко|плохо|уныл|депресс|жаль|горюю|расстро|разочаров|тяжело|" +
            "sad|unhappy|lonely|depressed|sorrow|upset|hurt|disappointed|gloomy|miserable|heartbroken|" +
            "triste|tristeza|deprimido|pena|dolor|decepcion|melancol|" +
            "traurig|trauer|einsam|deprimiert|schade|enttäuscht|betrübt|" +
            "tristesse|seul|déprimé|dommage|déçu|chagrin|mélancol|peine|" +
            "tristezza|depresso|peccato|deluso|malinconi|dispiace|" +
            "sozinho|chateado|" +
            "悲しい|さみしい|寂しい|つらい|辛い|落ち込|憂鬱|しょんぼり|" +
            "슬프|슬퍼|우울|외로|속상|힘들|서운|" +
            "难过|伤心|悲伤|孤独|郁闷|失落|沮丧|难受",
    ),
    CRY(
        setOf(Mood.SAD, Mood.NEUTRAL, Mood.HAPPY, Mood.TENDER, Mood.ANGRY), true, "╥;ಥ", listOf("T_T", "T-T", ";_;"),
        "плачу|плак|рыда|слёз|слез|рев|ною|всхлип|навзрыд|разрыд|" +
            "cry|crying|tears|sob|weep|bawl|tearful|wail|" +
            "llor|lágrim|lagrim|sollozo|llanto|" +
            "weinen|wein|träne|schluchz|heul|" +
            "pleur|larme|sanglot|chialer|" +
            "piang|lacrim|singhiozz|" +
            "chor|soluç|" +
            "泣|涙|うるうる|えーん|うえーん|びえん|" +
            "울|눈물|엉엉|흑흑|ㅠㅠ|ㅜㅜ|" +
            "哭|泪|眼泪|呜呜|嘤嘤",
    ),
    ANGRY(
        setOf(Mood.ANGRY), false, "╬ʘ凸#ψ▼", listOf("`Д´"),
        "злюсь|злой|злая|зол|злость|бесит|ярост|гнев|ненавиж|раздража|сержусь|взбесил|достал|рычу|" +
            "angry|furious|rage|hate|annoyed|irritated|pissed|grr|outraged|livid|annoying|" +
            "enfadado|enojado|furioso|rabia|odio|molesto|cabreado|harto|" +
            "wütend|wut|sauer|zorn|hasse|genervt|ärger|böse|verärgert|" +
            "en colère|colère|fâché|furieux|déteste|énervé|agacé|haine|" +
            "arrabbiato|rabbia|irritato|arrabbi|nervoso|incavolato|" +
            "raiva|ódio|irritado|zangado|" +
            "怒|むかつく|ムカつく|腹立つ|イライラ|ぷんぷん|激おこ|許せない|" +
            "화나|화났|짜증|분노|열받|빡치|싫어|" +
            "生气|愤怒|气死|讨厌|烦|恼火|火大|暴怒",
    ),
    SURPRISE(
        setOf(Mood.NEUTRAL, Mood.HAPPY, Mood.TENDER, Mood.SAD, Mood.ANGRY), true, "ʘ◎⊙〇Ｏ°", listOf("!?", "?!"),
        "вау|ого|ничего себе|шок|удивл|офигеть|ужас|страшно|боюсь|испуг|жуть|неожиданно|не может быть|" +
            "wow|omg|shock|surprise|scared|afraid|fear|scary|whoa|oh no|startled|amazed|gasp|yikes|" +
            "guau|sorpresa|miedo|susto|asombro|increíble|vaya|" +
            "überrasch|schock|angst|erschrock|krass|hilfe|unglaublich|" +
            "waouh|oups|surpris|choc|peur|effray|incroyable|sidéré|" +
            "sorpres|paura|spavent|incredibile|mamma mia|" +
            "uau|medo|assust|nossa|caramba|incrível|" +
            "えっ|びっくり|驚|ひえー|うそ|まじ|こわい|怖い|ギャー|" +
            "헉|놀라|깜짝|대박|무서|충격|헐|" +
            "哇|惊讶|吃惊|震惊|害怕|可怕|天哪|吓|惊",
    ),
    SHY(
        setOf(Mood.TENDER, Mood.HAPPY, Mood.NEUTRAL), true, "〃⸝⁄", listOf("///"),
        "стесняюсь|стесн|неловко|краснею|смущ|ой|засмущ|застенчив|кринж|" +
            "shy|embarrassed|blush|awkward|bashful|flustered|oops|cringe|timid|aww|" +
            "vergüenza|tímido|sonroj|apenado|incómodo|" +
            "schüchtern|peinlich|erröt|verlegen|unangenehm|scheu|" +
            "timide|gêné|rougir|honte|embarrass|mal à l'aise|" +
            "imbarazz|arross|vergogna|a disagio|" +
            "vergonha|envergonh|corar|constrang|sem graça|" +
            "照れ|恥ずかしい|はずかしい|赤面|てれ|もじもじ|気まずい|" +
            "부끄|쑥스|민망|수줍|어색|" +
            "害羞|尴尬|脸红|不好意思|羞|腼腆",
    ),
    SLEEPY(
        setOf(Mood.NEUTRAL, Mood.TENDER, Mood.SAD), true, "ᶻ", listOf("zzz", "Zzz", "zZ", "-ω-"),
        "устал|усталость|сплю|спать|сон|спокойной ночи|спокойной|зеваю|зевота|выгорел|вымотал|засыпаю|сонн|соня|доброй ночи|" +
            "tired|sleepy|sleep|zzz|good night|goodnight|yawn|exhausted|nap|bedtime|burnout|drowsy|" +
            "cansado|sueño|dormir|buenas noches|bostez|agotado|siesta|duermo|" +
            "müde|schlaf|gute nacht|gähn|erschöpft|schlummer|" +
            "fatigué|sommeil|dormir|bonne nuit|bâill|épuisé|sieste|crevé|" +
            "stanco|sonno|dormire|buonanotte|buona notte|sbadigl|esausto|pisolino|" +
            "boa noite|bocej|exausto|soneca|" +
            "眠い|ねむい|疲れ|おやすみ|寝|あくび|ねる|だるい|" +
            "졸려|피곤|잘자|자자|하품|지쳐|졸림|" +
            "困|累|睡|晚安|打哈欠|疲惫|疲倦|犯困",
    ),
    GREET(
        setOf(Mood.HAPPY, Mood.NEUTRAL, Mood.TENDER), true, "ﾉノ", listOf(")/"),
        "привет|приветик|здравствуй|здарова|хай|добрый день|доброе утро|добрый вечер|пока|до встречи|до свидания|бывай|увидимся|салют|здрасте|прощай|" +
            "hi|hello|hey|bye|goodbye|good morning|good evening|see you|cya|howdy|farewell|greetings|sup|yo|" +
            "hola|adiós|adios|buenos días|buenas tardes|hasta luego|chao|nos vemos|saludos|bienvenido|" +
            "hallo|tschüss|tschuess|guten morgen|guten tag|guten abend|bis bald|servus|moin|auf wiedersehen|" +
            "bonjour|salut|coucou|au revoir|bonsoir|à bientôt|a bientot|adieu|bienvenue|ciao|" +
            "salve|arrivederci|buongiorno|buonasera|a presto|addio|benvenuto|ehi|" +
            "oi|olá|ola|tchau|bom dia|boa tarde|até logo|ate logo|adeus|bem-vindo|" +
            "こんにちは|こんばんは|おはよう|バイバイ|さようなら|やあ|またね|じゃあね|ハロー|ばいばい|" +
            "안녕|안녕하세요|잘가|하이|바이|환영|" +
            "你好|嗨|早上好|晚上好|再见|拜拜|哈喽|欢迎|早安|下午好",
    ),
    THANKS(
        setOf(Mood.NEUTRAL, Mood.TENDER, Mood.HAPPY, Mood.SAD), true, "", listOf("m(", "_ _", ")m", "🙏"),
        "спасибо|спс|благодар|благодарю|признателен|пожалуйста|пжл|выручил|сенкс|мерси|премного|" +
            "thanks|thank you|thank|thx|ty|appreciate|grateful|much obliged|cheers|" +
            "gracias|agradecido|agradezco|por favor|de nada|" +
            "danke|dankeschön|vielen dank|dankbar|bitte|" +
            "merci|remercie|reconnaissant|s'il vous plaît|svp|de rien|" +
            "grazie|ringrazio|riconoscente|per favore|prego|" +
            "obrigado|obrigada|valeu|agradeço|grato|" +
            "ありがとう|感謝|ありがと|どうも|サンキュー|お願い|" +
            "감사|고마워|고맙|감사합니다|부탁|" +
            "谢谢|感谢|多谢|感激|拜托|谢啦",
    ),
    SORRY(
        setOf(Mood.SAD, Mood.NEUTRAL, Mood.TENDER, Mood.HAPPY), true, "╥", listOf("m(", "_ _", ")m", "orz", "🙇"),
        "прости|извини|извините|простите|сорри|виноват|прошу прощения|мои извинения|каюсь|упс|ошибся|моя вина|" +
            "sorry|apolog|pardon|my bad|excuse me|forgive|regret|mistake|" +
            "perdón|perdon|lo siento|disculp|mi culpa|lamento|" +
            "entschuldig|tut mir leid|verzeih|mein fehler|" +
            "désolé|desole|excuse|navré|mon mauvais|je m'excuse|" +
            "scusa|scusi|mi dispiace|perdono|perdonami|colpa mia|spiacente|" +
            "desculp|perdão|perdao|sinto muito|foi mal|minha culpa|" +
            "ごめん|ごめんなさい|すみません|申し訳|スミマセン|ゴメン|失礼|" +
            "미안|죄송|사과|용서|실수|" +
            "对不起|抱歉|道歉|原谅|我错了",
    ),
    SUPPORT(
        setOf(Mood.HAPPY, Mood.NEUTRAL, Mood.TENDER), true, "ᕦᕙง", listOf(")b", "b)", "💪"),
        "держись|молодец|красава|красавчик|ты лучший|так держать|поддерж|вперёд|вперед|сможешь|верю в тебя|ты можешь|успех|удачи|не сдавайся|победа|горжусь|браво|" +
            "good job|well done|you can do it|keep going|hang in there|proud|support|cheer up|nice work|bravo|fighting|stay strong|good luck|congrats|respect|" +
            "ánimo|animo|bien hecho|tú puedes|tu puedes|sigue|orgulloso|apoyo|suerte|fuerza|felicit|" +
            "halt durch|gut gemacht|du schaffst|weiter so|stolz|stark|viel glück|kopf hoch|" +
            "courage|bien joué|tu peux|continue|fier|soutien|bonne chance|force|tiens bon|" +
            "forza|coraggio|ce la fai|continua|orgoglio|supporto|buona fortuna|ottimo lavoro|" +
            "coragem|parabéns|você consegue|continue|orgulho|apoio|boa sorte|bom trabalho|" +
            "がんばれ|頑張|ファイト|応援|すごい|えらい|さすが|ナイス|よくやった|" +
            "힘내|화이팅|파이팅|잘했|대단|응원|최고야|수고|" +
            "加油|真棒|厉害|你可以|支持|干得好|佩服|努力|坚持|好样的",
    ),
    PARTY(
        setOf(Mood.HAPPY, Mood.TENDER, Mood.NEUTRAL), true, "♪♫★☆✧ヽ", listOf("\\(", "🎉"),
        "праздник|поздравл|с днём рождения|с днем рождения|днюха|новый год|с новым годом|рождество|с рождеством|8 марта|23 февраля|юбилей|свадьба|тост|вечеринк|торт|подарок|пасха|выпускной|отмечаем|" +
            "party|congratulations|birthday|happy birthday|new year|christmas|merry christmas|holiday|celebrate|anniversary|wedding|toast|gift|cake|easter|halloween|valentine|" +
            "fiesta|felicidades|cumpleaños|feliz cumpleaños|año nuevo|navidad|celebrar|aniversario|boda|brindis|regalo|pastel|feliz navidad|" +
            "feier|herzlichen glückwunsch|glückwunsch|geburtstag|neujahr|weihnacht|hochzeit|prost|geschenk|torte|ostern|jubiläum|" +
            "fête|fete|félicitations|anniversaire|bonne année|noël|noel|célébrer|mariage|santé|cadeau|gâteau|pâques|" +
            "festa|auguri|compleanno|buon compleanno|capodanno|natale|celebrare|matrimonio|brindisi|regalo|torta|pasqua|" +
            "aniversário|feliz aniversário|ano novo|natal|casamento|brinde|presente|bolo|páscoa|" +
            "お祝い|おめでとう|誕生日|パーティー|お正月|クリスマス|乾杯|プレゼント|ケーキ|結婚|祝|あけおめ|" +
            "축하|생일|파티|새해|크리스마스|축제|건배|선물|케이크|결혼|명절|" +
            "祝贺|生日|派对|新年|圣诞|庆祝|干杯|礼物|蛋糕|结婚|恭喜|节日|过年",
    ),
    MEH(
        setOf(Mood.NEUTRAL, Mood.HAPPY, Mood.TENDER, Mood.SAD, Mood.ANGRY), true, "¬￣…ー", listOf("-_-", "-.-"),
        "ладно|ну да|хм|хмм|не знаю|ну ок|пофиг|без разницы|скучно|нейтрально|да ладно|окей|серьёзно|серьезно|мда|безразлично|понятно|ага|" +
            "meh|whatever|hmm|idk|i don't know|okay|boring|neutral|so so|indifferent|shrug|" +
            "vale|no sé|no se|da igual|aburrido|en serio|mmm|qué más da|" +
            "naja|egal|keine ahnung|langweilig|schulterzucken|" +
            "bof|ouais|aucune idée|ennuyé|neutre|sérieux|peu importe|comme ci comme ça|" +
            "boh|vabbè|vabbe|non so|noioso|neutro|davvero|fa lo stesso|" +
            "tanto faz|sei lá|sei la|chato|sério|mais ou menos|" +
            "うーん|別に|どうでもいい|ふーん|微妙|そうですか|退屈|" +
            "글쎄|그냥|상관없|심심|그래|몰라|흠|" +
            "无所谓|随便|不知道|好吧|无聊|还行|一般",
    ),
    FOOD(
        setOf(Mood.HAPPY, Mood.TENDER, Mood.NEUTRAL), true, "旦☕ڡﾑﾓ", listOf("nom", "c[_]", "🍵", "🍰"),
        "кушаю|еда|вкусно|вкусняшка|голодный|голоден|обед|ужин|завтрак|кофе|чай|пицца|сладкое|перекус|аппетит|поесть|напиток|" +
            "eat|eating|food|yummy|delicious|tasty|hungry|lunch|dinner|breakfast|coffee|tea|pizza|snack|dessert|drink|nom|munch|" +
            "comer|comida|rico|delicioso|hambre|almuerzo|cena|desayuno|café|té|merienda|postre|bebida|" +
            "essen|lecker|hunger|mittagessen|abendessen|frühstück|kaffee|tee|nachtisch|trinken|" +
            "manger|nourriture|délicieux|miam|faim|déjeuner|dîner|petit déjeuner|thé|goûter|boire|" +
            "mangiare|cibo|buono|fame|pranzo|colazione|caffè|tè|spuntino|dolce|bere|" +
            "gostoso|fome|almoço|jantar|café da manhã|chá|lanche|sobremesa|beber|" +
            "食べ|ごはん|おいしい|美味しい|お腹|ランチ|ディナー|朝食|コーヒー|お茶|ピザ|おやつ|デザート|飲|もぐもぐ|" +
            "먹|맛있|배고|점심|저녁|아침|커피|피자|간식|디저트|마시|냠냠|" +
            "吃|好吃|美味|饿|午饭|晚饭|早饭|咖啡|茶|披萨|零食|甜点|喝|饭",
    ),
    PLAY(
        setOf(Mood.HAPPY, Mood.TENDER, Mood.NEUTRAL), true, "~ミ⌒ε", listOf(";)", "^~"),
        "шалю|шалость|подмигиваю|подмигив|хитрю|хитрый|дразню|дразнюсь|играю|озорн|шутка|шучу|прикалываюсь|флирт|кокетн|высунул язык|" +
            "playful|wink|tease|naughty|mischief|flirt|joking|kidding|cheeky|smirk|silly|prank|tongue|" +
            "juguetón|guiño|guino|travieso|bromear|broma|coquet|picaro|pícaro|lengua|" +
            "verspielt|zwinker|necken|frech|scherz|schelm|zunge|" +
            "espiègle|clin d'œil|clin d'oeil|taquin|coquin|blague|malicieux|langue|plaisanter|" +
            "giocoso|occhiolino|stuzzic|birichino|scherzo|furbo|linguaccia|burla|" +
            "brincalhão|piscadela|provocar|travesso|piada|flerte|malandro|língua|zoar|" +
            "いたずら|ウインク|からかう|いじわる|ふざけ|冗談|べー|ちゃめ|てへ|" +
            "장난|윙크|놀리|짓궂|농담|메롱|까불|헤헤|" +
            "调皮|眨眼|逗|淘气|开玩笑|撩|吐舌|搞怪|嘿嘿",
    );

    /** Основы слов: нижний регистр, без пробелов по краям. */
    private val stems: List<String> by lazy {
        words.split('|').map { it.trim().lowercase() }.filter { it.isNotEmpty() }.distinct()
    }

    /** Подходит ли настроение этого каомодзи группе. */
    fun acceptsMood(mood: Mood?): Boolean = mood != null && mood in moods

    /** Группа показывает только каомодзи со значком; без значка в библиотеке берётся всё настроение. */
    val onlyWithGlyph: Boolean get() = strict

    /** Есть ли в тексте каомодзи значок этой группы. */
    fun glyphMatches(text: String): Boolean =
        (chars.isNotEmpty() && text.any { it in chars }) || parts.any { text.contains(it) }

    internal fun matches(query: String, tokens: List<String>): Boolean {
        for (s in stems) {
            if (tokenMatches(query, s)) return true
            for (t in tokens) if (tokenMatches(t, s)) return true
        }
        return false
    }

    companion object {
        private fun isCjk(c: Char): Boolean = c.code >= 0x2E80

        /** Слово из запроса t подходит основе s. */
        private fun tokenMatches(t: String, s: String): Boolean {
            if (t.isEmpty() || s.isEmpty()) return false
            if (t == s) return true
            return if (isCjk(s[0]) || isCjk(t[0])) {
                (t.length >= 2 && s.startsWith(t)) || t.contains(s)
            } else {
                (t.length >= 3 && s.startsWith(t)) || (s.length >= 3 && t.startsWith(s))
            }
        }

        /** Какие группы подходят запросу (не больше трёх: чтобы выдача не расползалась). */
        fun forQuery(raw: String): List<Feel> {
            val cleaned = raw.lowercase().filter { it.isLetterOrDigit() || it.isWhitespace() || it == '-' || it == '\'' }
                .trim().replace(Regex("\\s+"), " ")
            if (cleaned.length < 2 && !(cleaned.length == 1 && isCjk(cleaned[0]))) return emptyList()
            val tokens = cleaned.split(' ').filter { it.isNotEmpty() }
            return entries.filter { it.matches(cleaned, tokens) }.take(3)
        }

        /**
         * Праздники и памятные дни: на эти дни «Хиты дня» сами подмешивают подходящие каомодзи.
         * Ничего включать не нужно, работает на заднем фоне.
         */
        fun holiday(date: LocalDate): Feel? {
            val m = date.monthValue
            val d = date.dayOfMonth
            return when {
                (m == 12 && d >= 24) || (m == 1 && d <= 3) -> PARTY
                m == 2 && d in 13..14 -> LOVE
                m == 2 && d in 22..23 -> SUPPORT
                m == 3 && d in 7..8 -> LOVE
                m == 4 && d == 1 -> PLAY
                m == 10 && d in 30..31 -> SURPRISE
                else -> null
            }
        }
    }
}
