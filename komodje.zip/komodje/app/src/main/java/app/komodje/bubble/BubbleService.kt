// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.bubble

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import app.komodje.KomodjeApp
import app.komodje.R
import app.komodje.ui.HomeViewModel
import app.komodje.ui.components.KomojiPanel
import app.komodje.ui.components.LocalCardScale
import app.komodje.ui.components.LocalHapticsEnabled
import app.komodje.ui.components.LogoMark
import app.komodje.ui.components.pressScale
import app.komodje.ui.components.softShadow
import app.komodje.ui.theme.KomodjeTheme
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.accentBrush
import app.komodje.ui.theme.backgroundBrush
import app.komodje.ui.theme.isDark

/**
 * Плавающее облачко с каомодзи. Когда в любом приложении открыта клавиатура и курсор стоит в поле ввода,
 * над клавиатурой появляется круглое облачко с логотипом. Нажали: раскрывается компактная панель каомодзи
 * в нашем стиле. Выбрали: каомодзи вставляется в поле.
 *
 * Работает только если человек сам включил эту службу в «Специальных возможностях» и включил переключатель
 * в настройках приложения. Текст из других приложений нигде не сохраняется: служба видит только, есть ли поле
 * ввода, и записывает в него выбранное каомодзи. Окно служба-облачко рисует без отдельного разрешения
 * «поверх других приложений».
 */
class BubbleService : AccessibilityService(), LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {

    private val registry = LifecycleRegistry(this)
    private val savedState = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()

    override val lifecycle: Lifecycle get() = registry
    override val savedStateRegistry: SavedStateRegistry get() = savedState.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = store

    private val handler = Handler(Looper.getMainLooper())
    private val evaluate = Runnable { evaluateNow() }
    private var window: WindowManager? = null
    private var view: ComposeView? = null
    private var vm: HomeViewModel? = null
    private var expanded by mutableStateOf(false)
    private var bottomOffset = 0

    override fun onCreate() {
        super.onCreate()
        savedState.performAttach()
        savedState.performRestore(null)
        registry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        window = getSystemService(WINDOW_SERVICE) as WindowManager
        registry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        registry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // События идут пачками: разбираемся один раз, когда всё улеглось.
        handler.removeCallbacks(evaluate)
        handler.postDelayed(evaluate, 120)
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        handler.removeCallbacks(evaluate)
        hide()
        registry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        store.clear()
        super.onDestroy()
    }

    private fun evaluateNow() {
        val container = (application as KomodjeApp).container
        if (!container.settings.bubbleEnabled.value) {
            hide()
            return
        }
        val ime = runCatching { windows.firstOrNull { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD } }.getOrNull()
        val root = runCatching { rootInActiveWindow }.getOrNull()
        val field = runCatching { root?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) }.getOrNull()
        val ours = root?.packageName == packageName || ime?.root?.packageName == packageName
        val usable = ime != null && field != null && field.isEditable && !field.isPassword && !ours
        if (!usable) {
            hide()
            return
        }
        val bounds = Rect()
        ime?.getBoundsInScreen(bounds)
        show(bounds.top)
    }

    private fun layoutParams(wide: Boolean) = WindowManager.LayoutParams(
        if (wide) WindowManager.LayoutParams.MATCH_PARENT else WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT,
    ).apply {
        gravity = Gravity.BOTTOM or Gravity.END
        y = bottomOffset
    }

    private fun show(keyboardTop: Int) {
        val wm = window ?: return
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        bottomOffset = (dm.heightPixels - keyboardTop).coerceAtLeast(0) + (6 * dm.density).toInt()
        val current = view
        if (current != null) {
            runCatching { wm.updateViewLayout(current, layoutParams(expanded)) }
            return
        }
        val created = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@BubbleService)
            setViewTreeViewModelStoreOwner(this@BubbleService)
            setViewTreeSavedStateRegistryOwner(this@BubbleService)
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
            setContent {
                val settings = (application as KomodjeApp).container.settings
                val mode by settings.themeMode.collectAsStateWithLifecycle()
                val accent by settings.accent.collectAsStateWithLifecycle()
                val haptics by settings.haptics.collectAsStateWithLifecycle()
                KomodjeTheme(dark = mode.isDark(), accent = accent) {
                    CompositionLocalProvider(
                        LocalHapticsEnabled provides haptics,
                        LocalCardScale provides 0.8f,
                    ) { BubbleContent() }
                }
            }
        }
        val added = runCatching { wm.addView(created, layoutParams(expanded)) }.isSuccess
        if (added) view = created
    }

    private fun hide() {
        val current = view ?: return
        view = null
        expanded = false
        runCatching { current.disposeComposition() }
        runCatching { window?.removeViewImmediate(current) }
    }

    private fun changeExpanded(value: Boolean) {
        expanded = value
        if (value) vm?.refreshTop()
        val current = view ?: return
        runCatching { window?.updateViewLayout(current, layoutParams(value)) }
    }

    private fun homeViewModel(): HomeViewModel = vm ?: ViewModelProvider(
        this,
        HomeViewModel.factory((application as KomodjeApp).container, rememberMood = true),
    )[HomeViewModel::class.java].also { vm = it }

    /** Вставляет каомодзи в поле, где стоит курсор. Если поле не даёт записать текст, вставляет из буфера обмена. */
    private fun insert(text: String) {
        val node = runCatching { rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) }.getOrNull() ?: return
        val current = if (node.isShowingHintText) "" else node.text?.toString().orEmpty()
        val start = node.textSelectionStart.takeIf { it in 0..current.length } ?: current.length
        val end = node.textSelectionEnd.takeIf { it in 0..current.length } ?: start
        val from = minOf(start, end)
        val to = maxOf(start, end)
        val updated = current.replaceRange(from, to, text)
        val set = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, updated)
        }
        val ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, set)
        if (ok) {
            val caret = from + text.length
            val sel = Bundle().apply {
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, caret)
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, caret)
            }
            node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel)
        } else {
            val clipboard = getSystemService(ClipboardManager::class.java)
            clipboard?.setPrimaryClip(ClipData.newPlainText("kaomoji", text))
            node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        }
    }

    @Composable
    private fun BubbleContent() {
        val p = LocalPalette.current
        Column(
            Modifier.padding(horizontal = 8.dp),
            horizontalAlignment = Alignment.End,
        ) {
            AnimatedVisibility(
                visible = expanded,
                enter = fadeIn() + expandVertically(expandFrom = Alignment.Bottom),
                exit = fadeOut() + shrinkVertically(shrinkTowards = Alignment.Bottom),
            ) {
                val model = remember { homeViewModel() }
                val state by model.state.collectAsStateWithLifecycle()
                Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                        .height(320.dp)
                        .softShadow(RoundedCornerShape(26.dp), elevation = 6.dp, drawn = false)
                        .clip(RoundedCornerShape(26.dp))
                        .background(p.backgroundBrush()),
                ) {
                    KomojiPanel(
                        state = state,
                        onSelect = model::select,
                        onPick = { text ->
                            insert(text)
                            model.picked(text)
                        },
                        onHold = model::toggleFavorite,
                        feedback = stringResource(R.string.inserted),
                        modifier = Modifier.fillMaxWidth().height(320.dp).padding(top = 6.dp),
                        topRow = state.top,
                    )
                }
            }
            val source = remember { MutableInteractionSource() }
            val fill = remember(p) { p.accentBrush() }
            Box(
                Modifier
                    .size(52.dp)
                    .pressScale(source)
                    .softShadow(CircleShape, elevation = 4.dp, drawn = false)
                    .clip(CircleShape)
                    .background(fill)
                    .clickable(interactionSource = source, indication = null) { changeExpanded(!expanded) },
                contentAlignment = Alignment.Center,
            ) { LogoMark(size = 34.dp, onAccentBg = true) }
        }
    }
}
