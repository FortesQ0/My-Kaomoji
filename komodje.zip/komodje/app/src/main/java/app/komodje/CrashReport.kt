package app.komodje

import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Записывает вылеты приложения в файл и собирает из них отчёт, который человек отправляет из настроек
 * («Отправить отчёт»). Сам по себе ничего никуда не отправляется: данные уходят только через окно
 * «Поделиться», когда человек нажал на плашку.
 */
object CrashReport {
    private const val FILE = "crash_report.txt"
    private const val MAX_STORED = 24_000
    private const val MAX_LOG = 9_000

    fun install(app: Application) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching {
                val file = File(app.filesDir, FILE)
                val old = if (file.exists()) file.readText() else ""
                val entry = buildString {
                    append("=== ").append(stamp()).append(", поток ").append(thread.name).append('\n')
                    append(Log.getStackTraceString(error)).append('\n')
                }
                file.writeText((entry + old).take(MAX_STORED))
            }
            previous?.uncaughtException(thread, error)
        }
    }

    private fun stamp(): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())

    /** Текст отчёта: сведения о телефоне и версии, записанные вылеты, хвост журнала приложения. */
    suspend fun build(context: Context): String = withContext(Dispatchers.IO) {
        val version = runCatching {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName
        }.getOrNull().orEmpty()
        val crashes = runCatching {
            File(context.filesDir, FILE).takeIf { it.exists() }?.readText()
        }.getOrNull().orEmpty().ifBlank { "(вылетов не записано)" }
        val log = runCatching {
            val proc = Runtime.getRuntime().exec(arrayOf("logcat", "-d", "-t", "250", "-v", "time"))
            proc.inputStream.bufferedReader().readText().takeLast(MAX_LOG)
        }.getOrNull().orEmpty().ifBlank { "(журнал недоступен)" }
        buildString {
            append("My Kaomoji ").append(version).append('\n')
            append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
            append(", Android ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n")
            append(stamp()).append("\n\n")
            append("--- Вылеты ---\n").append(crashes).append("\n\n")
            append("--- Журнал ---\n").append(log).append('\n')
        }
    }

    /** Открывает окно «Поделиться» с готовым отчётом. */
    suspend fun share(context: Context) {
        val text = build(context)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "My Kaomoji: отчёт")
            putExtra(Intent.EXTRA_TEXT, text)
        }
        val chooser = Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(chooser) }
    }
}
