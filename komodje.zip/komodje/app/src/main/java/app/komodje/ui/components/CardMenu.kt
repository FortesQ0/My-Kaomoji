package app.komodje.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.komodje.R
import app.komodje.domain.Folder
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.Onest

private val RowShape = RoundedCornerShape(topStart = 18.dp, topEnd = 8.dp, bottomEnd = 18.dp, bottomStart = 8.dp)

/**
 * Меню долгого нажатия в разделе «Любимые»: положить в папку, убрать из открытой папки
 * или убрать из любимых. Если комоджи уже лежит в папке, у неё стоит галочка.
 */
@Composable
fun CardMenuDialog(
    text: String,
    folders: List<Folder>,
    openFolder: String?,
    isFavorite: Boolean,
    onAddTo: (Folder) -> Unit,
    onRemoveFromFolder: () -> Unit,
    onUnfavorite: () -> Unit,
    onClose: () -> Unit,
) {
    val p = LocalPalette.current
    KomojeDialog(onClose = onClose) {
        Text(
            text = text,
            color = p.ink,
            fontSize = 22.sp,
            textAlign = TextAlign.Center,
            maxLines = 2,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.size(14.dp))
        Text(
            stringResource(R.string.folder_add_title),
            color = p.muted, fontFamily = Onest, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
        )
        Spacer(Modifier.size(8.dp))
        FolderRows(folders, text, onAddTo)
        if (openFolder != null) {
            Spacer(Modifier.size(8.dp))
            MenuRow(label = stringResource(R.string.folder_remove), checked = false, onClick = onRemoveFromFolder)
        }
        if (isFavorite) {
            Spacer(Modifier.size(8.dp))
            MenuRow(label = stringResource(R.string.folder_unfavorite), checked = false, onClick = onUnfavorite)
        }
    }
}

/** Строки папок одна под другой (папок немного, прокрутка не нужна). */
@Composable
private fun FolderRows(folders: List<Folder>, text: String, onAddTo: (Folder) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        folders.forEach { f ->
            MenuRow(label = folderTitle(f), checked = text in f.items, onClick = { onAddTo(f) })
        }
    }
}

@Composable
private fun MenuRow(label: String, checked: Boolean, onClick: () -> Unit) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val interaction = remember { MutableInteractionSource() }
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp)
            .pressScale(interaction)
            .clip(RowShape)
            .background(p.ink.copy(alpha = 0.07f))
            .clickable(interactionSource = interaction, indication = null) {
                tick()
                onClick()
            }
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = label,
            color = p.ink, fontFamily = Onest, fontWeight = FontWeight.SemiBold, fontSize = 16.sp,
            maxLines = 1,
            modifier = Modifier.weight(1f),
        )
        if (checked) {
            Icon(KomojeIcons.Check, contentDescription = null, tint = p.heart, modifier = Modifier.size(20.dp))
        }
    }
}
