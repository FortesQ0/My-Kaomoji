package app.komodje.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import app.komodje.domain.Folder
import app.komodje.domain.USER_FOLDER_PREFIX
import app.komodje.domain.defaultFolders
import app.komodje.domain.isBuiltIn
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json

/**
 * Папки раздела «Любимые». Хранятся в том же DataStore одной строкой JSON.
 * Пока человек ничего не менял, отдаются три готовые папки; при первом изменении
 * весь список (вместе с готовыми) записывается в хранилище.
 */
class FoldersStore(private val context: Context) {

    private val key = stringPreferencesKey("folders")
    private val listSerializer = ListSerializer(Folder.serializer())
    private val json = Json { ignoreUnknownKeys = true }

    private fun decode(raw: String?): List<Folder> =
        if (raw.isNullOrEmpty()) {
            defaultFolders()
        } else {
            runCatching { json.decodeFromString(listSerializer, raw) }.getOrDefault(defaultFolders())
        }

    val folders: Flow<List<Folder>> = context.dataStore.data.map { decode(it[key]) }

    private suspend fun update(change: (List<Folder>) -> List<Folder>) {
        context.dataStore.edit { prefs ->
            prefs[key] = json.encodeToString(listSerializer, change(decode(prefs[key])))
        }
    }

    /** Кладёт комоджи в папку. Если он там уже есть, ничего не меняет. */
    suspend fun add(folderId: String, text: String) = update { list ->
        list.map { f ->
            if (f.id == folderId && text !in f.items) f.copy(items = f.items + text) else f
        }
    }

    suspend fun remove(folderId: String, text: String) = update { list ->
        list.map { f -> if (f.id == folderId) f.copy(items = f.items - text) else f }
    }

    suspend fun create(name: String) {
        val clean = name.trim().take(MAX_NAME)
        if (clean.isEmpty()) return
        update { it + Folder(id = USER_FOLDER_PREFIX + System.currentTimeMillis(), name = clean) }
    }

    /** Удалить можно только свою папку; готовые остаются. Сами каомодзи остаются в «Любимых». */
    suspend fun delete(folderId: String) = update { list ->
        list.filterNot { it.id == folderId && !it.isBuiltIn() }
    }

    companion object {
        const val MAX_NAME = 20
    }
}
