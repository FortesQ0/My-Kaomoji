package app.komodje.ui

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import app.komodje.domain.AccentTheme

/**
 * Значок приложения на рабочем столе повторяет выбранный цвет темы. Для каждого цвета в манифесте
 * есть свой псевдоним входа (IconSakura, IconPeach, ...); включён ровно один. Android не умеет менять
 * иконку «на лету», поэтому лаунчер обновляет её с небольшой задержкой.
 */
object AppIcon {
    private fun alias(context: Context, accent: AccentTheme) = ComponentName(
        context.packageName,
        "app.komodje.Icon" + accent.name.lowercase().replaceFirstChar { it.uppercase() },
    )

    private fun isOn(pm: PackageManager, comp: ComponentName, accent: AccentTheme): Boolean =
        when (pm.getComponentEnabledSetting(comp)) {
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED -> true
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED -> false
            // Состояние «как в манифесте»: включена только сакура.
            else -> accent == AccentTheme.SAKURA
        }

    fun apply(context: Context, accent: AccentTheme) {
        val pm = context.packageManager
        val target = alias(context, accent)
        // Сначала включаем нужный значок, потом выключаем остальные: на рабочем столе приложение не пропадает.
        if (!isOn(pm, target, accent)) {
            pm.setComponentEnabledSetting(
                target,
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP,
            )
        }
        AccentTheme.entries.filter { it != accent }.forEach { other ->
            val comp = alias(context, other)
            if (isOn(pm, comp, other)) {
                pm.setComponentEnabledSetting(
                    comp,
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                    PackageManager.DONT_KILL_APP,
                )
            }
        }
    }
}
