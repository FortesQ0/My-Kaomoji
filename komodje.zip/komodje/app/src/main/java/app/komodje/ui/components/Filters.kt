package app.komodje.ui.components

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.komodje.R
import app.komodje.domain.KomojiFilter
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.Onest
import app.komodje.ui.theme.accentBrush

private val TabShape = RoundedCornerShape(topStart = 18.dp, topEnd = 8.dp, bottomEnd = 18.dp, bottomStart = 8.dp)

private fun KomojiFilter.label(): Int = when (this) {
    KomojiFilter.ALL -> R.string.filter_all
    KomojiFilter.SINGLE -> R.string.filter_single
    KomojiFilter.GROUP -> R.string.filter_group
    KomojiFilter.EFFECTS -> R.string.filter_effects
}

/**
 * Мини-вкладки над списком: только подписи, листовые формы, выбранная заливается цветом темы.
 * Если не влезают (длинные переводы), ряд прокручивается вбок.
 */
@Composable
fun FilterTabs(selected: KomojiFilter, onSelect: (KomojiFilter) -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        KomojiFilter.entries.forEach { f ->
            FilterTab(label = stringResource(f.label()), selected = f == selected, onClick = { onSelect(f) })
        }
    }
}

@Composable
private fun FilterTab(label: String, selected: Boolean, onClick: () -> Unit) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val interaction = remember { MutableInteractionSource() }
    val fill = remember(p) { p.accentBrush() }
    val sel by animateFloatAsState(
        targetValue = if (selected) 1f else 0f,
        animationSpec = tween(220),
        label = "tabSel",
    )
    Box(
        Modifier
            .height(38.dp)
            .pressScale(interaction)
            .clip(TabShape)
            .background(p.card)
            .drawBehind { drawRect(fill, alpha = sel) }
            .clickable(interactionSource = interaction, indication = null) {
                tick()
                onClick()
            }
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = lerp(p.ink, p.onAccent, sel),
            fontFamily = Onest,
            fontWeight = FontWeight.SemiBold,
            fontSize = 14.sp,
            maxLines = 1,
            softWrap = false,
        )
    }
}

/** Полупрозрачная подпись под вкладками: «Хиты дня» (или название открытой папки). */
@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    Row(
        modifier
            .fillMaxWidth()
            .padding(start = 22.dp, end = 22.dp, top = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = KomojeIcons.Sparkle,
            contentDescription = null,
            tint = p.accentDeep,
            modifier = Modifier
                .size(12.dp)
                .graphicsLayer { alpha = 0.75f },
        )
        Spacer(Modifier.width(6.dp))
        Crossfade(targetState = text, animationSpec = tween(220), label = "sectionLabel") { value ->
            Text(
                text = value,
                color = p.muted.copy(alpha = 0.8f),
                fontFamily = Onest,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp,
                letterSpacing = 0.6.sp,
                maxLines = 1,
            )
        }
    }
}
