package app.komodje.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.komodje.R
import app.komodje.domain.ThemeMode
import app.komodje.ui.components.KomojeIcons
import app.komodje.ui.components.LogoMark
import app.komodje.ui.theme.HeaderShape
import app.komodje.ui.theme.LeafShape
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.Onest
import app.komodje.ui.theme.accentBrush
import app.komodje.ui.theme.backgroundBrush

private const val AUTHOR_URL = "https://t.me/Elena_Eldak"
private const val AUTHOR_HANDLE = "@Elena_Eldak"
private const val SIGNATURE_KAOMOJI = "૮ ˶ᵔ ᵕ ᵔ˶ ა ♡"

@Composable
fun SettingsScreen(
    themeMode: ThemeMode,
    onThemeMode: (ThemeMode) -> Unit,
    onSetLanguage: (String) -> Unit,
    onBack: () -> Unit,
) {
    val p = LocalPalette.current
    val uri = LocalUriHandler.current
    val isRu = LocalConfiguration.current.locales[0].language == "ru"

    Column(
        Modifier
            .fillMaxSize()
            .background(p.backgroundBrush())
            .navigationBarsPadding()
    ) {
        SettingsHeader(onBack)

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(start = 14.dp, end = 14.dp, top = 14.dp, bottom = 10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            // Язык: подпись слева, RU | EN справа
            SettingsCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CardTitle(stringResource(R.string.settings_language), Modifier.weight(1f))
                    Segmented(
                        options = listOf("RU", "EN"),
                        selected = if (isRu) 0 else 1,
                        onSelect = { onSetLanguage(if (it == 0) "ru" else "en") },
                    )
                }
            }

            // Тема: три кнопки на всю ширину
            val modes = listOf(ThemeMode.LIGHT, ThemeMode.DARK, ThemeMode.SYSTEM)
            SettingsCard {
                CardTitle(stringResource(R.string.settings_theme))
                Spacer(Modifier.height(12.dp))
                Segmented(
                    options = listOf(
                        stringResource(R.string.theme_light),
                        stringResource(R.string.theme_dark),
                        stringResource(R.string.theme_system),
                    ),
                    selected = modes.indexOf(themeMode),
                    onSelect = { onThemeMode(modes[it]) },
                    equalWidth = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            // Автор: ссылка на Telegram
            SettingsCard(onClick = { uri.openUri(AUTHOR_URL) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            stringResource(R.string.settings_author),
                            color = p.muted, fontFamily = Onest, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            AUTHOR_HANDLE,
                            color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 18.sp,
                        )
                    }
                    LeafButton(onClick = { uri.openUri(AUTHOR_URL) }) {
                        Icon(KomojeIcons.ArrowOut, null, tint = p.accent, modifier = Modifier.size(22.dp))
                    }
                }
            }

            Spacer(Modifier.height(28.dp))
            Footer()
            Spacer(Modifier.height(12.dp))
        }
    }
}

/** Та же низкая шапка, что и на главном: кнопка назад в паре с логотипом по краям. */
@Composable
private fun SettingsHeader(onBack: () -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .clip(HeaderShape)
            .background(p.accentBrush())
            .statusBarsPadding()
            .padding(start = 14.dp, end = 16.dp, top = 8.dp, bottom = 12.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        LeafButton(onClick = onBack) {
            Icon(
                KomojeIcons.Back, stringResource(R.string.back),
                tint = p.accent, modifier = Modifier.size(22.dp),
            )
        }
        Spacer(Modifier.width(10.dp))
        Text(
            text = stringResource(R.string.settings_title),
            color = p.onAccent,
            fontFamily = Onest,
            fontWeight = FontWeight.Bold,
            fontSize = 26.sp,
            letterSpacing = (-0.5).sp,
            modifier = Modifier
                .weight(1f)
                .offset(y = 5.dp),
        )
        LogoMark(size = 36.dp)
    }
}

@Composable
private fun SettingsCard(onClick: (() -> Unit)? = null, content: @Composable () -> Unit) {
    val p = LocalPalette.current
    val base = Modifier
        .fillMaxWidth()
        .clip(LeafShape)
        .background(p.card)
    Column(
        (if (onClick != null) base.clickable(onClick = onClick) else base)
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) { content() }
}

@Composable
private fun CardTitle(text: String, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    Text(
        text, modifier = modifier,
        color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 18.sp,
    )
}

/** Сегменты-«таблетка»: активный — тёмный лист с персиковым текстом. */
@Composable
private fun Segmented(
    options: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
    equalWidth: Boolean = false,
) {
    val p = LocalPalette.current
    Row(
        modifier
            .clip(CircleShape)
            .background(p.ink.copy(alpha = 0.08f))
            .padding(4.dp)
    ) {
        options.forEachIndexed { i, label ->
            val active = i == selected
            val bg by animateColorAsState(if (active) p.badge else Color.Transparent, tween(200), label = "segBg")
            val fg by animateColorAsState(if (active) p.accent else p.ink, tween(200), label = "segFg")
            Box(
                (if (equalWidth) Modifier.weight(1f) else Modifier)
                    .clip(CircleShape)
                    .background(bg)
                    .clickable { onSelect(i) }
                    .padding(horizontal = 16.dp, vertical = 9.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label, color = fg, fontFamily = Onest, fontWeight = FontWeight.Bold,
                    fontSize = 14.sp, maxLines = 1,
                )
            }
        }
    }
}

/** Подпись внизу: комоджи с сердечком, «пользуйся на здоровье» и бренд со звездой. */
@Composable
private fun Footer() {
    val p = LocalPalette.current
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(SIGNATURE_KAOMOJI, color = p.ink, fontSize = 30.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        Text(
            stringResource(R.string.signature),
            color = p.ink, fontFamily = Onest, fontWeight = FontWeight.SemiBold, fontSize = 16.sp,
        )
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                stringResource(R.string.app_name),
                color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 14.sp,
            )
            Icon(
                KomojeIcons.Sparkle, null, tint = p.heart,
                modifier = Modifier.padding(horizontal = 6.dp).size(14.dp),
            )
            Text(
                stringResource(R.string.tagline),
                color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 14.sp,
            )
        }
    }
}
