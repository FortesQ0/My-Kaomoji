package app.komodje.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.Density
import app.komodje.ui.components.DialogButton
import app.komodje.ui.components.DonateSheet
import app.komodje.ui.components.FitText
import app.komodje.ui.components.KomojiCard
import app.komodje.ui.components.KomojeDialog
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.komodje.R
import app.komodje.domain.AccentTheme
import app.komodje.domain.ThemeMode
import app.komodje.ui.components.KomojeIcons
import app.komodje.ui.components.pressScale
import app.komodje.ui.components.softShadow
import app.komodje.ui.components.rememberTick
import app.komodje.ui.theme.LeafShape
import app.komodje.ui.theme.LogoShape
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.Onest
import app.komodje.ui.theme.badgeBrush

private const val AUTHOR_URL = "https://t.me/Nasral_v_Multivarky"
private const val AUTHOR_HANDLE = "@Nasral_v_Multivarky"
private const val SIGNATURE_KAOMOJI = "૮ ˶ᵔ ᵕ ᵔ˶ ა ♡"

/**
 * Экран настроек. Шапка с кнопкой «назад» общая и живёт в MainActivity.
 * Подпись внизу стоит по центру свободного места под карточками: если места мало,
 * она просто идёт следом, и экран прокручивается.
 */
@Composable
fun SettingsScreen(
    themeMode: ThemeMode,
    onThemeMode: (ThemeMode) -> Unit,
    accent: AccentTheme,
    onAccent: (AccentTheme) -> Unit,
    autoReturn: Boolean,
    onAutoReturn: (Boolean) -> Unit,
    haptics: Boolean,
    onHaptics: (Boolean) -> Unit,
    cardScale: Int,
    onCardScale: (Int) -> Unit,
    keyboardHelpSeen: Boolean,
    onKeyboardHelpSeen: () -> Unit,
    onSetLanguage: (String) -> Unit,
) {
    val p = LocalPalette.current
    val uri = LocalUriHandler.current
    val density = LocalDensity.current
    val currentTag = supportedLanguageFor(LocalConfiguration.current.locales[0].language).tag
    var helpOpen by rememberSaveable { mutableStateOf(false) }
    var aboutOpen by rememberSaveable { mutableStateOf(false) }
    var donateOpen by rememberSaveable { mutableStateOf(false) }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        if (helpOpen) KeyboardHelpDialog(onClose = { helpOpen = false })
        if (aboutOpen) AboutDialog(onClose = { aboutOpen = false })
        if (donateOpen) DonateSheet(onClose = { donateOpen = false })
        var cardsPx by remember { mutableIntStateOf(0) }
        var footerPx by remember { mutableIntStateOf(0) }
        val gap = with(density) {
            val free = maxHeight.toPx() - cardsPx - footerPx - 24.dp.toPx()
            (free / 2f).coerceAtLeast(24.dp.toPx()).toDp()
        }

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(start = 14.dp, end = 14.dp, top = 14.dp, bottom = 10.dp),
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .onSizeChanged { cardsPx = it.height },
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                // Язык: слева название, справа плашка с текущим языком; по тапу раскрывается список
                SettingsCard {
                    var languagesOpen by rememberSaveable { mutableStateOf(false) }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CardTitle(stringResource(R.string.settings_language), Modifier.weight(1f))
                        LanguageSelector(
                            lang = supportedLanguageFor(currentTag.substringBefore('-')),
                            open = languagesOpen,
                            onClick = { languagesOpen = !languagesOpen },
                        )
                    }
                    AnimatedVisibility(
                        visible = languagesOpen,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut(),
                    ) {
                        Column {
                            Spacer(Modifier.height(12.dp))
                            LanguageGrid(
                                selectedTag = currentTag,
                                onSelect = {
                                    languagesOpen = false
                                    onSetLanguage(it)
                                },
                            )
                        }
                    }
                }

                // Цвет: восемь плиток-листьев с градиентом, два ряда по четыре
                SettingsCard {
                    CardTitle(stringResource(R.string.settings_accent))
                    Spacer(Modifier.height(14.dp))
                    AccentPicker(selected = accent, onSelect = onAccent)
                }

                // Режим: светлая, тёмная, системная
                val modes = listOf(ThemeMode.LIGHT, ThemeMode.DARK, ThemeMode.SYSTEM)
                SettingsCard {
                    CardTitle(stringResource(R.string.settings_theme))
                    Spacer(Modifier.height(12.dp))
                    Segmented(
                        options = listOf(
                            stringResource(R.string.theme_light),
                            stringResource(R.string.theme_dark),
                            stringResource(R.string.theme_system),
                        ),
                        selected = modes.indexOf(themeMode),
                        onSelect = { onThemeMode(modes[it]) },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }

                // Масштаб карточек
                SettingsCard {
                    ScaleCard(percent = cardScale, onCommit = onCardScale)
                }

                // Вибрация при нажатии: лёгкий отклик на карточках, вкладках и папках
                SettingsCard(onClick = { onHaptics(!haptics) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CardTitle(stringResource(R.string.settings_haptics), Modifier.weight(1f))
                        Spacer(Modifier.width(14.dp))
                        KaojiSwitch(checked = haptics)
                    }
                }

                // Клавиатура: вернуться на прошлую клавиатуру после вставки
                SettingsCard(onClick = { onAutoReturn(!autoReturn) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CardTitle(stringResource(R.string.settings_keyboard))
                                Spacer(Modifier.width(10.dp))
                                KeyboardHelpButton(
                                    showDot = !keyboardHelpSeen,
                                    onClick = {
                                        helpOpen = true
                                        onKeyboardHelpSeen()
                                    },
                                )
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(
                                stringResource(R.string.settings_auto_return),
                                color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 14.sp,
                            )
                        }
                        Spacer(Modifier.width(14.dp))
                        KaojiSwitch(checked = autoReturn)
                    }
                }

                // Автор: ссылка на Telegram
                SettingsCard(onClick = { uri.openUri(AUTHOR_URL) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                stringResource(R.string.settings_author),
                                color = p.muted, fontFamily = Onest, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                AUTHOR_HANDLE,
                                color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 18.sp,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                        }
                        LeafButton(onClick = { uri.openUri(AUTHOR_URL) }) {
                            Icon(KomojeIcons.ArrowOut, null, tint = p.onBadge, modifier = Modifier.size(22.dp))
                        }
                    }
                }

                // Поддержать: нижняя панель со способами (пока оформление, ссылки подключим позже)
                SettingsCard(onClick = { donateOpen = true }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                stringResource(R.string.settings_donate),
                                color = p.muted, fontFamily = Onest, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                stringResource(R.string.donate_title),
                                color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 18.sp,
                                maxLines = 2, overflow = TextOverflow.Ellipsis,
                            )
                        }
                        Spacer(Modifier.width(10.dp))
                        LeafButton(onClick = { donateOpen = true }) {
                            Icon(KomojeIcons.Coffee, null, tint = p.onBadge, modifier = Modifier.size(22.dp))
                        }
                    }
                }
            }

            Spacer(Modifier.height(gap))
            Box(
                Modifier
                    .fillMaxWidth()
                    .onSizeChanged { footerPx = it.height },
                contentAlignment = Alignment.Center,
            ) { Footer(onAbout = { aboutOpen = true }) }
            Spacer(Modifier.height(gap))
        }
    }
}

/** Плитки языков по два в ряд. Выбранная заливается тёмным листом с градиентом. */
@Composable
private fun LanguageGrid(selectedTag: String, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        AppLanguages.chunked(2).forEach { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                pair.forEach { lang ->
                    LanguageChip(
                        lang = lang,
                        selected = lang.tag == selectedTag,
                        onClick = { onSelect(lang.tag) },
                        modifier = Modifier.weight(1f),
                    )
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun LanguageChip(lang: AppLanguage, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val fill = remember(p) { p.badgeBrush() }
    val sel = animateFloatAsState(
        targetValue = if (selected) 1f else 0f,
        animationSpec = tween(240),
        label = "langSel",
    )
    val tick = rememberTick()
    val source = remember { MutableInteractionSource() }
    Box(
        modifier
            .height(44.dp)
            .pressScale(source)
            .clip(ChipShape)
            .background(p.ink.copy(alpha = 0.08f))
            .drawBehind { drawRect(fill, alpha = sel.value) }
            .clickable(interactionSource = source, indication = null) {
                tick()
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = lang.native,
            color = lerp(p.ink, p.onBadge, sel.value),
            fontFamily = Onest,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            maxLines = 1,
        )
    }
}

/** Плашка-селектор языка: текущий язык и стрелка, которая переворачивается при раскрытии. */
@Composable
private fun LanguageSelector(lang: AppLanguage, open: Boolean, onClick: () -> Unit) {
    val p = LocalPalette.current
    val fill = remember(p) { p.badgeBrush() }
    val turn = animateFloatAsState(
        targetValue = if (open) 180f else 0f,
        animationSpec = tween(240),
        label = "langChevron",
    )
    val tick = rememberTick()
    val source = remember { MutableInteractionSource() }
    Row(
        Modifier
            .height(44.dp)
            .pressScale(source)
            .clip(ChipShape)
            .background(fill)
            .clickable(interactionSource = source, indication = null) {
                tick()
                onClick()
            }
            .padding(start = 18.dp, end = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = lang.native,
            color = p.onBadge,
            fontFamily = Onest,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            maxLines = 1,
        )
        Spacer(Modifier.width(6.dp))
        Icon(
            imageVector = KomojeIcons.ChevronDown,
            contentDescription = null,
            tint = p.onBadge,
            modifier = Modifier
                .size(22.dp)
                .graphicsLayer { rotationZ = turn.value },
        )
    }
}

/** Переключатель в стиле приложения. Сам не кликабелен: нажатие ловит вся карточка. */
@Composable
private fun KaojiSwitch(checked: Boolean) {
    val p = LocalPalette.current
    val fill = remember(p) { p.badgeBrush() }
    val t = animateFloatAsState(
        targetValue = if (checked) 1f else 0f,
        animationSpec = tween(200),
        label = "switchState",
    )
    Box(
        Modifier
            .size(width = 56.dp, height = 32.dp)
            .clip(CircleShape)
            .background(p.ink.copy(alpha = 0.08f))
            .drawBehind { drawRect(fill, alpha = t.value) },
    ) {
        Box(
            Modifier
                .offset(x = 4.dp + 24.dp * t.value, y = 4.dp)
                .size(24.dp)
                .clip(CircleShape)
                .background(lerp(p.muted, p.onBadge, t.value)),
        )
    }
}

private val ChipShape = RoundedCornerShape(topStart = 18.dp, topEnd = 8.dp, bottomEnd = 18.dp, bottomStart = 8.dp)

@Composable
private fun SettingsCard(onClick: (() -> Unit)? = null, content: @Composable () -> Unit) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val source = remember { MutableInteractionSource() }
    val base = Modifier
        .fillMaxWidth()
        .pressScale(source, pressedScale = 0.975f)
        .softShadow(LeafShape)
        .clip(LeafShape)
        .background(p.card)
    Column(
        (if (onClick != null) {
            base.clickable(interactionSource = source, indication = null) {
                tick()
                onClick()
            }
        } else {
            base
        })
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) { content() }
}

@Composable
private fun CardTitle(text: String, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    Text(
        text, modifier = modifier,
        color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 18.sp,
    )
}

/**
 * Сегменты-«таблетка». Тёмный лист-указатель плавно переезжает на пружине к выбранному
 * сегменту, а цвет текста перетекает вслед за ним. Ширина сегментов одинаковая.
 */
@Composable
private fun Segmented(
    options: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val p = LocalPalette.current
    val fill = remember(p) { p.badgeBrush() }
    BoxWithConstraints(
        modifier
            .clip(CircleShape)
            .background(p.ink.copy(alpha = 0.08f))
    ) {
        val pad = 4.dp
        val segW = (maxWidth - pad * 2) / options.size
        val x by animateDpAsState(
            targetValue = segW * selected.coerceAtLeast(0),
            animationSpec = spring(dampingRatio = 0.75f, stiffness = 520f),
            label = "segSlide",
        )
        Box(
            Modifier
                .padding(pad)
                .offset(x = x)
                .width(segW)
                .height(36.dp)
                .clip(CircleShape)
                .background(fill)
        )
        Row(Modifier.padding(pad)) {
            options.forEachIndexed { i, label ->
                val fg by animateColorAsState(
                    if (i == selected) p.onBadge else p.ink, tween(220), label = "segText",
                )
                val tick = rememberTick()
                val source = remember { MutableInteractionSource() }
                Box(
                    Modifier
                        .weight(1f)
                        .height(36.dp)
                        .pressScale(source, pressedScale = 0.94f)
                        .clip(CircleShape)
                        .clickable(interactionSource = source, indication = null) {
                            tick()
                            onSelect(i)
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        label, color = fg, fontFamily = Onest, fontWeight = FontWeight.Bold,
                        fontSize = 14.sp, maxLines = 1,
                    )
                }
            }
        }
    }
}

/** Восемь плиток-листьев в два ряда. Выбранная увеличивается и получает обводку и галочку. */
@Composable
private fun AccentPicker(selected: AccentTheme, onSelect: (AccentTheme) -> Unit) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        AccentTheme.values().toList().chunked(4).forEach { row ->
            Row(Modifier.fillMaxWidth()) {
                row.forEach { a ->
                    Box(Modifier.weight(1f), contentAlignment = Alignment.TopCenter) {
                        AccentTile(a, active = a == selected, onClick = { onSelect(a) })
                    }
                }
                repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun AccentTile(a: AccentTheme, active: Boolean, onClick: () -> Unit) {
    val p = LocalPalette.current
    val scale = animateFloatAsState(
        targetValue = if (active) 1f else 0.86f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 500f),
        label = "swatch",
    )
    val name = when (a) {
        AccentTheme.PEACH -> R.string.accent_peach
        AccentTheme.SAKURA -> R.string.accent_sakura
        AccentTheme.SEA -> R.string.accent_sea
        AccentTheme.BURGUNDY -> R.string.accent_burgundy
        AccentTheme.APPLE -> R.string.accent_apple
        AccentTheme.SUN -> R.string.accent_sun
        AccentTheme.LILAC -> R.string.accent_lilac
        AccentTheme.MILK -> R.string.accent_milk
    }
    val mark = if (a == AccentTheme.BURGUNDY) Color.White else Color(0xFF2B1812)
    val tick = rememberTick()
    val source = remember { MutableInteractionSource() }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        // Маски на всём столбце нет: раньше clip(LogoShape) срезал углами края подписи цвета.
        modifier = Modifier
            .fillMaxWidth()
            .pressScale(source)
            .clickable(interactionSource = source, indication = null) {
                tick()
                onClick()
            },
    ) {
        Box(
            Modifier
                .size(56.dp)
                .graphicsLayer { scaleX = scale.value; scaleY = scale.value }
                .clip(LogoShape)
                .background(Brush.linearGradient(listOf(Color(a.top), Color(a.bottom))))
                // Тонкая рамка у светлых плиток (молоко), чтобы не сливались с карточкой.
                .border(if (active) 3.dp else 1.dp, if (active) p.ink else p.ink.copy(alpha = 0.12f), LogoShape),
            contentAlignment = Alignment.Center,
        ) {
            if (active) Icon(KomojeIcons.Check, null, tint = mark, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.height(6.dp))
        FitText(
            text = stringResource(name),
            color = if (active) p.ink else p.muted,
            fontFamily = Onest,
            fontWeight = FontWeight.SemiBold,
            maxSize = 12.sp,
            minSize = 9.sp,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp),
        )
    }
}

private val ScaleTicks = listOf(50, 75, 100, 125, 150)
private val PreviewTexts = listOf("(◕‿◕)", "ʕ•ᴥ•ʔ", "(╥﹏╥)", "(≧◡≦) ♡")

/** Масштаб карточек: окошко-превью, ползунок с метками и значение в процентах (тап = 100%). */
@Composable
private fun ScaleCard(percent: Int, onCommit: (Int) -> Unit) {
    val p = LocalPalette.current
    var live by remember(percent) { mutableIntStateOf(percent) }
    val tick = rememberTick()
    Row(verticalAlignment = Alignment.CenterVertically) {
        CardTitle(stringResource(R.string.settings_scale), Modifier.weight(1f))
        val source = remember { MutableInteractionSource() }
        Text(
            "$live%",
            color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 16.sp,
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .clickable(interactionSource = source, indication = null) {
                    if (live != 100) tick()
                    live = 100
                    onCommit(100)
                }
                .padding(horizontal = 8.dp, vertical = 4.dp),
        )
    }
    Spacer(Modifier.height(12.dp))
    ScalePreview(live / 100f)
    Spacer(Modifier.height(6.dp))
    ScaleSlider(value = live, onChange = { live = it }, onDone = { onCommit(live) })
}

@Composable
private fun ScalePreview(scale: Float) {
    val p = LocalPalette.current
    val density = LocalDensity.current
    val scaled = remember(density, scale) { Density(density.density * scale, density.fontScale) }
    val absorb = remember { MutableInteractionSource() }
    Box(
        Modifier
            .fillMaxWidth()
            .height(180.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(p.ink.copy(alpha = 0.06f)),
    ) {
        CompositionLocalProvider(LocalDensity provides scaled) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .wrapContentHeight(align = Alignment.Top, unbounded = true)
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                PreviewTexts.forEach { text ->
                    KomojiCard(
                        text = text,
                        favorite = false,
                        feedback = "",
                        onTap = {},
                        onHold = {},
                        onFavorite = {},
                        onCopied = {},
                    )
                }
            }
        }
        // Превью только показывает размер: касания внутри не должны ничего делать.
        Box(Modifier.fillMaxSize().clickable(interactionSource = absorb, indication = null) {})
    }
}

/**
 * Плавный ползунок 50..150% с метками на концах, четвертях и середине. Рядом с меткой (±3%)
 * значение «прилипает» к ней и даёт лёгкий отклик.
 */
@Composable
private fun ScaleSlider(value: Int, onChange: (Int) -> Unit, onDone: () -> Unit) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val onChangeNow by rememberUpdatedState(onChange)
    val onDoneNow by rememberUpdatedState(onDone)
    val tickNow by rememberUpdatedState(tick)
    var lastSnap by remember { mutableIntStateOf(-1) }

    fun valueAt(x: Float, width: Float, pad: Float): Int {
        val frac = ((x - pad) / (width - 2 * pad)).coerceIn(0f, 1f)
        val raw = (50 + frac * 100).toInt().coerceIn(50, 150)
        return ScaleTicks.firstOrNull { kotlin.math.abs(it - raw) <= 3 } ?: raw
    }

    fun push(v: Int) {
        val snapped = v in ScaleTicks
        if (snapped && v != lastSnap) tickNow()
        lastSnap = if (snapped) v else -1
        onChangeNow(v)
    }

    Canvas(
        Modifier
            .fillMaxWidth()
            .height(36.dp)
            .pointerInput(Unit) {
                val pad = 14.dp.toPx()
                detectTapGestures { o ->
                    push(valueAt(o.x, size.width.toFloat(), pad))
                    onDoneNow()
                }
            }
            .pointerInput(Unit) {
                val pad = 14.dp.toPx()
                detectHorizontalDragGestures(
                    onDragStart = { o -> push(valueAt(o.x, size.width.toFloat(), pad)) },
                    onDragEnd = { onDoneNow() },
                    onDragCancel = { onDoneNow() },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        push(valueAt(change.position.x, size.width.toFloat(), pad))
                    },
                )
            },
    ) {
        val pad = 14.dp.toPx()
        val w = size.width - 2 * pad
        val cy = size.height / 2f
        val th = 8.dp.toPx()
        fun xOf(v: Int) = pad + w * (v - 50) / 100f
        val x = xOf(value)
        val r = th / 2f
        drawRoundRect(
            color = p.ink.copy(alpha = 0.12f),
            topLeft = Offset(pad, cy - r),
            size = androidx.compose.ui.geometry.Size(w, th),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(r, r),
        )
        drawRoundRect(
            color = p.accent,
            topLeft = Offset(pad, cy - r),
            size = androidx.compose.ui.geometry.Size((x - pad).coerceAtLeast(th), th),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(r, r),
        )
        ScaleTicks.forEach { v ->
            drawCircle(
                color = if (v <= value) p.onAccent.copy(alpha = 0.9f) else p.muted.copy(alpha = 0.55f),
                radius = 2.5.dp.toPx(),
                center = Offset(xOf(v), cy),
            )
        }
        drawCircle(color = p.card, radius = 13.dp.toPx(), center = Offset(x, cy))
        drawCircle(color = p.accentDeep, radius = 10.dp.toPx(), center = Offset(x, cy))
    }
}

/** Подпись: облачко с фразой, под ним смайлик «говорит», ниже бренд со звездой. */
@Composable
private fun Footer(onAbout: () -> Unit) {
    val p = LocalPalette.current
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        SpeechBubble(stringResource(R.string.signature))
        Spacer(Modifier.height(4.dp))
        Text(SIGNATURE_KAOMOJI, color = p.ink, fontSize = 34.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                stringResource(R.string.app_name),
                color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 14.sp,
            )
            Icon(
                KomojeIcons.Sparkle, null, tint = p.heart,
                modifier = Modifier.padding(horizontal = 6.dp).size(14.dp),
            )
            Text(
                stringResource(R.string.tagline),
                color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 14.sp,
            )
        }
        Spacer(Modifier.height(18.dp))
        AboutPill(onAbout)
    }
}

/** Маленькая округлая плашка «О проекте»: тихая, не бросается в глаза. */
@Composable
private fun AboutPill(onClick: () -> Unit) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val source = remember { MutableInteractionSource() }
    Row(
        Modifier
            .pressScale(source)
            .clip(CircleShape)
            .background(p.ink.copy(alpha = 0.06f))
            .clickable(interactionSource = source, indication = null) {
                tick()
                onClick()
            }
            .padding(horizontal = 14.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(KomojeIcons.Sparkle, null, tint = p.muted.copy(alpha = 0.7f), modifier = Modifier.size(11.dp))
        Spacer(Modifier.width(6.dp))
        Text(
            stringResource(R.string.about_pill),
            color = p.muted.copy(alpha = 0.8f), fontFamily = Onest, fontWeight = FontWeight.SemiBold,
            fontSize = 12.sp, maxLines = 1,
        )
    }
}

/** Мини-окно «О проекте»: пара слов о приложении и источники библиотек. Больше нигде не упоминаются. */
@Composable
private fun AboutDialog(onClose: () -> Unit) {
    val p = LocalPalette.current
    val faint = p.muted.copy(alpha = 0.85f)
    KomojeDialog(onClose = onClose) {
        Text(
            stringResource(R.string.about_pill),
            color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 18.sp,
        )
        Spacer(Modifier.height(10.dp))
        Text(
            stringResource(R.string.about_text),
            color = faint, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 13.sp,
            lineHeight = 19.sp,
        )
        Spacer(Modifier.height(14.dp))
        Text(
            stringResource(R.string.about_sources_title).uppercase(),
            color = faint, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 11.sp,
            letterSpacing = 1.2.sp,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            stringResource(R.string.about_source_kaomojiya),
            color = faint, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 13.sp,
            lineHeight = 19.sp,
        )
        Spacer(Modifier.height(18.dp))
        DialogButton(
            label = stringResource(R.string.folder_help_ok),
            filled = true,
            modifier = Modifier.fillMaxWidth(),
            onClick = onClose,
        )
    }
}

/** Облачко в манга-стиле: тёмная обводка и хвостик вниз, к смайлику. Выскакивает пружиной. */
@Composable
private fun SpeechBubble(text: String) {
    val p = LocalPalette.current
    val pop = remember { Animatable(0f) }
    LaunchedEffect(Unit) { pop.animateTo(1f, spring(dampingRatio = 0.5f, stiffness = 280f)) }
    val tailH = 12.dp

    Box(
        Modifier
            .graphicsLayer {
                val s = 0.8f + 0.2f * pop.value
                scaleX = s
                scaleY = s
                alpha = pop.value.coerceIn(0f, 1f)
                transformOrigin = TransformOrigin(0.5f, 1f)
            }
            .drawBehind {
                val tail = tailH.toPx()
                val r = 20.dp.toPx()
                val tw = 14.dp.toPx()
                val w = size.width
                val h = size.height - tail
                val cx = w / 2f
                val path = Path().apply {
                    moveTo(r, 0f)
                    lineTo(w - r, 0f)
                    arcTo(Rect(w - 2 * r, 0f, w, 2 * r), -90f, 90f, false)
                    lineTo(w, h - r)
                    arcTo(Rect(w - 2 * r, h - 2 * r, w, h), 0f, 90f, false)
                    lineTo(cx + tw / 2f, h)
                    lineTo(cx, h + tail)
                    lineTo(cx - tw / 2f, h)
                    lineTo(r, h)
                    arcTo(Rect(0f, h - 2 * r, 2 * r, h), 90f, 90f, false)
                    lineTo(0f, r)
                    arcTo(Rect(0f, 0f, 2 * r, 2 * r), 180f, 90f, false)
                    close()
                }
                drawPath(path, p.card)
                drawPath(path, p.ink, style = Stroke(width = 2.dp.toPx(), join = StrokeJoin.Round))
            }
            .padding(start = 24.dp, end = 24.dp, top = 12.dp, bottom = 12.dp + tailH)
    ) {
        Text(
            text,
            color = p.ink, fontFamily = Onest, fontWeight = FontWeight.SemiBold, fontSize = 16.sp,
            textAlign = TextAlign.Center,
        )
    }
}
