package app.komodje.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.komodje.R
import app.komodje.domain.AccentTheme
import app.komodje.domain.ThemeMode
import app.komodje.ui.components.KomojeIcons
import app.komodje.ui.theme.LeafShape
import app.komodje.ui.theme.LogoShape
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.Onest
import app.komodje.ui.theme.badgeBrush

private const val AUTHOR_URL = "https://t.me/Elena_Eldak"
private const val AUTHOR_HANDLE = "@Elena_Eldak"
private const val SIGNATURE_KAOMOJI = "૮ ˶ᵔ ᵕ ᵔ˶ ა ♡"

/**
 * Экран настроек. Шапка с кнопкой «назад» общая и живёт в MainActivity.
 * Подпись внизу стоит по центру свободного места под карточками: если места мало,
 * она просто идёт следом, и экран прокручивается.
 */
@Composable
fun SettingsScreen(
    themeMode: ThemeMode,
    onThemeMode: (ThemeMode) -> Unit,
    accent: AccentTheme,
    onAccent: (AccentTheme) -> Unit,
    autoReturn: Boolean,
    onAutoReturn: (Boolean) -> Unit,
    keyboardHelpSeen: Boolean,
    onKeyboardHelpSeen: () -> Unit,
    onSetLanguage: (String) -> Unit,
) {
    val p = LocalPalette.current
    val uri = LocalUriHandler.current
    val density = LocalDensity.current
    val currentTag = supportedLanguageFor(LocalConfiguration.current.locales[0].language).tag
    var helpOpen by rememberSaveable { mutableStateOf(false) }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        if (helpOpen) KeyboardHelpDialog(onClose = { helpOpen = false })
        var cardsPx by remember { mutableIntStateOf(0) }
        var footerPx by remember { mutableIntStateOf(0) }
        val gap = with(density) {
            val free = maxHeight.toPx() - cardsPx - footerPx - 24.dp.toPx()
            (free / 2f).coerceAtLeast(24.dp.toPx()).toDp()
        }

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(start = 14.dp, end = 14.dp, top = 14.dp, bottom = 10.dp),
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .onSizeChanged { cardsPx = it.height },
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                // Язык: слева название, справа плашка с текущим языком; по тапу раскрывается список
                SettingsCard {
                    var languagesOpen by rememberSaveable { mutableStateOf(false) }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CardTitle(stringResource(R.string.settings_language), Modifier.weight(1f))
                        LanguageSelector(
                            lang = supportedLanguageFor(currentTag.substringBefore('-')),
                            open = languagesOpen,
                            onClick = { languagesOpen = !languagesOpen },
                        )
                    }
                    AnimatedVisibility(
                        visible = languagesOpen,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut(),
                    ) {
                        Column {
                            Spacer(Modifier.height(12.dp))
                            LanguageGrid(
                                selectedTag = currentTag,
                                onSelect = {
                                    languagesOpen = false
                                    onSetLanguage(it)
                                },
                            )
                        }
                    }
                }

                // Цвет: четыре плитки-листа с градиентом
                SettingsCard {
                    CardTitle(stringResource(R.string.settings_accent))
                    Spacer(Modifier.height(14.dp))
                    AccentPicker(selected = accent, onSelect = onAccent)
                }

                // Режим: светлая, тёмная, системная
                val modes = listOf(ThemeMode.LIGHT, ThemeMode.DARK, ThemeMode.SYSTEM)
                SettingsCard {
                    CardTitle(stringResource(R.string.settings_theme))
                    Spacer(Modifier.height(12.dp))
                    Segmented(
                        options = listOf(
                            stringResource(R.string.theme_light),
                            stringResource(R.string.theme_dark),
                            stringResource(R.string.theme_system),
                        ),
                        selected = modes.indexOf(themeMode),
                        onSelect = { onThemeMode(modes[it]) },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }

                // Клавиатура: вернуться на прошлую клавиатуру после вставки
                SettingsCard(onClick = { onAutoReturn(!autoReturn) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CardTitle(stringResource(R.string.settings_keyboard))
                                Spacer(Modifier.width(10.dp))
                                KeyboardHelpButton(
                                    showDot = !keyboardHelpSeen,
                                    onClick = {
                                        helpOpen = true
                                        onKeyboardHelpSeen()
                                    },
                                )
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(
                                stringResource(R.string.settings_auto_return),
                                color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 14.sp,
                            )
                        }
                        Spacer(Modifier.width(14.dp))
                        KaojiSwitch(checked = autoReturn)
                    }
                }

                // Автор: ссылка на Telegram
                SettingsCard(onClick = { uri.openUri(AUTHOR_URL) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                stringResource(R.string.settings_author),
                                color = p.muted, fontFamily = Onest, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                AUTHOR_HANDLE,
                                color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 18.sp,
                            )
                        }
                        LeafButton(onClick = { uri.openUri(AUTHOR_URL) }) {
                            Icon(KomojeIcons.ArrowOut, null, tint = p.onBadge, modifier = Modifier.size(22.dp))
                        }
                    }
                }
            }

            Spacer(Modifier.height(gap))
            Box(
                Modifier
                    .fillMaxWidth()
                    .onSizeChanged { footerPx = it.height },
                contentAlignment = Alignment.Center,
            ) { Footer() }
            Spacer(Modifier.height(gap))
        }
    }
}

/** Плитки языков по два в ряд. Выбранная заливается тёмным листом с градиентом. */
@Composable
private fun LanguageGrid(selectedTag: String, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        AppLanguages.chunked(2).forEach { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                pair.forEach { lang ->
                    LanguageChip(
                        lang = lang,
                        selected = lang.tag == selectedTag,
                        onClick = { onSelect(lang.tag) },
                        modifier = Modifier.weight(1f),
                    )
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun LanguageChip(lang: AppLanguage, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val fill = remember(p) { p.badgeBrush() }
    val sel = animateFloatAsState(
        targetValue = if (selected) 1f else 0f,
        animationSpec = tween(240),
        label = "langSel",
    )
    Box(
        modifier
            .height(44.dp)
            .clip(ChipShape)
            .background(p.ink.copy(alpha = 0.08f))
            .drawBehind { drawRect(fill, alpha = sel.value) }
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = lang.native,
            color = lerp(p.ink, p.onBadge, sel.value),
            fontFamily = Onest,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            maxLines = 1,
        )
    }
}

/** Плашка-селектор языка: текущий язык и стрелка, которая переворачивается при раскрытии. */
@Composable
private fun LanguageSelector(lang: AppLanguage, open: Boolean, onClick: () -> Unit) {
    val p = LocalPalette.current
    val fill = remember(p) { p.badgeBrush() }
    val turn = animateFloatAsState(
        targetValue = if (open) 180f else 0f,
        animationSpec = tween(240),
        label = "langChevron",
    )
    Row(
        Modifier
            .height(44.dp)
            .clip(ChipShape)
            .background(fill)
            .clickable(onClick = onClick)
            .padding(start = 18.dp, end = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = lang.native,
            color = p.onBadge,
            fontFamily = Onest,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            maxLines = 1,
        )
        Spacer(Modifier.width(6.dp))
        Icon(
            imageVector = KomojeIcons.ChevronDown,
            contentDescription = null,
            tint = p.onBadge,
            modifier = Modifier
                .size(22.dp)
                .graphicsLayer { rotationZ = turn.value },
        )
    }
}

/** Переключатель в стиле приложения. Сам не кликабелен: нажатие ловит вся карточка. */
@Composable
private fun KaojiSwitch(checked: Boolean) {
    val p = LocalPalette.current
    val fill = remember(p) { p.badgeBrush() }
    val t = animateFloatAsState(
        targetValue = if (checked) 1f else 0f,
        animationSpec = tween(200),
        label = "switchState",
    )
    Box(
        Modifier
            .size(width = 56.dp, height = 32.dp)
            .clip(CircleShape)
            .background(p.ink.copy(alpha = 0.08f))
            .drawBehind { drawRect(fill, alpha = t.value) },
    ) {
        Box(
            Modifier
                .offset(x = 4.dp + 24.dp * t.value, y = 4.dp)
                .size(24.dp)
                .clip(CircleShape)
                .background(lerp(p.muted, p.onBadge, t.value)),
        )
    }
}

private val ChipShape = RoundedCornerShape(topStart = 18.dp, topEnd = 8.dp, bottomEnd = 18.dp, bottomStart = 8.dp)

@Composable
private fun SettingsCard(onClick: (() -> Unit)? = null, content: @Composable () -> Unit) {
    val p = LocalPalette.current
    val base = Modifier
        .fillMaxWidth()
        .clip(LeafShape)
        .background(p.card)
    Column(
        (if (onClick != null) base.clickable(onClick = onClick) else base)
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) { content() }
}

@Composable
private fun CardTitle(text: String, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    Text(
        text, modifier = modifier,
        color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 18.sp,
    )
}

/**
 * Сегменты-«таблетка». Тёмный лист-указатель плавно переезжает на пружине к выбранному
 * сегменту, а цвет текста перетекает вслед за ним. Ширина сегментов одинаковая.
 */
@Composable
private fun Segmented(
    options: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val p = LocalPalette.current
    val fill = remember(p) { p.badgeBrush() }
    BoxWithConstraints(
        modifier
            .clip(CircleShape)
            .background(p.ink.copy(alpha = 0.08f))
    ) {
        val pad = 4.dp
        val segW = (maxWidth - pad * 2) / options.size
        val x by animateDpAsState(
            targetValue = segW * selected.coerceAtLeast(0),
            animationSpec = spring(dampingRatio = 0.75f, stiffness = 520f),
            label = "segSlide",
        )
        Box(
            Modifier
                .padding(pad)
                .offset(x = x)
                .width(segW)
                .height(36.dp)
                .clip(CircleShape)
                .background(fill)
        )
        Row(Modifier.padding(pad)) {
            options.forEachIndexed { i, label ->
                val fg by animateColorAsState(
                    if (i == selected) p.onBadge else p.ink, tween(220), label = "segText",
                )
                Box(
                    Modifier
                        .weight(1f)
                        .height(36.dp)
                        .clip(CircleShape)
                        .clickable { onSelect(i) },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        label, color = fg, fontFamily = Onest, fontWeight = FontWeight.Bold,
                        fontSize = 14.sp, maxLines = 1,
                    )
                }
            }
        }
    }
}

/** Четыре плитки-листа с градиентом своего цвета. Выбранная увеличивается и получает обводку и галочку. */
@Composable
private fun AccentPicker(selected: AccentTheme, onSelect: (AccentTheme) -> Unit) {
    val p = LocalPalette.current
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        AccentTheme.values().forEach { a ->
            val active = a == selected
            val scale = animateFloatAsState(
                targetValue = if (active) 1f else 0.86f,
                animationSpec = spring(dampingRatio = 0.55f, stiffness = 500f),
                label = "swatch",
            )
            val name = when (a) {
                AccentTheme.PEACH -> R.string.accent_peach
                AccentTheme.SAKURA -> R.string.accent_sakura
                AccentTheme.SEA -> R.string.accent_sea
                AccentTheme.BURGUNDY -> R.string.accent_burgundy
            }
            val mark = if (a == AccentTheme.BURGUNDY) Color.White else Color(0xFF2B1812)
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .clip(LogoShape)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onSelect(a) },
            ) {
                Box(
                    Modifier
                        .size(56.dp)
                        .graphicsLayer { scaleX = scale.value; scaleY = scale.value }
                        .clip(LogoShape)
                        .background(Brush.linearGradient(listOf(Color(a.top), Color(a.bottom))))
                        .border(if (active) 3.dp else 0.dp, p.ink, LogoShape),
                    contentAlignment = Alignment.Center,
                ) {
                    if (active) Icon(KomojeIcons.Check, null, tint = mark, modifier = Modifier.size(24.dp))
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    stringResource(name),
                    color = if (active) p.ink else p.muted,
                    fontFamily = Onest,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp,
                    maxLines = 1,
                )
            }
        }
    }
}

/** Подпись: облачко с фразой, под ним смайлик «говорит», ниже бренд со звездой. */
@Composable
private fun Footer() {
    val p = LocalPalette.current
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        SpeechBubble(stringResource(R.string.signature))
        Spacer(Modifier.height(4.dp))
        Text(SIGNATURE_KAOMOJI, color = p.ink, fontSize = 34.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                stringResource(R.string.app_name),
                color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 14.sp,
            )
            Icon(
                KomojeIcons.Sparkle, null, tint = p.heart,
                modifier = Modifier.padding(horizontal = 6.dp).size(14.dp),
            )
            Text(
                stringResource(R.string.tagline),
                color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 14.sp,
            )
        }
    }
}

/** Облачко в манга-стиле: тёмная обводка и хвостик вниз, к смайлику. Выскакивает пружиной. */
@Composable
private fun SpeechBubble(text: String) {
    val p = LocalPalette.current
    val pop = remember { Animatable(0f) }
    LaunchedEffect(Unit) { pop.animateTo(1f, spring(dampingRatio = 0.5f, stiffness = 280f)) }
    val tailH = 12.dp

    Box(
        Modifier
            .graphicsLayer {
                val s = 0.8f + 0.2f * pop.value
                scaleX = s
                scaleY = s
                alpha = pop.value.coerceIn(0f, 1f)
                transformOrigin = TransformOrigin(0.5f, 1f)
            }
            .drawBehind {
                val tail = tailH.toPx()
                val r = 20.dp.toPx()
                val tw = 14.dp.toPx()
                val w = size.width
                val h = size.height - tail
                val cx = w / 2f
                val path = Path().apply {
                    moveTo(r, 0f)
                    lineTo(w - r, 0f)
                    arcTo(Rect(w - 2 * r, 0f, w, 2 * r), -90f, 90f, false)
                    lineTo(w, h - r)
                    arcTo(Rect(w - 2 * r, h - 2 * r, w, h), 0f, 90f, false)
                    lineTo(cx + tw / 2f, h)
                    lineTo(cx, h + tail)
                    lineTo(cx - tw / 2f, h)
                    lineTo(r, h)
                    arcTo(Rect(0f, h - 2 * r, 2 * r, h), 90f, 90f, false)
                    lineTo(0f, r)
                    arcTo(Rect(0f, 0f, 2 * r, 2 * r), 180f, 90f, false)
                    close()
                }
                drawPath(path, p.card)
                drawPath(path, p.ink, style = Stroke(width = 2.dp.toPx(), join = StrokeJoin.Round))
            }
            .padding(start = 24.dp, end = 24.dp, top = 12.dp, bottom = 12.dp + tailH)
    ) {
        Text(
            text,
            color = p.ink, fontFamily = Onest, fontWeight = FontWeight.SemiBold, fontSize = 16.sp,
            textAlign = TextAlign.Center,
        )
    }
}
