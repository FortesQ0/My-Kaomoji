package app.komodje.ui

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import app.komodje.R
import app.komodje.bubble.BubbleService
import app.komodje.ui.components.HelpBubble
import app.komodje.ui.components.LogoMark
import app.komodje.ui.theme.LeafShape
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.Onest
import app.komodje.ui.theme.accentBrush
import app.komodje.ui.theme.backgroundBrush

private const val BUBBLE_STEPS = 3

/** Включена ли в системных настройках служба плавающего облачка. */
fun isBubbleServiceEnabled(context: Context): Boolean = runCatching {
    val enabled = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        ?: return@runCatching false
    val component = ComponentName(context, BubbleService::class.java)
    enabled.split(':').any {
        it.equals(component.flattenToString(), ignoreCase = true) ||
            it.equals(component.flattenToShortString(), ignoreCase = true)
    }
}.getOrDefault(false)

private fun openAccessibilitySettings(context: Context) {
    runCatching {
        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

/**
 * Экран «О приложении»: там в меню ⋮ стоит «Разрешить ограниченные настройки». Без этого Android
 * (особенно на Xiaomi/HyperOS) не даёт включить службу у приложения, установленного не из магазина.
 */
private fun openAppInfo(context: Context) {
    runCatching {
        context.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                .setData(android.net.Uri.fromParts("package", context.packageName, null))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }
}

/** Значок «?» рядом с названием блока облачка. */
@Composable
fun BubbleHelpButton(onClick: () -> Unit) {
    HelpBubble(onClick = onClick, showDot = false)
}

/**
 * Инструкция из трёх шагов в том же стиле, что и у клавиатуры: что это, как включить службу, как пользоваться.
 * Картинки нарисованы тут же и красятся в цвета выбранной темы. Вернулись из настроек с включённой службой:
 * сами переходим к третьему шагу.
 */
@Composable
fun BubbleHelpDialog(onClose: () -> Unit) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    var step by rememberSaveable { mutableStateOf(0) }
    var enabled by remember { mutableStateOf(isBubbleServiceEnabled(ctx)) }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                val now = isBubbleServiceEnabled(ctx)
                if (now && !enabled && step == 1) step = 2
                enabled = now
            }
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .padding(horizontal = 20.dp)
                .fillMaxWidth()
                .clip(LeafShape)
                .background(p.card)
                .padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(p.backgroundBrush()),
                contentAlignment = Alignment.Center,
            ) {
                Crossfade(targetState = step, animationSpec = tween(250), label = "bubbleArt") { s ->
                    when (s) {
                        0 -> ArtBubble()
                        1 -> ArtService(enabled)
                        else -> ArtPanelOpen()
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            Dots(step, BUBBLE_STEPS)
            Spacer(Modifier.height(14.dp))

            AnimatedContent(
                targetState = step,
                transitionSpec = {
                    if (targetState > initialState) {
                        (slideInHorizontally(tween(280)) { it / 3 } + fadeIn(tween(280))) togetherWith
                            (slideOutHorizontally(tween(280)) { -it / 3 } + fadeOut(tween(160)))
                    } else {
                        (slideInHorizontally(tween(280)) { -it / 3 } + fadeIn(tween(280))) togetherWith
                            (slideOutHorizontally(tween(280)) { it / 3 } + fadeOut(tween(160)))
                    }
                },
                label = "bubbleText",
            ) { s ->
                val title = when (s) {
                    0 -> R.string.bubble_step1_title
                    1 -> R.string.bubble_step2_title
                    else -> R.string.bubble_step3_title
                }
                val body = when (s) {
                    0 -> R.string.bubble_step1_body
                    1 -> R.string.bubble_step2_body
                    else -> R.string.bubble_step3_body
                }
                Column(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(min = 150.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        stringResource(title),
                        color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold,
                        fontSize = 22.sp, textAlign = TextAlign.Center,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        stringResource(body),
                        color = p.ink.copy(alpha = 0.72f), fontFamily = Onest, fontWeight = FontWeight.Medium,
                        fontSize = 15.sp, lineHeight = 21.sp, textAlign = TextAlign.Center,
                    )
                }
            }
            Spacer(Modifier.height(10.dp))

            when {
                step == 1 && enabled -> EnabledBadge(stringResource(R.string.bubble_service_on))
                step == 1 -> Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillButton(
                        text = stringResource(R.string.bubble_open_appinfo),
                        onClick = { openAppInfo(ctx) },
                        modifier = Modifier.fillMaxWidth(),
                        filled = false,
                    )
                    PillButton(
                        text = stringResource(R.string.bubble_open_settings),
                        onClick = { openAccessibilitySettings(ctx) },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
            if (step == 1) Spacer(Modifier.height(10.dp))

            val hasAction = step == 1 && !enabled
            val last = step == BUBBLE_STEPS - 1
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (step > 0) {
                    PillButton(
                        text = stringResource(R.string.back),
                        onClick = { step -= 1 },
                        modifier = Modifier.weight(1f),
                        filled = false,
                    )
                }
                PillButton(
                    text = stringResource(if (last) R.string.kb_done else R.string.kb_next),
                    onClick = { if (last) onClose() else step += 1 },
                    modifier = Modifier.weight(1f),
                    filled = !hasAction,
                )
            }
        }
    }
}

/** Облачко с логотипом в цвете темы. */
@Composable
private fun BubbleDot(size: androidx.compose.ui.unit.Dp) {
    val p = LocalPalette.current
    val fill = remember(p) { p.accentBrush() }
    Box(
        Modifier.size(size).clip(CircleShape).background(fill),
        contentAlignment = Alignment.Center,
    ) { LogoMark(size = size * 0.66f, onAccentBg = true) }
}

/** Схема телефона: поле ввода, клавиатура и над ней облачко. */
@Composable
private fun ArtBubble() {
    val p = LocalPalette.current
    Box(Modifier.size(width = 230.dp, height = 138.dp).clip(RoundedCornerShape(18.dp)).background(p.card)) {
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .padding(top = 14.dp)
                .fillMaxWidth(0.8f)
                .height(24.dp)
                .clip(CircleShape)
                .background(p.ink.copy(alpha = 0.08f)),
        )
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(50.dp)
                .background(p.ink.copy(alpha = 0.10f)),
        )
        Box(Modifier.align(Alignment.BottomEnd).padding(end = 14.dp, bottom = 58.dp)) { BubbleDot(36.dp) }
    }
}

/** Схема списка специальных возможностей с включённым переключателем. */
@Composable
private fun ArtService(on: Boolean) {
    val p = LocalPalette.current
    Column(
        Modifier.size(width = 230.dp, height = 138.dp).clip(RoundedCornerShape(18.dp)).background(p.card).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        repeat(3) { i ->
            val target = i == 1
            Row(
                Modifier.fillMaxWidth().height(30.dp).clip(RoundedCornerShape(10.dp))
                    .background(if (target) p.accent.copy(alpha = 0.45f) else p.ink.copy(alpha = 0.06f))
                    .padding(horizontal = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (target) BubbleDot(20.dp) else Box(Modifier.size(20.dp).clip(CircleShape).background(p.ink.copy(alpha = 0.12f)))
                Spacer(Modifier.width(8.dp))
                Box(
                    Modifier.weight(1f).height(8.dp).clip(CircleShape)
                        .background(p.ink.copy(alpha = if (target) 0.35f else 0.14f)),
                )
                Spacer(Modifier.width(8.dp))
                Box(
                    Modifier.size(width = 30.dp, height = 16.dp).clip(CircleShape)
                        .background(if (target && on) p.heart else p.ink.copy(alpha = 0.18f)),
                    contentAlignment = if (target && on) Alignment.CenterEnd else Alignment.CenterStart,
                ) { Box(Modifier.padding(2.dp).size(12.dp).clip(CircleShape).background(p.card)) }
            }
        }
    }
}

/** Схема раскрытой панели: над клавиатурой несколько карточек каомодзи. */
@Composable
private fun ArtPanelOpen() {
    val p = LocalPalette.current
    Box(Modifier.size(width = 230.dp, height = 138.dp).clip(RoundedCornerShape(18.dp)).background(p.card)) {
        Column(
            Modifier.align(Alignment.TopCenter).padding(top = 12.dp).fillMaxWidth(0.84f),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            listOf("(＾▽＾)", "\\( >ᴗ< )/", "( ‾ ᴗ ‾ )b").forEach { face ->
                Box(
                    Modifier.fillMaxWidth().height(24.dp).clip(RoundedCornerShape(12.dp)).background(p.ink.copy(alpha = 0.07f))
                        .padding(horizontal = 12.dp),
                    contentAlignment = Alignment.CenterStart,
                ) { Text(face, color = p.ink, fontSize = 13.sp, maxLines = 1) }
            }
        }
        Box(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(26.dp).background(p.ink.copy(alpha = 0.10f)),
        )
        Box(Modifier.align(Alignment.BottomEnd).padding(end = 12.dp, bottom = 30.dp)) { BubbleDot(30.dp) }
    }
}
