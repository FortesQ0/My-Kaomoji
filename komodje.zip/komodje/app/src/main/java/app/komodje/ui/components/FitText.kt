package app.komodje.ui.components

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp

/**
 * Текст в одну строку, который сначала уменьшается (до [minSize]), и только потом, если всё равно
 * не помещается, переносится на вторую строку. Название цвета на любом языке остаётся целым.
 */
@Composable
fun FitText(
    text: String,
    color: Color,
    modifier: Modifier = Modifier,
    fontFamily: FontFamily? = null,
    fontWeight: FontWeight? = null,
    maxSize: TextUnit = 12.sp,
    minSize: TextUnit = 9.sp,
    textAlign: TextAlign = TextAlign.Center,
) {
    var size by remember(text, maxSize) { mutableFloatStateOf(maxSize.value) }
    var ready by remember(text, maxSize) { mutableStateOf(false) }
    val wrap = size <= minSize.value
    Text(
        text = text,
        color = color,
        fontFamily = fontFamily,
        fontWeight = fontWeight,
        fontSize = size.sp,
        textAlign = textAlign,
        maxLines = if (wrap) 2 else 1,
        softWrap = wrap,
        style = TextStyle(lineHeight = (size + 2f).sp),
        onTextLayout = { r ->
            if (!ready) {
                if ((r.didOverflowWidth || r.hasVisualOverflow) && size > minSize.value) {
                    size = (size - 0.5f).coerceAtLeast(minSize.value)
                } else {
                    ready = true
                }
            }
        },
        modifier = modifier
            .fillMaxWidth()
            .drawWithContent { if (ready) drawContent() },
    )
}
