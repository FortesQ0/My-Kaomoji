package app.komodje.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.komodje.ui.theme.LeafShape
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.cardBrush
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private fun mix(a: Float, b: Float, t: Float): Float = a + (b - a) * t

/**
 * Карточка в руке. Рисуется поверх всего экрана (выше ряда папок и нижней панели), поэтому
 * никуда не «проваливается».
 *
 * Как это выглядит:
 * 1. Взяли карточку: она поднимается (чуть вырастает, появляется мягкая тень) и едет за пальцем
 *    целиком, вместе с каомодзи; на месте остаётся бледный след.
 * 2. Над папкой плашка слегка уменьшается, папка в ответ вырастает.
 * 3. Отпустили над папкой: плашка коротко сжимается и падает в папку, папка пружинит.
 * 4. Отпустили мимо: плашка разворачивается обратно и садится на своё место.
 */
@Composable
fun CardDragGhost(drag: CardDragState, modifier: Modifier = Modifier) {
    var rootPos by remember { mutableStateOf(Offset.Zero) }
    var rootSize by remember { mutableStateOf(IntSize.Zero) }
    Box(modifier.fillMaxSize().onGloballyPositioned {
        rootPos = it.positionInRoot()
        rootSize = it.size
    }) {
        val text = drag.text
        val density = drag.cardDensity
        if (text != null && density != null && drag.cardSize.width > 0 && drag.cardSize.height > 0 && rootSize.width > 0) {
            GhostBody(drag, text, density, { rootPos }, { rootSize })
        }
    }
}

@Composable
private fun GhostBody(
    drag: CardDragState,
    text: String,
    cardDensity: Density,
    rootPos: () -> Offset,
    rootSize: () -> IntSize,
) {
    val p = LocalPalette.current
    val buzz = rememberBuzz()
    val cardFill = remember(p) { p.cardBrush() }

    val cardW = drag.cardSize.width.toFloat()
    val cardH = drag.cardSize.height.toFloat()
    val cardWidthDp = with(cardDensity) { cardW.toDp() }
    val lead = with(cardDensity) { 18.dp.toPx() }
    var plateSize by remember { mutableStateOf(IntSize.Zero) }
    var naturalTextSize by remember { mutableStateOf(IntSize.Zero) }

    val gather = remember { Animatable(0f) }
    val scale = remember { Animatable(1f) }
    val fly = remember { Animatable(0f) }
    var settleFrom by remember { mutableStateOf<Offset?>(null) }
    var settleTo by remember { mutableStateOf(Offset.Zero) }
    var dropping by remember { mutableStateOf(false) }

    // Карточка «собирается» в плашку под пальцем.
    LaunchedEffect(Unit) { gather.animateTo(1f, spring(dampingRatio = 0.82f, stiffness = 320f)) }

    // Плашка сужается внутри полноразмерного слоя, чтобы траектория и координаты призрака не менялись.
    val compactWidth = naturalTextSize.width.takeIf { it > 0 }?.let { with(cardDensity) { it.toDp() + 32.dp } }
    val plateMinWidth = if (compactWidth == null) cardWidthDp else
        cardWidthDp + (compactWidth - cardWidthDp) * gather.value

    // Пока тащим: поднята (чуть крупнее), над папкой слегка уменьшается.
    val over = drag.hover != null
    val carrying = drag.release == null
    LaunchedEffect(over, carrying) {
        if (carrying) scale.animateTo(if (over) 0.72f else 1.03f, spring(dampingRatio = 0.6f, stiffness = 420f))
    }

    // Центр плашки идёт за пальцем; её реальная ширина учитывается при удержании у края экрана.
    fun carryCenter(): Offset {
        val fy = drag.grab.y / cardH
        val s = scale.value
        val local = drag.pos - rootPos()
        val visualWidth = (plateSize.width.takeIf { it > 0 } ?: cardW.toInt()) * s
        val half = visualWidth / 2f
        val x = local.x.coerceIn(half, (rootSize().width - half).coerceAtLeast(half))
        return Offset(
            x,
            local.y - (fy * cardH - cardH / 2f) * s - lead * gather.value,
        )
    }

    fun center(): Offset {
        val from = settleFrom ?: return carryCenter()
        return Offset(mix(from.x, settleTo.x, fly.value), mix(from.y, settleTo.y, fly.value))
    }

    // Финал: упасть в папку или вернуться на место.
    val release = drag.release
    LaunchedEffect(release) {
        val r = release ?: return@LaunchedEffect
        settleFrom = carryCenter()
        val folderRect = r.folder?.let { drag.rects[it] }
        if (folderRect != null) {
            dropping = true
            settleTo = folderRect.center - rootPos()
            coroutineScope {
                launch { fly.animateTo(1f, tween(260, easing = FastOutLinearInEasing)) }
                launch { scale.animateTo(0.16f, tween(260, easing = FastOutLinearInEasing)) }
            }
            buzz()
            drag.landed = r.folder
            drag.landedTick++
            r.commit()
        } else {
            settleTo = r.backCenter - rootPos()
            coroutineScope {
                launch { fly.animateTo(1f, spring(dampingRatio = 0.8f, stiffness = 380f)) }
                launch { scale.animateTo(1f, spring(dampingRatio = 0.8f, stiffness = 380f)) }
                launch { gather.animateTo(0f, spring(dampingRatio = 0.85f, stiffness = 380f)) }
            }
        }
        drag.reset()
    }

    CompositionLocalProvider(LocalDensity provides cardDensity) {
        Box(
            Modifier
                .layout { measurable, _ ->
                    val w = cardW.roundToInt()
                    val h = cardH.roundToInt()
                    val placeable = measurable.measure(Constraints.fixed(w, h))
                    layout(w, h) { placeable.place(0, 0) }
                }
                .graphicsLayer {
                    val c = center()
                    translationX = c.x - cardW / 2f
                    translationY = c.y - cardH / 2f
                    scaleX = scale.value
                    scaleY = scale.value
                    // Падая в папку, плашка гаснет на последней трети пути.
                    alpha = if (dropping) (1f - (fly.value - 0.6f) / 0.4f).coerceIn(0f, 1f) else 1f
                },
        ) {
            // Слой во всю ширину карточки: без fillMaxSize плашка прижималась влево, а не стояла под пальцем.
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Box(
                    Modifier
                        .widthIn(min = plateMinWidth.coerceAtMost(cardWidthDp), max = cardWidthDp)
                        .onSizeChanged { plateSize = it }
                        .softShadow(LeafShape, elevation = 6.dp, drawn = false)
                        .clip(LeafShape)
                        .background(cardFill),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = text,
                        color = p.ink,
                        fontSize = 20.sp,
                        lineHeight = 26.sp,
                        maxLines = Int.MAX_VALUE,
                        softWrap = true,
                        modifier = Modifier
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                            .onSizeChanged { naturalTextSize = it },
                    )
                    // Несколько карточек сразу: счётчик остаётся прикреплён к сужающейся плашке.
                    if (drag.count > 1) {
                        Box(
                            Modifier
                                .align(Alignment.TopEnd)
                                .offset(x = 6.dp, y = (-8).dp)
                                .size(26.dp)
                                .clip(CircleShape)
                                .background(p.accentDeep),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                text = drag.count.toString(),
                                color = p.onAccent,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                }
            }
        }
    }
}
