package app.komodje.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

/** Фирменная «листовая» форма карточек: углы 28 / 12 / 28 / 12. */
val LeafShape = RoundedCornerShape(topStart = 28.dp, topEnd = 12.dp, bottomEnd = 28.dp, bottomStart = 12.dp)

/** Нижняя панель: тот же лист, но с другими пропорциями. */
val BarShape = RoundedCornerShape(topStart = 30.dp, topEnd = 14.dp, bottomEnd = 30.dp, bottomStart = 14.dp)

/** Шапка: острый верх (под статус-баром), лист снизу. */
val HeaderShape = RoundedCornerShape(topStart = 0.dp, topEnd = 0.dp, bottomEnd = 14.dp, bottomStart = 40.dp)

/** Активная вкладка: маленький лист + кольцо цвета фона вокруг него (вырез в панели). */
val BadgeShape = RoundedCornerShape(topStart = 22.dp, topEnd = 9.dp, bottomEnd = 22.dp, bottomStart = 9.dp)
val BadgeRingShape = RoundedCornerShape(topStart = 26.dp, topEnd = 12.dp, bottomEnd = 26.dp, bottomStart = 12.dp)
