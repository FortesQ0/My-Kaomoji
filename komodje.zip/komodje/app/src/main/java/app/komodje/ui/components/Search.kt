package app.komodje.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.komodje.R
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.Onest

/**
 * Строка над списком (28dp): подпись «Хиты дня» слева, справа значок лупы. По тапу строка
 * превращается в поле поиска, по крестику возвращается обратно.
 */
@Composable
fun SearchRow(
    open: Boolean,
    query: String,
    onOpen: () -> Unit,
    onClose: () -> Unit,
    onQuery: (String) -> Unit,
    modifier: Modifier = Modifier,
    label: @Composable () -> Unit,
) {
    Box(modifier.fillMaxWidth().height(28.dp)) {
        if (open) {
            SearchField(query, onQuery, onClose)
        } else {
            label()
            SearchButton(onOpen, Modifier.align(Alignment.CenterEnd))
        }
    }
}

@Composable
fun SearchButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val source = remember { MutableInteractionSource() }
    Box(
        modifier
            .padding(end = 14.dp)
            .size(28.dp)
            .pressScale(source)
            .clip(RoundedCornerShape(10.dp))
            .clickable(interactionSource = source, indication = null) {
                tick()
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        Icon(KomojeIcons.Search, contentDescription = stringResource(R.string.search_hint), tint = p.muted, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun SearchField(query: String, onQuery: (String) -> Unit, onClose: () -> Unit) {
    val p = LocalPalette.current
    val focus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    val tick = rememberTick()
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp)
            .height(28.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(p.card)
            .padding(start = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(KomojeIcons.Search, contentDescription = null, tint = p.muted, modifier = Modifier.size(15.dp))
        Spacer(Modifier.width(8.dp))
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
            if (query.isEmpty()) {
                Text(
                    stringResource(R.string.search_hint),
                    color = p.muted.copy(alpha = 0.7f),
                    fontFamily = Onest,
                    fontWeight = FontWeight.Medium,
                    fontSize = 13.sp,
                    maxLines = 1,
                )
            }
            BasicTextField(
                value = query,
                onValueChange = onQuery,
                singleLine = true,
                textStyle = TextStyle(color = p.ink, fontSize = 14.sp),
                cursorBrush = SolidColor(p.accentDeep),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
                modifier = Modifier.fillMaxWidth().focusRequester(focus),
            )
        }
        val source = remember { MutableInteractionSource() }
        Box(
            Modifier
                .size(28.dp)
                .clickable(interactionSource = source, indication = null) {
                    tick()
                    focusManager.clearFocus()
                    onClose()
                },
            contentAlignment = Alignment.Center,
        ) {
            Icon(KomojeIcons.Close, contentDescription = null, tint = p.muted, modifier = Modifier.size(14.dp))
        }
    }
}
