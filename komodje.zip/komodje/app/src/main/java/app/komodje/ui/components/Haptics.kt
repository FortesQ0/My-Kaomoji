package app.komodje.ui.components

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.interaction.InteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext

/** Включена ли вибрация при нажатии (переключатель в настройках). Задаётся в MainActivity и клавиатуре. */
val LocalHapticsEnabled = compositionLocalOf { true }

private fun vibratorOf(context: Context): Vibrator? = runCatching {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        context.getSystemService(VibratorManager::class.java)?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }
}.getOrNull()

/**
 * Прямая вибрация мотором телефона, без посредников: системный «haptic feedback» в Compose
 * на многих оболочках (например, Xiaomi) молчит. Работает от нашего переключателя.
 * Android 10+: штатный эффект TICK (лёгкий) или CLICK (плотнее); если телефон его не умеет
 * или Android старше, то короткий импульс.
 */
private fun vibrate(vibrator: Vibrator?, strong: Boolean) {
    if (vibrator == null) return
    runCatching {
        if (!vibrator.hasVibrator()) return
        val effectId = if (strong) VibrationEffect.EFFECT_CLICK else VibrationEffect.EFFECT_TICK
        val predefinedOk = when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.R ->
                vibrator.areAllEffectsSupported(effectId) == Vibrator.VIBRATION_EFFECT_SUPPORT_YES
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q -> true
            else -> false
        }
        val effect = if (predefinedOk) {
            VibrationEffect.createPredefined(effectId)
        } else {
            VibrationEffect.createOneShot(if (strong) 28L else 14L, VibrationEffect.DEFAULT_AMPLITUDE)
        }
        vibrator.vibrate(effect)
    }
}

/** Лёгкий «тик»: короткий тап. Если вибрация выключена в настройках приложения, ничего не делает. */
@Composable
fun rememberTick(): () -> Unit {
    val context = LocalContext.current
    val enabled = LocalHapticsEnabled.current
    return remember(context, enabled) {
        val vibrator = vibratorOf(context)
        val action: () -> Unit = { if (enabled) vibrate(vibrator, strong = false) }
        action
    }
}

/** Чуть плотнее «тик»: срабатывание долгого нажатия, лайк. */
@Composable
fun rememberBuzz(): () -> Unit {
    val context = LocalContext.current
    val enabled = LocalHapticsEnabled.current
    return remember(context, enabled) {
        val vibrator = vibratorOf(context)
        val action: () -> Unit = { if (enabled) vibrate(vibrator, strong = true) }
        action
    }
}

/**
 * Эффект глубины для ЛЮБОГО нажатия. Плашка вместе со всем содержимым уменьшается и пружинно
 * возвращается (с лёгким «перелётом»). Короткий тап даёт сообщения «нажали» и «отпустили»
 * почти одновременно, поэтому сжатие всегда отыгрывается до конца (~90 мс), и только потом
 * идёт возврат. Если держать палец, плашка остаётся сжатой до отпускания.
 * Ставить нужно ПЕРЕД clip и background, иначе фон не будет уменьшаться.
 */
@Composable
fun Modifier.pressScale(source: InteractionSource, pressedScale: Float = 0.96f): Modifier {
    val scale = remember { Animatable(1f) }
    LaunchedEffect(source, pressedScale) {
        source.interactions.collect { interaction ->
            when (interaction) {
                is PressInteraction.Press ->
                    scale.animateTo(pressedScale, tween(90, easing = FastOutSlowInEasing))
                is PressInteraction.Release, is PressInteraction.Cancel ->
                    scale.animateTo(1f, spring(dampingRatio = 0.5f, stiffness = 520f))
                else -> Unit
            }
        }
    }
    return this.graphicsLayer {
        scaleX = scale.value
        scaleY = scale.value
    }
}
