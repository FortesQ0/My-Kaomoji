package app.komodje.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.interaction.InteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback

/** Включена ли вибрация при нажатии (переключатель в настройках). Задаётся в MainActivity и клавиатуре. */
val LocalHapticsEnabled = compositionLocalOf { true }

/**
 * Лёгкий «тик» системной вибрации. Это штатный эффект телефона: его силу под свой мотор
 * настраивает производитель, и он сам молчит, если отклик выключен в системных настройках.
 */
@Composable
fun rememberTick(): () -> Unit {
    val haptic = LocalHapticFeedback.current
    val enabled = LocalHapticsEnabled.current
    return remember(haptic, enabled) {
        { if (enabled) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
    }
}

/** Чуть плотнее «тик»: долгое нажатие, лайк. */
@Composable
fun rememberBuzz(): () -> Unit {
    val haptic = LocalHapticFeedback.current
    val enabled = LocalHapticsEnabled.current
    return remember(haptic, enabled) {
        { if (enabled) haptic.performHapticFeedback(HapticFeedbackType.LongPress) }
    }
}

/**
 * Эффект глубины: пока плашку держат, она вместе со всем содержимым чуть уменьшается,
 * а когда отпускают, пружинно возвращается (с лёгким «перелётом»).
 */
@Composable
fun Modifier.pressScale(source: InteractionSource, pressedScale: Float = 0.96f): Modifier {
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) pressedScale else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 520f),
        label = "pressScale",
    )
    return this.graphicsLayer {
        scaleX = scale
        scaleY = scale
    }
}
