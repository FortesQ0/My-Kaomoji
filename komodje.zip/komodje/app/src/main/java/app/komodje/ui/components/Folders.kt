package app.komodje.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.komodje.R
import app.komodje.data.FoldersStore
import app.komodje.domain.FOLDER_CONGRATS
import app.komodje.domain.FOLDER_CUTE
import app.komodje.domain.FOLDER_SAD
import app.komodje.domain.Folder
import app.komodje.domain.isBuiltIn
import app.komodje.ui.theme.LeafShape
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.Onest
import app.komodje.ui.theme.accentBrush
import app.komodje.ui.theme.badgeBrush

/** Что можно делать с папками. Передаётся в панель только в приложении (в клавиатуре папок нет). */
class FolderActions(
    val onOpen: (String) -> Unit,
    val onCreate: (String) -> Unit,
    val onDelete: (String) -> Unit,
)

/** Название папки: у готовых берётся из строк на языке интерфейса, у своих то, что ввёл человек. */
@Composable
fun folderTitle(folder: Folder): String = folder.name ?: when (folder.id) {
    FOLDER_CONGRATS -> stringResource(R.string.folder_congrats)
    FOLDER_SAD -> stringResource(R.string.folder_sad)
    FOLDER_CUTE -> stringResource(R.string.folder_cute)
    else -> ""
}

private val FolderShape = RoundedCornerShape(topStart = 22.dp, topEnd = 10.dp, bottomEnd = 22.dp, bottomStart = 10.dp)
private val ButtonShape = RoundedCornerShape(topStart = 18.dp, topEnd = 8.dp, bottomEnd = 18.dp, bottomStart = 8.dp)

/**
 * Нижняя полоса раздела «Любимые»: большие папки в ряд и стилизованный «+».
 * Тап по папке открывает её, повторный тап закрывает. Долгое нажатие на своей папке предлагает удалить.
 */
@Composable
fun FolderStrip(
    folders: List<Folder>,
    openId: String?,
    actions: FolderActions,
    modifier: Modifier = Modifier,
) {
    var creating by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Folder?>(null) }

    LazyRow(
        modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        items(folders, key = { it.id }) { f ->
            FolderCard(
                folder = f,
                selected = f.id == openId,
                onClick = { actions.onOpen(f.id) },
                onLongClick = { if (!f.isBuiltIn()) deleting = f },
            )
        }
        item(key = "add") { AddFolderCard(onClick = { creating = true }) }
    }

    if (creating) {
        NewFolderDialog(
            onCreate = {
                actions.onCreate(it)
                creating = false
            },
            onClose = { creating = false },
        )
    }
    deleting?.let { f ->
        ConfirmDialog(
            title = folderTitle(f),
            message = stringResource(R.string.folder_delete_q),
            confirm = stringResource(R.string.folder_delete),
            onConfirm = {
                actions.onDelete(f.id)
                deleting = null
            },
            onClose = { deleting = null },
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FolderCard(folder: Folder, selected: Boolean, onClick: () -> Unit, onLongClick: () -> Unit) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val buzz = rememberBuzz()
    val interaction = remember { MutableInteractionSource() }
    val fill = remember(p) { p.accentBrush() }
    val sel by animateFloatAsState(
        targetValue = if (selected) 1f else 0f,
        animationSpec = tween(240),
        label = "folderSel",
    )
    Column(
        Modifier
            .width(124.dp)
            .height(66.dp)
            .pressScale(interaction)
            .clip(FolderShape)
            .background(p.card)
            .drawBehind { drawRect(fill, alpha = sel) }
            .combinedClickable(
                interactionSource = interaction,
                indication = null,
                onClick = {
                    tick()
                    onClick()
                },
                onLongClick = {
                    buzz()
                    onLongClick()
                },
            )
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            text = folderTitle(folder),
            color = lerp(p.ink, p.onAccent, sel),
            fontFamily = Onest,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.height(2.dp))
        Text(
            text = folder.items.size.toString(),
            color = lerp(p.muted, p.onAccent, sel),
            fontFamily = Onest,
            fontWeight = FontWeight.Medium,
            fontSize = 13.sp,
        )
    }
}

@Composable
private fun AddFolderCard(onClick: () -> Unit) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val interaction = remember { MutableInteractionSource() }
    val fill = remember(p) { p.badgeBrush() }
    Box(
        Modifier
            .width(66.dp)
            .height(66.dp)
            .pressScale(interaction)
            .clip(FolderShape)
            .background(fill)
            .clickable(interactionSource = interaction, indication = null) {
                tick()
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        Icon(KomojeIcons.Plus, contentDescription = null, tint = p.onBadge, modifier = Modifier.size(28.dp))
    }
}

/** Общая оболочка окошек: лист на карточном фоне, как в инструкции по клавиатуре. */
@Composable
internal fun KomojeDialog(onClose: () -> Unit, content: @Composable () -> Unit) {
    val p = LocalPalette.current
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .padding(horizontal = 20.dp)
                .fillMaxWidth()
                .clip(LeafShape)
                .background(p.card)
                .padding(20.dp),
        ) { content() }
    }
}

@Composable
internal fun DialogButton(
    label: String,
    filled: Boolean,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val interaction = remember { MutableInteractionSource() }
    val fill = remember(p) { p.accentBrush() }
    Box(
        modifier
            .height(46.dp)
            .pressScale(interaction)
            .clip(ButtonShape)
            .background(p.ink.copy(alpha = 0.08f))
            .drawBehind { if (filled) drawRect(fill, alpha = if (enabled) 1f else 0.35f) }
            .clickable(interactionSource = interaction, indication = null, enabled = enabled) {
                tick()
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = if (filled) p.onAccent else p.ink,
            fontFamily = Onest,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            maxLines = 1,
        )
    }
}

@Composable
private fun NewFolderDialog(onCreate: (String) -> Unit, onClose: () -> Unit) {
    val p = LocalPalette.current
    var name by remember { mutableStateOf("") }
    KomojeDialog(onClose = onClose) {
        Text(
            stringResource(R.string.folder_new_title),
            color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 18.sp,
        )
        Spacer(Modifier.height(14.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .clip(ButtonShape)
                .background(p.ink.copy(alpha = 0.08f))
                .padding(horizontal = 16.dp, vertical = 14.dp),
        ) {
            if (name.isEmpty()) {
                Text(
                    stringResource(R.string.folder_name_hint),
                    color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 17.sp,
                )
            }
            BasicTextField(
                value = name,
                onValueChange = { if (it.length <= FoldersStore.MAX_NAME) name = it },
                singleLine = true,
                textStyle = TextStyle(
                    color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 17.sp,
                ),
                cursorBrush = SolidColor(p.accentDeep),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { if (name.isNotBlank()) onCreate(name) }),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DialogButton(
                label = stringResource(R.string.folder_cancel),
                filled = false,
                modifier = Modifier.weight(1f),
                onClick = onClose,
            )
            DialogButton(
                label = stringResource(R.string.folder_create),
                filled = true,
                enabled = name.isNotBlank(),
                modifier = Modifier.weight(1f),
                onClick = { onCreate(name) },
            )
        }
    }
}

@Composable
private fun ConfirmDialog(
    title: String,
    message: String,
    confirm: String,
    onConfirm: () -> Unit,
    onClose: () -> Unit,
) {
    val p = LocalPalette.current
    KomojeDialog(onClose = onClose) {
        Text(
            title,
            color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 18.sp,
            textAlign = TextAlign.Start,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            message,
            color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 15.sp,
        )
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DialogButton(
                label = stringResource(R.string.folder_cancel),
                filled = false,
                modifier = Modifier.weight(1f),
                onClick = onClose,
            )
            DialogButton(label = confirm, filled = true, modifier = Modifier.weight(1f), onClick = onConfirm)
        }
    }
}
