package app.komodje.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.komodje.R
import app.komodje.data.FoldersStore
import app.komodje.domain.FOLDER_BLANK_1
import app.komodje.domain.FOLDER_BLANK_2
import app.komodje.domain.FOLDER_CONGRATS
import app.komodje.domain.Folder
import app.komodje.ui.theme.LeafShape
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.Onest
import app.komodje.ui.theme.accentBrush
import app.komodje.ui.theme.badgeBrush
import app.komodje.ui.theme.cardBrush

/** Что можно делать с папками. Передаётся в панель только в приложении (в клавиатуре папок нет). */
class FolderActions(
    val onOpen: (String) -> Unit,
    val onCreate: (String) -> Unit,
    val onRename: (String, String) -> Unit,
    val onDelete: (String) -> Unit,
)

/**
 * Название папки: пока человек не дал своё, берётся из строк на языке интерфейса
 * («Поздравления» или «Папка без названия»).
 */
@Composable
fun folderTitle(folder: Folder): String = folder.name ?: when (folder.id) {
    FOLDER_CONGRATS -> stringResource(R.string.folder_congrats)
    FOLDER_BLANK_1, FOLDER_BLANK_2 -> stringResource(R.string.folder_untitled)
    else -> stringResource(R.string.folder_untitled)
}

private val ButtonShape = RoundedCornerShape(topStart = 18.dp, topEnd = 8.dp, bottomEnd = 18.dp, bottomStart = 8.dp)

/** Высота папки вместе с язычком, без «подложки», и высота самой подложки (объём). */
private val FolderBodyHeight = 86.dp
private val FolderTabHeight = 14.dp
private val FolderDepth = 5.dp

/** Меню папки: какая папка и где она на экране. */
private class FolderMenu(val folder: Folder, val anchor: Rect)

/**
 * Нижняя полоса раздела «Любимые». Сверху справа всегда видна кнопка «+», слева значок «?» с подсказкой.
 * Ниже три папки сразу на экране (если папок больше, ряд прокручивается).
 * Тап по папке открывает её, повторный тап закрывает. Долгое нажатие открывает меню
 * «Переименовать / Удалить» рядом с папкой.
 */
@Composable
fun FolderStrip(
    folders: List<Folder>,
    openId: String?,
    actions: FolderActions,
    modifier: Modifier = Modifier,
) {
    var creating by remember { mutableStateOf(false) }
    var help by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf<FolderMenu?>(null) }
    var renaming by remember { mutableStateOf<Folder?>(null) }
    var deleting by remember { mutableStateOf<Folder?>(null) }

    Column(modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 14.dp, end = 14.dp, top = 2.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            HelpBubble(onClick = { help = true }, pulse = true)
            Spacer(Modifier.weight(1f))
            AddFolderButton(onClick = { creating = true })
        }

        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val sidePad = 14.dp
            val gap = 8.dp
            // Ровно три папки на ширину экрана.
            val itemWidth = (maxWidth - sidePad * 2 - gap * 2) / 3
            LazyRow(
                contentPadding = PaddingValues(start = sidePad, end = sidePad, top = 2.dp, bottom = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(gap),
            ) {
                items(folders, key = { it.id }) { f ->
                    FolderCard(
                        folder = f,
                        selected = f.id == openId,
                        width = itemWidth,
                        onClick = { actions.onOpen(f.id) },
                        onLongClick = { anchor -> menu = FolderMenu(f, anchor) },
                    )
                }
            }
        }
    }

    if (creating) {
        FolderNameDialog(
            title = stringResource(R.string.folder_new_title),
            initial = "",
            confirmLabel = stringResource(R.string.folder_create),
            onConfirm = {
                actions.onCreate(it)
                creating = false
            },
            onClose = { creating = false },
        )
    }
    if (help) FolderHelpDialog(onClose = { help = false })

    menu?.let { m ->
        AnchoredMenu(anchor = m.anchor, onClose = { menu = null }) {
            MenuItem(
                label = stringResource(R.string.folder_rename),
                trailing = KomojeIcons.Edit,
                onClick = {
                    renaming = m.folder
                    menu = null
                },
            )
            MenuDivider()
            MenuItem(
                label = stringResource(R.string.folder_delete),
                danger = true,
                trailing = KomojeIcons.Trash,
                onClick = {
                    deleting = m.folder
                    menu = null
                },
            )
        }
    }
    renaming?.let { f ->
        FolderNameDialog(
            title = stringResource(R.string.folder_rename_title),
            initial = f.name ?: folderTitle(f),
            confirmLabel = stringResource(R.string.folder_save),
            onConfirm = {
                actions.onRename(f.id, it)
                renaming = null
            },
            onClose = { renaming = null },
        )
    }
    deleting?.let { f ->
        ConfirmDialog(
            title = folderTitle(f),
            message = stringResource(R.string.folder_delete_q),
            confirm = stringResource(R.string.folder_delete),
            onConfirm = {
                actions.onDelete(f.id)
                deleting = null
            },
            onClose = { deleting = null },
        )
    }
}

/**
 * Контур папки: прямоугольник с «листовыми» углами (большие по диагонали, маленькие по другой)
 * и язычком сверху справа. Высота [h] считается от верха язычка до низа.
 */
private fun folderPath(w: Float, h: Float, tabH: Float, tabW: Float, slope: Float, big: Float, small: Float): Path {
    val path = Path()
    val xb = w - tabW          // где язычок выходит на полную высоту
    val xa = xb - slope        // где начинается подъём к язычку

    path.moveTo(0f, tabH + big)
    // Верхний левый (большой) угол: управляющая точка в углу, кубическая форма вместо квадратичной.
    path.cubicTo(0f, tabH + big / 3f, big / 3f, tabH, big, tabH)
    path.lineTo(xa, tabH)
    // Плавный подъём на язычок.
    path.cubicTo(xa + slope * 0.5f, tabH, xb - slope * 0.5f, 0f, xb, 0f)
    path.lineTo(w - small, 0f)
    // Верхний правый (маленький) угол: это угол язычка.
    path.cubicTo(w - small / 3f, 0f, w, small / 3f, w, small)
    path.lineTo(w, h - big)
    // Нижний правый (большой).
    path.cubicTo(w, h - big / 3f, w - big / 3f, h, w - big, h)
    path.lineTo(small, h)
    // Нижний левый (маленький).
    path.cubicTo(small / 3f, h, 0f, h - small / 3f, 0f, h - small)
    path.close()
    return path
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FolderCard(
    folder: Folder,
    selected: Boolean,
    width: Dp,
    onClick: () -> Unit,
    onLongClick: (Rect) -> Unit,
) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val buzz = rememberBuzz()
    val view = LocalView.current
    val interaction = remember { MutableInteractionSource() }
    val coords = remember { arrayOfNulls<LayoutCoordinates>(1) }
    val selectedFill = remember(p) { p.accentBrush() }
    val cardFill = remember(p) { p.cardBrush() }
    // Подложка: тёмный вариант акцентного цвета, видна снизу как толщина папки.
    val backColor = remember(p) { lerp(p.accentDeep, Color.Black, 0.45f) }
    val sel by animateFloatAsState(
        targetValue = if (selected) 1f else 0f,
        animationSpec = tween(240),
        label = "folderSel",
    )
    Box(
        Modifier
            .width(width)
            .height(FolderBodyHeight + FolderDepth)
            .onGloballyPositioned { coords[0] = it }
            .pressScale(interaction)
            .drawBehind {
                val depth = FolderDepth.toPx()
                val path = folderPath(
                    w = size.width,
                    h = size.height - depth,
                    tabH = FolderTabHeight.toPx(),
                    tabW = size.width * 0.42f,
                    slope = 12.dp.toPx(),
                    big = 20.dp.toPx(),
                    small = 9.dp.toPx(),
                )
                translate(left = 0f, top = depth) { drawPath(path, backColor) }
                drawPath(path, cardFill)
                drawPath(path, selectedFill, alpha = sel)
                drawPath(path, Color.White.copy(alpha = 0.14f), style = Stroke(width = 1.dp.toPx()))
            }
            .combinedClickable(
                interactionSource = interaction,
                indication = null,
                onClick = {
                    tick()
                    onClick()
                },
                onLongClick = {
                    buzz()
                    onLongClick(coords[0]?.screenBounds(view) ?: Rect.Zero)
                },
            )
            .padding(
                start = 12.dp,
                end = 10.dp,
                top = FolderTabHeight + 4.dp,
                bottom = FolderDepth + 4.dp,
            ),
        contentAlignment = Alignment.CenterStart,
    ) {
        Column(verticalArrangement = Arrangement.Center) {
            Text(
                text = folderTitle(folder),
                color = lerp(p.ink, p.onAccent, sel),
                fontFamily = Onest,
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp,
                lineHeight = 17.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = folder.items.size.toString(),
                color = lerp(p.muted, p.onAccent, sel),
                fontFamily = Onest,
                fontWeight = FontWeight.Medium,
                fontSize = 13.sp,
            )
        }
    }
}

@Composable
private fun AddFolderButton(onClick: () -> Unit) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val interaction = remember { MutableInteractionSource() }
    val fill = remember(p) { p.badgeBrush() }
    Box(
        Modifier
            .size(width = 56.dp, height = 38.dp)
            .pressScale(interaction, pressedScale = 0.9f)
            .clip(ButtonShape)
            .background(fill)
            .clickable(interactionSource = interaction, indication = null) {
                tick()
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        Icon(KomojeIcons.Plus, contentDescription = null, tint = p.onBadge, modifier = Modifier.size(24.dp))
    }
}

/** Общая оболочка окошек: лист на карточном фоне, как в инструкции по клавиатуре. */
@Composable
internal fun KomojeDialog(onClose: () -> Unit, content: @Composable () -> Unit) {
    val p = LocalPalette.current
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .padding(horizontal = 20.dp)
                .fillMaxWidth()
                .clip(LeafShape)
                .background(p.card)
                .padding(20.dp),
        ) { content() }
    }
}

@Composable
internal fun DialogButton(
    label: String,
    filled: Boolean,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val interaction = remember { MutableInteractionSource() }
    val fill = remember(p) { p.accentBrush() }
    Box(
        modifier
            .height(46.dp)
            .pressScale(interaction)
            .clip(ButtonShape)
            .background(p.ink.copy(alpha = 0.08f))
            .drawBehind { if (filled) drawRect(fill, alpha = if (enabled) 1f else 0.35f) }
            .clickable(interactionSource = interaction, indication = null, enabled = enabled) {
                tick()
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = if (filled) p.onAccent else p.ink,
            fontFamily = Onest,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            maxLines = 1,
        )
    }
}

/** Окошко с полем названия: и для новой папки, и для переименования. */
@Composable
internal fun FolderNameDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    onConfirm: (String) -> Unit,
    onClose: () -> Unit,
    hint: Int = R.string.folder_name_hint,
    maxLength: Int = FoldersStore.MAX_NAME,
) {
    val p = LocalPalette.current
    var name by remember { mutableStateOf(initial) }
    KomojeDialog(onClose = onClose) {
        Text(
            title,
            color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 18.sp,
        )
        Spacer(Modifier.height(14.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .clip(ButtonShape)
                .background(p.ink.copy(alpha = 0.08f))
                .padding(horizontal = 16.dp, vertical = 14.dp),
        ) {
            if (name.isEmpty()) {
                Text(
                    stringResource(hint),
                    color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 17.sp,
                )
            }
            BasicTextField(
                value = name,
                onValueChange = { if (it.length <= maxLength) name = it },
                singleLine = true,
                textStyle = TextStyle(
                    color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 17.sp,
                ),
                cursorBrush = SolidColor(p.accentDeep),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { if (name.isNotBlank()) onConfirm(name) }),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DialogButton(
                label = stringResource(R.string.folder_cancel),
                filled = false,
                modifier = Modifier.weight(1f),
                onClick = onClose,
            )
            DialogButton(
                label = confirmLabel,
                filled = true,
                enabled = name.isNotBlank(),
                modifier = Modifier.weight(1f),
                onClick = { onConfirm(name) },
            )
        }
    }
}

/** Короткая инструкция по папкам: открывается по значку «?» в «Любимых». */
@Composable
private fun FolderHelpDialog(onClose: () -> Unit) {
    val p = LocalPalette.current
    KomojeDialog(onClose = onClose) {
        Text(
            stringResource(R.string.folder_help_title),
            color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 18.sp,
        )
        Spacer(Modifier.height(10.dp))
        Text(
            stringResource(R.string.folder_help_body),
            color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 15.sp,
            lineHeight = 21.sp,
        )
        Spacer(Modifier.height(16.dp))
        DialogButton(
            label = stringResource(R.string.folder_help_ok),
            filled = true,
            modifier = Modifier.fillMaxWidth(),
            onClick = onClose,
        )
    }
}

@Composable
private fun ConfirmDialog(
    title: String,
    message: String,
    confirm: String,
    onConfirm: () -> Unit,
    onClose: () -> Unit,
) {
    val p = LocalPalette.current
    KomojeDialog(onClose = onClose) {
        Text(
            title,
            color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 18.sp,
            textAlign = TextAlign.Start,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            message,
            color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 15.sp,
        )
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DialogButton(
                label = stringResource(R.string.folder_cancel),
                filled = false,
                modifier = Modifier.weight(1f),
                onClick = onClose,
            )
            DialogButton(label = confirm, filled = true, modifier = Modifier.weight(1f), onClick = onConfirm)
        }
    }
}
