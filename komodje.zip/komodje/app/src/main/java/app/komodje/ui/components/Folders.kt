// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.zIndex
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import java.io.File
import app.komodje.data.Backup
import androidx.core.content.FileProvider
import android.content.Intent
import android.content.Context
import android.content.ClipData
import kotlinx.coroutines.launch
import app.komodje.KomodjeApp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.komodje.R
import app.komodje.data.FoldersStore
import app.komodje.domain.FOLDER_BLANK_1
import app.komodje.domain.FOLDER_BLANK_2
import app.komodje.domain.FOLDER_CONGRATS
import app.komodje.domain.Folder
import app.komodje.ui.theme.LeafShape
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.Onest
import app.komodje.ui.theme.accentBrush
import app.komodje.ui.theme.cardBrush

/** Что можно делать с папками. Передаётся в панель только в приложении (в клавиатуре папок нет). */
class FolderActions(
    val onOpen: (String) -> Unit,
    val onCreate: (String) -> Unit,
    val onRename: (String, String) -> Unit,
    val onDelete: (String) -> Unit,
    val onReorder: (List<String>) -> Unit,
)

/**
 * Название папки: пока человек не дал своё, берётся из строк на языке интерфейса
 * («Поздравления» или «Папка без названия»).
 */
@Composable
fun folderTitle(folder: Folder): String = folder.name ?: when (folder.id) {
    FOLDER_CONGRATS -> stringResource(R.string.folder_congrats)
    FOLDER_BLANK_1, FOLDER_BLANK_2 -> stringResource(R.string.folder_untitled)
    else -> stringResource(R.string.folder_untitled)
}

private val ButtonShape = RoundedCornerShape(topStart = 18.dp, topEnd = 8.dp, bottomEnd = 18.dp, bottomStart = 8.dp)

/** Высота папки вместе с язычком, без «подложки», и высота самой подложки (объём). */
private val FolderBodyHeight = 86.dp
private val FolderTabHeight = 14.dp
private val FolderDepth = 5.dp

/** Меню папки: какая папка и где она на экране. */
private class FolderMenu(val folder: Folder, val anchor: Rect)

/**
 * Нижняя полоса раздела «Любимые». Сверху справа всегда видна кнопка «+», слева значок «?» с подсказкой.
 * Ниже папки с шириной по названию; ряд можно прокручивать по горизонтали.
 * Тап по папке открывает её, повторный тап закрывает. Удержал и отпустил: меню «Переименовать / Удалить»
 * рядом с папкой. Удержал и потащил влево-вправо: папка встаёт на новое место.
 */
@Composable
fun FolderStrip(
    folders: List<Folder>,
    openId: String?,
    actions: FolderActions,
    modifier: Modifier = Modifier,
    /** Когда тянут карточку: ряд сообщает границы папок и подсвечивает ту, над которой палец. */
    drag: CardDragState? = null,
) {
    var creating by remember { mutableStateOf(false) }
    var help by remember { mutableStateOf(false) }
    // «?» исчезает навсегда только после кнопки «Понятно». Закрытие тапом мимо диалога его не убирает.
    val settings = (LocalContext.current.applicationContext as KomodjeApp).container.settings
    val helpDone by settings.folderHelpDone.collectAsStateWithLifecycle()
    val helpScope = rememberCoroutineScope()
    var menu by remember { mutableStateOf<FolderMenu?>(null) }
    var renaming by remember { mutableStateOf<Folder?>(null) }
    var deleting by remember { mutableStateOf<Folder?>(null) }

    Column(modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 14.dp, end = 14.dp, top = 2.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (!helpDone) HelpBubble(onClick = { help = true }, pulse = true)
            Spacer(Modifier.weight(1f))
            AddFolderButton(onClick = { creating = true })
        }

        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val sidePad = 20.dp
            val gap = 8.dp
            val listState = rememberLazyListState()
            val textMeasurer = rememberTextMeasurer()
            val density = LocalDensity.current
            val labelStyle = remember { TextStyle(fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 15.sp) }
            fun itemWidth(title: String): Dp {
                val words = title.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
                val textWidth = words.maxOfOrNull { textMeasurer.measure(it, labelStyle, maxLines = 1, softWrap = false).size.width } ?: 0
                return with(density) { textWidth.toDp() + 28.dp }.coerceAtLeast(100.dp).coerceAtMost((maxWidth - sidePad * 2).coerceAtLeast(100.dp))
            }
            // Порядок на время перетаскивания живёт здесь, в хранилище уходит один раз, когда отпустили.
            var order by remember { mutableStateOf(folders.map { it.id }) }
            var draggingId by remember { mutableStateOf<String?>(null) }
            var dragDx by remember { mutableFloatStateOf(0f) }
            var totalMove by remember { mutableFloatStateOf(0f) }
            val dragScope = rememberCoroutineScope()
            val slop = with(LocalDensity.current) { 8.dp.toPx() }
            val edge = with(LocalDensity.current) { 36.dp.toPx() }
            LaunchedEffect(folders) { if (draggingId == null) order = folders.map { it.id } }
            val shown = remember(order, folders) {
                order.mapNotNull { id -> folders.firstOrNull { it.id == id } } + folders.filter { it.id !in order }
            }

            // Если палец протащил папку за центр соседа, меняем их местами. Папка остаётся под пальцем:
            // сдвиг в ряду компенсируем смещением перетаскивания.
            fun checkSwap() {
                val id = draggingId ?: return
                val info = listState.layoutInfo.visibleItemsInfo
                val cur = info.firstOrNull { it.key == id } ?: return
                val center = cur.offset + cur.size / 2f + dragDx
                val target = info.firstOrNull {
                    it.key != id && center >= it.offset && center <= it.offset + it.size
                } ?: return
                val from = order.indexOf(id)
                val to = order.indexOf(target.key as String)
                if (from < 0 || to < 0 || from == to) return
                order = order.toMutableList().apply { add(to, removeAt(from)) }
                dragDx -= (target.offset - cur.offset)
            }

            // У края экрана ряд сам подкручивается, пока палец там.
            LaunchedEffect(draggingId) {
                while (draggingId != null) {
                    val id = draggingId
                    val cur = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.key == id }
                    if (cur != null) {
                        val left = cur.offset + dragDx
                        val right = left + cur.size
                        val viewport = listState.layoutInfo.viewportEndOffset
                        val step = when {
                            left < edge -> -10f
                            right > viewport - edge -> 10f
                            else -> 0f
                        }
                        if (step != 0f) {
                            val used = listState.scrollBy(step)
                            dragDx += used
                            checkSwap()
                        }
                    }
                    kotlinx.coroutines.delay(16)
                }
            }

            LazyRow(
                state = listState,
                userScrollEnabled = draggingId == null,
                contentPadding = PaddingValues(start = sidePad, end = sidePad, top = 16.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(gap),
            ) {
                items(shown, key = { it.id }) { f ->
                    val dragging = draggingId == f.id
                    // Карточка в руке над этой папкой: папка плавно приподнимается и вырастает.
                    val hoverAnim by animateFloatAsState(
                        targetValue = if (drag != null && drag.hover == f.id) 1f else 0f,
                        animationSpec = spring(dampingRatio = 0.55f, stiffness = 520f),
                        label = "folderHover",
                    )
                    // Карточка упала внутрь: папка коротко «проседает» и пружинит обратно.
                    val landBounce = remember(f.id) { Animatable(1f) }
                    val seenLand = remember { intArrayOf(drag?.landedTick ?: 0) }
                    LaunchedEffect(drag?.landedTick) {
                        val d = drag ?: return@LaunchedEffect
                        if (d.landedTick != seenLand[0]) {
                            seenLand[0] = d.landedTick
                            if (d.landed == f.id) {
                                landBounce.snapTo(0.9f)
                                landBounce.animateTo(1f, spring(dampingRatio = 0.35f, stiffness = 480f))
                            }
                        }
                    }
                    FolderCard(
                        folder = f,
                        selected = f.id == openId,
                        width = itemWidth(folderTitle(f)),
                        dragging = dragging,
                        dragOffset = { if (dragging) dragDx else 0f },
                        // Соседи плавно расступаются; саму тянущуюся папку не анимируем, она идёт за пальцем.
                        modifier = (if (dragging) Modifier.zIndex(1f) else Modifier.animateItem())
                            .then(
                                if (drag == null) Modifier else Modifier
                                    .onGloballyPositioned { drag.rects[f.id] = it.boundsInRoot() }
                                    .graphicsLayer {
                                        val s = (1f + 0.09f * hoverAnim) * landBounce.value
                                        scaleX = s
                                        scaleY = s
                                        translationY = -6.dp.toPx() * hoverAnim
                                    },
                            ),
                        onClick = { actions.onOpen(f.id) },
                        onDragStart = { anchor ->
                            draggingId = f.id
                            dragDx = 0f
                            totalMove = 0f
                            // Как на рабочем столе Android: папка подпрыгнула, и меню сразу рядом с ней.
                            menu = FolderMenu(f, anchor)
                        },
                        onDrag = { dx ->
                            totalMove += kotlin.math.abs(dx)
                            dragDx += dx
                            // Потащили: меню прячется, папка едет за пальцем.
                            if (totalMove >= slop && menu != null) menu = null
                            checkSwap()
                        },
                        onDragEnd = { anchor ->
                            if (anchor == null) {
                                // Жест прервала система: ничего не меняем и меню убираем.
                                draggingId = null
                                dragDx = 0f
                                menu = null
                            } else if (totalMove < slop) {
                                // Удержал и отпустил на месте: меню уже открыто, папка опускается обратно.
                                draggingId = null
                                dragDx = 0f
                            } else {
                                dragScope.launch {
                                    Animatable(dragDx).animateTo(0f, spring(dampingRatio = 0.75f, stiffness = 380f)) {
                                        dragDx = value
                                    }
                                    draggingId = null
                                    if (order != folders.map { it.id }) actions.onReorder(order)
                                }
                            }
                        },
                    )
                }
            }
        }
    }

    if (creating) {
        FolderNameDialog(
            title = stringResource(R.string.folder_new_title),
            initial = "",
            confirmLabel = stringResource(R.string.folder_create),
            onConfirm = {
                actions.onCreate(it)
                creating = false
            },
            onClose = { creating = false },
        )
    }
    if (help) {
        FolderHelpDialog(
            onClose = { help = false },
            onUnderstood = {
                help = false
                helpScope.launch { settings.markFolderHelpDone() }
            },
        )
    }

    val shareContext = LocalContext.current
    menu?.let { m ->
        val shareTitle = folderTitle(m.folder)
        AnchoredMenu(anchor = m.anchor, onClose = { menu = null }, preferAbove = true, compact = true, gap = 52.dp) {
            MenuItem(
                label = stringResource(R.string.folder_rename),
                trailing = KomojeIcons.Edit,
                compact = true,
                onClick = {
                    renaming = m.folder
                    menu = null
                },
            )
            MenuDivider()
            MenuItem(
                label = stringResource(R.string.folder_share),
                trailing = KomojeIcons.Send,
                compact = true,
                onClick = {
                    shareFolder(shareContext, shareTitle, m.folder.items)
                    menu = null
                },
            )
            MenuDivider()
            MenuItem(
                label = stringResource(R.string.folder_delete),
                danger = true,
                trailing = KomojeIcons.Trash,
                compact = true,
                onClick = {
                    deleting = m.folder
                    menu = null
                },
            )
        }
    }
    renaming?.let { f ->
        FolderNameDialog(
            title = stringResource(R.string.folder_rename_title),
            initial = f.name ?: folderTitle(f),
            confirmLabel = stringResource(R.string.folder_save),
            onConfirm = {
                actions.onRename(f.id, it)
                renaming = null
            },
            onClose = { renaming = null },
        )
    }
    deleting?.let { f ->
        ConfirmDialog(
            title = folderTitle(f),
            message = stringResource(R.string.folder_delete_q),
            confirm = stringResource(R.string.folder_delete),
            onConfirm = {
                actions.onDelete(f.id)
                deleting = null
            },
            onClose = { deleting = null },
        )
    }
}

/**
 * Контур папки: прямоугольник с «листовыми» углами (большие по диагонали, маленькие по другой)
 * и язычком сверху справа. Высота [h] считается от верха язычка до низа.
 */
private fun folderPath(w: Float, h: Float, tabH: Float, tabW: Float, slope: Float, big: Float, small: Float): Path {
    val path = Path()
    val xb = w - tabW          // где язычок выходит на полную высоту
    val xa = xb - slope        // где начинается подъём к язычку

    path.moveTo(0f, tabH + big)
    // Верхний левый (большой) угол: управляющая точка в углу, кубическая форма вместо квадратичной.
    path.cubicTo(0f, tabH + big / 3f, big / 3f, tabH, big, tabH)
    path.lineTo(xa, tabH)
    // Плавный подъём на язычок.
    path.cubicTo(xa + slope * 0.5f, tabH, xb - slope * 0.5f, 0f, xb, 0f)
    path.lineTo(w - small, 0f)
    // Верхний правый (маленький) угол: это угол язычка.
    path.cubicTo(w - small / 3f, 0f, w, small / 3f, w, small)
    path.lineTo(w, h - big)
    // Нижний правый (большой).
    path.cubicTo(w, h - big / 3f, w - big / 3f, h, w - big, h)
    path.lineTo(small, h)
    // Нижний левый (маленький).
    path.cubicTo(small / 3f, h, 0f, h - small / 3f, 0f, h - small)
    path.close()
    return path
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FolderCard(
    folder: Folder,
    selected: Boolean,
    width: Dp,
    dragging: Boolean,
    dragOffset: () -> Float,
    onClick: () -> Unit,
    onDragStart: (Rect) -> Unit,
    onDrag: (Float) -> Unit,
    onDragEnd: (Rect?) -> Unit,
    modifier: Modifier = Modifier,
) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val buzz = rememberBuzz()
    val view = LocalView.current
    val interaction = remember { MutableInteractionSource() }
    val coords = remember { arrayOfNulls<LayoutCoordinates>(1) }
    val selectedFill = remember(p) { p.accentBrush() }
    val cardFill = remember(p) { p.cardBrush() }
    // Подложка: тёмный вариант акцентного цвета, видна снизу как толщина папки.
    val backColor = remember(p) { lerp(p.accentDeep, Color.Black, 0.45f) }
    val sel by animateFloatAsState(
        targetValue = if (selected) 1f else 0f,
        animationSpec = tween(240),
        label = "folderSel",
    )
    // Поднятие при захвате: пружинка с отскоком («подпрыгивает») и короткая дрожь.
    val lift by animateFloatAsState(
        targetValue = if (dragging) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.45f, stiffness = 520f),
        label = "folderLift",
    )
    val shake = remember { Animatable(0f) }
    LaunchedEffect(dragging) {
        if (dragging) {
            repeat(3) {
                shake.animateTo(2.2f, tween(45))
                shake.animateTo(-2.2f, tween(90))
            }
            shake.animateTo(0f, tween(45))
        } else {
            shake.snapTo(0f)
        }
    }
    // Нажатия сразу после перетаскивания игнорируем: иначе отпускание открыло бы папку.
    var ignoreClickUntil by remember { mutableLongStateOf(0L) }
    val onDragStartState by rememberUpdatedState(onDragStart)
    val onDragState by rememberUpdatedState(onDrag)
    val onDragEndState by rememberUpdatedState(onDragEnd)
    Box(
        modifier
            .animateContentSize(animationSpec = tween(240))
            .width(width)
            .height(FolderBodyHeight + FolderDepth)
            .graphicsLayer {
                translationX = dragOffset()
                translationY = -10.dp.toPx() * lift
                val sc = 1f + 0.08f * lift
                scaleX = sc
                scaleY = sc
                rotationZ = shake.value
            }
            .onGloballyPositioned { coords[0] = it }
            .pressScale(interaction)
            .drawBehind {
                val depth = FolderDepth.toPx()
                val path = folderPath(
                    w = size.width,
                    h = size.height - depth,
                    tabH = FolderTabHeight.toPx(),
                    tabW = size.width * 0.42f,
                    slope = 12.dp.toPx(),
                    big = 20.dp.toPx(),
                    small = 9.dp.toPx(),
                )
                translate(left = 0f, top = depth) { drawPath(path, backColor) }
                drawPath(path, cardFill)
                drawPath(path, selectedFill, alpha = sel)
                drawPath(path, Color.White.copy(alpha = 0.14f), style = Stroke(width = 1.dp.toPx()))
            }
            .combinedClickable(
                interactionSource = interaction,
                indication = null,
                onClick = {
                    if (System.nanoTime() < ignoreClickUntil) return@combinedClickable
                    tick()
                    onClick()
                },
            )
            .pointerInput(folder.id) {
                detectDragGesturesAfterLongPress(
                    onDragStart = {
                        buzz()
                        onDragStartState(coords[0]?.screenBounds(view) ?: Rect.Zero)
                    },
                    onDrag = { change, amount ->
                        change.consume()
                        onDragState(amount.x)
                    },
                    onDragEnd = {
                        ignoreClickUntil = System.nanoTime() + 250_000_000L
                        onDragEndState(coords[0]?.screenBounds(view) ?: Rect.Zero)
                    },
                    onDragCancel = {
                        ignoreClickUntil = System.nanoTime() + 250_000_000L
                        onDragEndState(null)
                    },
                )
            }
            .padding(
                start = 12.dp,
                end = 10.dp,
                top = FolderTabHeight + 4.dp,
                bottom = FolderDepth + 4.dp,
            ),
        contentAlignment = Alignment.CenterStart,
    ) {
        Column(verticalArrangement = Arrangement.Center) {
            // Каждое слово на своей строке; размер шрифта постоянный, ширина рассчитана по длинному слову.
            FolderLabel(text = folderTitle(folder), color = lerp(p.ink, p.onAccent, sel))
            Spacer(Modifier.height(2.dp))
            Text(
                text = folder.items.size.toString(),
                color = lerp(p.muted, p.onAccent, sel),
                fontFamily = Onest,
                fontWeight = FontWeight.Medium,
                fontSize = 13.sp,
            )
        }
    }
}

/**
 * «+» той же формы и размера, что «?» слева, но сплошная заливка акцентным цветом и контрастный плюс:
 * «?» тихий, «+» зовёт к действию.
 */
@Composable
private fun AddFolderButton(onClick: () -> Unit) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val interaction = remember { MutableInteractionSource() }
    Box(
        Modifier
            .size(38.dp)
            .pressScale(interaction, pressedScale = 0.86f)
            .clip(BubbleShape)
            .background(p.accentDeep)
            .clickable(interactionSource = interaction, indication = null) {
                tick()
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        Icon(KomojeIcons.Plus, contentDescription = null, tint = p.onAccent, modifier = Modifier.size(22.dp))
    }
}

/** Общая оболочка окошек: лист на карточном фоне, как в инструкции по клавиатуре. */
@Composable
internal fun KomojeDialog(onClose: () -> Unit, content: @Composable () -> Unit) {
    val p = LocalPalette.current
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .padding(horizontal = 20.dp)
                .fillMaxWidth()
                .clip(LeafShape)
                .background(p.card)
                .padding(20.dp),
        ) { content() }
    }
}

@Composable
internal fun DialogButton(
    label: String,
    filled: Boolean,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    /** Залитая иконка слева от подписи (необязательна). */
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    onClick: () -> Unit,
) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val interaction = remember { MutableInteractionSource() }
    val fill = remember(p) { p.accentBrush() }
    Box(
        modifier
            .height(46.dp)
            .pressScale(interaction)
            .clip(ButtonShape)
            .background(p.ink.copy(alpha = 0.08f))
            .drawBehind { if (filled) drawRect(fill, alpha = if (enabled) 1f else 0.35f) }
            .clickable(interactionSource = interaction, indication = null, enabled = enabled) {
                tick()
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (filled) p.onAccent else p.ink,
                    modifier = Modifier.size(20.dp),
                )
                Spacer(Modifier.width(8.dp))
            }
            Text(
                text = label,
                color = if (filled) p.onAccent else p.ink,
                fontFamily = Onest,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                maxLines = 1,
            )
        }
    }
}

/** Окошко с полем названия: и для новой папки, и для переименования. */
@Composable
internal fun FolderNameDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    onConfirm: (String) -> Unit,
    onClose: () -> Unit,
    hint: Int = R.string.folder_name_hint,
    maxLength: Int = FoldersStore.MAX_NAME,
) {
    val p = LocalPalette.current
    var name by remember { mutableStateOf(initial) }
    KomojeDialog(onClose = onClose) {
        Text(
            title,
            color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 18.sp,
        )
        Spacer(Modifier.height(14.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .clip(ButtonShape)
                .background(p.ink.copy(alpha = 0.08f))
                .padding(horizontal = 16.dp, vertical = 14.dp),
        ) {
            if (name.isEmpty()) {
                Text(
                    stringResource(hint),
                    color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 17.sp,
                )
            }
            BasicTextField(
                value = name,
                onValueChange = { if (it.length <= maxLength) name = it },
                singleLine = true,
                textStyle = TextStyle(
                    color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 17.sp,
                ),
                cursorBrush = SolidColor(p.accentDeep),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { if (name.isNotBlank()) onConfirm(name) }),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DialogButton(
                label = stringResource(R.string.folder_cancel),
                filled = false,
                modifier = Modifier.weight(1f),
                onClick = onClose,
            )
            DialogButton(
                label = confirmLabel,
                filled = true,
                enabled = name.isNotBlank(),
                modifier = Modifier.weight(1f),
                onClick = { onConfirm(name) },
            )
        }
    }
}

/** Короткая инструкция по папкам: открывается по значку «?» в «Любимых». */
@Composable
private fun FolderHelpDialog(onClose: () -> Unit, onUnderstood: () -> Unit) {
    val p = LocalPalette.current
    KomojeDialog(onClose = onClose) {
        Text(
            stringResource(R.string.folder_help_title),
            color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 18.sp,
        )
        Spacer(Modifier.height(10.dp))
        Text(
            stringResource(R.string.folder_help_body),
            color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 15.sp,
            lineHeight = 21.sp,
        )
        Spacer(Modifier.height(16.dp))
        DialogButton(
            label = stringResource(R.string.folder_help_ok),
            filled = true,
            modifier = Modifier.fillMaxWidth(),
            onClick = onUnderstood,
        )
    }
}

@Composable
internal fun ConfirmDialog(
    title: String,
    message: String,
    confirm: String,
    onConfirm: () -> Unit,
    onClose: () -> Unit,
) {
    val p = LocalPalette.current
    KomojeDialog(onClose = onClose) {
        Text(
            title,
            color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 18.sp,
            textAlign = TextAlign.Start,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            message,
            color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 15.sp,
        )
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DialogButton(
                label = stringResource(R.string.folder_cancel),
                filled = false,
                modifier = Modifier.weight(1f),
                onClick = onClose,
            )
            DialogButton(label = confirm, filled = true, modifier = Modifier.weight(1f), onClick = onConfirm)
        }
    }
}

/** Название папки крупное, жирное, одинакового размера; каждое слово выводится с новой строки. */
@Composable
private fun FolderLabel(text: String, color: Color) {
    val words = remember(text) { text.trim().split(Regex("\\s+")).filter { it.isNotEmpty() } }
    val shown = words.joinToString("\n")
    Text(
        text = shown,
        color = color,
        fontFamily = Onest,
        fontWeight = FontWeight.Bold,
        fontSize = 15.sp,
        lineHeight = 18.sp,
        maxLines = words.size.coerceAtLeast(1),
        softWrap = false,
        overflow = TextOverflow.Clip,
        modifier = Modifier.fillMaxWidth(),
    )
}

/** Отправляет папку маленьким файлом .kaomoji: у друга он открывается в приложении и предлагает добавить папку. */
private fun shareFolder(context: Context, title: String, items: List<String>) {
    runCatching {
        val dir = File(context.cacheDir, "share").apply { mkdirs() }
        val safe = title.replace(Regex("[^\\p{L}\\p{N} _-]"), "").trim().ifEmpty { "folder" }
        val file = File(dir, "$safe.kaomoji")
        file.writeText(Backup.folderToJson(title, items))
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/octet-stream"
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri("", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(send, title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
