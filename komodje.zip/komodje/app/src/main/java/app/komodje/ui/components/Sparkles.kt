package app.komodje.ui.components

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** Одна вспышка звёздочек: точка старта в координатах окна и зерно для стабильного разброса. */
internal class Burst(val origin: Offset, val seed: Int)

/**
 * Шесть четырёхлучевых звёздочек веером вверх: летят, чуть вращаются и гаснут.
 * Только Canvas и один прогресс t от 0 до 1; никакой перекомпоновки.
 */
internal fun DrawScope.drawBurst(burst: Burst, t: Float, panelRoot: Offset, colors: List<Color>) {
    val rnd = Random(burst.seed)
    val ease = 1f - (1f - t) * (1f - t)
    val o = burst.origin - panelRoot
    for (i in 0 until 6) {
        val rad = Math.toRadians((-165f + i * 30f + rnd.nextFloat() * 14f).toDouble())
        val dist = (52f + rnd.nextFloat() * 46f) * density * ease
        val size = (5f + rnd.nextFloat() * 5f) * density * (1f - 0.55f * t)
        val spin = (if (i % 2 == 0) 1f else -1f) * 70f * t
        val c = Offset(
            o.x + (cos(rad) * dist).toFloat(),
            o.y + (sin(rad) * dist).toFloat() - 10f * density * ease,
        )
        rotate(spin, pivot = c) { drawSparkle(c, size, colors[i % colors.size], (1f - t * t).coerceIn(0f, 1f)) }
    }
}

/** Та же прогнутая четырёхлучевая звезда, что в бренде. */
internal fun DrawScope.drawSparkle(c: Offset, s: Float, color: Color, alpha: Float) {
    val k = 0.16f * s
    val path = Path().apply {
        moveTo(c.x, c.y - s)
        quadraticBezierTo(c.x + k, c.y - k, c.x + s, c.y)
        quadraticBezierTo(c.x + k, c.y + k, c.x, c.y + s)
        quadraticBezierTo(c.x - k, c.y + k, c.x - s, c.y)
        quadraticBezierTo(c.x - k, c.y - k, c.x, c.y - s)
        close()
    }
    drawPath(path, color, alpha = alpha)
}
