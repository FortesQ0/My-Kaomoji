package app.komodje.data

import android.content.Context
import app.komodje.domain.Komoji
import app.komodje.domain.Mood
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
internal data class LibraryDto(val categories: List<CategoryDto>)

@Serializable
internal data class CategoryDto(val mood: String, val items: List<String>)

class KomojiRepository(private val context: Context) {

    private val library: Map<Mood, List<Komoji>> by lazy {
        val raw = context.assets.open("komoji.json").bufferedReader().use { it.readText() }
        Json.decodeFromString<LibraryDto>(raw).categories
            .associate { Mood.valueOf(it.mood) to it.items.map(::Komoji) }
    }

    fun byMood(mood: Mood): List<Komoji> = library[mood].orEmpty()

    private val everything: List<Komoji> by lazy { library.values.flatten() }

    fun all(): List<Komoji> = everything
}
