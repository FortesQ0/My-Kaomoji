// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.data

import android.content.Context
import android.graphics.Paint
import app.komodje.domain.Komoji
import app.komodje.domain.Feel
import app.komodje.domain.Mood
import app.komodje.domain.PICK_COUNT
import app.komodje.domain.dailyPicks
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.util.concurrent.ConcurrentHashMap

@Serializable
internal data class LibraryDto(val categories: List<CategoryDto>)

/** flags идёт параллельно items: бит 1 = эффекты снаружи, бит 2 = два и более персонажей. */
@Serializable
internal data class CategoryDto(val mood: String, val items: List<String>, val flags: List<Int> = emptyList())

class KomojiRepository(private val context: Context) {

    /** Reuse the text-only view instead of rebuilding it for every favorites/keyboard refresh. */
    private val allTexts: List<String> by lazy(LazyThreadSafetyMode.PUBLICATION) {
        everything.map { it.text }
    }

    /** Normalize each searched text only once; subsequent keystrokes reuse the cached value. */
    private val normalizedSearchText = ConcurrentHashMap<String, String>()

    private fun normalizeSearchText(value: String): String = buildString(value.length) {
        value.forEach { if (!it.isWhitespace()) append(it) }
    }

    private val library: Map<Mood, List<Komoji>> by lazy {
        val raw = context.assets.open("komoji.json").bufferedReader().use { it.readText() }
        val full: Map<Mood, List<Komoji>> = Json.decodeFromString<LibraryDto>(raw).categories
            .associate { c ->
                Mood.valueOf(c.mood) to c.items.mapIndexed { i, text -> Komoji(text, c.flags.getOrElse(i) { -1 }) }
            }

        // Прячем те каомодзи, символы которых этот телефон не умеет рисовать: иначе рот или глаз
        // пропадает и лицо выглядит сломанным. Проверка идёт по реальным шрифтам устройства.
        val paint = Paint()
        val known = HashMap<Int, Boolean>()
        fun drawable(text: String): Boolean {
            var i = 0
            while (i < text.length) {
                val cp = text.codePointAt(i)
                i += Character.charCount(cp)
                if (cp <= 0x7F) continue
                val ok = known.getOrPut(cp) { paint.hasGlyph(String(Character.toChars(cp))) }
                if (!ok) return false
            }
            return true
        }

        val shown = full.mapValues { (_, list) -> list.filter { drawable(it.text) } }
        val total = full.values.sumOf { it.size }
        // Страховка: если проверка вдруг отсекла почти всё (нестандартная оболочка), показываем как есть.
        if (shown.values.sumOf { it.size } * 10 < total * 3) full else shown
    }

    private val everything: List<Komoji> by lazy { library.values.flatten() }

    private val index: Map<String, Komoji> by lazy { everything.associateBy { it.text } }

    fun byMood(mood: Mood): List<Komoji> = library[mood].orEmpty()

    fun all(): List<Komoji> = everything

    fun allTexts(): List<String> = allTexts

    fun normalizeSearchQuery(query: String): String = normalizeSearchText(query)

    fun matchesSearch(text: String, normalizedQuery: String): Boolean =
        normalizedSearchText.computeIfAbsent(text, ::normalizeSearchText)
            .contains(normalizedQuery, ignoreCase = true)

    /** Настроение каомодзи из библиотеки по тексту (для поиска по смыслу). */
    private val moodIndex: Map<String, Mood> by lazy {
        HashMap<String, Mood>().also { m -> library.forEach { (mood, list) -> list.forEach { m[it.text] = mood } } }
    }

    fun moodOf(text: String): Mood? = moodIndex[text]

    /**
     * Поиск в наборе [pool]: сначала совпадения по самим символам, затем по смыслу слова
     * («ура», «злюсь», «thanks», «ありがとう»). Подходящие по значкам идут выше остальных.
     */
    fun search(pool: List<Komoji>, normalizedQuery: String, rawQuery: String): List<Komoji> {
        val direct = pool.filter { matchesSearch(it.text, normalizedQuery) }
        val feels = Feel.forQuery(rawQuery)
        if (feels.isEmpty()) return direct
        val seen = HashSet<String>(direct.size * 2 + 16)
        direct.forEach { seen.add(it.text) }
        val ranked = ArrayList<Komoji>()
        val rest = ArrayList<Komoji>()
        for (feel in feels) {
            val inMood = pool.filter { feel.acceptsMood(moodOf(it.text)) }
            val withGlyph = inMood.filter { feel.glyphMatches(it.text) }
            for (k in withGlyph) if (seen.add(k.text)) ranked.add(k)
            if (!feel.onlyWithGlyph || withGlyph.isEmpty()) {
                for (k in inMood) if (seen.add(k.text)) rest.add(k)
            }
        }
        return direct + ranked + rest
    }

    /**
     * «Хиты дня» в праздничный день: половина подборки по теме праздника, остальное как обычно.
     * Если подходящих каомодзи мало, возвращает null, и берётся обычная подборка.
     */
    fun holidayPicks(items: List<Komoji>, feel: Feel, day: Long): List<String>? {
        val themed = items.filter { feel.acceptsMood(moodOf(it.text)) && feel.glyphMatches(it.text) }.map { it.text }
        if (themed.size < 12) return null
        val head = dailyPicks(themed, day, PICK_COUNT / 2)
        if (head.isEmpty()) return null
        val taken = head.toSet()
        val tail = dailyPicks(items.map { it.text }.filter { it !in taken }, day, PICK_COUNT - head.size)
        return head + tail
    }

    /** Каомодзи по тексту: из библиотеки (с разметкой) или просто обёртка, если такого в библиотеке нет. */
    fun komoji(text: String): Komoji = index[text] ?: Komoji(text)
}
