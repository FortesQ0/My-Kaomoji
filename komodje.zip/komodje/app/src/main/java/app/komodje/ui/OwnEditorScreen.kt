package app.komodje.ui

import android.graphics.Paint
import android.widget.Toast
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.komodje.R
import app.komodje.domain.Part
import app.komodje.domain.assemble
import app.komodje.domain.decodeBuilder
import app.komodje.domain.encodeBuilder
import app.komodje.domain.optionsFor
import app.komodje.domain.syncMirror
import app.komodje.domain.withChoice
import app.komodje.ui.components.Burst
import app.komodje.ui.components.DialogButton
import app.komodje.ui.components.FilterTab
import app.komodje.ui.components.FolderNameDialog
import app.komodje.ui.components.KomojeIcons
import app.komodje.ui.components.TabShape
import app.komodje.ui.components.drawBurst
import app.komodje.ui.components.pressScale
import app.komodje.ui.components.rememberTick
import app.komodje.ui.components.softShadow
import app.komodje.ui.theme.LeafShape
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.Onest
import app.komodje.ui.theme.accentBrush
import app.komodje.ui.theme.cardBrush
import kotlin.random.Random

private const val COLUMNS = 6
private const val COLLAPSED_TILES = COLUMNS * 2

/** Сколько шагов назад помним, и разделитель записей в сохраняемой строке истории. */
private const val MAX_HISTORY = 60
private const val HISTORY_SEP = "\u0001"
/** Ширина, начиная с которой в верхней строке хватает места на подпись «Ввести вручную». */
private val ROOMY_WIDTH = 460.dp

private val TileShape = RoundedCornerShape(topStart = 14.dp, topEnd = 6.dp, bottomEnd = 14.dp, bottomStart = 6.dp)

/** Какие символы устройство умеет рисовать (кэш, чтобы не проверять каждый раз). */
private val glyphCache = HashMap<String, Boolean>()

private fun renderable(options: List<String>): List<String> {
    val paint = Paint()
    val ok = options.filter { glyphCache.getOrPut(it) { paint.hasGlyph(it) } }
    // Если телефон не умеет почти ничего, лучше показать всё, чем пустую сетку.
    return if (ok.size * 2 >= options.size) ok else options
}

private fun partIcon(part: Part) = when (part) {
    Part.MOUTH -> KomojeIcons.PartMouth
    Part.EYE -> KomojeIcons.PartEye
    Part.CHEEK -> KomojeIcons.PartCheek
    Part.OUTLINE -> KomojeIcons.PartOutline
    Part.HAND -> KomojeIcons.PartHand
    Part.EFFECT -> KomojeIcons.Sparkle
}

private fun partLabel(part: Part): Int = when (part) {
    Part.HAND -> R.string.part_hand
    Part.OUTLINE -> R.string.part_outline
    Part.CHEEK -> R.string.part_cheek
    Part.EYE -> R.string.part_eye
    Part.MOUTH -> R.string.part_mouth
    Part.EFFECT -> R.string.part_effect
}

/**
 * Конструктор «Создать свой смайлик»: превью, «Копировать / Сохранить», вкладки частей,
 * сетка готовых символов. Левая сторона по умолчанию зеркалится на правую.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OwnEditorScreen(vm: HomeViewModel, onClose: () -> Unit) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    val state by vm.state.collectAsStateWithLifecycle()

    var encoded by rememberSaveable { mutableStateOf("") }
    var mirror by rememberSaveable { mutableStateOf(true) }
    var partName by rememberSaveable { mutableStateOf(Part.EYE.name) }
    var rightSide by rememberSaveable { mutableStateOf(false) }
    var expanded by rememberSaveable { mutableStateOf(false) }
    var manual by rememberSaveable { mutableStateOf<String?>(null) }
    // Ручная правка превью: тап по окошку. Меняет только превью и сбрасывается при выборе любого символа.
    var previewOverride by rememberSaveable { mutableStateOf<String?>(null) }
    var editingPreview by rememberSaveable { mutableStateOf(false) }

    // История шагов для кнопки «назад»: каждая запись это прежнее состояние сборки.
    var historyRaw by rememberSaveable { mutableStateOf("") }
    val history = remember(historyRaw) {
        if (historyRaw.isEmpty()) emptyList() else historyRaw.substring(1).split(HISTORY_SEP)
    }

    /** Любое изменение сборки идёт через неё: прежнее состояние уходит в историю. */
    fun commit(next: String) {
        if (next == encoded) return
        historyRaw = (history + encoded).takeLast(MAX_HISTORY).joinToString("") { HISTORY_SEP + it }
        encoded = next
    }

    val values = remember(encoded) { decodeBuilder(encoded) }
    val built = remember(values) { assemble(values) }
    val text = previewOverride ?: built
    LaunchedEffect(encoded) { previewOverride = null }
    val part = runCatching { Part.valueOf(partName) }.getOrDefault(Part.EYE)
    val slot = part.right?.takeIf { !mirror && rightSide } ?: part.left
    val options = remember(slot) { renderable(optionsFor(slot)) }

    val cardFill = remember(p) { p.cardBrush() }
    val savedMsg = stringResource(R.string.own_saved)
    val existsMsg = stringResource(R.string.own_exists)
    val longMsg = stringResource(R.string.own_too_long)

    val canUndo = previewOverride != null || history.isNotEmpty()

    /** Шаг назад: сначала снимает ручную правку превью, затем откатывает последнюю смену символа. */
    fun undo() {
        if (previewOverride != null) {
            previewOverride = null
        } else if (history.isNotEmpty()) {
            encoded = history.last()
            historyRaw = history.dropLast(1).joinToString("") { HISTORY_SEP + it }
        }
    }

    fun save(raw: String, onSaved: () -> Unit) {
        if (raw.length > HomeViewModel.MAX_OWN) {
            Toast.makeText(ctx, longMsg, Toast.LENGTH_SHORT).show()
            return
        }
        vm.addOwn(raw) { added ->
            Toast.makeText(ctx, if (added) savedMsg else existsMsg, Toast.LENGTH_SHORT).show()
            if (added) onSaved()
        }
    }

    // Звёздочки при копировании, как у карточки.
    var burst by remember { mutableStateOf<Burst?>(null) }
    val burstProgress = remember { Animatable(1f) }
    LaunchedEffect(burst) {
        if (burst != null) {
            burstProgress.snapTo(0f)
            burstProgress.animateTo(1f, tween(1200, easing = LinearOutSlowInEasing))
        }
    }
    val root = remember { floatArrayOf(0f, 0f) }
    val copyCoords = remember { arrayOfNulls<LayoutCoordinates>(1) }
    val sparkColors = remember(p) { listOf(p.heart, p.accentDeep, p.accent) }

    Box(
        Modifier
            .fillMaxSize()
            .onGloballyPositioned {
                val o = it.positionInRoot()
                root[0] = o.x
                root[1] = o.y
            },
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // Заголовок: назад, название и справа «шаг назад», «Ввести вручную», «Сбросить».
            // На узком экране «Ввести вручную» сжимается до карандаша (как «Создать свой» в папке).
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                val roomy = maxWidth >= ROOMY_WIDTH
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LeafButton(onClick = onClose) {
                        Icon(KomojeIcons.Back, contentDescription = stringResource(R.string.back), tint = p.onBadge, modifier = Modifier.size(22.dp))
                    }
                    Spacer(Modifier.size(10.dp))
                    Text(
                        stringResource(R.string.editor_title),
                        color = p.ink,
                        fontFamily = Onest,
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    HeaderPlaque(
                        icon = KomojeIcons.Undo,
                        label = null,
                        description = stringResource(R.string.ed_undo),
                        enabled = canUndo,
                        onClick = { undo() },
                    )
                    Spacer(Modifier.width(6.dp))
                    HeaderPlaque(
                        icon = KomojeIcons.Edit,
                        label = if (roomy) stringResource(R.string.ed_manual) else null,
                        description = stringResource(R.string.ed_manual),
                        onClick = { manual = "" },
                    )
                    Spacer(Modifier.width(6.dp))
                    FilterTab(
                        label = stringResource(R.string.ed_reset),
                        icon = null,
                        selected = false,
                        onClick = { commit(""); previewOverride = null },
                    )
                }
            }

            // Большое превью.
            Box(
                Modifier
                    .fillMaxWidth()
                    .heightIn(min = 130.dp)
                    .clip(LeafShape)
                    .background(cardFill)
                    .clickable { editingPreview = true }
                    .padding(20.dp),
                contentAlignment = Alignment.Center,
            ) {
                if (text.isEmpty()) {
                    Text(
                        stringResource(R.string.ed_empty),
                        color = p.muted,
                        fontFamily = Onest,
                        fontWeight = FontWeight.Medium,
                        fontSize = 16.sp,
                        textAlign = TextAlign.Center,
                    )
                } else {
                    val size = when {
                        text.length <= 12 -> 40
                        text.length <= 20 -> 32
                        else -> 26
                    }
                    Text(
                        text,
                        color = p.ink,
                        fontSize = size.sp,
                        lineHeight = (size + 8).sp,
                        textAlign = TextAlign.Center,
                        maxLines = 2,
                    )
                }
            }

            // Копировать / Сохранить.
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                DialogButton(
                    label = stringResource(R.string.ed_copy),
                    filled = false,
                    enabled = text.isNotEmpty(),
                    modifier = Modifier
                        .weight(1f)
                        .onGloballyPositioned { copyCoords[0] = it },
                    onClick = {
                        copyToClipboard(ctx, text)
                        copyCoords[0]?.let { c ->
                            val pos = c.positionInRoot()
                            burst = Burst(Offset(pos.x + c.size.width / 2f, pos.y), Random.nextInt())
                        }
                    },
                )
                DialogButton(
                    label = stringResource(R.string.ed_save),
                    filled = true,
                    enabled = text.isNotEmpty(),
                    modifier = Modifier.weight(1f),
                    onClick = { save(text) { encoded = ""; historyRaw = ""; previewOverride = null } },
                )
            }

            FadeDivider()

            // Зеркало (и в ручном режиме выбор стороны) стоит выше частей, отдельно от них.
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                FilterTab(
                    label = stringResource(R.string.ed_mirror),
                    icon = KomojeIcons.Mirror,
                    selected = mirror,
                    onClick = {
                        mirror = !mirror
                        if (mirror) commit(encodeBuilder(syncMirror(values)))
                    },
                )
                if (!mirror && part.right != null) {
                    FilterTab(
                        label = stringResource(R.string.ed_left),
                        icon = null,
                        selected = !rightSide,
                        onClick = { rightSide = false; expanded = false },
                    )
                    FilterTab(
                        label = stringResource(R.string.ed_right),
                        icon = null,
                        selected = rightSide,
                        onClick = { rightSide = true; expanded = false },
                    )
                }
            }

            FadeDivider()

            // Части: чипы в два ряда.
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Part.entries.forEach { entry ->
                    FilterTab(
                        label = stringResource(partLabel(entry)),
                        icon = partIcon(entry),
                        selected = entry == part,
                        onClick = {
                            partName = entry.name
                            expanded = false
                        },
                    )
                }
            }

            FadeDivider()

            // Сетка символов выбранной части; первая плитка «нет».
            val tiles: List<String?> = listOf<String?>(null) + options
            val shown = if (expanded) tiles else tiles.take(COLLAPSED_TILES)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                shown.chunked(COLUMNS).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { symbol ->
                            SymbolTile(
                                symbol = symbol,
                                selected = if (symbol == null) values[slot] == null else values[slot] == symbol,
                                modifier = Modifier.weight(1f),
                                onClick = {
                                    val current = values[slot]
                                    val choice = if (symbol == null || symbol == current) null else symbol
                                    commit(encodeBuilder(withChoice(values, slot, choice, mirror)))
                                },
                            )
                        }
                        repeat(COLUMNS - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
            if (tiles.size > COLLAPSED_TILES) {
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    FilterTab(
                        label = stringResource(if (expanded) R.string.ed_less else R.string.ed_more),
                        icon = if (expanded) null else KomojeIcons.ChevronDown,
                        selected = false,
                        onClick = { expanded = !expanded },
                    )
                }
            }

            // Начать с любимых и ручной ввод.
            val favorites = remember(state.favorites) { state.favorites.toList().take(20) }
            if (favorites.isNotEmpty()) {
                FadeDivider()
                Text(
                    stringResource(R.string.ed_from_fav),
                    color = p.muted,
                    fontFamily = Onest,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                )
                LazyRow(
                    contentPadding = PaddingValues(end = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    items(favorites, key = { it }) { fav ->
                        FavoriteChip(fav) { manual = fav }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }

        Canvas(Modifier.fillMaxSize()) {
            val b = burst
            val t = burstProgress.value
            if (b != null && t < 1f) drawBurst(b, t, Offset(root[0], root[1]), sparkColors)
        }
    }

    if (editingPreview) {
        FolderNameDialog(
            title = stringResource(R.string.editor_title),
            initial = text,
            confirmLabel = stringResource(R.string.ed_apply),
            hint = R.string.own_hint,
            maxLength = HomeViewModel.MAX_OWN,
            onConfirm = { typed ->
                previewOverride = typed.replace('\n', ' ').trim().ifEmpty { null }
                editingPreview = false
            },
            onClose = { editingPreview = false },
        )
    }

    manual?.let { initial ->
        FolderNameDialog(
            title = stringResource(R.string.own_title),
            initial = initial,
            confirmLabel = stringResource(R.string.own_add),
            hint = R.string.own_hint,
            maxLength = HomeViewModel.MAX_OWN,
            onConfirm = { typed ->
                save(typed.replace('\n', ' ').trim()) { }
                manual = null
            },
            onClose = { manual = null },
        )
    }
}

/**
 * Лёгкая разделительная полоска между зонами редактора: начинается с небольшого отступа слева
 * (не рубит блоки от края до края) и плавно угасает к правому концу. Отступы сверху и снизу равны.
 */
@Composable
private fun FadeDivider() {
    val p = LocalPalette.current
    Box(
        Modifier
            .fillMaxWidth()
            .padding(start = 10.dp, end = 4.dp, top = 2.dp, bottom = 2.dp)
            .height(1.5.dp)
            .clip(RoundedCornerShape(50))
            .background(
                Brush.horizontalGradient(
                    listOf(p.accentDeep.copy(alpha = 0.30f), p.ink.copy(alpha = 0.10f), Color.Transparent),
                ),
            ),
    )
}

/**
 * Плашка верхней строки редактора: той же высоты и формы, что вкладки. Иконка и необязательная подпись.
 * Выключенная гаснет и не реагирует на нажатия.
 */
@Composable
private fun HeaderPlaque(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String?,
    description: String,
    onClick: () -> Unit,
    enabled: Boolean = true,
) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val interaction = remember { MutableInteractionSource() }
    val dim by animateFloatAsState(if (enabled) 1f else 0.4f, tween(200), label = "plaqueAlpha")
    Row(
        Modifier
            .height(38.dp)
            .graphicsLayer { alpha = dim }
            .pressScale(interaction)
            .softShadow(TabShape, 2.dp)
            .clip(TabShape)
            .background(p.card)
            .clickable(interactionSource = interaction, indication = null, enabled = enabled) {
                tick()
                onClick()
            }
            .padding(horizontal = if (label == null) 11.dp else 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = description, tint = p.ink, modifier = Modifier.size(20.dp))
        if (label != null) {
            Spacer(Modifier.width(8.dp))
            Text(
                label,
                color = p.ink,
                fontFamily = Onest,
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp,
                maxLines = 1,
                softWrap = false,
            )
        }
    }
}

@Composable
private fun SymbolTile(symbol: String?, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val interaction = remember { MutableInteractionSource() }
    val fill = remember(p) { p.accentBrush() }
    val sel by animateFloatAsState(if (selected) 1f else 0f, tween(200), label = "tileSel")
    Box(
        modifier
            .height(50.dp)
            .pressScale(interaction, pressedScale = 0.9f)
            .clip(TileShape)
            .background(p.card)
            .drawBehind { drawRect(fill, alpha = sel) }
            .clickable(interactionSource = interaction, indication = null) {
                tick()
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        if (symbol == null) {
            Icon(
                KomojeIcons.Close,
                contentDescription = stringResource(R.string.ed_none),
                tint = lerp(p.muted, p.onAccent, sel),
                modifier = Modifier.size(18.dp),
            )
        } else {
            Text(
                symbol,
                color = lerp(p.ink, p.onAccent, sel),
                fontSize = 20.sp,
                maxLines = 1,
                softWrap = false,
            )
        }
    }
}

@Composable
private fun FavoriteChip(text: String, onClick: () -> Unit) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val interaction = remember { MutableInteractionSource() }
    Box(
        Modifier
            .height(44.dp)
            .pressScale(interaction)
            .clip(TileShape)
            .background(p.card)
            .clickable(interactionSource = interaction, indication = null) {
                tick()
                onClick()
            }
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = p.ink, fontSize = 17.sp, maxLines = 1, softWrap = false)
    }
}
