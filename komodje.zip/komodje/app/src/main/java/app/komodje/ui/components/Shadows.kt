package app.komodje.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.komodje.ui.theme.LocalPalette

/**
 * Лёгкая мягкая тень в тон темы: не серая, а тёплая (цвет акцента). Ставить после pressScale и
 * ПЕРЕД clip и background: тогда тень сжимается вместе с плашкой, а сама плашка не обрезается.
 * В тёмных темах тени не видны на фоне и не рисуются.
 */
@Composable
fun Modifier.softShadow(shape: Shape, elevation: Dp = 3.dp): Modifier {
    val p = LocalPalette.current
    if (p.bgMid.luminance() < 0.35f) return this
    val tone = p.accentDeep.copy(alpha = 0.5f)
    return this.shadow(elevation, shape, clip = false, ambientColor = tone, spotColor = tone)
}
