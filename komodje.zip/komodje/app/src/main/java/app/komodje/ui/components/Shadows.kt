package app.komodje.ui.components

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.util.LruCache
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import app.komodje.ui.theme.LocalPalette
import kotlin.math.ceil
import kotlin.math.roundToInt

/**
 * Переключатель. true: тень рисуется один раз в картинку и дальше только выкладывается (быстро при прокрутке).
 * false: прежняя системная тень Android. Если нарисованная тень не нравится, достаточно поставить false.
 */
private val DRAWN_SHADOWS = true

// Подбор под вид прежней системной тени (elevation 3 dp, цвет акцента). Всё в долях от высоты тени.
/** Рассеянный слой: мягкое свечение со всех сторон, без смещения. */
private const val AMBIENT_RADIUS = 0.9f
private const val AMBIENT_ALPHA = 0.07f
/** Направленный слой: чуть шире и смещён вниз. */
private const val SPOT_RADIUS = 1.6f
private const val SPOT_SHIFT = 0.55f
private const val SPOT_ALPHA = 0.17f

private data class ShadowKey(
    val w: Int,
    val h: Int,
    val shape: Shape,
    val dir: LayoutDirection,
    val elevation100: Int,
    val color: Int,
)

/** Готовые тени. Карточки в списке одного размера, поэтому почти всегда берётся уже готовая. */
private val shadowCache = object : LruCache<ShadowKey, Bitmap>(12 * 1024 * 1024) {
    override fun sizeOf(key: ShadowKey, value: Bitmap): Int = value.byteCount
}

private fun outlinePath(outline: Outline): Path = when (outline) {
    is Outline.Rectangle -> Path().apply { addRect(outline.rect) }
    is Outline.Rounded -> Path().apply { addRoundRect(outline.roundRect) }
    is Outline.Generic -> outline.path
}

private fun buildShadow(
    w: Int,
    h: Int,
    shape: Shape,
    dir: LayoutDirection,
    density: Density,
    elevationPx: Float,
    color: Int,
    pad: Int,
): Bitmap {
    val bmp = Bitmap.createBitmap(w + 2 * pad, h + 2 * pad, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bmp)
    val outline = shape.createOutline(Size(w.toFloat(), h.toFloat()), dir, density)
    val path = android.graphics.Path(outlinePath(outline).asAndroidPath())
    path.offset(pad.toFloat(), pad.toFloat())
    val rgb = color and 0x00FFFFFF

    fun layer(radius: Float, alpha: Float, dy: Float) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = ((alpha * 255f).roundToInt().coerceIn(0, 255) shl 24) or rgb
            maskFilter = BlurMaskFilter(radius.coerceAtLeast(0.5f), BlurMaskFilter.Blur.NORMAL)
        }
        canvas.save()
        canvas.translate(0f, dy)
        canvas.drawPath(path, paint)
        canvas.restore()
    }
    layer(elevationPx * AMBIENT_RADIUS, AMBIENT_ALPHA, 0f)
    layer(elevationPx * SPOT_RADIUS, SPOT_ALPHA, elevationPx * SPOT_SHIFT)

    // Под самой плашкой тени нет (как у системной): вырезаем её контур, чтобы полупрозрачная плашка не светилась.
    val clear = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR) }
    canvas.drawPath(path, clear)
    return bmp
}

/**
 * Лёгкая мягкая тень в тон темы: не серая, а тёплая (цвет акцента). Ставить после pressScale и
 * ПЕРЕД clip и background: тогда тень сжимается вместе с плашкой, а сама плашка не обрезается.
 * В тёмных темах тени не видны на фоне и не рисуются.
 */
@Composable
fun Modifier.softShadow(shape: Shape, elevation: Dp = 3.dp, drawn: Boolean = true): Modifier {
    val p = LocalPalette.current
    if (p.bgMid.luminance() < 0.35f) return this
    // drawn = false: для форм, у которых размер меняется каждый кадр (карточка в руке): там тень картинкой не кешируется.
    if (!DRAWN_SHADOWS || !drawn) {
        val tone = p.accentDeep.copy(alpha = 0.5f)
        return this.shadow(elevation, shape, clip = false, ambientColor = tone, spotColor = tone)
    }
    val color = p.accentDeep.toArgb()
    return this.drawWithCache {
        val w = size.width.roundToInt()
        val h = size.height.roundToInt()
        if (w <= 0 || h <= 0) {
            onDrawBehind { }
        } else {
            val e = elevation.toPx()
            val pad = ceil(e * SPOT_RADIUS * 1.5f + e * SPOT_SHIFT + 2f).toInt()
            val key = ShadowKey(w, h, shape, layoutDirection, (e * 100f).roundToInt(), color)
            val bmp = shadowCache.get(key)
                ?: buildShadow(w, h, shape, layoutDirection, this, e, color, pad).also { shadowCache.put(key, it) }
            val image = bmp.asImageBitmap()
            val shift = ((bmp.width - w) / 2).toFloat()
            onDrawBehind { drawImage(image, Offset(-shift, -shift)) }
        }
    }
}
