package app.komodje.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import app.komodje.widget.refreshWidgets
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

internal val Context.dataStore by preferencesDataStore(name = "komodje")

class FavoritesStore(private val context: Context) {

    private val key = stringSetPreferencesKey("favorites")

    /** Свои каомодзи, новые первыми (по одному в строке). Сами они лежат и в любимых. */
    private val ownKey = stringPreferencesKey("own_kaomoji")

    /** Закреплённые, новые первыми (по одному в строке). */
    private val pinnedKey = stringPreferencesKey("pinned_kaomoji")

    val pinned: Flow<List<String>> = context.dataStore.data.map { prefs ->
        prefs[pinnedKey].orEmpty().split('\n').filter { it.isNotEmpty() }
    }

    val favorites: Flow<Set<String>> = context.dataStore.data.map { it[key].orEmpty() }

    val own: Flow<List<String>> = context.dataStore.data.map { prefs ->
        prefs[ownKey].orEmpty().split('\n').filter { it.isNotEmpty() }
    }

    /** Добавляет своё каомодзи в любимые. false, если такое уже есть в любимых. */
    suspend fun addOwn(text: String): Boolean {
        var added = false
        context.dataStore.edit { prefs ->
            val current = prefs[key].orEmpty()
            if (text in current) return@edit
            prefs[key] = current + text
            val others = prefs[ownKey].orEmpty().split('\n').filter { it.isNotEmpty() && it != text }
            prefs[ownKey] = (listOf(text) + others).joinToString("\n")
            added = true
        }
        if (added) refreshWidgets(context)
        return added
    }

    /** Закрепить или открепить. Новые закрепления встают первыми. */
    suspend fun togglePin(text: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[pinnedKey].orEmpty().split('\n').filter { it.isNotEmpty() }
            prefs[pinnedKey] = if (text in current) {
                (current - text).joinToString("\n")
            } else {
                (listOf(text) + current).joinToString("\n")
            }
        }
    }

    /** Добавляет сразу несколько каомодзи в любимые. */
    suspend fun addAll(texts: Collection<String>) {
        context.dataStore.edit { prefs -> prefs[key] = prefs[key].orEmpty() + texts }
        refreshWidgets(context)
    }

    suspend fun toggle(text: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[key].orEmpty()
            val removing = text in current
            prefs[key] = if (removing) current - text else current + text
            // Убрали из любимых: закрепление тоже снимается.
            if (removing) {
                val pins = prefs[pinnedKey].orEmpty().split('\n').filter { it.isNotEmpty() && it != text }
                prefs[pinnedKey] = pins.joinToString("\n")
            }
        }
        refreshWidgets(context)
    }
}
