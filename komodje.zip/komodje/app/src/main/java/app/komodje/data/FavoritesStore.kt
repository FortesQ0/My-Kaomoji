package app.komodje.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "komodje")

class FavoritesStore(private val context: Context) {

    private val key = stringSetPreferencesKey("favorites")

    val favorites: Flow<Set<String>> = context.dataStore.data.map { it[key].orEmpty() }

    suspend fun toggle(text: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[key].orEmpty()
            prefs[key] = if (text in current) current - text else current + text
        }
    }
}
