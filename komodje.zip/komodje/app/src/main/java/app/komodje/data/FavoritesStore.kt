package app.komodje.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import app.komodje.widget.refreshWidgets
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

internal val Context.dataStore by preferencesDataStore(name = "komodje")

class FavoritesStore(private val context: Context) {

    private val key = stringSetPreferencesKey("favorites")

    /** Свои каомодзи, новые первыми (по одному в строке). Сами они лежат и в любимых. */
    private val ownKey = stringPreferencesKey("own_kaomoji")

    val favorites: Flow<Set<String>> = context.dataStore.data.map { it[key].orEmpty() }

    val own: Flow<List<String>> = context.dataStore.data.map { prefs ->
        prefs[ownKey].orEmpty().split('\n').filter { it.isNotEmpty() }
    }

    /** Добавляет своё каомодзи в любимые. false, если такое уже есть в любимых. */
    suspend fun addOwn(text: String): Boolean {
        var added = false
        context.dataStore.edit { prefs ->
            val current = prefs[key].orEmpty()
            if (text in current) return@edit
            prefs[key] = current + text
            val others = prefs[ownKey].orEmpty().split('\n').filter { it.isNotEmpty() && it != text }
            prefs[ownKey] = (listOf(text) + others).joinToString("\n")
            added = true
        }
        if (added) refreshWidgets(context)
        return added
    }

    suspend fun toggle(text: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[key].orEmpty()
            prefs[key] = if (text in current) current - text else current + text
        }
        refreshWidgets(context)
    }
}
