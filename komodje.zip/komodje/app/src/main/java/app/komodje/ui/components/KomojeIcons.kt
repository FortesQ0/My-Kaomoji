package app.komodje.ui.components

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathBuilder
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

private fun PathBuilder.circle(cx: Float, cy: Float, r: Float) {
    moveTo(cx - r, cy)
    arcToRelative(r, r, 0f, true, true, 2 * r, 0f)
    arcToRelative(r, r, 0f, true, true, -2 * r, 0f)
    close()
}

private fun PathBuilder.rect(l: Float, t: Float, r: Float, b: Float) {
    moveTo(l, t); lineTo(r, t); lineTo(r, b); lineTo(l, b); close()
}

private fun PathBuilder.poly(vararg pts: Float) {
    moveTo(pts[0], pts[1])
    for (i in 2 until pts.size step 2) lineTo(pts[i], pts[i + 1])
    close()
}

/** Полудиск: top = true — дуга вверх (грусть / закрытый глаз), false — вниз (улыбка). */
private fun PathBuilder.halfDisc(x1: Float, y: Float, x2: Float, top: Boolean) {
    val r = (x2 - x1) / 2f
    moveTo(x1, y)
    arcTo(r, r, 0f, false, top, x2, y)
    close()
}

private fun PathBuilder.face() = circle(12f, 12f, 10.5f)

private fun PathBuilder.roundEyes() {
    circle(8.6f, 9.8f, 1.5f)
    circle(15.4f, 9.8f, 1.5f)
}

/** Заливка с even-odd: черты лица «вырезаются» из залитого круга. */
private fun icon(name: String, block: PathBuilder.() -> Unit): ImageVector =
    ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f)
        .path(
            fill = SolidColor(Color.Black),
            pathFillType = PathFillType.EvenOdd,
            pathBuilder = block,
        )
        .build()

private const val HEART =
    "M12,21.35l-1.45,-1.32C5.4,15.36 2,12.28 2,8.5 2,5.42 4.42,3 7.5,3c1.74,0 3.41,0.81 4.5,2.09" +
        "C13.09,3.81 14.76,3 16.5,3 19.58,3 22,5.42 22,8.5c0,3.78 -3.4,6.86 -8.55,11.54L12,21.35z"

object KomojeIcons {

    val Favorite: ImageVector by lazy {
        ImageVector.Builder("Favorite", 24.dp, 24.dp, 24f, 24f)
            .addPath(addPathNodes(HEART), fill = SolidColor(Color.Black))
            .build()
    }

    val HeartOutline: ImageVector by lazy {
        ImageVector.Builder("HeartOutline", 24.dp, 24.dp, 24f, 24f)
            .addPath(
                addPathNodes(HEART),
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2.2f,
                strokeLineJoin = StrokeJoin.Round,
            )
            .build()
    }

    val Happy: ImageVector by lazy {
        icon("Happy") { face(); roundEyes(); halfDisc(7.2f, 13.6f, 16.8f, top = false) }
    }

    val Sad: ImageVector by lazy {
        icon("Sad") { face(); roundEyes(); halfDisc(7.6f, 17.6f, 16.4f, top = true) }
    }

    val Neutral: ImageVector by lazy {
        icon("Neutral") { face(); roundEyes(); rect(8f, 14f, 16f, 15.8f) }
    }

    val Angry: ImageVector by lazy {
        icon("Angry") {
            face()
            poly(6.4f, 8.4f, 10.8f, 10.4f, 10.3f, 12.4f, 6.4f, 10.6f)
            poly(17.6f, 8.4f, 13.2f, 10.4f, 13.7f, 12.4f, 17.6f, 10.6f)
            halfDisc(8.8f, 17.4f, 15.2f, top = true)
        }
    }

    val Tender: ImageVector by lazy {
        icon("Tender") {
            face()
            halfDisc(6.6f, 11.2f, 10.8f, top = true)
            halfDisc(13.2f, 11.2f, 17.4f, top = true)
            halfDisc(9.6f, 14.4f, 14.4f, top = false)
        }
    }

    val Keyboard: ImageVector by lazy {
        icon("Keyboard") {
            rect(2.5f, 5.5f, 21.5f, 18.5f)
            for (x in listOf(5.2f, 8.9f, 12.6f, 16.3f)) {
                rect(x, 8.2f, x + 2f, 10.2f)
                rect(x, 11.5f, x + 2f, 13.5f)
            }
            rect(7.5f, 14.7f, 16.5f, 16.2f)
        }
    }
}
