package app.komodje

import android.os.Bundle
import android.graphics.Color
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import app.komodje.ui.HomeScreen
import app.komodje.ui.HomeViewModel
import app.komodje.ui.theme.KomodjeTheme

class MainActivity : AppCompatActivity() {

    private val vm: HomeViewModel by viewModels {
        HomeViewModel.factory((application as KomodjeApp).container)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
        )
        setContent {
            KomodjeTheme {
                HomeScreen(vm = vm, onToggleLanguage = ::toggleLanguage)
            }
        }
    }

    private fun toggleLanguage() {
        val isRu = resources.configuration.locales[0].language == "ru"
        AppCompatDelegate.setApplicationLocales(
            LocaleListCompat.forLanguageTags(if (isRu) "en" else "ru")
        )
    }
}
