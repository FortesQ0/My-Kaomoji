package app.komodje

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalConfiguration
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.komodje.domain.Mood
import app.komodje.ui.AppHeader
import app.komodje.ui.HomeScreen
import app.komodje.ui.HomeViewModel
import app.komodje.ui.LanguageWelcome
import app.komodje.ui.OwnEditorScreen
import app.komodje.ui.SettingsScreen
import app.komodje.ui.components.LocalCardScale
import app.komodje.ui.components.cardScaleFactor
import app.komodje.ui.components.LocalHapticsEnabled
import app.komodje.ui.supportedLanguageFor
import app.komodje.ui.theme.KomodjeTheme
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.backgroundBrush
import app.komodje.ui.theme.isDark
import app.komodje.ui.theme.paletteFor
import app.komodje.widget.refreshWidgetsAsync
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private val vm: HomeViewModel by viewModels {
        HomeViewModel.factory((application as KomodjeApp).container)
    }

    /** Растёт, когда ярлык с иконки просит открыть вкладку: экран настроек при этом закрывается. */
    private var shortcutTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) handleShortcut(intent)
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT))
        val settings = (application as KomodjeApp).container.settings
        setContent {
            // StateFlow со стартовым значением из хранилища: после смены языка (пересоздание
            // Activity) экран сразу рисуется с настоящей темой и ничего не «прыгает».
            val mode by settings.themeMode.collectAsStateWithLifecycle()
            val accent by settings.accent.collectAsStateWithLifecycle()
            val languageChosen by settings.languageChosen.collectAsStateWithLifecycle()
            val autoReturn by settings.autoReturn.collectAsStateWithLifecycle()
            val haptics by settings.haptics.collectAsStateWithLifecycle()
            val cardScale by settings.cardScale.collectAsStateWithLifecycle()
            val keyboardHelpSeen by settings.keyboardHelpSeen.collectAsStateWithLifecycle()
            val scope = rememberCoroutineScope()
            var showSettings by rememberSaveable { mutableStateOf(false) }
            var showEditor by rememberSaveable { mutableStateOf(false) }
            val dark = mode.isDark()
            LaunchedEffect(shortcutTick) {
                if (shortcutTick > 0) {
                    showSettings = false
                    showEditor = false
                }
            }

            // Тёмная шапка (бордо, море) требует светлых значков в статус-баре, светлая требует тёмных.
            val lightStatusIcons = remember(accent, dark, languageChosen) {
                // До выбора языка сверху обычный фон страницы, а не цветная шапка.
                if (!languageChosen) dark else paletteFor(accent, dark).onAccent.luminance() > 0.5f
            }
            LaunchedEffect(lightStatusIcons) {
                enableEdgeToEdge(
                    statusBarStyle = if (lightStatusIcons) {
                        SystemBarStyle.dark(Color.TRANSPARENT)
                    } else {
                        SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                    },
                )
            }

            KomodjeTheme(dark = dark, accent = accent) {
              CompositionLocalProvider(
                  LocalHapticsEnabled provides haptics,
                  LocalCardScale provides cardScaleFactor(cardScale),
              ) {
                val p = LocalPalette.current
                val systemLanguage = LocalConfiguration.current.locales[0].language
                BackHandler(enabled = showSettings && languageChosen) { showSettings = false }
                BackHandler(enabled = showEditor && languageChosen) { showEditor = false }

                Crossfade(targetState = languageChosen, animationSpec = tween(350), label = "welcome") { chosen ->
                    if (!chosen) {
                        // Первый запуск: сначала выбор языка (предвыбран язык системы или английский).
                        LanguageWelcome(
                            initialTag = supportedLanguageFor(systemLanguage).tag,
                            onContinue = { lang ->
                                scope.launch {
                                    settings.markLanguageChosen()
                                    setLanguage(lang.tag)
                                }
                            },
                        )
                    } else {
                        Column(
                            Modifier
                                .fillMaxSize()
                                .background(p.backgroundBrush())
                                .navigationBarsPadding()
                        ) {
                            AppHeader(
                                settingsOpen = showSettings,
                                onAction = {
                                    // Из конструктора шестерёнка ведёт в настройки.
                                    if (showEditor) {
                                        showEditor = false
                                        showSettings = true
                                    } else {
                                        showSettings = !showSettings
                                    }
                                },
                            )
                            Box(Modifier.weight(1f)) {
                                Crossfade(
                                    targetState = if (showSettings) 1 else if (showEditor) 2 else 0,
                                    animationSpec = tween(200),
                                    label = "screen",
                                ) { screen ->
                                    if (screen == 2) {
                                        OwnEditorScreen(vm = vm, onClose = { showEditor = false })
                                    } else if (screen == 1) {
                                        SettingsScreen(
                                            themeMode = mode,
                                            onThemeMode = { scope.launch { settings.setThemeMode(it) } },
                                            accent = accent,
                                            onAccent = { scope.launch { settings.setAccent(it) } },
                                            autoReturn = autoReturn,
                                            onAutoReturn = { scope.launch { settings.setAutoReturn(it) } },
                                            haptics = haptics,
                                            onHaptics = { scope.launch { settings.setHaptics(it) } },
                                            cardScale = cardScale,
                                            onCardScale = { scope.launch { settings.setCardScale(it) } },
                                            keyboardHelpSeen = keyboardHelpSeen,
                                            onKeyboardHelpSeen = { scope.launch { settings.markKeyboardHelpSeen() } },
                                            onSetLanguage = ::setLanguage,
                                        )
                                    } else {
                                        HomeScreen(vm = vm, onCreateOwn = { showEditor = true })
                                    }
                                }
                            }
                        }
                    }
                }
              }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShortcut(intent)
    }

    /** Ярлык на иконке приложения: открыть нужную вкладку (Избранные, Радостные и т. д.). */
    private fun handleShortcut(intent: Intent?) {
        val name = intent?.getStringExtra(EXTRA_MOOD) ?: return
        // Один раз: после пересоздания Activity (поворот, смена языка) ярлык повторно не применяем.
        intent.removeExtra(EXTRA_MOOD)
        val mood = runCatching { Mood.valueOf(name) }.getOrNull() ?: return
        vm.select(mood)
        shortcutTick++
    }

    override fun onStop() {
        super.onStop()
        // Запоминаем вкладку, фильтры и место в списке на случай, если систему закроет приложение.
        vm.persistHome()
        // Ушли из приложения: самое время обновить виджет под новые «частые».
        refreshWidgetsAsync(applicationContext)
        // Значок на рабочем столе меняем только когда приложение свернули: на глазах оно не закрывается,
        // и цвет темы можно спокойно рассмотреть.
        runCatching {
            app.komodje.ui.AppIcon.apply(applicationContext, (application as KomodjeApp).container.settings.accent.value)
        }
    }

    private fun setLanguage(tag: String) {
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
    }

    companion object {
        const val EXTRA_MOOD = "app.komodje.extra.MOOD"
    }
}
