package app.komodje

import android.graphics.Color
import android.os.Bundle
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.komodje.domain.ThemeMode
import app.komodje.ui.HomeScreen
import app.komodje.ui.HomeViewModel
import app.komodje.ui.SettingsScreen
import app.komodje.ui.theme.KomodjeTheme
import app.komodje.ui.theme.isDark
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private val vm: HomeViewModel by viewModels {
        HomeViewModel.factory((application as KomodjeApp).container)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
        )
        val settings = (application as KomodjeApp).container.settings
        setContent {
            val mode by settings.themeMode.collectAsStateWithLifecycle(initialValue = ThemeMode.SYSTEM)
            val scope = rememberCoroutineScope()
            var showSettings by rememberSaveable { mutableStateOf(false) }

            KomodjeTheme(dark = mode.isDark()) {
                BackHandler(enabled = showSettings) { showSettings = false }
                Crossfade(targetState = showSettings, animationSpec = tween(200), label = "screen") { settingsOpen ->
                    if (settingsOpen) {
                        SettingsScreen(
                            themeMode = mode,
                            onThemeMode = { scope.launch { settings.setThemeMode(it) } },
                            onSetLanguage = ::setLanguage,
                            onBack = { showSettings = false },
                        )
                    } else {
                        HomeScreen(vm = vm, onOpenSettings = { showSettings = true })
                    }
                }
            }
        }
    }

    private fun setLanguage(tag: String) {
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
    }
}
