package app.komodje

import android.graphics.Color
import android.os.Bundle
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalConfiguration
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.komodje.ui.AppHeader
import app.komodje.ui.HomeScreen
import app.komodje.ui.HomeViewModel
import app.komodje.ui.LanguageWelcome
import app.komodje.ui.SettingsScreen
import app.komodje.ui.components.LocalCardScale
import app.komodje.ui.components.LocalHapticsEnabled
import app.komodje.ui.supportedLanguageFor
import app.komodje.ui.theme.KomodjeTheme
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.backgroundBrush
import app.komodje.ui.theme.isDark
import app.komodje.ui.theme.paletteFor
import app.komodje.widget.refreshWidgetsAsync
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private val vm: HomeViewModel by viewModels {
        HomeViewModel.factory((application as KomodjeApp).container)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT))
        val settings = (application as KomodjeApp).container.settings
        setContent {
            // StateFlow со стартовым значением из хранилища: после смены языка (пересоздание
            // Activity) экран сразу рисуется с настоящей темой и ничего не «прыгает».
            val mode by settings.themeMode.collectAsStateWithLifecycle()
            val accent by settings.accent.collectAsStateWithLifecycle()
            val languageChosen by settings.languageChosen.collectAsStateWithLifecycle()
            val autoReturn by settings.autoReturn.collectAsStateWithLifecycle()
            val haptics by settings.haptics.collectAsStateWithLifecycle()
            val cardScale by settings.cardScale.collectAsStateWithLifecycle()
            val keyboardHelpSeen by settings.keyboardHelpSeen.collectAsStateWithLifecycle()
            val scope = rememberCoroutineScope()
            var showSettings by rememberSaveable { mutableStateOf(false) }
            val dark = mode.isDark()

            // Тёмная шапка (бордо, море) требует светлых значков в статус-баре, светлая требует тёмных.
            val lightStatusIcons = remember(accent, dark, languageChosen) {
                // До выбора языка сверху обычный фон страницы, а не цветная шапка.
                if (!languageChosen) dark else paletteFor(accent, dark).onAccent.luminance() > 0.5f
            }
            LaunchedEffect(lightStatusIcons) {
                enableEdgeToEdge(
                    statusBarStyle = if (lightStatusIcons) {
                        SystemBarStyle.dark(Color.TRANSPARENT)
                    } else {
                        SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                    },
                )
            }

            KomodjeTheme(dark = dark, accent = accent) {
              CompositionLocalProvider(
                  LocalHapticsEnabled provides haptics,
                  LocalCardScale provides cardScale / 100f,
              ) {
                val p = LocalPalette.current
                val systemLanguage = LocalConfiguration.current.locales[0].language
                BackHandler(enabled = showSettings && languageChosen) { showSettings = false }

                Crossfade(targetState = languageChosen, animationSpec = tween(350), label = "welcome") { chosen ->
                    if (!chosen) {
                        // Первый запуск: сначала выбор языка (предвыбран язык системы или английский).
                        LanguageWelcome(
                            initialTag = supportedLanguageFor(systemLanguage).tag,
                            onContinue = { lang ->
                                scope.launch {
                                    settings.markLanguageChosen()
                                    setLanguage(lang.tag)
                                }
                            },
                        )
                    } else {
                        Column(
                            Modifier
                                .fillMaxSize()
                                .background(p.backgroundBrush())
                                .navigationBarsPadding()
                        ) {
                            AppHeader(settingsOpen = showSettings, onAction = { showSettings = !showSettings })
                            Box(Modifier.weight(1f)) {
                                Crossfade(targetState = showSettings, animationSpec = tween(200), label = "screen") { settingsOpen ->
                                    if (settingsOpen) {
                                        SettingsScreen(
                                            themeMode = mode,
                                            onThemeMode = { scope.launch { settings.setThemeMode(it) } },
                                            accent = accent,
                                            onAccent = { scope.launch { settings.setAccent(it) } },
                                            autoReturn = autoReturn,
                                            onAutoReturn = { scope.launch { settings.setAutoReturn(it) } },
                                            haptics = haptics,
                                            onHaptics = { scope.launch { settings.setHaptics(it) } },
                                            cardScale = cardScale,
                                            onCardScale = { scope.launch { settings.setCardScale(it) } },
                                            keyboardHelpSeen = keyboardHelpSeen,
                                            onKeyboardHelpSeen = { scope.launch { settings.markKeyboardHelpSeen() } },
                                            onSetLanguage = ::setLanguage,
                                        )
                                    } else {
                                        HomeScreen(vm = vm)
                                    }
                                }
                            }
                        }
                    }
                }
              }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        // Ушли из приложения: самое время обновить виджет под новые «частые».
        refreshWidgetsAsync(applicationContext)
    }

    private fun setLanguage(tag: String) {
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
    }
}
