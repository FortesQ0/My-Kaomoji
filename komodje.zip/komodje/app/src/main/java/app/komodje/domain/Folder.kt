package app.komodje.domain

import kotlinx.serialization.Serializable

/**
 * Папка в разделе «Любимые». У готовых папок name пустой: название берётся из строк
 * приложения (на языке интерфейса). У папок пользователя name это то, что он ввёл.
 */
@Serializable
data class Folder(
    val id: String,
    val name: String? = null,
    val items: List<String> = emptyList(),
)

const val FOLDER_CONGRATS = "congrats"
const val FOLDER_SAD = "sad"
const val FOLDER_CUTE = "cute"

/** Папки пользователя получают id с этим префиксом: так их можно отличить от готовых. */
const val USER_FOLDER_PREFIX = "u"

fun Folder.isBuiltIn(): Boolean = !id.startsWith(USER_FOLDER_PREFIX)

/** Три готовые папки. В первой базовые каомодзи в духе поздравлений, остальные пустые. */
fun defaultFolders(): List<Folder> = listOf(
    Folder(
        id = FOLDER_CONGRATS,
        items = listOf(
        "\\( >ᗜ< )/",
        "(ﾉ✧ ‿‿ ✧)ﾉ",
        "┏( ◕ ‿‿ ◕ )┛",
        "(ง ✧ ᗜ ✧ )ง",
        "\\(*ˊ□ˋ*)/",
        "\\( *ˊ ᵕ ˋ* )/",
        "(ﾉ ◕ ᗜ ◕ )ﾉ",
        "✧ ᗜ ✧",
        "(ᵔ ᵕ ᵔ )ﾉ",
        "( ‾ ᴗ ‾ )b",
        ),
    ),
    Folder(id = FOLDER_SAD),
    Folder(id = FOLDER_CUTE),
)
