package app.komodje.domain

import androidx.compose.runtime.Immutable
import kotlinx.serialization.Serializable

/**
 * Папка в разделе «Любимые». Пока name пустой, название берётся из строк приложения
 * (на языке интерфейса). Когда человек переименовал папку или создал свою, name это то, что он ввёл.
 */
@Immutable
@Serializable
data class Folder(
    val id: String,
    val name: String? = null,
    val items: List<String> = emptyList(),
)

const val FOLDER_CONGRATS = "congrats"

/** Две пустые готовые папки: пока человек их не назвал, они «Папка без названия». */
const val FOLDER_BLANK_1 = "blank1"
const val FOLDER_BLANK_2 = "blank2"

/** Папки пользователя получают id с этим префиксом. */
const val USER_FOLDER_PREFIX = "u"

/**
 * Три готовые папки. В первой базовые каомодзи в духе поздравлений, остальные пустые.
 * Все папки равноправны: любую можно переименовать и удалить.
 */
fun defaultFolders(): List<Folder> = listOf(
    Folder(
        id = FOLDER_CONGRATS,
        items = listOf(
        "\\( >ᗜ< )/",
        "(ﾉ✧ ‿‿ ✧)ﾉ",
        "┏( ◕ ‿‿ ◕ )┛",
        "(ง ✧ ᗜ ✧ )ง",
        "\\(*ˊ□ˋ*)/",
        "\\( *ˊ ᵕ ˋ* )/",
        "(ﾉ ◕ ᗜ ◕ )ﾉ",
        "✧ ᗜ ✧",
        "(ᵔ ᵕ ᵔ )ﾉ",
        "( ‾ ᴗ ‾ )b",
        ),
    ),
    Folder(id = FOLDER_BLANK_1),
    Folder(id = FOLDER_BLANK_2),
)
