package app.komodje.ui.components

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import androidx.core.content.FileProvider
import app.komodje.ui.SIGNATURE_KAOMOJI
import java.io.File

/**
 * Открытка «Спасибо за поддержку» для кнопки «Поделиться»: квадрат 1:1: каомодзи, подпись, плашка с QR, сеть и адрес.
 * Рисуется обычным Canvas в Bitmap, сохраняется в cache/share и отдаётся через FileProvider.
 */
object ShareCard {

    private const val W = 1080
    private const val H = 1080

    /**
     * Цвета открытки (ARGB), из палитры темы: фон тёмный оттенка темы (bgTop → bgBottom),
     * надписи светлые (ink), блики и значки (accent). Белая плашка с QR остаётся белой в любой теме.
     */
    class Colors(val bgTop: Int, val bgBottom: Int, val ink: Int, val accent: Int)

    fun render(thanks: String, network: String, colors: Colors): Bitmap {
        @Suppress("UNUSED_VARIABLE") val unused = colors
        val ink = 0xFF4A1A2C.toInt()
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        // Фон всегда в цвете сакуры, как логотип: светло-розовый с лёгким белесым переходом.
        paint.shader = LinearGradient(
            0f, 0f, W * 0.5f, H.toFloat(),
            intArrayOf(0xFFFFF1F5.toInt(), 0xFFFFD3E1.toInt(), 0xFFFFB6CC.toInt()),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP,
        )
        c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), paint)
        paint.shader = RadialGradient(W * 0.3f, 80f, 760f, Color.argb(150, 255, 255, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), paint)
        paint.shader = RadialGradient(W * 0.85f, H.toFloat(), 700f, Color.argb(90, 255, 120, 160), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), paint)
        paint.shader = null

        // Каомодзи и подпись.
        paint.color = ink
        paint.textAlign = Paint.Align.CENTER
        paint.typeface = Typeface.DEFAULT
        paint.textSize = fitSize(paint, SIGNATURE_KAOMOJI, 84f, W - 260f)
        // Каомодзи уезжает чуть вправо: визуально он тяжелее слева, так по центру смотрится ровнее.
        c.drawText(SIGNATURE_KAOMOJI, W / 2f + 20f, 118f, paint)
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = fitSize(paint, thanks, 58f, W - 200f)
        c.drawText(thanks, W / 2f, 196f, paint)

        // Белая плашка с QR: тень, скругление, ровная тихая зона.
        val modules = UsdtQr.MODULES
        var minX = Int.MAX_VALUE; var minY = Int.MAX_VALUE; var maxX = -1; var maxY = -1
        for (y in modules.indices) for (x in modules[y].indices) if (modules[y][x] == '1') {
            if (x < minX) minX = x; if (x > maxX) maxX = x
            if (y < minY) minY = y; if (y > maxY) maxY = y
        }
        val n = maxX - minX + 1
        val pad = 40
        val cell = (520 / n).coerceAtLeast(1)
        val qr = n * cell
        val panel = qr + 2 * pad
        val left = (W - panel) / 2
        val top = 232
        val rect = RectF(left.toFloat(), top.toFloat(), (left + panel).toFloat(), (top + panel).toFloat())
        paint.color = Color.argb(50, 120, 20, 60)
        c.drawRoundRect(RectF(rect.left, rect.top + 12f, rect.right, rect.bottom + 12f), 52f, 52f, paint)
        paint.color = Color.WHITE
        c.drawRoundRect(rect, 52f, 52f, paint)
        // Модули рисуем по целым пикселям без сглаживания: никаких полос между клетками.
        val qp = Paint().apply { isAntiAlias = false; color = 0xFF14101C.toInt(); style = Paint.Style.FILL }
        val qx = left + pad
        val qy = top + pad
        for (y in minY..maxY) {
            var x = minX
            while (x <= maxX) {
                if (modules[y][x] == '1') {
                    var e = x
                    while (e + 1 <= maxX && modules[y][e + 1] == '1') e++
                    c.drawRect(
                        (qx + (x - minX) * cell).toFloat(), (qy + (y - minY) * cell).toFloat(),
                        (qx + (e - minX + 1) * cell).toFloat(), (qy + (y - minY + 1) * cell).toFloat(), qp,
                    )
                    x = e + 1
                } else x++
            }
        }

        // Плашка сети.
        val below = (top + panel).toFloat()
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = fitSize(paint, network, 40f, W - 260f)
        val tw = paint.measureText(network)
        val pill = RectF(W / 2f - tw / 2f - 40f, below + 26f, W / 2f + tw / 2f + 40f, below + 94f)
        paint.color = Color.argb(46, 74, 26, 44)
        c.drawRoundRect(pill, 34f, 34f, paint)
        paint.color = ink
        c.drawText(network, W / 2f, below + 72f, paint)

        // Адрес двумя строками, моноширинным.
        paint.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        val groups = UsdtQr.ADDRESS.chunked(6)
        val half = (groups.size + 1) / 2
        val lines = listOf(groups.take(half).joinToString(" "), groups.drop(half).joinToString(" "))
        paint.textSize = fitSize(paint, lines.maxBy { it.length }, 54f, W - 140f)
        c.drawText(lines[0], W / 2f, below + 168f, paint)
        c.drawText(lines[1], W / 2f, below + 238f, paint)

        return bmp
    }

    private fun withAlpha(color: Int, alpha: Int): Int =
        Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))

    /** Четырёхлучевая искорка с вогнутыми гранями. */
    private fun sparkle(c: Canvas, paint: Paint, cx: Float, cy: Float, r: Float) {
        val path = Path()
        path.moveTo(cx, cy - r)
        path.quadTo(cx, cy, cx + r, cy)
        path.quadTo(cx, cy, cx, cy + r)
        path.quadTo(cx, cy, cx - r, cy)
        path.quadTo(cx, cy, cx, cy - r)
        path.close()
        c.drawPath(path, paint)
    }

    /** Уменьшает размер шрифта, пока строка не влезет по ширине. */
    private fun fitSize(paint: Paint, text: String, start: Float, maxWidth: Float): Float {
        var size = start
        paint.textSize = size
        while (size > 20f && paint.measureText(text) > maxWidth) {
            size -= 2f
            paint.textSize = size
        }
        return size
    }

    /** Сохраняет открытку в cache/share/usdt_thanks.png и возвращает окно «Поделиться» с картинкой и адресом текстом. */
    fun buildIntent(ctx: Context, bitmap: Bitmap, chooserTitle: String, text: String): Intent {
        val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
        val file = File(dir, "usdt_thanks.png")
        file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, text)
            clipData = ClipData.newRawUri("", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return Intent.createChooser(send, chooserTitle).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }
}
