package app.komodje.ui.components

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import androidx.core.content.FileProvider
import app.komodje.ui.SIGNATURE_KAOMOJI
import java.io.File

/**
 * Открытка «Спасибо за поддержку» для кнопки «Поделиться»: плашка с QR, подпись, каомодзи и адрес.
 * Рисуется обычным Canvas в Bitmap, сохраняется в cache/share и отдаётся через FileProvider.
 */
object ShareCard {

    private const val W = 1080
    private const val H = 1560

    /** Цвета открытки (ARGB), берутся из палитры текущей темы. */
    class Colors(val bgTop: Int, val bgBottom: Int, val ink: Int, val accent: Int)

    fun render(thanks: String, network: String, colors: Colors): Bitmap {
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        // Фон: мягкий градиент темы со скруглением, за ним белые поля, чтобы открытка читалась в любом чате.
        c.drawColor(Color.WHITE)
        paint.shader = LinearGradient(0f, 0f, 0f, H.toFloat(), colors.bgTop, colors.bgBottom, Shader.TileMode.CLAMP)
        c.drawRoundRect(RectF(0f, 0f, W.toFloat(), H.toFloat()), 72f, 72f, paint)
        paint.shader = null

        // Подпись и каомодзи.
        paint.color = colors.ink
        paint.textAlign = Paint.Align.CENTER
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = fitSize(paint, thanks, 66f, W - 160f)
        c.drawText(thanks, W / 2f, 190f, paint)
        paint.typeface = Typeface.DEFAULT
        paint.textSize = fitSize(paint, SIGNATURE_KAOMOJI, 92f, W - 200f)
        c.drawText(SIGNATURE_KAOMOJI, W / 2f, 330f, paint)

        // Белая плашка с QR.
        val modules = UsdtQr.MODULES
        val n = modules.size
        val cell = 21
        val qr = n * cell
        val pad = 48
        val panelW = qr + 2 * pad
        val left = (W - panelW) / 2f
        val top = 400f
        paint.color = Color.WHITE
        c.drawRoundRect(RectF(left, top, left + panelW, top + panelW), 56f, 56f, paint)
        paint.color = 0xFF111111.toInt()
        val qx = left + pad
        val qy = top + pad
        for (y in 0 until n) for (x in 0 until n) {
            if (modules[y][x] == '1') {
                c.drawRect(qx + x * cell, qy + y * cell, qx + (x + 1) * cell, qy + (y + 1) * cell, paint)
            }
        }

        // Сеть и адрес.
        val below = top + panelW
        paint.color = colors.ink
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = fitSize(paint, network, 46f, W - 160f)
        c.drawText(network, W / 2f, below + 96f, paint)

        paint.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        val groups = UsdtQr.ADDRESS.chunked(6)
        val half = (groups.size + 1) / 2
        val lines = listOf(groups.take(half).joinToString(" "), groups.drop(half).joinToString(" "))
        paint.textSize = fitSize(paint, lines.maxBy { it.length }, 54f, W - 140f)
        c.drawText(lines[0], W / 2f, below + 190f, paint)
        c.drawText(lines[1], W / 2f, below + 262f, paint)
        return bmp
    }

    /** Уменьшает размер шрифта, пока строка не влезет по ширине. */
    private fun fitSize(paint: Paint, text: String, start: Float, maxWidth: Float): Float {
        var size = start
        paint.textSize = size
        while (size > 20f && paint.measureText(text) > maxWidth) {
            size -= 2f
            paint.textSize = size
        }
        return size
    }

    /** Сохраняет открытку в cache/share/usdt_thanks.png и возвращает окно «Поделиться» с картинкой и адресом текстом. */
    fun buildIntent(ctx: Context, bitmap: Bitmap, chooserTitle: String): Intent {
        val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
        val file = File(dir, "usdt_thanks.png")
        file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, UsdtQr.ADDRESS)
            clipData = ClipData.newRawUri("", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return Intent.createChooser(send, chooserTitle).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }
}
