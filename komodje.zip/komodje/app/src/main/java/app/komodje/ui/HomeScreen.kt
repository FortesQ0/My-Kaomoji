package app.komodje.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.komodje.R
import app.komodje.ui.components.KomojeIcons
import app.komodje.ui.components.KomojiPanel
import app.komodje.ui.components.LogoMark
import app.komodje.ui.theme.HeaderShape
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.LogoShape
import app.komodje.ui.theme.Onest
import app.komodje.ui.theme.accentBrush
import app.komodje.ui.theme.backgroundBrush
import app.komodje.ui.theme.badgeBrush

@Composable
fun HomeScreen(vm: HomeViewModel, onOpenSettings: () -> Unit) {
    val state by vm.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val p = LocalPalette.current

    Column(
        Modifier
            .fillMaxSize()
            .background(p.backgroundBrush())
            .navigationBarsPadding()
    ) {
        TopBar(onOpenSettings)
        KomojiPanel(
            state = state,
            onSelect = vm::select,
            onPick = { copyToClipboard(ctx, it) },
            onHold = vm::toggleFavorite,
            feedback = stringResource(R.string.copied),
            modifier = Modifier.weight(1f),
        )
    }
}

private fun copyToClipboard(ctx: Context, text: String) {
    ctx.getSystemService(ClipboardManager::class.java)
        .setPrimaryClip(ClipData.newPlainText("kaoji", text))
}

/**
 * Низкая шапка в одну строку. Всё стоит на одной нижней линии: низ логотипа, база букв «Kaoji»
 * и низ кнопки настроек. Левый край логотипа = левый край карточек (14dp), центр шестерёнки
 * над центром сердечек.
 */
@Composable
private fun TopBar(onOpenSettings: () -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .clip(HeaderShape)
            .background(p.accentBrush())
            .statusBarsPadding()
            .padding(start = 14.dp, end = 16.dp, top = 8.dp, bottom = 12.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        LogoMark(size = 36.dp)
        Spacer(Modifier.width(10.dp))
        Text(
            text = stringResource(R.string.app_name),
            color = p.onAccent,
            fontFamily = Onest,
            fontWeight = FontWeight.Bold,
            fontSize = 26.sp,
            letterSpacing = (-0.5).sp,
            modifier = Modifier
                .weight(1f)
                .offset(y = 5.dp),
        )
        LeafButton(onClick = onOpenSettings) {
            Icon(
                imageVector = KomojeIcons.Gear,
                contentDescription = stringResource(R.string.settings_title),
                tint = p.accent,
                modifier = Modifier.size(22.dp),
            )
        }
    }
}

/** Тёмная кнопка тех же пропорций, что и логотип: пара к нему по краям шапки. */
@Composable
fun LeafButton(onClick: () -> Unit, content: @Composable () -> Unit) {
    val p = LocalPalette.current
    Box(
        Modifier
            .size(36.dp)
            .clip(LogoShape)
            .background(p.badgeBrush())
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { content() }
}
