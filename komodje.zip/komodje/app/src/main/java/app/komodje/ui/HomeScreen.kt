package app.komodje.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.komodje.R
import app.komodje.ui.components.KomojiPanel

/** Главный экран: только список и нижняя панель. Шапка живёт выше, в MainActivity. */
@Composable
fun HomeScreen(vm: HomeViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current

    KomojiPanel(
        state = state,
        onSelect = vm::select,
        onPick = { copyToClipboard(ctx, it) },
        onHold = vm::toggleFavorite,
        feedback = stringResource(R.string.copied),
        modifier = Modifier.fillMaxSize(),
    )
}

private fun copyToClipboard(ctx: Context, text: String) {
    ctx.getSystemService(ClipboardManager::class.java)
        .setPrimaryClip(ClipData.newPlainText("kaoji", text))
}
