package app.komodje.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.komodje.R
import app.komodje.ui.components.Categories
import app.komodje.ui.components.KomojiPanel
import app.komodje.ui.components.LogoMark
import app.komodje.ui.theme.HeaderShape
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.Onest
import app.komodje.ui.theme.backgroundBrush

@Composable
fun HomeScreen(vm: HomeViewModel, onToggleLanguage: () -> Unit) {
    val state by vm.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val p = LocalPalette.current

    Column(
        Modifier
            .fillMaxSize()
            .background(p.backgroundBrush())
            .navigationBarsPadding()
    ) {
        val category = Categories.first { it.mood == state.mood }
        TopBar(
            title = stringResource(category.label),
            count = state.items.size,
            onToggleLanguage = onToggleLanguage,
        )
        KomojiPanel(
            state = state,
            onSelect = vm::select,
            onPick = { copyToClipboard(ctx, it) },
            onHold = vm::toggleFavorite,
            feedback = stringResource(R.string.copied),
            modifier = Modifier.weight(1f),
        )
    }
}

private fun copyToClipboard(ctx: Context, text: String) {
    ctx.getSystemService(ClipboardManager::class.java)
        .setPrimaryClip(ClipData.newPlainText("komodje", text))
}

/** Персиковая шапка: логотип, название, чип языка и строка «категория · количество». */
@Composable
private fun TopBar(title: String, count: Int, onToggleLanguage: () -> Unit) {
    val p = LocalPalette.current
    Column(
        Modifier
            .fillMaxWidth()
            .clip(HeaderShape)
            .background(p.accent)
            .statusBarsPadding()
            .padding(start = 20.dp, end = 16.dp, top = 12.dp, bottom = 20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            LogoMark()
            Spacer(Modifier.width(12.dp))
            Text(
                text = stringResource(R.string.app_name),
                color = p.onAccent,
                fontFamily = Onest,
                fontWeight = FontWeight.Bold,
                fontSize = 26.sp,
                letterSpacing = (-0.5).sp,
                modifier = Modifier.weight(1f),
            )
            LanguageChip(onToggleLanguage)
        }
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                text = title,
                color = p.onAccent,
                fontFamily = Onest,
                fontWeight = FontWeight.Bold,
                fontSize = 30.sp,
                letterSpacing = (-0.5).sp,
                modifier = Modifier.weight(1f),
            )
            Text(
                text = count.toString(),
                color = p.onAccent.copy(alpha = 0.6f),
                fontFamily = Onest,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                modifier = Modifier.padding(bottom = 3.dp),
            )
        }
    }
}

/** RU | EN: один тап переключает язык, активный сегмент — тёмный лист с персиковым текстом. */
@Composable
private fun LanguageChip(onClick: () -> Unit) {
    val p = LocalPalette.current
    val ru = LocalConfiguration.current.locales[0].language == "ru"
    Row(
        Modifier
            .clip(CircleShape)
            .background(p.onAccent.copy(alpha = 0.14f))
            .clickable(onClick = onClick)
            .padding(4.dp)
    ) {
        Segment("RU", ru)
        Segment("EN", !ru)
    }
}

@Composable
private fun Segment(label: String, active: Boolean) {
    val p = LocalPalette.current
    val bg by animateColorAsState(if (active) p.badge else Color.Transparent, tween(250), label = "segBg")
    val fg by animateColorAsState(if (active) p.accent else p.onAccent, tween(250), label = "segFg")
    Text(
        text = label,
        color = fg,
        fontFamily = Onest,
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp,
        modifier = Modifier
            .clip(CircleShape)
            .background(bg)
            .padding(horizontal = 12.dp, vertical = 7.dp),
    )
}
