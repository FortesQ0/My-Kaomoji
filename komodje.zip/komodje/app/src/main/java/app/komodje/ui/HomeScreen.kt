package app.komodje.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.komodje.R
import app.komodje.domain.Mood
import app.komodje.ui.components.CardMenu
import app.komodje.ui.components.FolderActions
import app.komodje.ui.components.KomojiPanel

/** Главный экран: только список и нижняя панель. Шапка живёт выше, в MainActivity. */
@Composable
fun HomeScreen(vm: HomeViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    // Какой комоджи сейчас в меню «В папку…» (долгое нажатие в разделе «Любимые») и где он на экране.
    var menuFor by remember { mutableStateOf<String?>(null) }
    var menuAnchor by remember { mutableStateOf(Rect.Zero) }
    val folderActions = remember(vm) {
        FolderActions(
            onOpen = vm::toggleFolder,
            onCreate = vm::createFolder,
            onRename = vm::renameFolder,
            onDelete = vm::deleteFolder,
        )
    }

    KomojiPanel(
        state = state,
        onSelect = vm::select,
        onPick = {
            copyToClipboard(ctx, it)
            vm.picked(it)
        },
        onHold = vm::toggleFavorite,
        // В каталоге долгое нажатие по-прежнему ставит лайк, в «Любимых» открывает меню рядом с карточкой.
        onHoldAt = { text, bounds ->
            if (state.mood == Mood.FAVORITE) {
                menuAnchor = bounds
                menuFor = text
            } else {
                vm.toggleFavorite(text)
            }
        },
        feedback = stringResource(R.string.copied),
        modifier = Modifier.fillMaxSize(),
        onFavorite = vm::toggleFavorite,
        onFilter = vm::toggleFilter,
        onQuery = vm::setQuery,
        folderActions = folderActions,
    )

    menuFor?.let { text ->
        val alreadyMessage = stringResource(R.string.folder_already)
        CardMenu(
            text = text,
            anchor = menuAnchor,
            folders = state.folders,
            openFolder = state.openFolder,
            isFavorite = text in state.favorites,
            onAddTo = { folder ->
                if (text in folder.items) {
                    // Мягкое предупреждение: в этой папке он уже лежит, ничего не меняем.
                    Toast.makeText(ctx, alreadyMessage, Toast.LENGTH_SHORT).show()
                } else {
                    vm.addToFolder(folder.id, text)
                }
                menuFor = null
            },
            onRemoveFromFolder = {
                state.openFolder?.let { vm.removeFromFolder(it, text) }
                menuFor = null
            },
            onUnfavorite = {
                vm.toggleFavorite(text)
                menuFor = null
            },
            onClose = { menuFor = null },
        )
    }
}

private fun copyToClipboard(ctx: Context, text: String) {
    ctx.getSystemService(ClipboardManager::class.java)
        .setPrimaryClip(ClipData.newPlainText("kaoji", text))
}
