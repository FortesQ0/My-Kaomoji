// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.LaunchedEffect
import app.komodje.ui.components.CardDragGhost
import app.komodje.ui.components.CardDragState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.komodje.R
import app.komodje.domain.Mood
import app.komodje.ui.components.CardMenu
import app.komodje.ui.components.FolderActions
import app.komodje.ui.components.KomojiPanel

/** Главный экран: только список и нижняя панель. Шапка живёт выше, в MainActivity. */
@Composable
fun HomeScreen(vm: HomeViewModel, onCreateOwn: () -> Unit) {
    val state by vm.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    // Какой комоджи сейчас в меню «В папку…» (долгое нажатие в разделе «Любимые») и где он на экране.
    var menuFor by remember { mutableStateOf<String?>(null) }
    var menuAnchor by remember { mutableStateOf(Rect.Zero) }
    // Перетаскивание карточек в папки и режим выбора нескольких (только «Любимые»).
    val dragState = remember { CardDragState() }
    var selection by remember { mutableStateOf<Set<String>?>(null) }
    // Режим выбора живёт только в «Любимых»: ушли из раздела, он выключается.
    LaunchedEffect(state.mood) { if (state.mood != Mood.FAVORITE) selection = null }
    val alreadyAll = stringResource(R.string.folder_already)
    val folderActions = remember(vm) {
        FolderActions(
            onOpen = vm::toggleFolder,
            onCreate = vm::createFolder,
            onRename = vm::renameFolder,
            onDelete = vm::deleteFolder,
            onReorder = vm::reorderFolders,
        )
    }

    Box(Modifier.fillMaxSize()) {
        KomojiPanel(
            state = state,
            onSelect = vm::select,
            onPick = {
                copyToClipboard(ctx, it)
                vm.picked(it)
                vm.copiedFromList(it)
            },
            onHold = vm::toggleFavorite,
            // В каталоге долгое нажатие по-прежнему ставит лайк, в «Любимых» открывает меню рядом с карточкой.
            onHoldAt = { text, bounds ->
                if (state.mood == Mood.FAVORITE) {
                    menuAnchor = bounds
                    menuFor = text
                } else {
                    vm.toggleFavorite(text)
                }
            },
            feedback = stringResource(R.string.copied),
            modifier = Modifier.fillMaxSize(),
            onFavorite = vm::toggleFavorite,
            onFilter = vm::toggleFilter,
            onQuery = vm::setQuery,
            folderActions = folderActions,
            scrollStart = vm::scrollFor,
            onScrolled = vm::rememberScroll,
            onCreateOwn = onCreateOwn,
            onRoll = vm::rollDice,
            dragState = dragState,
            selection = selection,
            onSelectToggle = { t ->
                val cur = selection ?: emptySet()
                selection = if (t in cur) cur - t else cur + t
            },
            onSelectionClose = { selection = null },
            onDragBegin = {
                menuFor = null
                dragState.count = selection?.size ?: 1
            },
            onCardDrop = { text, folderId ->
                val folder = state.folders.firstOrNull { it.id == folderId }
                val sel = selection
                val texts = if (sel != null && text in sel) sel.toList() else listOf(text)
                if (folder != null) {
                    val fresh = texts.filter { it !in folder.items }
                    fresh.forEach { vm.addToFolder(folderId, it) }
                    if (fresh.isEmpty()) Toast.makeText(ctx, alreadyAll, Toast.LENGTH_SHORT).show()
                }
                if (sel != null) selection = null
            },
        )
        // Карточка в руке рисуется поверх всего: выше списка, ряда папок и нижней панели.
        CardDragGhost(dragState)
    }

    menuFor?.let { text ->
        val alreadyMessage = stringResource(R.string.folder_already)
        CardMenu(
            text = text,
            anchor = menuAnchor,
            folders = state.folders,
            openFolder = state.openFolder,
            isFavorite = text in state.favorites,
            isPinned = text in state.pinned,
            onTogglePin = {
                vm.togglePin(text)
                menuFor = null
            },
            onAddTo = { folder ->
                if (text in folder.items) {
                    // Мягкое предупреждение: в этой папке он уже лежит, ничего не меняем.
                    Toast.makeText(ctx, alreadyMessage, Toast.LENGTH_SHORT).show()
                } else {
                    vm.addToFolder(folder.id, text)
                }
                menuFor = null
            },
            onRemoveFromFolder = {
                state.openFolder?.let { vm.removeFromFolder(it, text) }
                menuFor = null
            },
            onUnfavorite = {
                vm.toggleFavorite(text)
                menuFor = null
            },
            onSelectMultiple = {
                selection = setOf(text)
                menuFor = null
            },
            onClose = { menuFor = null },
        )
    }
}

internal fun copyToClipboard(ctx: Context, text: String) {
    ctx.getSystemService(ClipboardManager::class.java)
        .setPrimaryClip(ClipData.newPlainText("kaoji", text))
}
