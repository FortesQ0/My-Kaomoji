// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.ui.components

import androidx.compose.ui.graphics.vector.ImageVector
import app.komodje.R
import app.komodje.domain.Mood

/** label: полное название (для озвучки), tab: короткая подпись под значком в нижней панели. */
data class Category(val mood: Mood, val icon: ImageVector, val label: Int, val tab: Int)

val Categories: List<Category> = listOf(
    Category(Mood.FAVORITE, KomojeIcons.Favorite, R.string.mood_favorite, R.string.tab_favorite),
    Category(Mood.HAPPY, KomojeIcons.Happy, R.string.mood_happy, R.string.tab_happy),
    Category(Mood.SAD, KomojeIcons.Sad, R.string.mood_sad, R.string.tab_sad),
    Category(Mood.NEUTRAL, KomojeIcons.Neutral, R.string.mood_neutral, R.string.tab_neutral),
    Category(Mood.ANGRY, KomojeIcons.Angry, R.string.mood_angry, R.string.tab_angry),
    Category(Mood.TENDER, KomojeIcons.Tender, R.string.mood_tender, R.string.tab_tender),
)
