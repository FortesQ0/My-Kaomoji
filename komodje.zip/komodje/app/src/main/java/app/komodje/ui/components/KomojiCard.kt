package app.komodje.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.komodje.ui.theme.LeafShape
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.Onest
import kotlinx.coroutines.delay

/**
 * Строка-карточка на всю ширину, сердечко справа.
 * Тап по карточке = действие (копировать / вставить). Тап по сердцу или удержание карточки = любимое.
 * Комоджи рисуем системным шрифтом: в Onest нет этих символов, fallback стабильнее.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun KomojiCard(
    text: String,
    favorite: Boolean,
    feedback: String,
    onTap: () -> Unit,
    onHold: () -> Unit,
    onFavorite: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val p = LocalPalette.current
    val haptic = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    var flash by remember { mutableStateOf(false) }

    LaunchedEffect(flash) {
        if (flash) {
            delay(900)
            flash = false
        }
    }

    // Сердце «подпрыгивает» только при добавлении, не при первом показе карточки.
    val pop = remember { Animatable(1f) }
    var first by remember { mutableStateOf(true) }
    LaunchedEffect(favorite) {
        if (first) {
            first = false
        } else if (favorite) {
            pop.snapTo(0.55f)
            pop.animateTo(1f, spring(dampingRatio = 0.35f, stiffness = 380f))
        }
    }

    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.97f else 1f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 500f),
        label = "scale",
    )
    val bg by animateColorAsState(if (flash) p.accent else p.card, tween(220), label = "bg")
    val fg by animateColorAsState(if (flash) p.onAccent else p.ink, tween(220), label = "fg")

    Row(
        modifier
            .fillMaxWidth()
            .heightIn(min = 68.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(LeafShape)
            .background(bg)
            .combinedClickable(
                interactionSource = interaction,
                indication = null,
                onClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    flash = true
                    onTap()
                },
                onLongClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onHold()
                },
            ),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = text,
            color = fg,
            fontSize = 22.sp,
            maxLines = 2,
            modifier = Modifier
                .weight(1f)
                .padding(start = 24.dp, top = 14.dp, bottom = 14.dp, end = 8.dp),
        )
        if (flash) {
            Text(
                feedback,
                color = fg,
                fontFamily = Onest,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp,
                modifier = Modifier.padding(end = 24.dp),
            )
        } else {
            Box(
                Modifier
                    .padding(end = 10.dp)
                    .size(48.dp)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                    ) {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onFavorite()
                    },
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = if (favorite) KomojeIcons.Favorite else KomojeIcons.HeartOutline,
                    contentDescription = null,
                    tint = if (favorite) p.heart else p.muted,
                    modifier = Modifier
                        .size(27.dp)
                        .graphicsLayer { scaleX = pop.value; scaleY = pop.value },
                )
            }
        }
    }
}
