package app.komodje.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.komodje.ui.theme.LeafShape
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.accentBrush
import app.komodje.ui.theme.cardBrush
import kotlinx.coroutines.delay

/**
 * Строка-карточка на всю ширину (~56dp, как в mymoji), сердечко справа.
 * Тап по карточке = действие (копировать / вставить). Тап по сердцу или удержание = любимое.
 * Комоджи рисуем системным шрифтом: в Onest нет этих символов.
 *
 * Копирование: цвет вспыхивает и плавно гаснет, сердечко на миг превращается в галочку,
 * а родитель получает точку старта для звёздочек. Анимации читаются только при рисовании.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun KomojiCard(
    text: String,
    favorite: Boolean,
    feedback: String,
    onTap: () -> Unit,
    /** Долгое нажатие; передаёт границы карточки на экране (откуда выпрыгивает меню). */
    onHold: (Rect) -> Unit,
    onFavorite: () -> Unit,
    onCopied: (Offset) -> Unit,
    modifier: Modifier = Modifier,
    /** «Хит дня»: тонкая рамка цвета темы. */
    highlight: Boolean = false,
    /** Закреплено в «Любимых»: маленькая скрепка в углу. */
    pinned: Boolean = false,
    /** Режим выбора нескольких карточек: вместо сердечка кружок, тап отмечает. */
    selecting: Boolean = false,
    selected: Boolean = false,
    onSelectToggle: () -> Unit = {},
    /** Перетаскивание в папки (только «Любимые»). null: выключено, удержание сразу открывает меню. */
    dragState: CardDragState? = null,
    /** Начали тянуть: меню карточки надо убрать. */
    onDragBegin: () -> Unit = {},
    /** Отпустили над папкой с этим id. */
    onDragDrop: (String) -> Unit = {},
) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val buzz = rememberBuzz()
    val density = LocalDensity.current
    val interaction = remember { MutableInteractionSource() }
    val view = LocalView.current
    val flashBrush = remember(p) { p.accentBrush() }
    val cardFill = remember(p) { p.cardBrush() }
    val coords = remember { arrayOfNulls<LayoutCoordinates>(1) }
    // Нажатия сразу после перетаскивания игнорируем: иначе отпускание скопировало бы карточку.
    var ignoreClickUntil by remember { mutableLongStateOf(0L) }
    var moved by remember { mutableFloatStateOf(0f) }
    var lifted by remember { mutableStateOf(false) }
    val liftAnim by animateFloatAsState(
        targetValue = if (lifted) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 520f),
        label = "cardLift",
    )
    val slop = with(density) { 8.dp.toPx() }
    val selectingState by rememberUpdatedState(selecting)
    val selectedState by rememberUpdatedState(selected)
    val onHoldState by rememberUpdatedState(onHold)
    val onSelectToggleState by rememberUpdatedState(onSelectToggle)
    val onDragBeginState by rememberUpdatedState(onDragBegin)
    val onDragDropState by rememberUpdatedState(onDragDrop)
    val beingDragged = dragState != null && dragState.text == text
    // Место, откуда взяли карточку, мягко бледнеет и так же мягко возвращается.
    val dragAlpha by animateFloatAsState(
        targetValue = if (beingDragged) 0.35f else 1f,
        animationSpec = tween(160),
        label = "cardDragAlpha",
    )
    // Центр карточки в корне окна: сюда она возвращается, если отпустили мимо папки.
    val originCenter: () -> Offset = {
        coords[0]?.let { c -> c.positionInRoot() + Offset(c.size.width / 2f, c.size.height / 2f) } ?: Offset.Zero
    }
    // Карточку убрали из списка посреди жеста: убираем и «призрак», чтобы он не завис на экране.
    androidx.compose.runtime.DisposableEffect(Unit) {
        onDispose { if (dragState != null && dragState.text == text) dragState.reset() }
    }
    // Без перетаскивания (каталог, клавиатура) удержание сразу отдаёт карточку родителю.
    val plainHold: () -> Unit = {
        buzz()
        onHold(coords[0]?.screenBounds(view) ?: Rect.Zero)
    }

    // Вспышка: мгновенно полная, короткая выдержка, затем плавное угасание.
    val flash = remember { Animatable(0f) }
    var copyTick by remember { mutableIntStateOf(0) }
    LaunchedEffect(copyTick) {
        if (copyTick > 0) {
            flash.snapTo(1f)
            delay(450)
            flash.animateTo(0f, tween(950, easing = FastOutSlowInEasing))
        }
    }

    // Сердце «подпрыгивает» только при добавлении, не при первом показе карточки.
    val pop = remember { Animatable(1f) }
    var first by remember { mutableIntStateOf(0) }
    LaunchedEffect(favorite) {
        if (first == 0) {
            first = 1
        } else if (favorite) {
            pop.snapTo(0.55f)
            pop.animateTo(1f, spring(dampingRatio = 0.35f, stiffness = 380f))
        }
    }

    Row(
        modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .onGloballyPositioned { coords[0] = it }
            .graphicsLayer {
                // Поднятая карточка чуть вырастает; та, что уехала в «призрак», бледнеет на месте.
                val sc = 1f + 0.03f * liftAnim
                scaleX = sc
                scaleY = sc
                alpha = dragAlpha
            }
            .pressScale(interaction)
            .softShadow(LeafShape)
            .clip(LeafShape)
            .background(cardFill)
            .then(
                if (highlight || selected) Modifier.border(1.5.dp, p.accentDeep.copy(alpha = 0.6f), LeafShape) else Modifier,
            )
            .drawBehind { drawRect(flashBrush, alpha = flash.value) }
            .combinedClickable(
                interactionSource = interaction,
                indication = null,
                onClick = {
                    if (System.nanoTime() < ignoreClickUntil) return@combinedClickable
                    if (selecting) {
                        tick()
                        onSelectToggle()
                        return@combinedClickable
                    }
                    tick()
                    copyTick++
                    onTap()
                    coords[0]?.let { c ->
                        val pos = c.positionInRoot()
                        with(density) {
                            onCopied(Offset(pos.x + c.size.width - 28.dp.toPx(), pos.y + c.size.height / 2f))
                        }
                    }
                },
                onLongClick = if (dragState == null) plainHold else null,
            )
            .then(
                if (dragState == null) Modifier else Modifier.pointerInput(text) {
                    var grabAt = Offset.Zero
                    detectDragGesturesAfterLongPress(
                        onDragStart = { startAt ->
                            grabAt = startAt
                            buzz()
                            moved = 0f
                            lifted = true
                            // Как у папок: карточка приподнялась, и меню сразу рядом с ней. Потащили: меню уходит.
                            // В режиме выбора меню не нужно: карточка просто попадает в отмеченные.
                            if (selectingState) {
                                if (!selectedState) onSelectToggleState()
                            } else {
                                onHoldState(coords[0]?.screenBounds(view) ?: Rect.Zero)
                            }
                        },
                        onDrag = { change, amount ->
                            change.consume()
                            moved += kotlin.math.abs(amount.x) + kotlin.math.abs(amount.y)
                            if (moved >= slop) {
                                val pos = (coords[0]?.positionInRoot() ?: Offset.Zero) + change.position
                                if (dragState.text == null && dragState.release == null) {
                                    // Начали тянуть: запоминаем, как выглядит карточка и за какое место её взяли.
                                    dragState.cardSize = coords[0]?.size ?: androidx.compose.ui.unit.IntSize.Zero
                                    dragState.grab = grabAt
                                    dragState.cardDensity = density
                                    dragState.pos = pos
                                    dragState.hover = null
                                    dragState.text = text
                                    onDragBeginState()
                                }
                                if (dragState.text == text && dragState.release == null) {
                                    dragState.pos = pos
                                    val over = dragState.folderAt(pos)
                                    if (over != dragState.hover) {
                                        // Палец зашёл на папку или сошёл с неё: лёгкий отклик.
                                        if (over != null) tick()
                                        dragState.hover = over
                                    }
                                }
                            }
                        },
                        onDragEnd = {
                            ignoreClickUntil = System.nanoTime() + 250_000_000L
                            lifted = false
                            if (dragState.text == text && dragState.release == null) {
                                val target = dragState.hover
                                // Отпустили: «призрак» сам упадёт в папку или вернётся, а в папку карточка ляжет, когда долетит.
                                dragState.release = DragRelease(
                                    folder = target,
                                    backCenter = originCenter(),
                                    commit = { if (target != null) onDragDropState(target) },
                                )
                            }
                        },
                        onDragCancel = {
                            ignoreClickUntil = System.nanoTime() + 250_000_000L
                            lifted = false
                            if (dragState.text == text && dragState.release == null) {
                                dragState.release = DragRelease(folder = null, backCenter = originCenter(), commit = {})
                            }
                        },
                    )
                },
            ),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.weight(1f)) {
            Text(
                text = text,
                color = lerp(p.ink, p.onAccent, flash.value),
                fontSize = 20.sp,
                lineHeight = 26.sp,
                maxLines = 2,
                modifier = Modifier.padding(start = 20.dp, top = 12.dp, bottom = 12.dp, end = 6.dp),
            )
        }
        // Скрепка стоит слева от сердца, на одном уровне и того же размера (24dp).
        if (pinned) {
            Icon(
                imageVector = KomojeIcons.Pin,
                contentDescription = null,
                tint = lerp(p.accentDeep, p.onAccent, flash.value),
                modifier = Modifier.size(24.dp),
            )
        }
        Box(
            Modifier
                .size(width = 40.dp, height = 48.dp)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                ) {
                    if (selecting) {
                        tick()
                        onSelectToggle()
                    } else {
                        buzz()
                        onFavorite()
                    }
                },
            contentAlignment = Alignment.Center,
        ) {
            if (selecting) {
                // Кружок отметки на месте сердечка: пустой тихий или залитый акцентом с галочкой.
                Box(
                    Modifier
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(if (selected) flashBrush else Brush.linearGradient(listOf(p.muted.copy(alpha = 0.2f), p.muted.copy(alpha = 0.2f)))),
                    contentAlignment = Alignment.Center,
                ) {
                    if (selected) {
                        Icon(KomojeIcons.Check, null, tint = p.onAccent, modifier = Modifier.size(18.dp))
                    }
                }
            }
            Icon(
                imageVector = if (favorite) KomojeIcons.Favorite else KomojeIcons.HeartOutline,
                contentDescription = null,
                tint = if (favorite) p.heart else p.muted,
                modifier = Modifier
                    .size(24.dp)
                    .graphicsLayer {
                        // Сердце возвращается только после того, как галочка погасла: вместе их не видно.
                        alpha = if (selecting) 0f else ((0.4f - flash.value) / 0.4f).coerceIn(0f, 1f)
                        scaleX = pop.value
                        scaleY = pop.value
                    },
            )
            Icon(
                imageVector = KomojeIcons.Check,
                contentDescription = feedback,
                tint = p.onAccent,
                modifier = Modifier
                    .size(22.dp)
                    .graphicsLayer { alpha = if (selecting) 0f else ((flash.value - 0.5f) / 0.5f).coerceIn(0f, 1f) },
            )
        }
    }
}
