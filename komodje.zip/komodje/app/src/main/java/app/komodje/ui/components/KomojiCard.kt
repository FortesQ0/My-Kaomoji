package app.komodje.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.komodje.ui.theme.LeafShape
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.accentBrush
import app.komodje.ui.theme.cardBrush
import kotlinx.coroutines.delay

/**
 * Строка-карточка на всю ширину (~56dp, как в mymoji), сердечко справа.
 * Тап по карточке = действие (копировать / вставить). Тап по сердцу или удержание = любимое.
 * Комоджи рисуем системным шрифтом: в Onest нет этих символов.
 *
 * Копирование: цвет вспыхивает и плавно гаснет, сердечко на миг превращается в галочку,
 * а родитель получает точку старта для звёздочек. Анимации читаются только при рисовании.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun KomojiCard(
    text: String,
    favorite: Boolean,
    feedback: String,
    onTap: () -> Unit,
    onHold: () -> Unit,
    onFavorite: () -> Unit,
    onCopied: (Offset) -> Unit,
    modifier: Modifier = Modifier,
    /** «Хит дня»: тонкая рамка цвета темы. */
    highlight: Boolean = false,
) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val buzz = rememberBuzz()
    val density = LocalDensity.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val flashBrush = remember(p) { p.accentBrush() }
    val cardFill = remember(p) { p.cardBrush() }
    val coords = remember { arrayOfNulls<LayoutCoordinates>(1) }

    // Вспышка: мгновенно полная, короткая выдержка, затем плавное угасание.
    val flash = remember { Animatable(0f) }
    var copyTick by remember { mutableIntStateOf(0) }
    LaunchedEffect(copyTick) {
        if (copyTick > 0) {
            flash.snapTo(1f)
            delay(450)
            flash.animateTo(0f, tween(950, easing = FastOutSlowInEasing))
        }
    }

    // Сердце «подпрыгивает» только при добавлении, не при первом показе карточки.
    val pop = remember { Animatable(1f) }
    var first by remember { mutableIntStateOf(0) }
    LaunchedEffect(favorite) {
        if (first == 0) {
            first = 1
        } else if (favorite) {
            pop.snapTo(0.55f)
            pop.animateTo(1f, spring(dampingRatio = 0.35f, stiffness = 380f))
        }
    }

    val press = animateFloatAsState(
        targetValue = if (pressed) 0.96f else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 520f),
        label = "press",
    )

    Row(
        modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .onGloballyPositioned { coords[0] = it }
            .graphicsLayer { scaleX = press.value; scaleY = press.value }
            .clip(LeafShape)
            .background(cardFill)
            .then(
                if (highlight) Modifier.border(1.5.dp, p.accentDeep.copy(alpha = 0.6f), LeafShape) else Modifier,
            )
            .drawBehind { drawRect(flashBrush, alpha = flash.value) }
            .combinedClickable(
                interactionSource = interaction,
                indication = null,
                onClick = {
                    tick()
                    copyTick++
                    onTap()
                    coords[0]?.let { c ->
                        val pos = c.positionInRoot()
                        with(density) {
                            onCopied(Offset(pos.x + c.size.width - 28.dp.toPx(), pos.y + c.size.height / 2f))
                        }
                    }
                },
                onLongClick = {
                    buzz()
                    onHold()
                },
            ),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = text,
            color = lerp(p.ink, p.onAccent, flash.value),
            fontSize = 20.sp,
            lineHeight = 26.sp,
            maxLines = 2,
            modifier = Modifier
                .weight(1f)
                .padding(start = 20.dp, top = 12.dp, bottom = 12.dp, end = 6.dp),
        )
        Box(
            Modifier
                .size(width = 40.dp, height = 48.dp)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                ) {
                    buzz()
                    onFavorite()
                },
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = if (favorite) KomojeIcons.Favorite else KomojeIcons.HeartOutline,
                contentDescription = null,
                tint = if (favorite) p.heart else p.muted,
                modifier = Modifier
                    .size(24.dp)
                    .graphicsLayer {
                        alpha = 1f - flash.value
                        scaleX = pop.value
                        scaleY = pop.value
                    },
            )
            Icon(
                imageVector = KomojeIcons.Check,
                contentDescription = feedback,
                tint = p.onAccent,
                modifier = Modifier
                    .size(22.dp)
                    .graphicsLayer { alpha = flash.value },
            )
        }
    }
}
