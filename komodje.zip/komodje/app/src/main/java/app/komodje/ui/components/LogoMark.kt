package app.komodje.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.komodje.domain.AccentTheme
import app.komodje.ui.theme.LocalAccentTheme
import app.komodje.ui.theme.LocalPalette

/**
 * Логотип приложения: облачко с глазками-галочками и звёздочкой на градиентном «листе».
 * Фон, облачко и глаза берутся из палитры выбранной темы, а у «Молока» фон голографический.
 */
@Composable
fun LogoMark(
    size: Dp = 38.dp,
    modifier: Modifier = Modifier,
) {
    val p = LocalPalette.current
    val milk = LocalAccentTheme.current == AccentTheme.MILK
    val shape = RoundedCornerShape(
        topStartPercent = 39, topEndPercent = 14, bottomEndPercent = 39, bottomStartPercent = 14,
    )
    val cloud = if (milk) Color.White else lerp(Color.White, p.accent, 0.25f)
    val bgStart = lerp(p.accentDeep, Color.White, 0.2f)
    val bgEnd = p.heart
    val eyes = if (milk) lerp(p.ink, Color(0xFF4A3F66), 0.5f) else p.badge
    Canvas(modifier.size(size).clip(shape)) {
        val w = this.size.minDimension
        if (milk) drawHolographic(w) else {
            drawRect(Brush.linearGradient(listOf(bgStart, bgEnd), Offset.Zero, Offset(w, w)))
        }
        val s = w / 1080f
        withTransform({ scale(s, s, pivot = Offset.Zero) }) {
            // Мягкая тень под облачком, чтобы белое не терялось на светлом фоне.
            withTransform({ translate(0f, 16f) }) { drawPath(LogoArt.body, eyes.copy(alpha = 0.2f)) }
            drawPath(LogoArt.body, cloud)
            val stroke = Stroke(width = LogoArt.EYE_WIDTH, cap = StrokeCap.Round, join = StrokeJoin.Round)
            LogoArt.eyes.forEach { eye ->
                val path = Path().apply {
                    moveTo(eye[0].first, eye[0].second)
                    eye.drop(1).forEach { lineTo(it.first, it.second) }
                }
                drawPath(path, eyes, style = stroke)
            }
            drawPath(
                LogoArt.star,
                Brush.linearGradient(
                    listOf(Color(0xFFFFD23F), Color(0xFFFFAE00)),
                    Offset(800f, 160f),
                    Offset(960f, 440f),
                ),
            )
        }
    }
}

/** Голографический перламутр: серебристая основа и мягкие цветные переливы (как в иконке «Молока»). */
fun DrawScope.drawHolographic(w: Float) {
    drawRect(
        Brush.linearGradient(
            listOf(Color(0xFFEDEFF7), Color(0xFFC6CCE0), Color(0xFFF4F0FA)),
            Offset.Zero,
            Offset(w, w),
        ),
    )
    fun blob(cx: Float, cy: Float, r: Float, c: Color) = drawRect(
        Brush.radialGradient(listOf(c, c.copy(alpha = 0f)), Offset(w * cx, w * cy), w * r),
    )
    blob(0.15f, 0.2f, 0.75f, Color(0xB0FFB8E2))
    blob(0.9f, 0.3f, 0.7f, Color(0xA8A8E8FF))
    blob(0.45f, 1.0f, 0.8f, Color(0xA0B8FFD6))
    blob(0.95f, 0.9f, 0.55f, Color(0x80D8B8FF))
    drawRect(
        Brush.linearGradient(
            listOf(Color.Transparent, Color(0x70FFFFFF), Color.Transparent),
            Offset.Zero,
            Offset(w, w),
        ),
    )
}
