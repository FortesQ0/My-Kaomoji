package app.komodje.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.komodje.R

/** Логотип приложения (кролик My Kaomoji): та же картинка, что и на иконке, в «листовой» рамке. */
@Composable
fun LogoMark(
    size: Dp = 38.dp,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(
        topStartPercent = 39, topEndPercent = 14, bottomEndPercent = 39, bottomStartPercent = 14,
    )
    Image(
        painter = painterResource(R.drawable.logo_mark),
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = modifier.size(size).clip(shape),
    )
}
