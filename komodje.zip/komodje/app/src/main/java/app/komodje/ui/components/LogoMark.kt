package app.komodje.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.komodje.ui.theme.LocalPalette

/**
 * Логотип приложения: кролик на градиентном «листе». Фон, тело и глаза берутся из палитры выбранной
 * темы, поэтому логотип сочетается с любым цветом (как и иконка на телефоне).
 */
@Composable
fun LogoMark(
    size: Dp = 38.dp,
    modifier: Modifier = Modifier,
) {
    val p = LocalPalette.current
    val shape = RoundedCornerShape(
        topStartPercent = 39, topEndPercent = 14, bottomEndPercent = 39, bottomStartPercent = 14,
    )
    val bodyColor = lerp(Color.White, p.accent, 0.25f)
    val bgStart = lerp(p.accentDeep, Color.White, 0.2f)
    val bgEnd = p.heart
    Canvas(modifier.size(size).clip(shape)) {
        val w = this.size.minDimension
        drawRect(Brush.linearGradient(listOf(bgStart, bgEnd), Offset.Zero, Offset(w, w)))
        val s = w / 1080f
        withTransform({ scale(s, s, pivot = Offset.Zero) }) {
            drawPath(LogoArt.body, bodyColor)
            val stroke = Stroke(width = 16f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            LogoArt.eyes.forEach { eye ->
                val path = Path().apply {
                    moveTo(eye[0].first, eye[0].second)
                    eye.drop(1).forEach { lineTo(it.first, it.second) }
                }
                drawPath(path, p.badge, style = stroke)
            }
            drawPath(LogoArt.star, Color(0xFFFFC21A))
        }
    }
}
