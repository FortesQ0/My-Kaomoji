package app.komodje.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.komodje.ui.theme.LocalPalette

/** Листок с лицом: те же пропорции, что и у иконки приложения. */
@Composable
fun LogoMark(
    size: Dp = 38.dp,
    modifier: Modifier = Modifier,
    leaf: Color = LocalPalette.current.badge,
    face: Color = LocalPalette.current.accent,
) {
    val shape = RoundedCornerShape(
        topStartPercent = 39, topEndPercent = 14, bottomEndPercent = 39, bottomStartPercent = 14,
    )
    Canvas(modifier.size(size).clip(shape).background(leaf)) {
        val w = this.size.width
        val h = this.size.height
        val stroke = Stroke(width = w * 0.079f, cap = StrokeCap.Round)
        val eye = Size(w * 0.179f, h * 0.179f)
        drawArc(face, 180f, 180f, false, Offset(w * 0.214f, h * 0.304f), eye, style = stroke)
        drawArc(face, 180f, 180f, false, Offset(w * 0.607f, h * 0.304f), eye, style = stroke)
        drawArc(
            face, 0f, 180f, false,
            Offset(w * 0.304f, h * 0.446f), Size(w * 0.393f, h * 0.321f), style = stroke,
        )
    }
}
