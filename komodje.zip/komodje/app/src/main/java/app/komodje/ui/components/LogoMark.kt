package app.komodje.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.komodje.domain.AccentTheme
import app.komodje.ui.theme.LocalAccentTheme
import app.komodje.ui.theme.LocalPalette

/**
 * Логотип приложения: облачко с глазками-галочками и звёздочкой на градиентном «листе».
 * Фон, облачко и глаза берутся из палитры выбранной темы, а у «Молока» фон голографический.
 */
@Composable
fun LogoMark(
    size: Dp = 38.dp,
    modifier: Modifier = Modifier,
    /** Логотип стоит прямо на цветной шапке: у «Молока» тогда фона нет, только облачко. */
    onAccentBg: Boolean = false,
) {
    val p = LocalPalette.current
    val milk = LocalAccentTheme.current == AccentTheme.MILK
    val shape = RoundedCornerShape(
        topStartPercent = 39, topEndPercent = 14, bottomEndPercent = 39, bottomStartPercent = 14,
    )
    val bare = milk && onAccentBg
    val cloud = when {
        bare -> p.onAccent
        milk -> Color.White
        else -> lerp(Color.White, p.accent, 0.25f)
    }
    val bgStart = lerp(p.accentDeep, Color.White, 0.2f)
    val bgEnd = p.heart
    val eyes = when {
        bare -> p.accent
        milk -> Color(0xFF2A2435)
        else -> p.badge
    }
    Canvas(modifier.size(size).then(if (bare) Modifier else Modifier.clip(shape))) {
        val w = this.size.minDimension
        when {
            bare -> Unit
            milk -> drawRect(Color(0xFF2A2435))
            else -> drawRect(Brush.linearGradient(listOf(bgStart, bgEnd), Offset.Zero, Offset(w, w)))
        }
        // Логотип чуть меньше кадра, чтобы не липнуть к краям.
        val k = 0.94f
        val s = w / 1080f * k
        withTransform({ translate(w * (1f - k) / 2f, w * (1f - k) / 2f); scale(s, s, pivot = Offset.Zero) }) {
            // Мягкая тень под облачком, чтобы белое не терялось на светлом фоне.
            if (!bare) withTransform({ translate(0f, 16f) }) { drawPath(LogoArt.body, eyes.copy(alpha = 0.2f)) }
            drawPath(LogoArt.body, cloud)
            val stroke = Stroke(width = LogoArt.EYE_WIDTH, cap = StrokeCap.Round, join = StrokeJoin.Round)
            LogoArt.eyes.forEach { eye ->
                val path = Path().apply {
                    moveTo(eye[0].first, eye[0].second)
                    eye.drop(1).forEach { lineTo(it.first, it.second) }
                }
                drawPath(path, eyes, style = stroke)
            }
            drawPath(
                LogoArt.star,
                Brush.linearGradient(
                    listOf(Color(0xFFFFD23F), Color(0xFFFFAE00)),
                    Offset(800f, 160f),
                    Offset(960f, 440f),
                ),
            )
        }
    }
}
