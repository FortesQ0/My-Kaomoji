package app.komodje.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import app.komodje.ui.theme.LocalPalette
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

/**
 * Игральная кость напротив подписи «Коллекция». Тап: кость подпрыгивает, крутится и меняет грань,
 * а в середине броска просит перемешать список (onRoll). Грани рисуем сами (скруглённый квадрат
 * с вырезами-точками), поэтому точки всегда ровные и перекрашиваются вместе с темой.
 */
@Composable
fun DiceButton(onRoll: () -> Unit, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val source = remember { MutableInteractionSource() }
    val scope = rememberCoroutineScope()
    val spin = remember { Animatable(0f) }
    val hop = remember { Animatable(0f) }
    var face by remember { mutableIntStateOf(5) }
    var busy by remember { mutableStateOf(false) }
    val tint = p.accentDeep

    Box(
        modifier
            .pressScale(source, pressedScale = 0.9f)
            .clickable(interactionSource = source, indication = null) {
                if (busy) return@clickable
                busy = true
                tick()
                scope.launch {
                    // Итоговая грань выбирается сразу: на какую упала, на той и остаётся.
                    val result = nextFace(face)
                    launch {
                        hop.snapTo(0f)
                        hop.animateTo(1f, tween(240, easing = FastOutSlowInEasing))
                        hop.animateTo(0f, spring(dampingRatio = 0.55f, stiffness = 420f))
                    }
                    launch {
                        // Грани мелькают, пока кость быстро вертится; итоговая встаёт, пока кость ещё
                        // доворачивается, и после этого уже не меняется.
                        var shown = face
                        for (wait in longArrayOf(80, 85, 95)) {
                            delay(wait)
                            shown = nextFace(shown, avoid = result)
                            face = shown
                        }
                        delay(110)
                        face = result
                    }
                    launch {
                        delay(200)
                        onRoll()
                    }
                    spin.snapTo(0f)
                    spin.animateTo(720f, tween(900, easing = Motion.Ease))
                    spin.snapTo(0f)
                    busy = false
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(
            Modifier
                .size(22.dp)
                .graphicsLayer {
                    rotationZ = spin.value
                    translationY = -hop.value * 9.dp.toPx()
                    val s = 1f + 0.16f * hop.value
                    scaleX = s
                    scaleY = s
                },
        ) { drawDie(face, tint) }
    }
}

private fun nextFace(current: Int, avoid: Int = current): Int {
    var next = Random.nextInt(1, 7)
    while (next == current || next == avoid) next = Random.nextInt(1, 7)
    return next
}

/** Центры точек в сетке 3x3 (0..2 по каждой оси) для каждой грани. */
private fun pips(face: Int): List<Pair<Int, Int>> = when (face) {
    1 -> listOf(1 to 1)
    2 -> listOf(0 to 0, 2 to 2)
    3 -> listOf(0 to 0, 1 to 1, 2 to 2)
    4 -> listOf(0 to 0, 2 to 0, 0 to 2, 2 to 2)
    5 -> listOf(0 to 0, 2 to 0, 1 to 1, 0 to 2, 2 to 2)
    else -> listOf(0 to 0, 2 to 0, 0 to 1, 2 to 1, 0 to 2, 2 to 2)
}

private fun DrawScope.drawDie(face: Int, color: Color) {
    val s = size.minDimension
    val path = Path().apply {
        fillType = PathFillType.EvenOdd
        addRoundRect(RoundRect(Rect(0f, 0f, s, s), CornerRadius(s * 0.28f)))
        val step = s * 0.29f
        val r = s * 0.085f
        pips(face).forEach { (gx, gy) ->
            val c = Offset(s / 2f + (gx - 1) * step, s / 2f + (gy - 1) * step)
            addOval(Rect(c.x - r, c.y - r, c.x + r, c.y + r))
        }
    }
    drawPath(path, color)
}
