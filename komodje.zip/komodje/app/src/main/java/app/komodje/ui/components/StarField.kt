package app.komodje.ui.components

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.unit.dp
import kotlin.random.Random

/**
 * Узор из крупных четырёхконечных звёзд по периметру подложки. Звёзды стоят на самой кромке слева,
 * справа и снизу (их обрезает скругление подложки), поэтому видны только половинки. Над надписью
 * «Хиты дня» звёзд нет: сверху они только в правом углу, над плашкой поиска. К низу чуть гаснут.
 * Только залитые, без обводок и теней. Позиции считаются один раз на размер.
 */
fun Modifier.starField(color: Color, maxAlpha: Float = 0.30f, seed: Int = 11): Modifier = drawWithCache {
    val w = size.width
    val h = size.height
    val rnd = Random(seed)
    val xs = ArrayList<Float>()
    val ys = ArrayList<Float>()
    val rs = ArrayList<Float>()
    val alphas = ArrayList<Float>()
    fun add(x: Float, y: Float, rDp: Float, sz: Float) {
        val fade = 1f - 0.55f * (y / h).coerceIn(0f, 1f)
        xs.add(x)
        ys.add(y)
        rs.add(rDp.dp.toPx())
        alphas.add(maxAlpha * fade * (0.6f + 0.4f * sz))
    }
    val step = 46.dp.toPx()
    // Левая и правая кромки: звёзды чередуются по высоте, центр на самой кромке или чуть внутри.
    var y = 22.dp.toPx()
    var left = true
    while (y < h - 12.dp.toPx()) {
        val sz = rnd.nextFloat()
        val r = 9f + 8f * sz
        val dx = (rnd.nextFloat() * 6f - 1f).dp.toPx()
        add(if (left) dx else w - dx, y, r, sz)
        left = !left
        y += step * (0.8f + 0.5f * rnd.nextFloat())
    }
    // Нижняя кромка.
    var x = 34.dp.toPx()
    while (x < w - 20.dp.toPx()) {
        val sz = rnd.nextFloat()
        add(x, h - (rnd.nextFloat() * 5f).dp.toPx(), 9f + 7f * sz, sz)
        x += 64.dp.toPx() * (0.8f + 0.6f * rnd.nextFloat())
    }
    // Верхний правый угол, над плашкой поиска.
    add(w - 30.dp.toPx(), 2.dp.toPx(), 11f, 0.8f)
    add(w - 86.dp.toPx(), 0f, 8f, 0.4f)
    // Звезда единичного размера: четыре луча, стороны вогнуты к центру.
    val unit = Path().apply {
        moveTo(0f, -1f)
        quadraticBezierTo(0.12f, -0.12f, 1f, 0f)
        quadraticBezierTo(0.12f, 0.12f, 0f, 1f)
        quadraticBezierTo(-0.12f, 0.12f, -1f, 0f)
        quadraticBezierTo(-0.12f, -0.12f, 0f, -1f)
        close()
    }
    onDrawBehind {
        for (i in xs.indices) {
            withTransform({
                translate(xs[i], ys[i])
                scale(rs[i], rs[i], pivot = Offset.Zero)
            }) { drawPath(unit, color.copy(alpha = alphas[i])) }
        }
    }
}
