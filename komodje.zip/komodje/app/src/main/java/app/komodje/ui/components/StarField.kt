package app.komodje.ui.components

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.unit.dp
import kotlin.math.pow
import kotlin.random.Random

/**
 * Едва заметный узор из четырёхконечных звёзд на подложке. Звёзды стоят в шахматном порядке со
 * сдвигами, сверху крупнее и ярче, к низу уменьшаются и гаснут. Только залитые, без обводок и теней.
 * Рисуется под содержимым; позиции считаются один раз на размер.
 */
fun Modifier.starField(color: Color, maxAlpha: Float = 0.16f, seed: Int = 11): Modifier = drawWithCache {
    val cell = 30.dp.toPx()
    val cols = (size.width / cell).toInt() + 1
    val rows = (size.height / cell).toInt() + 1
    val rnd = Random(seed)
    val xs = ArrayList<Float>()
    val ys = ArrayList<Float>()
    val rs = ArrayList<Float>()
    val alphas = ArrayList<Float>()
    for (row in 0 until rows) {
        for (col in 0 until cols) {
            val skip = rnd.nextFloat()
            val jx = rnd.nextFloat()
            val jy = rnd.nextFloat()
            val sz = rnd.nextFloat()
            if (skip < 0.28f) continue
            val shift = if (row % 2 == 0) 0f else 0.5f
            val x = (col + shift + (jx - 0.5f) * 0.5f) * cell
            val y = (row + 0.5f + (jy - 0.5f) * 0.5f) * cell
            if (x < 0f || x > size.width || y > size.height) continue
            val fade = (1f - y / size.height).coerceIn(0f, 1f).pow(1.3f)
            val a = maxAlpha * fade * (0.45f + 0.55f * sz)
            if (a < 0.008f) continue
            xs.add(x)
            ys.add(y)
            rs.add((2.5f + 4.5f * sz).dp.toPx() * (0.65f + 0.35f * fade))
            alphas.add(a)
        }
    }
    // Звезда единичного размера: четыре луча, стороны вогнуты к центру.
    val unit = Path().apply {
        moveTo(0f, -1f)
        quadraticBezierTo(0.12f, -0.12f, 1f, 0f)
        quadraticBezierTo(0.12f, 0.12f, 0f, 1f)
        quadraticBezierTo(-0.12f, 0.12f, -1f, 0f)
        quadraticBezierTo(-0.12f, -0.12f, 0f, -1f)
        close()
    }
    onDrawBehind {
        for (i in xs.indices) {
            withTransform({
                translate(xs[i], ys[i])
                scale(rs[i], rs[i], pivot = Offset.Zero)
            }) { drawPath(unit, color.copy(alpha = alphas[i])) }
        }
    }
}
