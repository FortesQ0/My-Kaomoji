package app.komodje.ui.components

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.unit.dp
import kotlin.random.Random

/**
 * Россыпь четырёхконечных полупрозрачных звёзд по всей подложке: и по краям, и в середине, и под надписью.
 * Звёзды разбросаны случайно, но ровно (не слипаются и не оставляют пустых проплешин), разного размера
 * и прозрачности. Часть звёзд сидит у самой кромки и обрезается скруглением подложки.
 * Яркость идёт градиентом: сильнее к правому верхнему углу, к левому нижнему постепенно гаснет,
 * поэтому надпись и карточки «Хитов дня» не перегружены.
 * Только залитые, без обводок и теней. Позиции считаются один раз на размер и не прыгают.
 */
fun Modifier.starField(color: Color, maxAlpha: Float = 0.26f, seed: Int = 11): Modifier = drawWithCache {
    val w = size.width
    val h = size.height
    val rnd = Random(seed)
    val xs = ArrayList<Float>()
    val ys = ArrayList<Float>()
    val rs = ArrayList<Float>()
    val alphas = ArrayList<Float>()
    val gap = 7.dp.toPx()
    // Сколько звёзд: примерно одна на 3500 dp2, но не меньше десятка.
    val area = (w / 1.dp.toPx()) * (h / 1.dp.toPx())
    val target = (area / 3500f).toInt().coerceIn(10, 60)
    var attempts = 0
    while (xs.size < target && attempts < 900) {
        attempts++
        val sz = rnd.nextFloat()
        // Больше мелких, чем крупных.
        val r = (7f + 14f * sz * sz).dp.toPx()
        // Центр может лежать за кромкой: такая звезда видна половинкой или четвертинкой.
        val x = (rnd.nextFloat() * 1.12f - 0.06f) * w
        val y = (rnd.nextFloat() * 1.10f - 0.05f) * h
        var free = true
        for (i in xs.indices) {
            val dx = xs[i] - x
            val dy = ys[i] - y
            val need = rs[i] + r + gap
            if (dx * dx + dy * dy < need * need) {
                free = false
                break
            }
        }
        if (!free) continue
        // Градиент яркости: 1 у правого верхнего угла, около 0.3 у левого нижнего.
        val t = (0.55f * (1f - x / w) + 0.45f * (y / h)).coerceIn(0f, 1f)
        val fade = 1f - 0.7f * t
        xs.add(x)
        ys.add(y)
        rs.add(r)
        alphas.add(maxAlpha * fade * (0.55f + 0.45f * sz))
    }
    // Звезда единичного размера: четыре луча, стороны вогнуты к центру.
    val unit = Path().apply {
        moveTo(0f, -1f)
        quadraticBezierTo(0.12f, -0.12f, 1f, 0f)
        quadraticBezierTo(0.12f, 0.12f, 0f, 1f)
        quadraticBezierTo(-0.12f, 0.12f, -1f, 0f)
        quadraticBezierTo(-0.12f, -0.12f, 0f, -1f)
        close()
    }
    onDrawBehind {
        for (i in xs.indices) {
            withTransform({
                translate(xs[i], ys[i])
                scale(rs[i], rs[i], pivot = Offset.Zero)
            }) { drawPath(unit, color.copy(alpha = alphas[i])) }
        }
    }
}
