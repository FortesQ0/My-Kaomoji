package app.komodje.domain

import kotlin.random.Random

/**
 * Вкладки-фильтры над списком. Тип считается автоматически по самому тексту каомодзи.
 *
 * Принцип разметки:
 *  - всё, что составляет самого персонажа (лицо, руки, уши, румянец, слёзы, пот), это основа;
 *  - эффект: то, что стоит снаружи и только усиливает эмоцию (звёздочки, сердечки, линии уныния);
 *  - компания: явно два и более персонажа.
 * Один и тот же комоджи может попасть сразу в несколько вкладок.
 */
enum class KomojiFilter {
    ALL, SINGLE, GROUP, EFFECTS;

    fun matches(text: String): Boolean = when (this) {
        ALL -> true
        SINGLE -> analyse(text).faces < 2
        GROUP -> analyse(text).faces >= 2
        EFFECTS -> analyse(text).effects
    }
}

private const val OPENERS = "(（ʕ₍≽૮⊂"
private const val CLOSERS = ")）ʔ₎≼ა⊃"

/** Знаки, которые снаружи лица работают как эффект. Внутри лица (например, глаза-звёзды) это не эффект. */
private const val EFFECT_GLYPHS = "✧♡♥❤❀✿✦★☆♪♫ღ⌘ᶻ˚°※≡=?!#|…¤┻┴━─"

private val LATIN_WORD = Regex("[A-Za-z]{3,}")

private class Shape(val faces: Int, val effects: Boolean)

private fun analyse(text: String): Shape {
    val lastCloser = text.indexOfLast { it in CLOSERS }
    var depth = 0
    var faces = 0
    var prev = ' '
    var hasBrackets = false
    val outside = StringBuilder()
    for ((i, ch) in text.withIndex()) {
        when {
            ch in OPENERS -> {
                hasBrackets = true
                // Новое лицо: скобка на верхнем уровне или вложенная, но не подряд ((( или ⊂(
                if (depth == 0 || prev !in OPENERS) faces++
                depth++
            }
            ch in CLOSERS -> {
                hasBrackets = true
                if (depth > 0) depth--
            }
            depth == 0 || (lastCloser >= 0 && i > lastCloser) -> outside.append(ch)
        }
        if (!ch.isWhitespace()) prev = ch
    }

    if (!hasBrackets) {
        // Лицо без скобок: эффектом считается только хвост вроде «...» или «?» после пробела.
        val trimmed = text.trimEnd()
        val tail = trimmed.substringAfterLast(' ')
        val tailEffect = trimmed.contains(' ') && tail.isNotEmpty() && tail.all { it in ".…?!ᶻ" }
        return Shape(1, tailEffect)
    }

    val out = outside.toString()
    val effects = out.any { it in EFFECT_GLYPHS } ||
        out.count { it == '.' } >= 2 ||
        LATIN_WORD.containsMatchIn(out)
    return Shape(faces, effects)
}

const val PICK_COUNT = 4

/**
 * «Хиты дня»: каждый день другая четвёрка из списка. Без сервера: выбор зависит только от
 * даты и самого списка, поэтому в течение дня он не меняется, а на следующий день другой.
 * Если в списке не больше четырёх штук, хитов нет (выделять нечего).
 */
fun dailyPicks(items: List<String>, day: Long, count: Int = PICK_COUNT): List<String> {
    if (items.size <= count) return emptyList()
    val seed = day * 31L + items.size * 7919L + items.first().hashCode()
    return items.shuffled(Random(seed)).take(count)
}
