package app.komodje.keyboard

import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.inputmethod.InputMethodManager
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import app.komodje.KomodjeApp
import app.komodje.R
import app.komodje.ui.HomeViewModel
import app.komodje.ui.components.KomojiPanel
import app.komodje.ui.components.SwitchKey
import app.komodje.ui.theme.KomodjeTheme
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.backgroundBrush

/**
 * Клавиатура-панель: та же KomojiPanel, что и в приложении. Тап вставляет комоджи в поле ввода.
 * Compose в IME требует ручных Lifecycle / SavedState / ViewModelStore owners — отсюда шаблон.
 */
class KomodjeIme : InputMethodService(), LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {

    private val registry = LifecycleRegistry(this)
    private val savedState = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()
    private lateinit var vm: HomeViewModel

    override val lifecycle: Lifecycle get() = registry
    override val savedStateRegistry: SavedStateRegistry get() = savedState.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = store

    override fun onCreate() {
        super.onCreate()
        savedState.performAttach()
        savedState.performRestore(null)
        registry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        val container = (application as KomodjeApp).container
        vm = ViewModelProvider(this, HomeViewModel.factory(container))[HomeViewModel::class.java]
    }

    override fun onCreateInputView(): View {
        window.window?.decorView?.let { decor ->
            decor.setViewTreeLifecycleOwner(this)
            decor.setViewTreeViewModelStoreOwner(this)
            decor.setViewTreeSavedStateRegistryOwner(this)
        }
        if (!registry.currentState.isAtLeast(Lifecycle.State.STARTED)) {
            registry.handleLifecycleEvent(Lifecycle.Event.ON_START)
            registry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
        }
        return ComposeView(this).apply {
            setContent { KomodjeTheme { ImePanel() } }
        }
    }

    override fun onDestroy() {
        registry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        store.clear()
        super.onDestroy()
    }

    @Composable
    private fun ImePanel() {
        val state by vm.state.collectAsStateWithLifecycle()
        val p = LocalPalette.current
        KomojiPanel(
            state = state,
            onSelect = vm::select,
            onPick = { currentInputConnection?.commitText(it, 1) },
            onHold = vm::toggleFavorite,
            feedback = stringResource(R.string.inserted),
            modifier = Modifier
                .fillMaxWidth()
                .height(340.dp)
                .background(p.backgroundBrush())
                .padding(top = 8.dp),
            barLeading = {
                SwitchKey(onClick = {
                    if (!switchToPreviousInputMethod()) {
                        getSystemService(InputMethodManager::class.java).showInputMethodPicker()
                    }
                })
            },
        )
    }
}
