package app.komodje.keyboard

import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import app.komodje.KomodjeApp
import app.komodje.R
import app.komodje.ui.HomeViewModel
import app.komodje.ui.components.KomojiPanel
import app.komodje.ui.components.SwitchKey
import app.komodje.ui.theme.KomodjeTheme
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.backgroundBrush
import app.komodje.ui.theme.isDark

/**
 * Клавиатура-панель: та же KomojiPanel, что и в приложении. Тап вставляет комоджи в поле ввода.
 * Compose в IME требует ручных Lifecycle / SavedState / ViewModelStore owners — отсюда шаблон.
 */
class KomodjeIme : InputMethodService(), LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {

    private val registry = LifecycleRegistry(this)
    private val savedState = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()
    private lateinit var vm: HomeViewModel

    override val lifecycle: Lifecycle get() = registry
    override val savedStateRegistry: SavedStateRegistry get() = savedState.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = store

    override fun onCreate() {
        super.onCreate()
        savedState.performAttach()
        savedState.performRestore(null)
        registry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        val container = (application as KomodjeApp).container
        vm = ViewModelProvider(this, HomeViewModel.factory(container, rememberMood = true))[HomeViewModel::class.java]
    }

    override fun onCreateInputView(): View {
        window.window?.decorView?.let { decor ->
            decor.setViewTreeLifecycleOwner(this)
            decor.setViewTreeViewModelStoreOwner(this)
            decor.setViewTreeSavedStateRegistryOwner(this)
        }
        if (!registry.currentState.isAtLeast(Lifecycle.State.STARTED)) {
            registry.handleLifecycleEvent(Lifecycle.Event.ON_START)
            registry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
        }
        return ComposeView(this).apply {
            setContent {
                val settings = (application as KomodjeApp).container.settings
                val mode by settings.themeMode.collectAsStateWithLifecycle()
                val accent by settings.accent.collectAsStateWithLifecycle()
                KomodjeTheme(dark = mode.isDark(), accent = accent) { ImePanel() }
            }
        }
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        // Быстрый ряд пересобираем при каждом открытии клавиатуры, чтобы он не прыгал во время работы.
        vm.refreshTop()
    }

    override fun onDestroy() {
        registry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        store.clear()
        super.onDestroy()
    }

    @Composable
    private fun ImePanel() {
        val state by vm.state.collectAsStateWithLifecycle()
        val p = LocalPalette.current
        val settings = (application as KomodjeApp).container.settings
        KomojiPanel(
            state = state,
            onSelect = vm::select,
            onPick = { text ->
                currentInputConnection?.commitText(text, 1)
                vm.picked(text)
                // Вставили и сразу вернулись на прошлую клавиатуру (если включено в настройках).
                if (settings.autoReturn.value) switchToPreviousInputMethod()
            },
            onHold = vm::toggleFavorite,
            feedback = stringResource(R.string.inserted),
            modifier = Modifier
                .fillMaxWidth()
                .height(388.dp)
                .background(p.backgroundBrush())
                .padding(top = 8.dp),
            topRow = state.top,
            barLeading = {
                SwitchKey(onClick = {
                    if (!switchToPreviousInputMethod()) {
                        getSystemService(InputMethodManager::class.java).showInputMethodPicker()
                    }
                })
            },
        )
    }
}
