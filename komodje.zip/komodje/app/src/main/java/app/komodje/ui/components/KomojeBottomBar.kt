package app.komodje.ui.components

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.komodje.ui.theme.BadgeRingShape
import app.komodje.ui.theme.BadgeShape
import app.komodje.ui.theme.BarShape
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.Onest

/**
 * Персиковая панель-«лист». Активная вкладка поднимается над ней тёмным листом-значком
 * с вырезом по кольцу и подписью снизу; значок перетекает между вкладками на spring.
 */
@Composable
fun KomojeBottomBar(
    items: List<Category>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val p = LocalPalette.current
    val haptic = LocalHapticFeedback.current
    val barH = 64.dp
    val badge = 62.dp

    BoxWithConstraints(modifier.height(86.dp)) {
        val itemW = maxWidth / items.size
        val x by animateDpAsState(
            targetValue = itemW * selected + (itemW - badge) / 2,
            animationSpec = spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMediumLow),
            label = "badge",
        )

        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(barH)
                .clip(BarShape)
                .background(p.accent)
        )

        Row(Modifier.fillMaxSize()) {
            items.forEachIndexed { i, c ->
                val active = i == selected
                val iconAlpha by animateFloatAsState(if (active) 0f else 1f, tween(180), label = "ia")
                val labelAlpha by animateFloatAsState(if (active) 1f else 0f, tween(240), label = "la")
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                        ) {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onSelect(i)
                        },
                ) {
                    Icon(
                        imageVector = c.icon,
                        contentDescription = stringResource(c.label),
                        tint = p.onAccent.copy(alpha = 0.72f),
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 17.dp)
                            .size(30.dp)
                            .graphicsLayer { alpha = iconAlpha },
                    )
                    Text(
                        text = stringResource(c.label),
                        color = p.onAccent,
                        fontFamily = Onest,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 11.sp,
                        maxLines = 1,
                        softWrap = false,
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 7.dp)
                            .wrapContentWidth(unbounded = true)
                            .graphicsLayer { alpha = labelAlpha },
                    )
                }
            }
        }

        Box(
            Modifier
                .offset(x = x)
                .size(badge)
                .clip(BadgeRingShape)
                .background(p.bgBottom),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                Modifier
                    .size(badge - 8.dp)
                    .clip(BadgeShape)
                    .background(p.badge),
                contentAlignment = Alignment.Center,
            ) {
                Crossfade(targetState = selected, animationSpec = tween(200), label = "badgeIcon") { idx ->
                    Icon(
                        imageVector = items[idx].icon,
                        contentDescription = null,
                        tint = p.accent,
                        modifier = Modifier.size(30.dp),
                    )
                }
            }
        }
    }
}
