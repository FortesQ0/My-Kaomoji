package app.komodje.ui.components

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.material3.Text
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp
import app.komodje.ui.theme.Onest
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import app.komodje.ui.theme.BadgeRingShape
import app.komodje.ui.theme.BadgeShape
import app.komodje.ui.theme.BarShape
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.accentBrush
import app.komodje.ui.theme.badgeBrush
import app.komodje.ui.theme.gradientTint
import app.komodje.ui.theme.onAccentBrush
import app.komodje.ui.theme.onBadgeBrush

/**
 * Персиковая панель-«лист» с градиентом. Активная вкладка поднимается над ней тёмным
 * листом-значком с вырезом по кольцу; значок перетекает между вкладками на spring.
 * Под каждым значком короткая подпись (Избранное, Счастье, Грусть, ...).
 */
@Composable
fun KomojeBottomBar(
    items: List<Category>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val barBrush = remember(p) { p.accentBrush() }
    val badgeFill = remember(p) { p.badgeBrush() }
    val tabBrush = remember(p) { p.onAccentBrush() }
    val activeBrush = remember(p) { p.onBadgeBrush() }
    val barH = 70.dp
    val badge = 62.dp

    BoxWithConstraints(modifier.height(96.dp)) {
        val itemW = maxWidth / items.size
        val x by animateDpAsState(
            targetValue = itemW * selected + (itemW - badge) / 2,
            animationSpec = spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMediumLow),
            label = "badge",
        )

        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(barH)
                .clip(BarShape)
                .background(barBrush)
        )

        Row(Modifier.fillMaxSize()) {
            items.forEachIndexed { i, c ->
                val active = i == selected
                val iconAlpha = animateFloatAsState(if (active) 0f else 1f, tween(160), label = "ia")
                val source = remember { MutableInteractionSource() }
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .pressScale(source, pressedScale = 0.88f)
                        .clickable(
                            interactionSource = source,
                            indication = null,
                        ) {
                            tick()
                            onSelect(i)
                        },
                ) {
                    Column(
                        Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 10.dp, start = 2.dp, end = 2.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Icon(
                            imageVector = c.icon,
                            contentDescription = stringResource(c.label),
                            tint = Color.Black,
                            modifier = Modifier
                                .size(30.dp)
                                .graphicsLayer { alpha = iconAlpha.value * 0.92f }
                                .gradientTint(tabBrush),
                        )
                        Spacer(Modifier.height(3.dp))
                        TabLabel(
                            text = stringResource(c.tab),
                            color = p.onAccent.copy(alpha = if (active) 1f else 0.78f),
                        )
                    }
                }
            }
        }

        Box(
            Modifier
                .offset(x = x)
                .size(badge)
                .clip(BadgeRingShape)
                .background(p.bgBottom),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                Modifier
                    .size(badge - 8.dp)
                    .clip(BadgeShape)
                    .background(badgeFill),
                contentAlignment = Alignment.Center,
            ) {
                Crossfade(targetState = selected, animationSpec = tween(180), label = "badgeIcon") { idx ->
                    Icon(
                        imageVector = items[idx].icon,
                        contentDescription = null,
                        tint = Color.Black,
                        modifier = Modifier.size(30.dp).gradientTint(activeBrush),
                    )
                }
            }
        }
    }
}

/**
 * Короткая подпись под значком: всегда в одну строку, без переносов. Шрифт начинается с 11sp и
 * уменьшается шагами, пока самое длинное слово не поместится в свою ячейку (до 7sp), поэтому на любом
 * языке подпись целая, читаемая и не заезжает на соседние значки.
 */
@Composable
private fun TabLabel(text: String, color: Color) {
    var size by remember(text) { mutableFloatStateOf(11f) }
    var ready by remember(text) { mutableStateOf(false) }
    Text(
        text = text,
        color = color,
        fontFamily = Onest,
        fontWeight = FontWeight.SemiBold,
        fontSize = size.sp,
        lineHeight = 14.sp,
        maxLines = 1,
        softWrap = false,
        overflow = TextOverflow.Clip,
        textAlign = TextAlign.Center,
        onTextLayout = { r ->
            if (!ready) {
                if (r.didOverflowWidth && size > 7f) size = (size - 0.5f).coerceAtLeast(7f) else ready = true
            }
        },
        modifier = Modifier.fillMaxWidth().drawWithContent { if (ready) drawContent() },
    )
}
