// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.ui.theme

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.lerp
import app.komodje.domain.AccentTheme
import app.komodje.domain.ThemeMode

/** Выбранный цвет темы (нужен там, где одной палитры мало: например, голографическое «Молоко»). */
val LocalAccentTheme = compositionLocalOf { AccentTheme.SAKURA }

@Composable
fun ThemeMode.isDark(): Boolean = when (this) {
    ThemeMode.SYSTEM -> isSystemInDarkTheme()
    ThemeMode.LIGHT -> false
    ThemeMode.DARK -> true
}

@Composable
fun KomodjeTheme(
    dark: Boolean = isSystemInDarkTheme(),
    accent: AccentTheme = AccentTheme.SAKURA,
    content: @Composable () -> Unit,
) {
    val p = paletteFor(accent, dark)
    val scheme = if (dark) {
        darkColorScheme(primary = p.accent, onPrimary = p.onAccent, background = p.bgBottom, surface = p.card, onSurface = p.ink)
    } else {
        lightColorScheme(primary = p.accent, onPrimary = p.onAccent, background = p.bgTop, surface = p.card, onSurface = p.ink)
    }
    CompositionLocalProvider(LocalPalette provides p, LocalAccentTheme provides accent) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
