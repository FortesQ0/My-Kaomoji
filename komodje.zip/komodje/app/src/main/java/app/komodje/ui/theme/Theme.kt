// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.ui.theme

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.lerp
import app.komodje.domain.AccentTheme
import app.komodje.domain.ThemeMode

/** Выбранный цвет темы (нужен там, где одной палитры мало: например, голографическое «Молоко»). */
val LocalAccentTheme = compositionLocalOf { AccentTheme.SAKURA }

@Composable
fun ThemeMode.isDark(): Boolean = when (this) {
    ThemeMode.SYSTEM -> isSystemInDarkTheme()
    ThemeMode.LIGHT -> false
    ThemeMode.DARK -> true
}

/**
 * Плавный переход между палитрами через единый прогресс [0→1].
 * Один Animatable<Float> вместо 16 отдельных animateColorAsState — одна инвалидация
 * снэпшота в кадр, нет рваных кадровых пачек.
 */
@Composable
private fun Palette.animated(): Palette {
    val target = this
    val fromState = remember { mutableStateOf(target) }
    val toState   = remember { mutableStateOf(target) }
    val progress  = remember { Animatable(1f) }

    LaunchedEffect(target) {
        if (toState.value == target) return@LaunchedEffect
        // Захватываем текущее визуальное состояние как новый «from»
        fromState.value = lerpPalette(fromState.value, toState.value, progress.value)
        toState.value   = target
        progress.snapTo(0f)
        progress.animateTo(1f, tween(520, easing = FastOutSlowInEasing))
    }

    return lerpPalette(fromState.value, toState.value, progress.value)
}

private fun lerpPalette(a: Palette, b: Palette, t: Float): Palette {
    fun c(ca: androidx.compose.ui.graphics.Color, cb: androidx.compose.ui.graphics.Color) = lerp(ca, cb, t)
    return Palette(
        bgTop      = c(a.bgTop,      b.bgTop),
        bgMid      = c(a.bgMid,      b.bgMid),
        bgBottom   = c(a.bgBottom,   b.bgBottom),
        card       = c(a.card,       b.card),
        cardDeep   = c(a.cardDeep,   b.cardDeep),
        ink        = c(a.ink,        b.ink),
        muted      = c(a.muted,      b.muted),
        accent     = c(a.accent,     b.accent),
        accentDeep = c(a.accentDeep, b.accentDeep),
        onAccent   = c(a.onAccent,   b.onAccent),
        onAccent2  = c(a.onAccent2,  b.onAccent2),
        badge      = c(a.badge,      b.badge),
        badgeDeep  = c(a.badgeDeep,  b.badgeDeep),
        onBadge    = c(a.onBadge,    b.onBadge),
        onBadgeDeep= c(a.onBadgeDeep,b.onBadgeDeep),
        heart      = c(a.heart,      b.heart),
    )
}

@Composable
fun KomodjeTheme(
    dark: Boolean = isSystemInDarkTheme(),
    accent: AccentTheme = AccentTheme.SAKURA,
    content: @Composable () -> Unit,
) {
    val p = paletteFor(accent, dark).animated()
    val scheme = if (dark) {
        darkColorScheme(primary = p.accent, onPrimary = p.onAccent, background = p.bgBottom, surface = p.card, onSurface = p.ink)
    } else {
        lightColorScheme(primary = p.accent, onPrimary = p.onAccent, background = p.bgTop, surface = p.card, onSurface = p.ink)
    }
    CompositionLocalProvider(LocalPalette provides p, LocalAccentTheme provides accent) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
