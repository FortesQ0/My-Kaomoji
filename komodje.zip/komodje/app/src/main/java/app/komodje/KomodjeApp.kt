package app.komodje

import android.app.Application
import app.komodje.data.FavoritesStore
import app.komodje.data.KomojiRepository
import app.komodje.data.SettingsStore

/** Ручной DI: для двух экранов Hilt пока избыточен. */
class AppContainer(app: Application) {
    val repository = KomojiRepository(app)
    val favorites = FavoritesStore(app)
    val settings = SettingsStore(app)
}

class KomodjeApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
