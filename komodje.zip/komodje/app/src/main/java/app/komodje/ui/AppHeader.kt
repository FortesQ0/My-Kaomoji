package app.komodje.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import app.komodje.ui.components.drawSparkle
import app.komodje.ui.components.rememberBuzz
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.komodje.R
import app.komodje.ui.components.KomojeIcons
import app.komodje.ui.components.LogoMark
import app.komodje.ui.components.pressScale
import app.komodje.ui.components.rememberTick
import app.komodje.ui.theme.HeaderShape
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.LogoShape
import app.komodje.ui.theme.Onest
import app.komodje.ui.theme.accentBrush
import app.komodje.ui.theme.badgeBrush

/**
 * Одна общая шапка на все экраны: стоит над сменой экранов и никуда не двигается.
 * Логотип всегда слева. Справа шестерёнка на главном превращается в «назад» на том же месте:
 * при переходе она проворачивается на пол-оборота, и по ходу вращения значок сменяется.
 */
@Composable
fun AppHeader(settingsOpen: Boolean, onAction: () -> Unit) {
    val p = LocalPalette.current
    val fill = remember(p) { p.accentBrush() }
    val rot by animateFloatAsState(
        targetValue = if (settingsOpen) 180f else 0f,
        animationSpec = spring(dampingRatio = 0.7f, stiffness = 260f),
        label = "gearTurn",
    )
    val back = rot >= 90f

    // Пасхалка: несколько быстрых тапов подряд по логотипу и названию, и из логотипа вылетает салют.
    val buzz = rememberBuzz()
    var taps by remember { mutableIntStateOf(0) }
    var lastTap by remember { mutableLongStateOf(0L) }
    var eggSeed by remember { mutableIntStateOf(0) }
    val egg = remember { Animatable(1f) }
    LaunchedEffect(eggSeed) {
        if (eggSeed > 0) {
            egg.snapTo(0f)
            egg.animateTo(1f, tween(1100, easing = LinearOutSlowInEasing))
        }
    }
    var logoCenter by remember { mutableStateOf(Offset.Zero) }
    var canvasRoot by remember { mutableStateOf(Offset.Zero) }
    val sparkColors = remember(p) { listOf(p.heart, p.accentDeep, p.badge, p.onBadgeDeep) }
    val tapSource = remember { MutableInteractionSource() }

    Box(Modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(HeaderShape)
                .background(fill)
                .statusBarsPadding()
                .padding(start = 14.dp, end = 16.dp, top = 8.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(
                Modifier
                    .weight(1f)
                    .clickable(interactionSource = tapSource, indication = null) {
                        val now = System.nanoTime()
                        taps = if (now - lastTap < 600_000_000L) taps + 1 else 1
                        lastTap = now
                        if (taps >= 5 && egg.value >= 1f) {
                            taps = 0
                            buzz()
                            eggSeed++
                        }
                    },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .onGloballyPositioned { c ->
                            val pos = c.positionInRoot()
                            logoCenter = Offset(pos.x + c.size.width / 2f, pos.y + c.size.height / 2f)
                        }
                        .graphicsLayer {
                            // Логотип подпрыгивает в такт салюту.
                            val t = egg.value
                            val k = if (t < 1f) kotlin.math.sin(t * Math.PI.toFloat()) else 0f
                            val sc = 1f + 0.22f * k
                            scaleX = sc
                            scaleY = sc
                            rotationZ = -8f * k
                        },
                ) { LogoMark(size = 36.dp, onAccentBg = true) }
                Spacer(Modifier.width(10.dp))
                AnimatedContent(
                    targetState = settingsOpen,
                    transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(120)) },
                    modifier = Modifier.weight(1f),
                    label = "headerTitle",
                ) { open ->
                    Text(
                        text = stringResource(if (open) R.string.settings_title else R.string.app_name),
                        color = p.onAccent,
                        fontFamily = Onest,
                        fontWeight = FontWeight.Bold,
                        fontSize = 26.sp,
                        letterSpacing = (-0.5).sp,
                        maxLines = 1,
                    )
                }
            }
            LeafButton(onClick = onAction) {
                Icon(
                    imageVector = if (back) KomojeIcons.Back else KomojeIcons.Gear,
                    contentDescription = stringResource(if (settingsOpen) R.string.back else R.string.settings_title),
                    tint = p.onBadge,
                    modifier = Modifier
                        .size(22.dp)
                        .graphicsLayer { rotationZ = if (back) rot - 180f else rot },
                )
            }
        }
        // Салют: два кольца четырёхлучевых звёздочек разлетаются из логотипа и гаснут. Только Canvas.
        Canvas(
            Modifier
                .matchParentSize()
                .onGloballyPositioned { canvasRoot = it.positionInRoot() },
        ) {
            val t = egg.value
            if (t < 1f) {
                val o = logoCenter - canvasRoot
                val ease = 1f - (1f - t) * (1f - t)
                for (ring in 0..1) {
                    val n = if (ring == 0) 8 else 12
                    for (i in 0 until n) {
                        val rad = Math.toRadians((i * 360.0 / n) + ring * 15.0)
                        val dist = (if (ring == 0) 44f else 82f) * density * ease
                        val sz = (if (ring == 0) 7f else 5f) * density * (1f - 0.6f * t)
                        val c = Offset(o.x + (kotlin.math.cos(rad) * dist).toFloat(), o.y + (kotlin.math.sin(rad) * dist).toFloat())
                        rotate(60f * t * (if (i % 2 == 0) 1f else -1f), pivot = c) {
                            drawSparkle(c, sz, sparkColors[(i + ring) % sparkColors.size], (1f - t * t).coerceIn(0f, 1f))
                        }
                    }
                }
            }
        }
    }
}

/** Тёмная кнопка тех же пропорций, что и логотип. На нажатие «проседает» и пружинит назад. */
@Composable
fun LeafButton(onClick: () -> Unit, content: @Composable () -> Unit) {
    val p = LocalPalette.current
    val fill = remember(p) { p.badgeBrush() }
    val source = remember { MutableInteractionSource() }
    val tick = rememberTick()
    Box(
        Modifier
            .size(36.dp)
            .pressScale(source, pressedScale = 0.86f)
            .clip(LogoShape)
            .background(fill)
            .clickable(interactionSource = source, indication = null) {
                tick()
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) { content() }
}
