package app.komodje.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.komodje.R
import app.komodje.ui.components.KomojeIcons
import app.komodje.ui.components.LogoMark
import app.komodje.ui.components.pressScale
import app.komodje.ui.components.rememberTick
import app.komodje.ui.theme.HeaderShape
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.LogoShape
import app.komodje.ui.theme.Onest
import app.komodje.ui.theme.accentBrush
import app.komodje.ui.theme.badgeBrush

/**
 * Одна общая шапка на все экраны: стоит над сменой экранов и никуда не двигается.
 * Логотип всегда слева. Справа шестерёнка на главном превращается в «назад» на том же месте:
 * при переходе она проворачивается на пол-оборота, и по ходу вращения значок сменяется.
 */
@Composable
fun AppHeader(settingsOpen: Boolean, onAction: () -> Unit) {
    val p = LocalPalette.current
    val fill = remember(p) { p.accentBrush() }
    val rot by animateFloatAsState(
        targetValue = if (settingsOpen) 180f else 0f,
        animationSpec = spring(dampingRatio = 0.7f, stiffness = 260f),
        label = "gearTurn",
    )
    val back = rot >= 90f

    Row(
        Modifier
            .fillMaxWidth()
            .clip(HeaderShape)
            .background(fill)
            .statusBarsPadding()
            .padding(start = 14.dp, end = 16.dp, top = 8.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        LogoMark(size = 36.dp)
        Spacer(Modifier.width(10.dp))
        AnimatedContent(
            targetState = settingsOpen,
            transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(120)) },
            modifier = Modifier.weight(1f),
            label = "headerTitle",
        ) { open ->
            Text(
                text = stringResource(if (open) R.string.settings_title else R.string.app_name),
                color = p.onAccent,
                fontFamily = Onest,
                fontWeight = FontWeight.Bold,
                fontSize = 26.sp,
                letterSpacing = (-0.5).sp,
                maxLines = 1,
            )
        }
        LeafButton(onClick = onAction) {
            Icon(
                imageVector = if (back) KomojeIcons.Back else KomojeIcons.Gear,
                contentDescription = stringResource(if (settingsOpen) R.string.back else R.string.settings_title),
                tint = p.onBadge,
                modifier = Modifier
                    .size(22.dp)
                    .graphicsLayer { rotationZ = if (back) rot - 180f else rot },
            )
        }
    }
}

/** Тёмная кнопка тех же пропорций, что и логотип. На нажатие «проседает» и пружинит назад. */
@Composable
fun LeafButton(onClick: () -> Unit, content: @Composable () -> Unit) {
    val p = LocalPalette.current
    val fill = remember(p) { p.badgeBrush() }
    val source = remember { MutableInteractionSource() }
    val tick = rememberTick()
    Box(
        Modifier
            .size(36.dp)
            .pressScale(source, pressedScale = 0.86f)
            .clip(LogoShape)
            .background(fill)
            .clickable(interactionSource = source, indication = null) {
                tick()
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) { content() }
}
