package app.komodje.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import app.komodje.AppContainer
import app.komodje.data.FavoritesStore
import app.komodje.data.KomojiRepository
import app.komodje.data.SettingsStore
import app.komodje.data.UsageStore
import app.komodje.domain.Komoji
import app.komodje.domain.Mood
import app.komodje.domain.topPicks
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HomeState(
    val mood: Mood = Mood.HAPPY,
    val favorites: Set<String> = emptySet(),
    val items: List<Komoji> = emptyList(),
    /** Быстрый ряд над списком (только в клавиатуре): любимые и частые. */
    val top: List<String> = emptyList(),
)

class HomeViewModel(
    private val repository: KomojiRepository,
    private val favoritesStore: FavoritesStore,
    private val usageStore: UsageStore,
    private val settings: SettingsStore,
    private val rememberMood: Boolean,
) : ViewModel() {

    private val selected = MutableStateFlow(if (rememberMood) settings.imeMood() else Mood.HAPPY)
    private val top = MutableStateFlow<List<String>>(emptyList())

    init {
        refreshTop()
    }

    val state: StateFlow<HomeState> = combine(selected, favoritesStore.favorites, top) { mood, favs, topRow ->
        HomeState(
            mood = mood,
            favorites = favs,
            items = if (mood == Mood.FAVORITE) {
                repository.all().filter { it.text in favs }
            } else {
                repository.byMood(mood)
            },
            top = topRow,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeState())

    fun select(mood: Mood) {
        selected.value = mood
        if (rememberMood) viewModelScope.launch { settings.setImeMood(mood) }
    }

    /**
     * Пересобирает быстрый ряд. Вызывается при открытии клавиатуры, а не после каждого тапа:
     * иначе карточки прыгали бы из-под пальца.
     */
    fun refreshTop() {
        viewModelScope.launch {
            val favorites = favoritesStore.favorites.first()
            val counts = usageStore.counts.first()
            top.value = topPicks(repository.all().map { it.text }, favorites, counts, TOP_COUNT)
        }
    }

    /** Комоджи скопирован или вставлен: идёт в счётчик «частых». */
    fun picked(text: String) = usageStore.record(text)

    fun toggleFavorite(text: String) {
        viewModelScope.launch { favoritesStore.toggle(text) }
    }

    companion object {
        private const val TOP_COUNT = 8

        fun factory(container: AppContainer, rememberMood: Boolean = false) = viewModelFactory {
            initializer {
                HomeViewModel(
                    container.repository,
                    container.favorites,
                    container.usage,
                    container.settings,
                    rememberMood,
                )
            }
        }
    }
}
