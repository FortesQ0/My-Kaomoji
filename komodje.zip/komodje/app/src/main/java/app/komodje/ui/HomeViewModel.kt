package app.komodje.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import app.komodje.AppContainer
import app.komodje.data.FavoritesStore
import app.komodje.data.KomojiRepository
import app.komodje.domain.Komoji
import app.komodje.domain.Mood
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HomeState(
    val mood: Mood = Mood.HAPPY,
    val favorites: Set<String> = emptySet(),
    val items: List<Komoji> = emptyList(),
)

class HomeViewModel(
    private val repository: KomojiRepository,
    private val favoritesStore: FavoritesStore,
) : ViewModel() {

    private val selected = MutableStateFlow(Mood.HAPPY)

    val state: StateFlow<HomeState> = combine(selected, favoritesStore.favorites) { mood, favs ->
        HomeState(
            mood = mood,
            favorites = favs,
            items = if (mood == Mood.FAVORITE) {
                repository.all().filter { it.text in favs }
            } else {
                repository.byMood(mood)
            },
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeState())

    fun select(mood: Mood) {
        selected.value = mood
    }

    fun toggleFavorite(text: String) {
        viewModelScope.launch { favoritesStore.toggle(text) }
    }

    companion object {
        fun factory(container: AppContainer) = viewModelFactory {
            initializer { HomeViewModel(container.repository, container.favorites) }
        }
    }
}
