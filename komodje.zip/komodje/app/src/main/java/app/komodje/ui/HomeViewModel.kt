package app.komodje.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import app.komodje.AppContainer
import app.komodje.data.FavoritesStore
import app.komodje.data.FoldersStore
import app.komodje.data.KomojiRepository
import app.komodje.data.SettingsStore
import app.komodje.data.UsageStore
import app.komodje.domain.Folder
import app.komodje.domain.Komoji
import app.komodje.domain.KomojiFilter
import app.komodje.domain.Mood
import app.komodje.domain.dailyPicks
import app.komodje.domain.topPicks
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

data class HomeState(
    val mood: Mood = Mood.HAPPY,
    val favorites: Set<String> = emptySet(),
    val items: List<Komoji> = emptyList(),
    /** Быстрый ряд над списком (только в клавиатуре): любимые и частые. */
    val top: List<String> = emptyList(),
    /** Вкладка-фильтр над списком (только в приложении). */
    val filter: KomojiFilter = KomojiFilter.ALL,
    /** «Хиты дня»: подсвеченные карточки, они же стоят в списке первыми. */
    val picks: Set<String> = emptySet(),
    /** Папки раздела «Любимые» и id открытой папки (если открыта). */
    val folders: List<Folder> = emptyList(),
    val openFolder: String? = null,
)

class HomeViewModel(
    private val repository: KomojiRepository,
    private val favoritesStore: FavoritesStore,
    private val usageStore: UsageStore,
    private val settings: SettingsStore,
    private val foldersStore: FoldersStore,
    private val rememberMood: Boolean,
    /** Вкладки, «Хиты дня» и папки: только в приложении, в клавиатуре порядок обычный. */
    private val richUi: Boolean,
) : ViewModel() {

    private val selected = MutableStateFlow(if (rememberMood) settings.imeMood() else Mood.HAPPY)
    private val filter = MutableStateFlow(KomojiFilter.ALL)
    private val openFolder = MutableStateFlow<String?>(null)
    private val top = MutableStateFlow<List<String>>(emptyList())

    init {
        refreshTop()
    }

    private data class Selection(val mood: Mood, val filter: KomojiFilter, val folderId: String?)

    private val selection = combine(selected, filter, openFolder) { mood, f, folderId ->
        Selection(mood, f, folderId)
    }

    val state: StateFlow<HomeState> = combine(
        selection,
        favoritesStore.favorites,
        top,
        foldersStore.folders,
    ) { sel, favs, topRow, folders ->
        val folder = folders.firstOrNull { it.id == sel.folderId }
        val base: List<Komoji> = when {
            sel.mood == Mood.FAVORITE && folder != null -> folder.items.map(::Komoji)
            sel.mood == Mood.FAVORITE -> repository.all().filter { it.text in favs }
            else -> repository.byMood(sel.mood)
        }
        val filtered = if (sel.filter == KomojiFilter.ALL) base else base.filter { sel.filter.matches(it.text) }

        // «Хиты дня» только в приложении и не в «Любимых»: там список уже собран самим человеком.
        val picks = if (richUi && sel.mood != Mood.FAVORITE) {
            dailyPicks(filtered.map { it.text }, LocalDate.now().toEpochDay())
        } else {
            emptyList()
        }
        val ordered = if (picks.isEmpty()) {
            filtered
        } else {
            val chosen = picks.toSet()
            picks.map(::Komoji) + filtered.filter { it.text !in chosen }
        }

        HomeState(
            mood = sel.mood,
            favorites = favs,
            items = ordered,
            top = topRow,
            filter = sel.filter,
            picks = picks.toSet(),
            folders = folders,
            openFolder = folder?.id,
        )
    }
        // Библиотека большая (десятки тысяч строк): разбор, фильтры и «Хиты дня» считаем не в главном потоке.
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeState())

    fun select(mood: Mood) {
        selected.value = mood
        openFolder.value = null
        if (rememberMood) viewModelScope.launch { settings.setImeMood(mood) }
    }

    fun setFilter(value: KomojiFilter) {
        filter.value = value
    }

    /** Тап по папке: открыть её, а если она уже открыта, закрыть. */
    fun toggleFolder(id: String) {
        openFolder.value = if (openFolder.value == id) null else id
    }

    fun createFolder(name: String) {
        viewModelScope.launch { foldersStore.create(name) }
    }

    fun renameFolder(id: String, name: String) {
        viewModelScope.launch { foldersStore.rename(id, name) }
    }

    fun deleteFolder(id: String) {
        if (openFolder.value == id) openFolder.value = null
        viewModelScope.launch { foldersStore.delete(id) }
    }

    fun addToFolder(folderId: String, text: String) {
        viewModelScope.launch { foldersStore.add(folderId, text) }
    }

    fun removeFromFolder(folderId: String, text: String) {
        viewModelScope.launch { foldersStore.remove(folderId, text) }
    }

    /**
     * Пересобирает быстрый ряд. Вызывается при открытии клавиатуры, а не после каждого тапа:
     * иначе карточки прыгали бы из-под пальца.
     */
    fun refreshTop() {
        viewModelScope.launch {
            val favorites = favoritesStore.favorites.first()
            val counts = usageStore.counts.first()
            top.value = withContext(Dispatchers.Default) {
                topPicks(repository.all().map { it.text }, favorites, counts, TOP_COUNT)
            }
        }
    }

    /** Комоджи скопирован или вставлен: идёт в счётчик «частых». */
    fun picked(text: String) = usageStore.record(text)

    fun toggleFavorite(text: String) {
        viewModelScope.launch { favoritesStore.toggle(text) }
    }

    companion object {
        private const val TOP_COUNT = 8

        fun factory(container: AppContainer, rememberMood: Boolean = false) = viewModelFactory {
            initializer {
                HomeViewModel(
                    container.repository,
                    container.favorites,
                    container.usage,
                    container.settings,
                    container.folders,
                    rememberMood,
                    richUi = !rememberMood,
                )
            }
        }
    }
}
