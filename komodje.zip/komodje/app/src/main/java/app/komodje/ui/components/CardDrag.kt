package app.komodje.ui.components

import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect

/**
 * Состояние перетаскивания карточки из «Любимых» в папку. Живёт на главном экране и общее для карточки,
 * ряда папок и «призрака» под пальцем. Все координаты в системе корня окна.
 */
@Stable
class CardDragState {
    /** Какую карточку тянут (null: ничего не тянут). */
    var text by mutableStateOf<String?>(null)

    /** Сколько карточек едет вместе с ней (в режиме выбора). */
    var count by mutableStateOf(1)

    /** Где сейчас палец. */
    var pos by mutableStateOf(Offset.Zero)

    /** Над какой папкой палец (id) или null. */
    var hover by mutableStateOf<String?>(null)

    /** Границы папок в ряду: заполняет сам ряд. */
    val rects = HashMap<String, Rect>()

    fun folderAt(p: Offset): String? = rects.entries.firstOrNull { it.value.contains(p) }?.key
}
