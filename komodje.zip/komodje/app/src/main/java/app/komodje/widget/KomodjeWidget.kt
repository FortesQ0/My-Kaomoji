// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.widget

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.LocalSize
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionParametersOf
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.updateAll
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxHeight
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextAlign
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import app.komodje.KomodjeApp
import app.komodje.R
import app.komodje.domain.ThemeMode
import app.komodje.domain.topPicks
import app.komodje.ui.theme.paletteFor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val WIDGET_COUNT = 4

private val PickKey = ActionParameters.Key<String>("kaomoji_text")

/** Всё, что нужно для рисования виджета: четыре комоджи и цвета текущей темы приложения. */
internal class WidgetData(
    val picks: List<String>,
    val background: Color,
    val tile: Color,
    val ink: Color,
)

/**
 * Виджет на главный экран: четыре любимых или самых частых комоджи в плитках 2×2.
 * Тап по плитке копирует. Цвета берутся из выбранного в приложении акцента и режима.
 */
class KomodjeWidget : GlanceAppWidget() {

    override val sizeMode: SizeMode = SizeMode.Exact

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val data = loadWidgetData(context)
        provideContent { WidgetContent(data) }
    }
}

class KomodjeWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = KomodjeWidget()
}

internal suspend fun loadWidgetData(context: Context): WidgetData {
    val container = (context.applicationContext as KomodjeApp).container
    val favorites = container.favorites.favorites.first()
    val counts = container.usage.counts.first()
    val picks = topPicks(container.repository.allTexts(), favorites, counts, WIDGET_COUNT)

    val night = (context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
        Configuration.UI_MODE_NIGHT_YES
    val dark = when (container.settings.readThemeMode()) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> night
    }
    val p = paletteFor(container.settings.readAccent(), dark)
    return WidgetData(picks = picks, background = p.accent, tile = p.card, ink = p.ink)
}

@Composable
private fun WidgetContent(data: WidgetData) {
    // Размер шрифта подбираем по ширине плитки и самому длинному комоджи, чтобы все влезли целиком.
    val tileWidthDp = (LocalSize.current.width.value - 16f - 6f) / 2f
    val longest = (data.picks.maxOfOrNull { it.length } ?: 1).coerceAtLeast(1)
    val fontSize = ((tileWidthDp - 12f) / (longest * 0.62f)).coerceIn(11f, 20f)

    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(ColorProvider(data.background))
            .cornerRadius(24.dp)
            .padding(8.dp),
    ) {
        Row(modifier = GlanceModifier.fillMaxWidth().defaultWeight()) {
            Tile(data.picks.getOrNull(0).orEmpty(), data, fontSize, GlanceModifier.defaultWeight().fillMaxHeight())
            Spacer(GlanceModifier.width(6.dp))
            Tile(data.picks.getOrNull(1).orEmpty(), data, fontSize, GlanceModifier.defaultWeight().fillMaxHeight())
        }
        Spacer(GlanceModifier.height(6.dp))
        Row(modifier = GlanceModifier.fillMaxWidth().defaultWeight()) {
            Tile(data.picks.getOrNull(2).orEmpty(), data, fontSize, GlanceModifier.defaultWeight().fillMaxHeight())
            Spacer(GlanceModifier.width(6.dp))
            Tile(data.picks.getOrNull(3).orEmpty(), data, fontSize, GlanceModifier.defaultWeight().fillMaxHeight())
        }
    }
}

@Composable
private fun Tile(text: String, data: WidgetData, fontSize: Float, modifier: GlanceModifier) {
    Box(
        modifier = modifier
            .background(ColorProvider(data.tile))
            .cornerRadius(16.dp)
            .padding(horizontal = 4.dp)
            .clickable(onClick = actionRunCallback<CopyAction>(actionParametersOf(PickKey to text))),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = text,
            maxLines = 2,
            style = TextStyle(
                color = ColorProvider(data.ink),
                fontSize = fontSize.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
            ),
        )
    }
}

/** Тап по плитке: копируем в буфер и считаем использование. Сам виджет не перерисовывается, плитки не прыгают. */
class CopyAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        val text = parameters[PickKey]
        if (text.isNullOrEmpty()) return

        context.getSystemService(ClipboardManager::class.java)
            .setPrimaryClip(ClipData.newPlainText("kaomoji", text))
        (context.applicationContext as? KomodjeApp)?.container?.usage?.recordNow(text)

        // С Android 13 систему показывает своё подтверждение копирования.
        if (Build.VERSION.SDK_INT < 33) {
            withContext(Dispatchers.Main) {
                Toast.makeText(context, context.getString(R.string.copied), Toast.LENGTH_SHORT).show()
            }
        }
    }
}

private val refreshScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

/** Перерисовать все виджеты на экране (если их нет, ничего не делает). */
suspend fun refreshWidgets(context: Context) {
    runCatching { KomodjeWidget().updateAll(context.applicationContext) }
}

fun refreshWidgetsAsync(context: Context) {
    val app = context.applicationContext
    refreshScope.launch { refreshWidgets(app) }
}
