package app.komodje.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import kotlin.random.Random
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.komodje.R
import app.komodje.domain.Komoji
import app.komodje.domain.KomojiFilter
import app.komodje.domain.Mood
import app.komodje.ui.HomeState
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.Onest

/**
 * Одна панель на два входа: экран приложения и клавиатура (IME).
 * Различаются только onPick (копировать / вставить) и barLeading (кнопка смены клавиатуры).
 */
@Composable
fun KomojiPanel(
    state: HomeState,
    onSelect: (Mood) -> Unit,
    onPick: (String) -> Unit,
    onHold: (String) -> Unit,
    feedback: String,
    modifier: Modifier = Modifier,
    topRow: List<String> = emptyList(),
    barLeading: (@Composable () -> Unit)? = null,
    /** Тап по сердечку. Если не задан, работает как onHold. */
    onFavorite: ((String) -> Unit)? = null,
    /** Задан только в приложении: тогда над списком появляются вкладки-фильтры и подпись. */
    onFilter: ((KomojiFilter) -> Unit)? = null,
    /** Задан только в приложении: поиск по символам над списком. */
    onQuery: ((String) -> Unit)? = null,
    /** Задан только в приложении: тогда в разделе «Любимые» снизу лежат папки. */
    folderActions: FolderActions? = null,
    /** Если задан, долгое нажатие идёт сюда (с границами карточки на экране), а не в onHold. */
    onHoldAt: ((String, Rect) -> Unit)? = null,
) {
    val p = LocalPalette.current
    val sparkColors = remember(p) { listOf(p.heart, p.accentDeep, p.accent) }
    val panelRoot = remember { floatArrayOf(0f, 0f) }
    var burst by remember { mutableStateOf<Burst?>(null) }
    val burstProgress = remember { Animatable(1f) }
    var searchOpen by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(burst) {
        if (burst != null) {
            burstProgress.snapTo(0f)
            burstProgress.animateTo(1f, tween(1200, easing = LinearOutSlowInEasing))
        }
    }

    Column(modifier) {
        if (topRow.isNotEmpty()) QuickRow(topRow, onPick)
        if (onFilter != null) {
            FilterTabs(state.filters, onFilter, Modifier.padding(top = 6.dp))
            val openFolder = state.folders.firstOrNull { it.id == state.openFolder }
            val label = when {
                openFolder != null -> folderTitle(openFolder)
                state.picks.isNotEmpty() -> stringResource(R.string.hits_of_day)
                else -> null
            }
            // Место под подпись занято всегда, чтобы список не прыгал при смене вкладки.
            if (onQuery != null) {
                SearchRow(
                    open = searchOpen,
                    query = state.query,
                    onOpen = { searchOpen = true },
                    onClose = {
                        searchOpen = false
                        onQuery("")
                    },
                    onQuery = onQuery,
                ) {
                    if (label != null) SectionLabel(label)
                }
            } else {
                Box(Modifier.fillMaxWidth().height(28.dp)) {
                    if (label != null) SectionLabel(label)
                }
            }
        }
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .onGloballyPositioned {
                    val o = it.positionInRoot()
                    panelRoot[0] = o.x
                    panelRoot[1] = o.y
                },
        ) {
            key(state.mood, state.filters, state.openFolder) {
                if (state.items.isEmpty()) {
                    when {
                        state.query.isNotBlank() -> EmptyState(KomojeIcons.Search, R.string.filter_empty, null)
                        state.openFolder != null ->
                            EmptyState(KomojeIcons.Favorite, R.string.folder_empty, R.string.folder_empty_hint)
                        state.mood == Mood.FAVORITE && state.filters.isEmpty() ->
                            EmptyState(KomojeIcons.Favorite, R.string.empty_title, R.string.empty_hint)
                        else -> EmptyState(KomojeIcons.Sparkle, R.string.filter_empty, null)
                    }
                } else {
                    // Один прогресс на весь список: читается только при рисовании, без перекомпоновок.
                    val enter = remember { Animatable(0f) }
                    LaunchedEffect(Unit) { enter.animateTo(1f, tween(360, easing = FastOutSlowInEasing)) }
                    val listState = rememberLazyListState()
                    LaunchedEffect(state.query) { listState.scrollToItem(0) }
                    // Масштаб карточек из настроек: меняем плотность только внутри списка.
                    val density = LocalDensity.current
                    val scale = LocalCardScale.current
                    val scaled = remember(density, scale) { Density(density.density * scale, density.fontScale) }
                    val head = if (onFilter != null) state.picks.size.coerceAtMost(state.items.size) else 0
                    val card: @Composable (Int, Komoji) -> Unit = { i, k ->
                        KomojiCard(
                            text = k.text,
                            favorite = k.text in state.favorites,
                            feedback = feedback,
                            onTap = { onPick(k.text) },
                            onHold = { bounds -> if (onHoldAt != null) onHoldAt(k.text, bounds) else onHold(k.text) },
                            onFavorite = { (onFavorite ?: onHold)(k.text) },
                            onCopied = { burst = Burst(it, Random.nextInt()) },
                            highlight = k.text in state.picks,
                            modifier = if (i < ENTER_COUNT) Modifier.graphicsLayer {
                                val delay = i * 0.045f
                                val t = ((enter.value - delay) / (1f - delay)).coerceIn(0f, 1f)
                                alpha = t
                                translationY = (1f - t) * 48f
                            } else Modifier,
                        )
                    }
                    CompositionLocalProvider(LocalDensity provides scaled) {
                        LazyColumn(
                            state = listState,
                            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 14.dp, bottom = 10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            // «Хиты дня» сверху, затем отделённая подписью «Коллекция» остальная библиотека.
                            itemsIndexed(
                                state.items.subList(0, head),
                                key = { _, k -> k.text },
                                contentType = { _, _ -> "card" },
                            ) { i, k -> card(i, k) }
                            if (head > 0 && head < state.items.size) {
                                item(key = "collection-header", contentType = "header") {
                                    SectionLabel(
                                        stringResource(R.string.collection),
                                        Modifier.offset(x = (-8).dp).padding(top = 10.dp),
                                        KomojeIcons.Cards,
                                    )
                                }
                            }
                            itemsIndexed(
                                state.items.subList(head, state.items.size),
                                key = { _, k -> k.text },
                                contentType = { _, _ -> "card" },
                            ) { j, k -> card(head + j, k) }
                        }
                    }
                }
            }
            // Звёздочки поверх списка: не перехватывают нажатия, перерисовываются только в Canvas.
            Canvas(Modifier.fillMaxSize()) {
                val b = burst
                val t = burstProgress.value
                if (b != null && t < 1f) drawBurst(b, t, Offset(panelRoot[0], panelRoot[1]), sparkColors)
            }
        }
        AnimatedVisibility(
            visible = folderActions != null && state.mood == Mood.FAVORITE,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut(),
        ) {
            if (folderActions != null) FolderStrip(state.folders, state.openFolder, folderActions)
        }
        Row(
            Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, top = 2.dp, bottom = 10.dp),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            barLeading?.invoke()
            KomojeBottomBar(
                items = Categories,
                selected = Categories.indexOfFirst { it.mood == state.mood },
                onSelect = { onSelect(Categories[it].mood) },
                modifier = Modifier.weight(1f),
            )
        }
    }
}

/**
 * Быстрый ряд: любимые и частые в одну строку, листаются вбок. Каждое комоджи показано целиком.
 * Цвет акцента отличает его от списка ниже.
 */
@Composable
private fun QuickRow(texts: List<String>, onPick: (String) -> Unit) {
    val p = LocalPalette.current
    LazyRow(
        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
        contentPadding = PaddingValues(horizontal = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        items(texts, key = { it }) { text ->
            val tick = rememberTick()
            val source = remember { MutableInteractionSource() }
            Box(
                Modifier
                    .height(46.dp)
                    .pressScale(source)
                    .clip(QuickShape)
                    .background(p.accent)
                    .clickable(interactionSource = source, indication = null) {
                        tick()
                        onPick(text)
                    }
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(text, color = p.onAccent, fontSize = 19.sp, maxLines = 1, softWrap = false)
            }
        }
    }
}

private val QuickShape = RoundedCornerShape(topStart = 18.dp, topEnd = 8.dp, bottomEnd = 18.dp, bottomStart = 8.dp)

/** Въезжают только первые экранные карточки; остальные появляются без ожидания. */
private const val ENTER_COUNT = 9

@Composable
private fun EmptyState(icon: ImageVector, title: Int, hint: Int?) {
    val p = LocalPalette.current
    Column(
        Modifier.fillMaxSize().padding(40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(icon, contentDescription = null, tint = p.heart, modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(18.dp))
        Text(
            stringResource(title),
            color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 20.sp,
            textAlign = TextAlign.Center,
        )
        if (hint != null) {
            Spacer(Modifier.height(6.dp))
            Text(
                stringResource(hint),
                color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Medium,
                fontSize = 15.sp, textAlign = TextAlign.Center,
            )
        }
    }
}
