package app.komodje.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.widthIn
import app.komodje.ui.theme.accentBrush
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.positionInParent
import app.komodje.domain.AccentTheme
import app.komodje.ui.theme.LocalAccentTheme
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.layout.layout
import app.komodje.ui.theme.UnboundedBlack
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.runtime.derivedStateOf
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.animation.core.LinearEasing
import kotlin.math.roundToInt
import kotlin.random.Random
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.komodje.R
import app.komodje.domain.Komoji
import app.komodje.domain.KomojiFilter
import app.komodje.domain.Mood
import app.komodje.ui.HomeState
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.Onest

/**
 * Одна панель на два входа: экран приложения и клавиатура (IME).
 * Различаются только onPick (копировать / вставить) и barLeading (кнопка смены клавиатуры).
 */
@Composable
fun KomojiPanel(
    state: HomeState,
    onSelect: (Mood) -> Unit,
    onPick: (String) -> Unit,
    onHold: (String) -> Unit,
    feedback: String,
    modifier: Modifier = Modifier,
    topRow: List<String> = emptyList(),
    barLeading: (@Composable () -> Unit)? = null,
    /** Тап по сердечку. Если не задан, работает как onHold. */
    onFavorite: ((String) -> Unit)? = null,
    /** Задан только в приложении: тогда над списком появляются вкладки-фильтры и подпись. */
    onFilter: ((KomojiFilter) -> Unit)? = null,
    /** Задан только в приложении: поиск по символам над списком. */
    onQuery: ((String) -> Unit)? = null,
    /** Задан только в приложении: тогда в разделе «Любимые» снизу лежат папки. */
    folderActions: FolderActions? = null,
    /** Если задан, долгое нажатие идёт сюда (с границами карточки на экране), а не в onHold. */
    onHoldAt: ((String, Rect) -> Unit)? = null,
    /** Только в приложении: с какой карточки начать список этой вкладки (запомнено с прошлого раза). */
    scrollStart: (Mood) -> Int = { 0 },
    /** Только в приложении: сообщает, до какой карточки долистали (хранится в памяти, на диск уходит позже). */
    onScrolled: ((Mood, Int) -> Unit)? = null,
    /** Только в приложении: в «Любимых» слева в верхней строке появляется «Создать свой смайлик». */
    onCreateOwn: (() -> Unit)? = null,
    /** Только в приложении: «кубик» напротив «Коллекции» перемешивает её. */
    onRoll: (() -> Unit)? = null,
    /** Только в «Любимых» приложения: перетаскивание карточек в папки. */
    dragState: CardDragState? = null,
    /** Режим выбора нескольких карточек: какие отмечены (null: режим выключен). */
    selection: Set<String>? = null,
    onSelectToggle: ((String) -> Unit)? = null,
    onSelectionClose: (() -> Unit)? = null,
    /** Начали тянуть карточку: меню надо закрыть. */
    onDragBegin: (() -> Unit)? = null,
    /** Карточку (текст) отпустили над папкой (id). */
    onCardDrop: ((String, String) -> Unit)? = null,
) {
    val p = LocalPalette.current
    // Масштаб из настроек: одна и та же плотность для карточек и для всех подписей над ними
    // («Хиты дня», «Недавние», «Коллекция»), чтобы они менялись пропорционально.
    val baseDensity = LocalDensity.current
    val cardScale = LocalCardScale.current
    val scaled = remember(baseDensity, cardScale) { Density(baseDensity.density * cardScale, baseDensity.fontScale) }
    // 0 = список вверху, 1 = пролистан: подпись «Хиты дня» тогда уходит за «шторку», а поиск остаётся.
    val labelFade = remember { mutableFloatStateOf(0f) }
    // Подложка «Хитов дня»: верхняя часть (за поиском) и нижняя (вокруг карточек) одного цвета,
    // нижняя лежит прямо в списке и едет вместе с карточками. Координаты не считаются.
    val darkTheme = p.bgTop.luminance() < 0.5f
    val hasPlate = onFilter != null && onQuery != null && state.picks.isNotEmpty() &&
        state.openFolder == null && state.query.isBlank() && state.items.isNotEmpty()
    // Светлая тема: тёмная подложка в оттенке темы; тёмная тема: светлая. Градиент только по горизонтали,
    // чтобы верхняя и нижняя части сходились без шва.
    val plateBrush = remember(p, darkTheme) {
        val from = if (darkTheme) lerp(p.accent, Color.White, 0.22f) else lerp(p.badge, Color.White, 0.08f)
        val to = if (darkTheme) p.accentDeep else p.badgeDeep
        Brush.horizontalGradient(listOf(from, to))
    }
    val plateStyle = remember(p, darkTheme) {
        if (darkTheme) PlateStyle(p.badge, p.onBadge, p.onBadge.copy(alpha = 0.7f))
        else PlateStyle(Color.White, Color(0xFF2A2133), Color(0xFF2A2133).copy(alpha = 0.6f))
    }
    val plateInset = minOf(6f * baseDensity.density, 14f * scaled.density)
    val plateBleed = 14f * scaled.density - plateInset
    // Сколько пикселей пролистано (для верхней части подложки, которая уезжает вместе с карточками).
    val scrollPx = remember { mutableFloatStateOf(0f) }
    // Где кончается блок подложки относительно верха списка (пока он ниже верха, число положительное).
    val plateEndPx = remember { mutableFloatStateOf(100000f) }
    val searchDensity = baseDensity.density
    // Насколько плашка поиска ещё лежит на подложке: 1 пока подложка под ней, плавно до 0, когда блок уходит выше.
    // Плашка стоит на 22..66 dp от верха списка.
    val plateCover by remember {
        derivedStateOf {
            val under = plateEndPx.floatValue - 22f * searchDensity
            (under / (44f * searchDensity)).coerceIn(0f, 1f)
        }
    }
    // Единый въезд при первом открытии: все блоки одной кривой и скоростью, с небольшим шагом сверху вниз.
    val introT = remember { Animatable(if (onFilter != null && !IntroState.done) 0f else 1f) }
    LaunchedEffect(Unit) {
        if (introT.value < 1f) {
            IntroState.done = true
            introT.animateTo(1f, tween(INTRO_TOTAL_MS, easing = LinearEasing))
        }
    }
    val introDensity = baseDensity.density
    fun Modifier.intro(order: Int): Modifier = graphicsLayer {
        val t = ((introT.value * INTRO_TOTAL_MS - order * INTRO_STEP_MS) / INTRO_MS).coerceIn(0f, 1f)
        val e = Motion.Ease.transform(t)
        alpha = e
        translationY = (1f - e) * 28f * introDensity
    }
    val sparkColors = remember(p) { listOf(p.heart, p.accentDeep, p.accent) }
    val panelRoot = remember { floatArrayOf(0f, 0f) }
    var burst by remember { mutableStateOf<Burst?>(null) }
    val burstProgress = remember { Animatable(1f) }
    var searchOpen by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(burst) {
        if (burst != null) {
            burstProgress.snapTo(0f)
            burstProgress.animateTo(1f, tween(1200, easing = LinearOutSlowInEasing))
        }
    }

    val openFolder = state.folders.firstOrNull { it.id == state.openFolder }
    val label = when {
        openFolder != null -> folderTitle(openFolder)
        state.picks.isNotEmpty() -> stringResource(R.string.hits_of_day)
        else -> null
    }
    // Поиск плавает поверх списка: карточки уходят под него до самых вкладок, без жёсткого среза.
    val floating = onFilter != null && onQuery != null
    // Размеры «в обычных dp» (не зависят от масштаба карточек), пересчитанные под плотность списка.
    fun baseDp(x: Float) = (x * baseDensity.density / scaled.density).dp

    Column(
        modifier,
    ) {
        if (topRow.isNotEmpty()) QuickRow(topRow, onPick)
        if (onFilter != null) {
            FilterTabs(state.filters, onFilter, Modifier.padding(top = 6.dp).intro(0))
            if (!floating) {
                Box(Modifier.fillMaxWidth().height(28.dp)) {
                    if (label != null) {
                        CompositionLocalProvider(LocalDensity provides scaled) { SectionLabel(label) }
                    }
                }
            }
        }
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .intro(1)
                .onGloballyPositioned {
                    val o = it.positionInRoot()
                    panelRoot[0] = o.x
                    panelRoot[1] = o.y
                },
        ) {
            key(state.mood, state.filters, state.openFolder) {
                if (state.items.isEmpty()) {
                  Box(Modifier.fillMaxSize().padding(top = if (floating) 66.dp else 0.dp)) {
                    when {
                        state.query.isNotBlank() -> EmptyState(KomojeIcons.Search, R.string.filter_empty, null)
                        state.openFolder != null ->
                            EmptyState(KomojeIcons.Favorite, R.string.folder_empty, R.string.folder_empty_hint)
                        state.mood == Mood.FAVORITE && state.filters.isEmpty() ->
                            EmptyState(KomojeIcons.Favorite, R.string.empty_title, R.string.empty_hint)
                        else -> EmptyState(KomojeIcons.Sparkle, R.string.filter_empty, null)
                    }
                  }
                } else {
                    // Прогресс «въезда» карточек нужен только после броска кубика: первый показ играет общий въезд.
                    val enter = remember { Animatable(1f) }
                    // С какой карточки считать «въезд»: с первой, а после броска кубика с начала коллекции.
                    var enterBase by remember { mutableIntStateOf(0) }
                    // «Хиты дня» сверху, затем «Недавние» (если есть), затем отделённая подписью «Коллекция».
                    val head = if (onFilter != null) state.picks.size.coerceAtMost(state.items.size) else 0
                    val recentCount = if (onFilter != null) state.recent.size else 0
                    // «Недавние» раскрываются плавно, только если появились на глазах (список был без них).
                    val animateRecent = remember { recentCount == 0 }
                    val showCollection = (head > 0 || recentCount > 0) && head < state.items.size
                    // Номер элемента списка, с которого начинается подпись «Коллекция» (карточки и блок «Недавние»).
                    val collectionItem = (if (hasPlate && head > 0) 1 else head) + if (recentCount > 0) 1 else 0
                    // Возвращаемся на прежнее место только в обычном списке: не в папке и не в поиске.
                    val plain = state.openFolder == null && state.query.isBlank()
                    val startIndex = if (plain) scrollStart(state.mood).coerceIn(0, state.items.lastIndex) else 0
                    val listState = rememberLazyListState(initialFirstVisibleItemIndex = startIndex)
                    // Подложка «Хитов дня» одним элементом списка: карточки внутри неё.
                    val plateBlock = hasPlate && head > 0
                    val headItems = if (plateBlock) 1 else head
                    LaunchedEffect(listState) {
                        val threshold = with(baseDensity) { 40.dp.toPx() }
                        snapshotFlow {
                            val first = listState.firstVisibleItemIndex
                            val scroll = if (first > 0) 100000f else listState.firstVisibleItemScrollOffset.toFloat()
                            val plate = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.key == "hits-plate" }
                            val end = when {
                                plate != null -> (plate.offset + plate.size - listState.layoutInfo.viewportStartOffset).toFloat()
                                first > 0 -> -100000f
                                else -> 100000f
                            }
                            scroll to end
                        }.collect { (scroll, end) ->
                            scrollPx.floatValue = scroll
                            plateEndPx.floatValue = end
                            labelFade.floatValue = (scroll / threshold).coerceIn(0f, 1f)
                        }
                    }
                    DisposableEffect(listState) {
                        onDispose {
                            labelFade.floatValue = 0f
                            scrollPx.floatValue = 0f
                            plateEndPx.floatValue = 100000f
                        }
                    }
                    // Бросок кубика. Где был список в момент нажатия (до перемешивания), запоминаем здесь.
                    val anchor = remember { intArrayOf(0, 0) }
                    var lastShuffle by remember { mutableLongStateOf(state.shuffle) }
                    LaunchedEffect(state.shuffle) {
                        if (state.shuffle != lastShuffle) {
                            lastShuffle = state.shuffle
                            val index = anchor[0]
                            val offset = anchor[1]
                            // Хиты дня или «Недавнее» ещё на экране: неспешно подъезжаем к коллекции.
                            // Человек уже ниже: не тянем наверх, коллекция меняется прямо на его месте.
                            val seesHead = showCollection && index < collectionItem
                            val firstCardItem = collectionItem + if (showCollection) 1 else 0
                            enterBase = head + recentCount + if (seesHead) 0 else (index - firstCardItem).coerceAtLeast(0)
                            enter.snapTo(0f)
                            coroutineScope {
                                launch { enter.animateTo(1f, tween(if (seesHead) 1700 else 700, easing = Motion.Gentle)) }
                                if (seesHead) launch { listState.glideToItem(collectionItem) } else listState.scrollToItem(index, offset)
                            }
                        }
                    }
                    // К началу прыгаем только когда запрос действительно изменился, а не при первом показе.
                    var lastQuery by remember { mutableStateOf(state.query) }
                    LaunchedEffect(state.query) {
                        if (state.query != lastQuery) {
                            lastQuery = state.query
                            listState.scrollToItem(0)
                        }
                    }
                    if (onScrolled != null && plain) {
                        val mood = state.mood
                        LaunchedEffect(listState) {
                            snapshotFlow { listState.firstVisibleItemIndex }.collect { onScrolled(mood, it) }
                        }
                    }
                    // i < 0: карточка без «въезда» (блок «Недавние» появляется своей анимацией).
                    val card: @Composable (Int, Komoji) -> Unit = { i, k ->
                        val rel = i - enterBase
                        KomojiCard(
                            text = k.text,
                            favorite = k.text in state.favorites,
                            feedback = feedback,
                            onTap = { onPick(k.text) },
                            onHold = { bounds -> if (onHoldAt != null) onHoldAt(k.text, bounds) else onHold(k.text) },
                            onFavorite = { (onFavorite ?: onHold)(k.text) },
                            onCopied = { burst = Burst(it, Random.nextInt()) },
                            highlight = k.text in state.picks,
                            pinned = state.mood == Mood.FAVORITE && state.openFolder == null && k.text in state.pinned,
                            selecting = selection != null,
                            selected = selection?.contains(k.text) == true,
                            onSelectToggle = { onSelectToggle?.invoke(k.text) },
                            dragState = if (state.mood == Mood.FAVORITE) dragState else null,
                            onDragBegin = { onDragBegin?.invoke() },
                            onDragDrop = { folderId -> onCardDrop?.invoke(k.text, folderId) },
                            modifier = if (i >= 0 && rel in 0 until ENTER_COUNT) Modifier.graphicsLayer {
                                val delay = rel * 0.045f
                                val t = ((enter.value - delay) / (1f - delay)).coerceIn(0f, 1f)
                                alpha = t
                                translationY = (1f - t) * 48f
                            } else Modifier,
                        )
                    }
                    CompositionLocalProvider(LocalDensity provides scaled) {
                        LazyColumn(
                            state = listState,
                            modifier = if (floating) Modifier.topFade(with(baseDensity) { 10.dp.toPx() }) else Modifier,
                            contentPadding = PaddingValues(
                                start = 14.dp, end = 14.dp,
                                // Под плавающим поиском: подложка начинается с 14 dp, обычный список ниже ряда поиска.
                                top = if (!floating) 14.dp else if (plateBlock) baseDp(14f) else baseDp(78f), bottom = if (onRoll != null) 84.dp else 10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            if (plateBlock) {
                                item(key = "hits-plate", contentType = "plate") {
                                    HitsPlate(
                                        brush = plateBrush,
                                        bleedPx = plateBleed,
                                        bleedDp = (plateBleed / scaled.density).dp,
                                        corner = (22f * baseDensity.density / scaled.density).dp,
                                        header = baseDp(58f),
                                        title = label ?: "",
                                        titleColor = (if (darkTheme) p.onAccent else p.onBadge).copy(alpha = 0.42f),
                                        pillReserve = baseDp(150f),
                                        titleCenter = baseDp(30f),
                                    ) {
                                        for (i in 0 until head) {
                                            val k = state.items[i]
                                            key(k.text) { card(i, k) }
                                        }
                                    }
                                }
                            } else {
                                itemsIndexed(
                                    state.items.subList(0, head),
                                    key = { _, k -> k.text },
                                    contentType = { _, _ -> "card" },
                                ) { i, k -> card(i, k) }
                            }
                            if (recentCount > 0) {
                                item(key = "recent-section", contentType = "recent") {
                                    RecentSection(state.recent, animateRecent, card)
                                }
                            }
                            if (showCollection) {
                                item(key = "collection-header", contentType = "header") {
                                    Row(
                                        Modifier.fillMaxWidth().padding(top = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) {
                                        SectionLabel(
                                            stringResource(R.string.collection),
                                            Modifier.weight(1f).offset(x = (-14).dp),
                                            KomojeIcons.Books,
                                        )
                                    }
                                }
                            }
                            itemsIndexed(
                                state.items.subList(head, state.items.size),
                                key = { _, k -> k.text },
                                contentType = { _, _ -> "card" },
                            ) { j, k -> card(head + recentCount + j, k) }
                        }
                    }
                    if (onRoll != null && showCollection) {
                        DiceFab(
                            onRoll = {
                                anchor[0] = listState.firstVisibleItemIndex
                                anchor[1] = listState.firstVisibleItemScrollOffset
                                onRoll()
                            },
                            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 16.dp, bottom = 14.dp),
                        )
                    }
                }
            }
            // Плавающий поиск: поверх списка, не привязан к подложке; цвет подстраивается под то, что под ним.
            if (floating && onQuery != null && onFilter != null) {
                val fade = labelFade.floatValue
                val onPlateAnim by animateFloatAsState(
                    targetValue = if (hasPlate) 1f else 0f,
                    animationSpec = tween(300),
                    label = "plaqueOnPlate",
                )
                val plaqueMix = onPlateAnim * plateCover
                val labelInk = if (darkTheme) p.onAccent else p.onBadge
                val labelPalette = if (hasPlate) {
                    p.copy(muted = labelInk.copy(alpha = 0.8f), heart = labelInk, ink = labelInk, accentDeep = labelInk.copy(alpha = 0.85f))
                } else p
                Column(Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(top = 14.dp)) {
                    Spacer(Modifier.height(8.dp))
                    if (selection != null) {
                        SelectionBar(count = selection.size, onClose = { onSelectionClose?.invoke() })
                    } else CompositionLocalProvider(
                        LocalPlateStyle provides plateStyle,
                        LocalPlateMix provides plaqueMix,
                    ) {
                        SearchRow(
                            open = searchOpen,
                            query = state.query,
                            onOpen = { searchOpen = true },
                            onClose = {
                                searchOpen = false
                                onQuery("")
                            },
                            onQuery = onQuery,
                            leading = if (onCreateOwn != null && state.mood == Mood.FAVORITE) {
                                { CreateOwnButton(compact = openFolder != null, onClick = onCreateOwn) }
                            } else {
                                null
                            },
                        ) {
                            if (label != null && !hasPlate) {
                                LabelCurtain(fade = { labelFade.floatValue }) {
                                    CompositionLocalProvider(
                                        LocalDensity provides scaled,
                                        LocalPalette provides labelPalette,
                                    ) {
                                        SectionLabel(label, topPadding = 0.dp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            // Звёздочки поверх списка: не перехватывают нажатия, перерисовываются только в Canvas.
            Canvas(Modifier.fillMaxSize()) {
                val b = burst
                val t = burstProgress.value
                if (b != null && t < 1f) drawBurst(b, t, Offset(panelRoot[0], panelRoot[1]), sparkColors)
            }
        }
        AnimatedVisibility(
            modifier = Modifier.intro(2),
            visible = folderActions != null && state.mood == Mood.FAVORITE,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut(),
        ) {
            if (folderActions != null) FolderStrip(state.folders, state.openFolder, folderActions, drag = dragState)
        }
        Row(
            Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, top = 2.dp, bottom = 10.dp).intro(2),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            barLeading?.invoke()
            KomojeBottomBar(
                items = Categories,
                selected = Categories.indexOfFirst { it.mood == state.mood },
                onSelect = { onSelect(Categories[it].mood) },
                modifier = Modifier.weight(1f),
            )
        }
    }
}

/**
 * «Недавние»: последние скопированные из списков. Блок один элемент списка: появляется плавным
 * раскрытием по высоте (список под ним уезжает вниз не рывком), а рост на новую карточку тоже анимируется.
 */
@Composable
private fun RecentSection(recent: List<Komoji>, animateIn: Boolean, card: @Composable (Int, Komoji) -> Unit) {
    // Без анимации блок сразу стоит раскрытым (смена закладки), с анимацией растёт из нуля.
    val visible = remember { MutableTransitionState(!animateIn).apply { targetState = true } }
    AnimatedVisibility(
        visibleState = visible,
        enter = expandVertically(Motion.slow(), expandFrom = Alignment.Top) + fadeIn(Motion.standard()),
    ) {
        Column(
            Modifier.fillMaxWidth().animateContentSize(Motion.standard()),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            SectionLabel(
                stringResource(R.string.recent),
                Modifier.offset(x = (-14).dp).padding(top = 10.dp),
                KomojeIcons.Clock,
            )
            recent.forEach { k -> key(k.text) { card(-1, k) } }
        }
    }
}

/**
 * Быстрый ряд: любимые и частые в одну строку, листаются вбок. Каждое комоджи показано целиком.
 * Цвет акцента отличает его от списка ниже.
 */
@Composable
private fun QuickRow(texts: List<String>, onPick: (String) -> Unit) {
    val p = LocalPalette.current
    LazyRow(
        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
        contentPadding = PaddingValues(horizontal = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        items(texts, key = { it }) { text ->
            val tick = rememberTick()
            val source = remember { MutableInteractionSource() }
            Box(
                Modifier
                    .height(46.dp)
                    .pressScale(source)
                    .clip(QuickShape)
                    .background(p.accent)
                    .clickable(interactionSource = source, indication = null) {
                        tick()
                        onPick(text)
                    }
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(text, color = p.onAccent, fontSize = 19.sp, maxLines = 1, softWrap = false)
            }
        }
    }
}

private val QuickShape = RoundedCornerShape(topStart = 18.dp, topEnd = 8.dp, bottomEnd = 18.dp, bottomStart = 8.dp)

/**
 * Неспешно подводит заголовок «Коллекции» к верху списка. Если заголовок на экране, едем ровно до него;
 * если он ещё ниже, оцениваем путь по средней высоте карточек. В конце лёгкая подгонка до точного места.
 */
private suspend fun LazyListState.glideToItem(index: Int) {
    val visible = layoutInfo.visibleItemsInfo
    val first = visible.firstOrNull() ?: return
    val target = visible.firstOrNull { it.index == index }
    val distance = if (target != null) {
        target.offset.toFloat()
    } else {
        val last = visible.last()
        if (last.index >= index) return
        val stride = if (visible.size > 1) (last.offset - first.offset).toFloat() / (visible.size - 1) else first.size.toFloat()
        (last.offset + last.size) + (index - last.index - 1) * stride
    }
    if (distance > 1f) animateScrollBy(distance, tween(1700, easing = Motion.Gentle))
    animateScrollToItem(index)
}

/** Въезжают только первые экранные карточки; остальные появляются без ожидания. */
private const val ENTER_COUNT = 9

@Composable
private fun EmptyState(icon: ImageVector, title: Int, hint: Int?) {
    val p = LocalPalette.current
    Column(
        Modifier.fillMaxSize().padding(40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(icon, contentDescription = null, tint = p.heart, modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(18.dp))
        Text(
            stringResource(title),
            color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 20.sp,
            textAlign = TextAlign.Center,
        )
        if (hint != null) {
            Spacer(Modifier.height(6.dp))
            Text(
                stringResource(hint),
                color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Medium,
                fontSize = 15.sp, textAlign = TextAlign.Center,
            )
        }
    }
}

/** «Шторка» для подписи: при прокрутке вниз подпись плавно гаснет и уезжает вверх за свою границу. */
@Composable
private fun LabelCurtain(fade: () -> Float, content: @Composable () -> Unit) {
    Box(Modifier.clipToBounds()) {
        Box(
            Modifier.graphicsLayer {
                val f = fade()
                alpha = 1f - f
                translationY = -f * 18.dp.toPx()
            },
        ) { content() }
    }
}

/** Блок подложки с карточками «Хитов дня»: шире списка на запас по бокам, низ скруглён. */
@Composable
private fun HitsPlate(
    brush: Brush,
    bleedPx: Float,
    bleedDp: Dp,
    corner: Dp,
    header: Dp,
    title: String,
    titleColor: Color,
    pillReserve: Dp,
    titleCenter: Dp,
    content: @Composable () -> Unit,
) {
    Column(
        Modifier
            .layout { measurable, constraints ->
                val b = bleedPx.roundToInt().coerceAtLeast(0)
                val w = constraints.maxWidth + 2 * b
                val placeable = measurable.measure(Constraints(minWidth = w, maxWidth = w, minHeight = 0, maxHeight = constraints.maxHeight))
                layout(constraints.maxWidth, placeable.height) { placeable.place(-b, 0) }
            }
            .clip(RoundedCornerShape(corner))
            .background(brush)
            .starField(titleColor.copy(alpha = 1f))
            .padding(start = bleedDp, end = bleedDp, bottom = 14.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        // Верхняя часть подложки под плавающим поиском: здесь большая надпись. Она тянется почти до плашки
        // поиска и стоит с ней на одной линии по центру.
        BoxWithConstraints(Modifier.fillMaxWidth().height(header)) {
            val density = LocalDensity.current
            val measurer = rememberTextMeasurer()
            val availPx = with(density) { (maxWidth - pillReserve - 8.dp).toPx() }
            val style = TextStyle(fontFamily = UnboundedBlack, fontWeight = FontWeight.Black, fontSize = 40.sp)
            val refWidth = remember(title) {
                measurer.measure(title, style, maxLines = 1, softWrap = false).size.width.coerceAtLeast(1)
            }
            val sizeSp = (40f * availPx / refWidth).coerceIn(16f, 48f)
            // Центр надписи по высоте совпадает с центром плашки поиска (titleCenter от верха подложки).
            Text(
                text = title,
                style = style.copy(fontSize = sizeSp.sp, color = titleColor, letterSpacing = (-0.5).sp),
                maxLines = 1,
                softWrap = false,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .offset(x = 8.dp, y = with(density) { (titleCenter.toPx() - sizeSp.sp.toPx() * 0.62f).toDp() }),
            )
        }
        content()
    }
}

/** Общий въезд при первом открытии: один раз за запуск приложения. */
private object IntroState { var done = false }

private const val INTRO_MS = 480f
private const val INTRO_STEP_MS = 70f
private const val INTRO_TOTAL_MS = 480 + 70 * 2

/** Верхний край списка мягко гаснет: карточки уходят под вкладки без жёсткого среза. */
private fun Modifier.topFade(heightPx: Float): Modifier = this
    .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
    .drawWithContent {
        drawContent()
        drawRect(
            brush = Brush.verticalGradient(0f to Color.Transparent, 1f to Color.Black, startY = 0f, endY = heightPx),
            blendMode = BlendMode.DstIn,
        )
    }
