package app.komodje.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import kotlin.random.Random
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.komodje.R
import app.komodje.domain.Komoji
import app.komodje.domain.KomojiFilter
import app.komodje.domain.Mood
import app.komodje.ui.HomeState
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.Onest

/**
 * Одна панель на два входа: экран приложения и клавиатура (IME).
 * Различаются только onPick (копировать / вставить) и barLeading (кнопка смены клавиатуры).
 */
@Composable
fun KomojiPanel(
    state: HomeState,
    onSelect: (Mood) -> Unit,
    onPick: (String) -> Unit,
    onHold: (String) -> Unit,
    feedback: String,
    modifier: Modifier = Modifier,
    topRow: List<String> = emptyList(),
    barLeading: (@Composable () -> Unit)? = null,
    /** Тап по сердечку. Если не задан, работает как onHold. */
    onFavorite: ((String) -> Unit)? = null,
    /** Задан только в приложении: тогда над списком появляются вкладки-фильтры и подпись. */
    onFilter: ((KomojiFilter) -> Unit)? = null,
    /** Задан только в приложении: поиск по символам над списком. */
    onQuery: ((String) -> Unit)? = null,
    /** Задан только в приложении: тогда в разделе «Любимые» снизу лежат папки. */
    folderActions: FolderActions? = null,
    /** Если задан, долгое нажатие идёт сюда (с границами карточки на экране), а не в onHold. */
    onHoldAt: ((String, Rect) -> Unit)? = null,
    /** Только в приложении: с какой карточки начать список этой вкладки (запомнено с прошлого раза). */
    scrollStart: (Mood) -> Int = { 0 },
    /** Только в приложении: сообщает, до какой карточки долистали (хранится в памяти, на диск уходит позже). */
    onScrolled: ((Mood, Int) -> Unit)? = null,
    /** Только в приложении: в «Любимых» слева в верхней строке появляется «Создать свой смайлик». */
    onCreateOwn: (() -> Unit)? = null,
    /** Только в приложении: «кубик» напротив «Коллекции» перемешивает её. */
    onRoll: (() -> Unit)? = null,
) {
    val p = LocalPalette.current
    // Масштаб из настроек: одна и та же плотность для карточек и для всех подписей над ними
    // («Хиты дня», «Недавние», «Коллекция»), чтобы они менялись пропорционально.
    val baseDensity = LocalDensity.current
    val cardScale = LocalCardScale.current
    val scaled = remember(baseDensity, cardScale) { Density(baseDensity.density * cardScale, baseDensity.fontScale) }
    // 0 = список вверху, 1 = пролистан: подпись «Хиты дня» тогда уходит за «шторку», а поиск остаётся.
    val labelFade = remember { mutableFloatStateOf(0f) }
    val sparkColors = remember(p) { listOf(p.heart, p.accentDeep, p.accent) }
    val panelRoot = remember { floatArrayOf(0f, 0f) }
    var burst by remember { mutableStateOf<Burst?>(null) }
    val burstProgress = remember { Animatable(1f) }
    var searchOpen by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(burst) {
        if (burst != null) {
            burstProgress.snapTo(0f)
            burstProgress.animateTo(1f, tween(1200, easing = LinearOutSlowInEasing))
        }
    }

    Column(modifier) {
        if (topRow.isNotEmpty()) QuickRow(topRow, onPick)
        if (onFilter != null) {
            FilterTabs(state.filters, onFilter, Modifier.padding(top = 6.dp))
            val openFolder = state.folders.firstOrNull { it.id == state.openFolder }
            val label = when {
                openFolder != null -> folderTitle(openFolder)
                state.picks.isNotEmpty() -> stringResource(R.string.hits_of_day)
                else -> null
            }
            // Место под подпись занято всегда, чтобы список не прыгал при смене вкладки.
            if (onQuery != null) {
                SearchRow(
                    open = searchOpen,
                    query = state.query,
                    onOpen = { searchOpen = true },
                    onClose = {
                        searchOpen = false
                        onQuery("")
                    },
                    onQuery = onQuery,
                    leading = if (onCreateOwn != null && state.mood == Mood.FAVORITE) {
                        { CreateOwnButton(compact = openFolder != null, onClick = onCreateOwn) }
                    } else {
                        null
                    },
                ) {
                    if (label != null) {
                        LabelCurtain(fade = { labelFade.floatValue }) {
                            CompositionLocalProvider(LocalDensity provides scaled) {
                                SectionLabel(label, topPadding = 0.dp)
                            }
                        }
                    }
                }
            } else {
                Box(Modifier.fillMaxWidth().height(28.dp)) {
                    if (label != null) {
                        CompositionLocalProvider(LocalDensity provides scaled) { SectionLabel(label) }
                    }
                }
            }
        }
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .onGloballyPositioned {
                    val o = it.positionInRoot()
                    panelRoot[0] = o.x
                    panelRoot[1] = o.y
                },
        ) {
            key(state.mood, state.filters, state.openFolder) {
                if (state.items.isEmpty()) {
                    when {
                        state.query.isNotBlank() -> EmptyState(KomojeIcons.Search, R.string.filter_empty, null)
                        state.openFolder != null ->
                            EmptyState(KomojeIcons.Favorite, R.string.folder_empty, R.string.folder_empty_hint)
                        state.mood == Mood.FAVORITE && state.filters.isEmpty() ->
                            EmptyState(KomojeIcons.Favorite, R.string.empty_title, R.string.empty_hint)
                        else -> EmptyState(KomojeIcons.Sparkle, R.string.filter_empty, null)
                    }
                } else {
                    // Один прогресс на весь список: читается только при рисовании, без перекомпоновок.
                    val enter = remember { Animatable(0f) }
                    LaunchedEffect(Unit) { enter.animateTo(1f, Motion.standard()) }
                    // С какой карточки считать «въезд»: с первой, а после броска кубика с начала коллекции.
                    var enterBase by remember { mutableIntStateOf(0) }
                    // «Хиты дня» сверху, затем «Недавние» (если есть), затем отделённая подписью «Коллекция».
                    val head = if (onFilter != null) state.picks.size.coerceAtMost(state.items.size) else 0
                    val recentCount = if (onFilter != null) state.recent.size else 0
                    val showCollection = (head > 0 || recentCount > 0) && head < state.items.size
                    // Номер элемента списка, с которого начинается подпись «Коллекция» (карточки и блок «Недавние»).
                    val collectionItem = head + if (recentCount > 0) 1 else 0
                    // Возвращаемся на прежнее место только в обычном списке: не в папке и не в поиске.
                    val plain = state.openFolder == null && state.query.isBlank()
                    val startIndex = if (plain) scrollStart(state.mood).coerceIn(0, state.items.lastIndex) else 0
                    val listState = rememberLazyListState(initialFirstVisibleItemIndex = startIndex)
                    LaunchedEffect(listState) {
                        val threshold = with(baseDensity) { 56.dp.toPx() }
                        snapshotFlow {
                            if (listState.firstVisibleItemIndex > 0) 1f
                            else (listState.firstVisibleItemScrollOffset / threshold).coerceIn(0f, 1f)
                        }.collect { labelFade.floatValue = it }
                    }
                    DisposableEffect(listState) { onDispose { labelFade.floatValue = 0f } }
                    // Бросок кубика. Где был список в момент нажатия (до перемешивания), запоминаем здесь.
                    val anchor = remember { intArrayOf(0, 0) }
                    var lastShuffle by remember { mutableLongStateOf(state.shuffle) }
                    LaunchedEffect(state.shuffle) {
                        if (state.shuffle != lastShuffle) {
                            lastShuffle = state.shuffle
                            val index = anchor[0]
                            val offset = anchor[1]
                            // Хиты дня или «Недавнее» ещё на экране: неспешно подъезжаем к коллекции.
                            // Человек уже ниже: не тянем наверх, коллекция меняется прямо на его месте.
                            val seesHead = showCollection && index < collectionItem
                            val firstCardItem = collectionItem + if (showCollection) 1 else 0
                            enterBase = head + recentCount + if (seesHead) 0 else (index - firstCardItem).coerceAtLeast(0)
                            enter.snapTo(0f)
                            coroutineScope {
                                launch { enter.animateTo(1f, tween(if (seesHead) 1700 else 700, easing = Motion.Gentle)) }
                                if (seesHead) launch { listState.glideToItem(collectionItem) } else listState.scrollToItem(index, offset)
                            }
                        }
                    }
                    // К началу прыгаем только когда запрос действительно изменился, а не при первом показе.
                    var lastQuery by remember { mutableStateOf(state.query) }
                    LaunchedEffect(state.query) {
                        if (state.query != lastQuery) {
                            lastQuery = state.query
                            listState.scrollToItem(0)
                        }
                    }
                    if (onScrolled != null && plain) {
                        val mood = state.mood
                        LaunchedEffect(listState) {
                            snapshotFlow { listState.firstVisibleItemIndex }.collect { onScrolled(mood, it) }
                        }
                    }
                    // i < 0: карточка без «въезда» (блок «Недавние» появляется своей анимацией).
                    val card: @Composable (Int, Komoji) -> Unit = { i, k ->
                        val rel = i - enterBase
                        KomojiCard(
                            text = k.text,
                            favorite = k.text in state.favorites,
                            feedback = feedback,
                            onTap = { onPick(k.text) },
                            onHold = { bounds -> if (onHoldAt != null) onHoldAt(k.text, bounds) else onHold(k.text) },
                            onFavorite = { (onFavorite ?: onHold)(k.text) },
                            onCopied = { burst = Burst(it, Random.nextInt()) },
                            highlight = k.text in state.picks,
                            pinned = state.mood == Mood.FAVORITE && state.openFolder == null && k.text in state.pinned,
                            modifier = if (i >= 0 && rel in 0 until ENTER_COUNT) Modifier.graphicsLayer {
                                val delay = rel * 0.045f
                                val t = ((enter.value - delay) / (1f - delay)).coerceIn(0f, 1f)
                                alpha = t
                                translationY = (1f - t) * 48f
                            } else Modifier,
                        )
                    }
                    CompositionLocalProvider(LocalDensity provides scaled) {
                        LazyColumn(
                            state = listState,
                            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 14.dp, bottom = if (onRoll != null) 84.dp else 10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            itemsIndexed(
                                state.items.subList(0, head),
                                key = { _, k -> k.text },
                                contentType = { _, _ -> "card" },
                            ) { i, k -> card(i, k) }
                            if (recentCount > 0) {
                                item(key = "recent-section", contentType = "recent") {
                                    RecentSection(state.recent, card)
                                }
                            }
                            if (showCollection) {
                                item(key = "collection-header", contentType = "header") {
                                    Row(
                                        Modifier.fillMaxWidth().padding(top = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) {
                                        SectionLabel(
                                            stringResource(R.string.collection),
                                            Modifier.weight(1f).offset(x = (-14).dp),
                                            KomojeIcons.Books,
                                        )
                                    }
                                }
                            }
                            itemsIndexed(
                                state.items.subList(head, state.items.size),
                                key = { _, k -> k.text },
                                contentType = { _, _ -> "card" },
                            ) { j, k -> card(head + recentCount + j, k) }
                        }
                    }
                    if (onRoll != null && showCollection) {
                        DiceFab(
                            onRoll = {
                                anchor[0] = listState.firstVisibleItemIndex
                                anchor[1] = listState.firstVisibleItemScrollOffset
                                onRoll()
                            },
                            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 16.dp, bottom = 14.dp),
                        )
                    }
                }
            }
            // Звёздочки поверх списка: не перехватывают нажатия, перерисовываются только в Canvas.
            Canvas(Modifier.fillMaxSize()) {
                val b = burst
                val t = burstProgress.value
                if (b != null && t < 1f) drawBurst(b, t, Offset(panelRoot[0], panelRoot[1]), sparkColors)
            }
        }
        AnimatedVisibility(
            visible = folderActions != null && state.mood == Mood.FAVORITE,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut(),
        ) {
            if (folderActions != null) FolderStrip(state.folders, state.openFolder, folderActions)
        }
        Row(
            Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, top = 2.dp, bottom = 10.dp),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            barLeading?.invoke()
            KomojeBottomBar(
                items = Categories,
                selected = Categories.indexOfFirst { it.mood == state.mood },
                onSelect = { onSelect(Categories[it].mood) },
                modifier = Modifier.weight(1f),
            )
        }
    }
}

/**
 * «Недавние»: последние скопированные из списков. Блок один элемент списка: появляется плавным
 * раскрытием по высоте (список под ним уезжает вниз не рывком), а рост на новую карточку тоже анимируется.
 */
@Composable
private fun RecentSection(recent: List<Komoji>, card: @Composable (Int, Komoji) -> Unit) {
    val visible = remember { MutableTransitionState(false).apply { targetState = true } }
    AnimatedVisibility(
        visibleState = visible,
        enter = expandVertically(Motion.slow(), expandFrom = Alignment.Top) + fadeIn(Motion.standard()),
    ) {
        Column(
            Modifier.fillMaxWidth().animateContentSize(Motion.standard()),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            SectionLabel(
                stringResource(R.string.recent),
                Modifier.offset(x = (-14).dp).padding(top = 10.dp),
                KomojeIcons.Clock,
            )
            recent.forEach { k -> key(k.text) { card(-1, k) } }
        }
    }
}

/**
 * Быстрый ряд: любимые и частые в одну строку, листаются вбок. Каждое комоджи показано целиком.
 * Цвет акцента отличает его от списка ниже.
 */
@Composable
private fun QuickRow(texts: List<String>, onPick: (String) -> Unit) {
    val p = LocalPalette.current
    LazyRow(
        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
        contentPadding = PaddingValues(horizontal = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        items(texts, key = { it }) { text ->
            val tick = rememberTick()
            val source = remember { MutableInteractionSource() }
            Box(
                Modifier
                    .height(46.dp)
                    .pressScale(source)
                    .clip(QuickShape)
                    .background(p.accent)
                    .clickable(interactionSource = source, indication = null) {
                        tick()
                        onPick(text)
                    }
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(text, color = p.onAccent, fontSize = 19.sp, maxLines = 1, softWrap = false)
            }
        }
    }
}

private val QuickShape = RoundedCornerShape(topStart = 18.dp, topEnd = 8.dp, bottomEnd = 18.dp, bottomStart = 8.dp)

/**
 * Неспешно подводит заголовок «Коллекции» к верху списка. Если заголовок на экране, едем ровно до него;
 * если он ещё ниже, оцениваем путь по средней высоте карточек. В конце лёгкая подгонка до точного места.
 */
private suspend fun LazyListState.glideToItem(index: Int) {
    val visible = layoutInfo.visibleItemsInfo
    val first = visible.firstOrNull() ?: return
    val target = visible.firstOrNull { it.index == index }
    val distance = if (target != null) {
        target.offset.toFloat()
    } else {
        val last = visible.last()
        if (last.index >= index) return
        val stride = if (visible.size > 1) (last.offset - first.offset).toFloat() / (visible.size - 1) else first.size.toFloat()
        (last.offset + last.size) + (index - last.index - 1) * stride
    }
    if (distance > 1f) animateScrollBy(distance, tween(1700, easing = Motion.Gentle))
    animateScrollToItem(index)
}

/** Въезжают только первые экранные карточки; остальные появляются без ожидания. */
private const val ENTER_COUNT = 9

@Composable
private fun EmptyState(icon: ImageVector, title: Int, hint: Int?) {
    val p = LocalPalette.current
    Column(
        Modifier.fillMaxSize().padding(40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(icon, contentDescription = null, tint = p.heart, modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(18.dp))
        Text(
            stringResource(title),
            color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 20.sp,
            textAlign = TextAlign.Center,
        )
        if (hint != null) {
            Spacer(Modifier.height(6.dp))
            Text(
                stringResource(hint),
                color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Medium,
                fontSize = 15.sp, textAlign = TextAlign.Center,
            )
        }
    }
}

/** «Шторка» для подписи: при прокрутке вниз подпись плавно гаснет и уезжает вверх за свою границу. */
@Composable
private fun LabelCurtain(fade: () -> Float, content: @Composable () -> Unit) {
    Box(Modifier.clipToBounds()) {
        Box(
            Modifier.graphicsLayer {
                val f = fade()
                alpha = 1f - f
                translationY = -f * 18.dp.toPx()
            },
        ) { content() }
    }
}
