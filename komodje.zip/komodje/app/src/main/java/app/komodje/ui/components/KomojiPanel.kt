package app.komodje.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import kotlin.random.Random
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.komodje.R
import app.komodje.domain.Mood
import app.komodje.ui.HomeState
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.Onest

/**
 * Одна панель на два входа: экран приложения и клавиатура (IME).
 * Различаются только onPick (копировать / вставить) и barLeading (кнопка смены клавиатуры).
 */
@Composable
fun KomojiPanel(
    state: HomeState,
    onSelect: (Mood) -> Unit,
    onPick: (String) -> Unit,
    onHold: (String) -> Unit,
    feedback: String,
    modifier: Modifier = Modifier,
    barLeading: (@Composable () -> Unit)? = null,
) {
    val p = LocalPalette.current
    val sparkColors = remember(p) { listOf(p.heart, p.accentDeep, p.accent) }
    val panelRoot = remember { floatArrayOf(0f, 0f) }
    var burst by remember { mutableStateOf<Burst?>(null) }
    val burstProgress = remember { Animatable(1f) }
    LaunchedEffect(burst) {
        if (burst != null) {
            burstProgress.snapTo(0f)
            burstProgress.animateTo(1f, tween(680, easing = LinearOutSlowInEasing))
        }
    }

    Column(modifier) {
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .onGloballyPositioned {
                    val o = it.positionInRoot()
                    panelRoot[0] = o.x
                    panelRoot[1] = o.y
                },
        ) {
            key(state.mood) {
                if (state.mood == Mood.FAVORITE && state.items.isEmpty()) {
                    EmptyFavorites()
                } else {
                    // Один прогресс на весь список: читается только при рисовании, без перекомпоновок.
                    val enter = remember { Animatable(0f) }
                    LaunchedEffect(Unit) { enter.animateTo(1f, tween(360, easing = FastOutSlowInEasing)) }
                    LazyColumn(
                        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 14.dp, bottom = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        itemsIndexed(
                            state.items,
                            key = { _, k -> k.text },
                            contentType = { _, _ -> "card" },
                        ) { i, k ->
                            KomojiCard(
                                text = k.text,
                                favorite = k.text in state.favorites,
                                feedback = feedback,
                                onTap = { onPick(k.text) },
                                onHold = { onHold(k.text) },
                                onFavorite = { onHold(k.text) },
                                onCopied = { burst = Burst(it, Random.nextInt()) },
                                modifier = if (i < ENTER_COUNT) Modifier.graphicsLayer {
                                    val delay = i * 0.045f
                                    val t = ((enter.value - delay) / (1f - delay)).coerceIn(0f, 1f)
                                    alpha = t
                                    translationY = (1f - t) * 48f
                                } else Modifier,
                            )
                        }
                    }
                }
            }
            // Звёздочки поверх списка: не перехватывают нажатия, перерисовываются только в Canvas.
            Canvas(Modifier.fillMaxSize()) {
                val b = burst
                val t = burstProgress.value
                if (b != null && t < 1f) drawBurst(b, t, Offset(panelRoot[0], panelRoot[1]), sparkColors)
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, top = 2.dp, bottom = 10.dp),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            barLeading?.invoke()
            KomojeBottomBar(
                items = Categories,
                selected = Categories.indexOfFirst { it.mood == state.mood },
                onSelect = { onSelect(Categories[it].mood) },
                modifier = Modifier.weight(1f),
            )
        }
    }
}

/** Въезжают только первые экранные карточки; остальные появляются без ожидания. */
private const val ENTER_COUNT = 9

@Composable
private fun EmptyFavorites() {
    val p = LocalPalette.current
    Column(
        Modifier.fillMaxSize().padding(40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(KomojeIcons.Favorite, contentDescription = null, tint = p.heart, modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(18.dp))
        Text(
            stringResource(R.string.empty_title),
            color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 20.sp,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            stringResource(R.string.empty_hint),
            color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Medium,
            fontSize = 15.sp, textAlign = TextAlign.Center,
        )
    }
}
