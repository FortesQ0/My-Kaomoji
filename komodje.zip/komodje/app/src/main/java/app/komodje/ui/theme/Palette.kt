package app.komodje.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

@Immutable
data class Palette(
    val bgTop: Color,
    val bgMid: Color,
    val bgBottom: Color,
    val card: Color,
    val ink: Color,
    val muted: Color,
    /** Персиковый: шапка, нижняя панель, вспышка карточки. accentDeep — конец мягкого градиента. */
    val accent: Color,
    val accentDeep: Color,
    val onAccent: Color,
    /** Тёмный лист активной вкладки и логотипа. */
    val badge: Color,
    val badgeDeep: Color,
    /** Цвет залитого сердечка. */
    val heart: Color,
)

val LightPalette = Palette(
    bgTop = Color(0xFFFFF9F5),
    bgMid = Color(0xFFFFF0E8),
    bgBottom = Color(0xFFFFE4D6),
    card = Color(0xFFFFFFFF),
    ink = Color(0xFF2B1812),
    muted = Color(0xFFA68578),
    accent = Color(0xFFFFB496),
    accentDeep = Color(0xFFFF9B78),
    onAccent = Color(0xFF2B1812),
    badge = Color(0xFF3A211A),
    badgeDeep = Color(0xFF22120D),
    heart = Color(0xFFFF7A59),
)

val DarkPalette = Palette(
    bgTop = Color(0xFF241814),
    bgMid = Color(0xFF1A110E),
    bgBottom = Color(0xFF120B09),
    card = Color(0xFF2E1F1A),
    ink = Color(0xFFFFF0E8),
    muted = Color(0xFFB89A8E),
    accent = Color(0xFFFFB594),
    accentDeep = Color(0xFFFF9B78),
    onAccent = Color(0xFF2B1812),
    badge = Color(0xFF1E110C),
    badgeDeep = Color(0xFF120A07),
    heart = Color(0xFFFFA283),
)

val LocalPalette = compositionLocalOf { DarkPalette }

/** Фон экрана: три остановки, чуть темнее книзу. */
fun Palette.backgroundBrush(): Brush = Brush.verticalGradient(listOf(bgTop, bgMid, bgBottom))

/** Мягкий диагональный градиент персика: шапка, нижняя панель, вспышка карточки. */
fun Palette.accentBrush(): Brush = Brush.linearGradient(listOf(accent, accentDeep))

/** Тёмный лист: логотип, значок активной вкладки, кнопки. */
fun Palette.badgeBrush(): Brush = Brush.linearGradient(listOf(badge, badgeDeep))
