package app.komodje.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

@Immutable
data class Palette(
    val bgTop: Color,
    val bgBottom: Color,
    val card: Color,
    val ink: Color,
    val muted: Color,
    /** Персиковый: шапка, нижняя панель, вспышка карточки. */
    val accent: Color,
    val onAccent: Color,
    /** Тёмная «капля» активной вкладки. */
    val badge: Color,
    /** Цвет залитого сердечка. */
    val heart: Color,
)

val LightPalette = Palette(
    bgTop = Color(0xFFFFF8F3),
    bgBottom = Color(0xFFFFE9DE),
    card = Color(0xFFFFFFFF),
    ink = Color(0xFF2B1812),
    muted = Color(0xFFA68578),
    accent = Color(0xFFFFA987),
    onAccent = Color(0xFF2B1812),
    badge = Color(0xFF2B1812),
    heart = Color(0xFFFF7A59),
)

val DarkPalette = Palette(
    bgTop = Color(0xFF211613),
    bgBottom = Color(0xFF130C0A),
    card = Color(0xFF2E1F1A),
    ink = Color(0xFFFFF0E8),
    muted = Color(0xFFB89A8E),
    accent = Color(0xFFFFB090),
    onAccent = Color(0xFF2B1812),
    badge = Color(0xFF1A0F0B),
    heart = Color(0xFFFFA283),
)

val LocalPalette = staticCompositionLocalOf { DarkPalette }

fun Palette.backgroundBrush(): Brush = Brush.verticalGradient(listOf(bgTop, bgBottom))
