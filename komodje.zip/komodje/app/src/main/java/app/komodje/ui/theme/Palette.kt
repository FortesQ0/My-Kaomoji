package app.komodje.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import app.komodje.domain.AccentTheme

@Immutable
data class Palette(
    val bgTop: Color,
    val bgMid: Color,
    val bgBottom: Color,
    val card: Color,
    val cardDeep: Color,
    val ink: Color,
    val muted: Color,
    /** Цветной блок: шапка, нижняя панель, вспышка карточки. accentDeep: конец градиента. */
    val accent: Color,
    val accentDeep: Color,
    /** Текст и иконки поверх цветного блока (тёмные на светлом акценте, светлые на тёмном). */
    val onAccent: Color,
    val onAccent2: Color,
    /** Тёмный лист: логотип, значок активной вкладки, кнопки. */
    val badge: Color,
    val badgeDeep: Color,
    /** Светлые иконки и текст на тёмном листе. */
    val onBadge: Color,
    val onBadgeDeep: Color,
    /** Цвет залитого сердечка. */
    val heart: Color,
)

private fun c(argb: Long) = Color(argb)

/** Восемь палитр: четыре цвета, у каждого светлый и тёмный режим в своём тоне. */
fun paletteFor(accent: AccentTheme, dark: Boolean): Palette = when (accent) {
    AccentTheme.PEACH -> if (!dark) Palette(
        bgTop = c(0xFFFFF9F5), bgMid = c(0xFFFFF0E8), bgBottom = c(0xFFFFE4D6),
        card = c(0xFFFFFFFF), cardDeep = c(0xFFFFF8F4), ink = c(0xFF2B1812), muted = c(0xFFA68578),
        accent = c(0xFFFFE6DA), accentDeep = c(0xFFFFB896), onAccent = c(0xFF4A2A20), onAccent2 = c(0xFF22120D),
        badge = c(0xFF4A2A20), badgeDeep = c(0xFF22120D), onBadge = c(0xFFFFC9AE), onBadgeDeep = c(0xFFFF9B78),
        heart = c(0xFFFF7A59),
    ) else Palette(
        bgTop = c(0xFF241814), bgMid = c(0xFF1A110E), bgBottom = c(0xFF120B09),
        card = c(0xFF2E1F1A), cardDeep = c(0xFF281A16), ink = c(0xFFFFF0E8), muted = c(0xFFB89A8E),
        accent = c(0xFFF3CBB8), accentDeep = c(0xFFE39F7E), onAccent = c(0xFF4A2A20), onAccent2 = c(0xFF22120D),
        badge = c(0xFF1E110C), badgeDeep = c(0xFF120A07), onBadge = c(0xFFFFC9AE), onBadgeDeep = c(0xFFFF9B78),
        heart = c(0xFFFFA283),
    )

    AccentTheme.SAKURA -> if (!dark) Palette(
        bgTop = c(0xFFFFF8FA), bgMid = c(0xFFFFEFF4), bgBottom = c(0xFFFFE0EA),
        card = c(0xFFFFFFFF), cardDeep = c(0xFFFFF6F9), ink = c(0xFF3A1424), muted = c(0xFFB07A8E),
        accent = c(0xFFFFE8EF), accentDeep = c(0xFFFFB6CC), onAccent = c(0xFF4A1A2C), onAccent2 = c(0xFF2A0D19),
        badge = c(0xFF5A2540), badgeDeep = c(0xFF2E1020), onBadge = c(0xFFFFD0DF), onBadgeDeep = c(0xFFFF9FBD),
        heart = c(0xFFFF5C8A),
    ) else Palette(
        bgTop = c(0xFF28121C), bgMid = c(0xFF1B0C14), bgBottom = c(0xFF12070D),
        card = c(0xFF361C29), cardDeep = c(0xFF2F1823), ink = c(0xFFFFE9F0), muted = c(0xFFC195A8),
        accent = c(0xFFF2C4D4), accentDeep = c(0xFFE592AE), onAccent = c(0xFF3A1325), onAccent2 = c(0xFF1F0913),
        badge = c(0xFF2A1020), badgeDeep = c(0xFF170812), onBadge = c(0xFFFFC2D4), onBadgeDeep = c(0xFFFF8FB1),
        heart = c(0xFFFF86A8),
    )

    AccentTheme.SEA -> if (!dark) Palette(
        bgTop = c(0xFFF5FAFF), bgMid = c(0xFFE9F3FF), bgBottom = c(0xFFD8E8FB),
        card = c(0xFFFFFFFF), cardDeep = c(0xFFF3F8FF), ink = c(0xFF0E1B3A), muted = c(0xFF7389A8),
        accent = c(0xFFE0F0FF), accentDeep = c(0xFF93C4F7), onAccent = c(0xFF0E1F45), onAccent2 = c(0xFF081330),
        badge = c(0xFF1F3A6B), badgeDeep = c(0xFF0E1B3A), onBadge = c(0xFFBFDDFF), onBadgeDeep = c(0xFF7DB6F5),
        heart = c(0xFF3B82F6),
    ) else Palette(
        bgTop = c(0xFF0E1638), bgMid = c(0xFF0A1030), bgBottom = c(0xFF070B1C),
        card = c(0xFF141E47), cardDeep = c(0xFF111A3F), ink = c(0xFFEAF1FF), muted = c(0xFF8FA2C8),
        accent = c(0xFFB5D6FA), accentDeep = c(0xFF6FA9E8), onAccent = c(0xFF0A1A38), onAccent2 = c(0xFF060F26),
        badge = c(0xFF0C1530), badgeDeep = c(0xFF060B1D), onBadge = c(0xFFA8D0FF), onBadgeDeep = c(0xFF6EAAF0),
        heart = c(0xFF6FA8FF),
    )

    AccentTheme.BURGUNDY -> if (!dark) Palette(
        bgTop = c(0xFFFFF9F9), bgMid = c(0xFFFFEFF1), bgBottom = c(0xFFFBDDE3),
        card = c(0xFFFFFFFF), cardDeep = c(0xFFFFF6F7), ink = c(0xFF2A0C14), muted = c(0xFFA5707C),
        accent = c(0xFFBD5A72), accentDeep = c(0xFF7E2339), onAccent = c(0xFFFFEFF2), onAccent2 = c(0xFFFFC4CF),
        badge = c(0xFF2E0A14), badgeDeep = c(0xFF160509), onBadge = c(0xFFFFB3C1), onBadgeDeep = c(0xFFFF8FA3),
        heart = c(0xFFD83A5A),
    ) else Palette(
        bgTop = c(0xFF2B0E16), bgMid = c(0xFF1D0910), bgBottom = c(0xFF12050A),
        card = c(0xFF3A1823), cardDeep = c(0xFF33141E), ink = c(0xFFFFE8EC), muted = c(0xFFC595A0),
        accent = c(0xFFA24A62), accentDeep = c(0xFF6B1B31), onAccent = c(0xFFFFEEF1), onAccent2 = c(0xFFFFBFCB),
        badge = c(0xFF24080F), badgeDeep = c(0xFF130407), onBadge = c(0xFFFFB3C1), onBadgeDeep = c(0xFFFF8FA3),
        heart = c(0xFFFF6B86),
    )
}

val LocalPalette = compositionLocalOf { paletteFor(AccentTheme.PEACH, dark = false) }

/** Фон экрана: три остановки, чуть темнее книзу. */
fun Palette.backgroundBrush(): Brush = Brush.verticalGradient(listOf(bgTop, bgMid, bgBottom))

/** Диагональный градиент цветного блока: шапка, нижняя панель, вспышка карточки. */
fun Palette.accentBrush(): Brush = Brush.linearGradient(listOf(accent, accentDeep))

/** Тёмный лист: логотип, значок активной вкладки, кнопки. */
fun Palette.badgeBrush(): Brush = Brush.linearGradient(listOf(badge, badgeDeep))

/** Едва заметный градиент самой карточки. */
fun Palette.cardBrush(): Brush = Brush.verticalGradient(listOf(card, cardDeep))

/** Градиент иконок на цветном блоке (нижняя панель). */
fun Palette.onAccentBrush(): Brush = Brush.verticalGradient(listOf(onAccent, onAccent2))

/** Градиент иконок на тёмном листе (значок активной вкладки). */
fun Palette.onBadgeBrush(): Brush = Brush.verticalGradient(listOf(onBadge, onBadgeDeep))
