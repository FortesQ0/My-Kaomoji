package app.komodje.ui.components

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.komodje.R
import app.komodje.ui.theme.LeafShape
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.LogoShape
import app.komodje.ui.theme.Onest
import app.komodje.ui.theme.badgeBrush
import androidx.compose.foundation.layout.offset
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.lerp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay

/** Способ поддержать. Ссылки и кошельки подключим позже: пока строки только оформлены. */
private enum class DonateMethod(val icon: ImageVector, val title: Int, val hint: Int) {
    TELEGRAM(KomojeIcons.Plane, R.string.donate_telegram, R.string.donate_telegram_hint),
    CRYPTO(KomojeIcons.Coin, R.string.donate_crypto, R.string.donate_crypto_hint),
    CARD(KomojeIcons.Card, R.string.donate_card, R.string.donate_card_hint),
}

private val SheetShape = RoundedCornerShape(topStart = 34.dp, topEnd = 14.dp, bottomEnd = 0.dp, bottomStart = 0.dp)

/**
 * Нижняя панель «Купить мне чашку кофе»: поднимается снизу, под ней мягко темнеет фон,
 * способы появляются по одному. Закрывается тапом по затемнению, кнопкой «назад» или свайпом системы.
 */
@Composable
fun DonateSheet(onClose: () -> Unit) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    val soon = stringResource(R.string.donate_soon)
    var cryptoOpen by remember { mutableStateOf(false) }
    if (cryptoOpen) UsdtDialog(onClose = { cryptoOpen = false })
    // Закрытие идёт через обратную анимацию: сначала уезжает панель, потом закрывается окно.
    val visible = remember { MutableTransitionState(false).apply { targetState = true } }
    LaunchedEffect(visible.currentState, visible.targetState) {
        if (!visible.currentState && !visible.targetState) onClose()
    }
    val dismiss = { visible.targetState = false }

    Dialog(onDismissRequest = dismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
            val scrimSource = remember { MutableInteractionSource() }
            AnimatedVisibility(
                visibleState = visible,
                enter = fadeIn(Motion.standard()),
                exit = fadeOut(Motion.standard()),
            ) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.32f))
                        .clickable(interactionSource = scrimSource, indication = null) { dismiss() },
                )
            }
            AnimatedVisibility(
                visibleState = visible,
                enter = slideInVertically(Motion.slow()) { it / 3 } + fadeIn(Motion.standard()),
                exit = slideOutVertically(Motion.standard()) { it / 3 } + fadeOut(Motion.quick()),
            ) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(SheetShape)
                        .background(p.bgTop)
                        // Тап по самой панели не должен закрывать её через затемнение.
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
                        .navigationBarsPadding()
                        .padding(start = 20.dp, end = 20.dp, top = 10.dp, bottom = 22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Box(
                        Modifier
                            .width(38.dp)
                            .height(4.dp)
                            .clip(CircleShape)
                            .background(p.muted.copy(alpha = 0.35f)),
                    )
                    Spacer(Modifier.height(18.dp))
                    SheetHeader()
                    Spacer(Modifier.height(18.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        DonateMethod.entries.forEachIndexed { index, method ->
                            Staggered(index) {
                                MethodRow(
                                    method,
                                    soon = stringResource(R.string.donate_soon),
                                    ready = method == DonateMethod.CRYPTO,
                                ) {
                                    if (method == DonateMethod.CRYPTO) cryptoOpen = true
                                    else Toast.makeText(ctx, soon, Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Text(
                        stringResource(R.string.donate_thanks),
                        color = p.muted.copy(alpha = 0.9f),
                        fontFamily = Onest,
                        fontWeight = FontWeight.Medium,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                    )
                }
            }
        }
    }
}

@Composable
private fun SheetHeader() {
    val p = LocalPalette.current
    val fill = remember(p) { p.badgeBrush() }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(52.dp).clip(LogoShape).background(fill),
            contentAlignment = Alignment.Center,
        ) {
            Icon(KomojeIcons.Coffee, contentDescription = null, tint = p.onBadge, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                stringResource(R.string.donate_title),
                color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 20.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(2.dp))
            Text(
                stringResource(R.string.donate_sheet_hint),
                color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 14.sp,
                lineHeight = 19.sp,
            )
        }
    }
}

/** Строки способов въезжают по очереди: прозрачность и лёгкий подъём. */
@Composable
private fun Staggered(index: Int, content: @Composable () -> Unit) {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(160L + index * 70L)
        progress.animateTo(1f, Motion.standard())
    }
    Box(
        Modifier.graphicsLayer {
            alpha = progress.value
            translationY = (1f - progress.value) * 24f
        },
    ) { content() }
}

@Composable
private fun MethodRow(method: DonateMethod, soon: String, ready: Boolean, onClick: () -> Unit) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val source = remember { MutableInteractionSource() }
    val fill = remember(p) { p.badgeBrush() }
    Row(
        Modifier
            .fillMaxWidth()
            .pressScale(source, pressedScale = 0.975f)
            .softShadow(LeafShape)
            .clip(LeafShape)
            .background(p.card)
            .clickable(interactionSource = source, indication = null) {
                tick()
                onClick()
            }
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(42.dp).clip(LogoShape).background(fill),
            contentAlignment = Alignment.Center,
        ) {
            Icon(method.icon, contentDescription = null, tint = p.onBadge, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                stringResource(method.title),
                color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 16.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Text(
                stringResource(method.hint),
                color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 13.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.width(10.dp))
        if (ready) {
            Icon(KomojeIcons.Sparkle, contentDescription = null, tint = p.heart, modifier = Modifier.size(18.dp))
        } else {
            Box(
                Modifier
                    .clip(CircleShape)
                    .background(p.ink.copy(alpha = 0.06f))
                    .padding(horizontal = 10.dp, vertical = 5.dp),
            ) {
                Text(
                    soon,
                    color = p.muted, fontFamily = Onest, fontWeight = FontWeight.SemiBold, fontSize = 12.sp,
                    maxLines = 1,
                )
            }
        }
    }
}

/**
 * Экран «Криптовалюта»: сеть, QR, адрес и предупреждение читаются одним блоком. Чтобы не ошибиться,
 * сеть названа плашкой, адрес показан целиком группами по 6 символов, а тап по адресу (как и кнопка
 * «Копировать») кладёт его в буфер и подтверждает это сообщением. «Поделиться» отправляет открытку.
 */
@Composable
private fun UsdtDialog(onClose: () -> Unit) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    val tick = rememberTick()
    val buzz = rememberBuzz()
    val scope = rememberCoroutineScope()
    val copiedMsg = stringResource(R.string.usdt_copied)
    val shareTitle = stringResource(R.string.usdt_share)
    val thanks = stringResource(R.string.usdt_thanks)
    val networkLine = stringResource(R.string.usdt_network, UsdtQr.NETWORK)
    val copyAddress = {
        buzz()
        val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("USDT", UsdtQr.ADDRESS))
        Toast.makeText(ctx, copiedMsg, Toast.LENGTH_SHORT).show()
    }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                // Весь блок чуть ниже центра экрана.
                .offset(y = 28.dp)
                .padding(horizontal = 18.dp)
                .fillMaxWidth()
                .softShadow(RoundedCornerShape(30.dp), 10.dp)
                .clip(RoundedCornerShape(30.dp))
                .background(p.bgTop)
                .padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                stringResource(R.string.usdt_title),
                color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 20.sp,
            )
            Spacer(Modifier.height(8.dp))
            // Сеть одной плашкой: «Сеть: Tron (TRC-20)».
            Box(
                Modifier
                    .clip(CircleShape)
                    .background(p.ink.copy(alpha = 0.07f))
                    .padding(horizontal = 14.dp, vertical = 6.dp),
            ) {
                Text(
                    networkLine,
                    color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            Spacer(Modifier.height(10.dp))
            // QR всегда чёрный на белом: так его уверенно читают любые кошельки и банки.
            Column(
                Modifier
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color.White)
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                QrCode(UsdtQr.MODULES, Modifier.fillMaxWidth().aspectRatio(1f))
                Spacer(Modifier.height(10.dp))
                // Тап по адресу копирует его так же, как кнопка «Копировать».
                val addressSource = remember { MutableInteractionSource() }
                Text(
                    UsdtQr.ADDRESS.chunked(6).joinToString(" "),
                    color = Color(0xFF111111), fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold, fontSize = 15.sp, lineHeight = 21.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable(interactionSource = addressSource, indication = null) { copyAddress() }
                        .padding(horizontal = 4.dp, vertical = 2.dp),
                )
            }
            Spacer(Modifier.height(8.dp))
            // Предупреждение о сети: самая частая ошибка при переводах. Стоит вплотную к блоку с адресом.
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(p.heart.copy(alpha = 0.12f))
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(KomojeIcons.Sparkle, null, tint = p.heart, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(10.dp))
                Text(
                    stringResource(R.string.usdt_warning),
                    color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Medium,
                    fontSize = 13.sp, lineHeight = 18.sp,
                )
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                DialogButton(
                    label = stringResource(R.string.usdt_copy),
                    filled = true,
                    icon = KomojeIcons.Copy,
                    modifier = Modifier.weight(1f),
                    onClick = { copyAddress() },
                )
                DialogButton(
                    label = stringResource(R.string.usdt_share),
                    filled = false,
                    icon = KomojeIcons.Send,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        tick()
                        // Открытка: QR, «Спасибо за поддержку», каомодзи и адрес; адрес идёт ещё и текстом.
                        val colors = ShareCard.Colors(
                            // Открытка всегда светлая и с тёмным текстом: читается в любом чате и любой теме.
                            bgTop = lerp(p.accent, Color.White, 0.45f).toArgb(),
                            bgBottom = lerp(p.accent, Color.White, 0.85f).toArgb(),
                            ink = 0xFF2A2133.toInt(),
                            accent = p.accentDeep.toArgb(),
                        )
                        scope.launch {
                            val chooser = withContext(Dispatchers.IO) {
                                runCatching {
                                    val bmp = ShareCard.render(thanks, networkLine, colors)
                                    ShareCard.buildIntent(ctx, bmp, shareTitle)
                                }.getOrNull()
                            }
                            if (chooser != null) {
                                runCatching { ctx.startActivity(chooser) }
                            } else {
                                // Картинку собрать не вышло: отправляем хотя бы адрес текстом.
                                val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(android.content.Intent.EXTRA_TEXT, UsdtQr.ADDRESS)
                                }
                                ctx.startActivity(android.content.Intent.createChooser(send, shareTitle))
                            }
                        }
                    },
                )
            }
            Spacer(Modifier.height(8.dp))
            DialogButton(
                label = stringResource(R.string.folder_help_ok),
                filled = false,
                modifier = Modifier.fillMaxWidth(),
                onClick = onClose,
            )
        }
    }
}

/** Рисует QR из таблицы модулей: чёрные квадраты со всех сторон окружены белой «тихой зоной» самой карточкой. */
@Composable
private fun QrCode(modules: List<String>, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val n = modules.size
        val cell = size.minDimension / n
        for (y in 0 until n) for (x in 0 until n) {
            if (modules[y][x] == '1') {
                drawRect(
                    Color(0xFF111111),
                    topLeft = Offset(x * cell, y * cell),
                    size = Size(cell + 0.6f, cell + 0.6f),
                )
            }
        }
    }
}
