// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import app.komodje.ui.HomeViewModel
import kotlinx.coroutines.launch

/**
 * Пункт «Добавить в Kaoji» в меню выделения текста в любом приложении (PROCESS_TEXT).
 * Без интерфейса: читает выделенное, кладёт в «Любимые» как своё каомодзи, показывает
 * короткое сообщение и сразу закрывается.
 */
class AddToKaojiActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val raw = intent?.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString().orEmpty()
        val text = raw.replace(Regex("\\s*[\\r\\n]+\\s*"), " ").trim()
        if (text.isEmpty()) {
            finish()
            return
        }
        if (text.length > HomeViewModel.MAX_OWN) {
            Toast.makeText(this, R.string.own_too_long, Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        val favorites = (application as KomodjeApp).container.favorites
        val appContext = applicationContext
        lifecycleScope.launch {
            val added = favorites.addOwn(text)
            Toast.makeText(
                appContext,
                if (added) R.string.own_saved else R.string.own_exists,
                Toast.LENGTH_SHORT,
            ).show()
            finish()
        }
    }
}
