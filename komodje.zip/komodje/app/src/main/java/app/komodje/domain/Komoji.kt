package app.komodje.domain

enum class Mood { FAVORITE, HAPPY, SAD, NEUTRAL, ANGRY, TENDER }

data class Komoji(val text: String)

/** Отсекает «просто скобки» и чистый ASCII-смайлик: нужен хотя бы один не-ASCII символ. */
fun Komoji.isComplex(): Boolean =
    text.length >= 3 && text.any { it.code > 127 }

private val sadGlyphs = setOf('◞', '◟', '︵', '╥', '﹏', '；')

/** Грубый линт настроения: в «весёлых» не должно быть грустных глифов. */
fun Komoji.fitsHappy(): Boolean = text.none { it in sadGlyphs }

/** Тема оформления: своя настройка поверх системной. */
enum class ThemeMode { SYSTEM, LIGHT, DARK }
