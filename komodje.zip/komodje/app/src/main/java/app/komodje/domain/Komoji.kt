package app.komodje.domain

enum class Mood { FAVORITE, HAPPY, SAD, NEUTRAL, ANGRY, TENDER }

data class Komoji(val text: String)

/** Отсекает «просто скобки» и чистый ASCII-смайлик: нужен хотя бы один не-ASCII символ. */
fun Komoji.isComplex(): Boolean =
    text.length >= 3 && text.any { it.code > 127 }

private val sadGlyphs = setOf('◞', '◟', '︵', '╥', '﹏', '；')

/** Грубый линт настроения: в «весёлых» не должно быть грустных глифов. */
fun Komoji.fitsHappy(): Boolean = text.none { it in sadGlyphs }

/** Тема оформления: своя настройка поверх системной. */
enum class ThemeMode { SYSTEM, LIGHT, DARK }

/** Акцентный цвет приложения. top/bottom: цвета превью-плитки в настройках (ARGB). */
enum class AccentTheme(val top: Long, val bottom: Long) {
    PEACH(0xFFFFC0A0, 0xFFFF8F6B),
    SAKURA(0xFFFFC9DA, 0xFFFF8FB1),
    SEA(0xFFA9D3FF, 0xFF4F9BF0),
    BURGUNDY(0xFF9C3350, 0xFF5C1022),
}
