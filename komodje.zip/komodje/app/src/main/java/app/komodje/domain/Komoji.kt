package app.komodje.domain

enum class Mood { FAVORITE, HAPPY, SAD, NEUTRAL, ANGRY, TENDER }

data class Komoji(val text: String)

/** Отсекает «просто скобки»: нужна длина и минимум два разных не-ASCII символа. */
fun Komoji.isComplex(): Boolean =
    text.length >= 7 && text.filter { it.code > 127 }.toSet().size >= 2

private val sadGlyphs = setOf('◞', '◟', '︵', '╥', '﹏', '；')

/** Грубый линт настроения: в «весёлых» не должно быть грустных глифов. */
fun Komoji.fitsHappy(): Boolean = text.none { it in sadGlyphs }
