package app.komodje.domain

enum class Mood { FAVORITE, HAPPY, SAD, NEUTRAL, ANGRY, TENDER }

/**
 * flags: бит 1 = есть эффекты снаружи, бит 2 = два и более персонажей; -1 = не размечено,
 * тогда считаем по тексту.
 */
data class Komoji(val text: String, val flags: Int = -1) {
    val resolvedFlags: Int get() = if (flags >= 0) flags else flagsOf(text)
}

/** Отсекает «просто скобки» и чистый ASCII-смайлик: нужен хотя бы один не-ASCII символ. */
fun Komoji.isComplex(): Boolean =
    text.length >= 3 && text.any { it.code > 127 }

private val sadGlyphs = setOf('◞', '◟', '︵', '╥', '﹏', '；')

/** Грубый линт настроения: в «весёлых» не должно быть грустных глифов. */
fun Komoji.fitsHappy(): Boolean = text.none { it in sadGlyphs }

/** Тема оформления: своя настройка поверх системной. */
enum class ThemeMode { SYSTEM, LIGHT, DARK }

/** Акцентный цвет приложения. top/bottom: цвета превью-плитки в настройках (ARGB). */
enum class AccentTheme(val top: Long, val bottom: Long) {
    PEACH(0xFFFFE6DA, 0xFFFFB896),
    SAKURA(0xFFFFE8EF, 0xFFFFB6CC),
    SEA(0xFFE0F0FF, 0xFF93C4F7),
    BURGUNDY(0xFFBD5A72, 0xFF7E2339),
}
