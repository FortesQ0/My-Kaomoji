#!/usr/bin/env python3
"""Пересобирает категории в komoji.json: каждое каомодзи оценивается по лицу целиком.

Запуск из корня проекта:
    python3 tools/recategorize.py --dry          # только отчёт
    python3 tools/recategorize.py --write        # переписать assets/komoji.json

Правило переноса консервативное: смайлик уходит из своей категории, только если классификатор
уверен (запас очков >= 2) и в тексте нет явных признаков текущей категории. Всё сомнительное
остаётся как было. Каждый смайлик остаётся ровно в одной категории; flags едут вместе с ним.
"""
import argparse
import collections
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import classify  # noqa: E402
import facekit  # noqa: E402

JSON_PATH = os.path.join(HERE, "..", "app", "src", "main", "assets", "komoji.json")

HAPPY_GLYPHS = set("∀▽∇◡‿ᴗᗜᗨヮ^＾≧≦♪♫♬✧☆★ꇴ▿艸ڡ")
ANGRY_GLYPHS = set("皿益凸ಠꐦ#＃╬ψ┻┴òóÒÓ◣◢")
SAD_GLYPHS = set("╥ಥ༎இ︵﹏︿⌓‸ཀཫ⍛ᾥㅠㅜᯅ〒")
TENDER_GLYPHS = set("♡♥❤ღ꒳ᵕ❥˶〃⸝")
BROWS = re.compile(r"[`｀ˋ].{0,3}[´ˊ]")
TEARS = re.compile(r"[;；].{0,3}[;；]|[TТтＴ].{0,2}[TТтＴ]|(?i:orz|otl)|[×✖].{0,3}[×✖]|[xX].{0,2}[×✖xX]")
FLAT_FINGER = re.compile(r"╭∩╮")


def has_angry(t):
    s = facekit.squash(t)
    return any(c in ANGRY_GLYPHS for c in s) or bool(BROWS.search(s)) or bool(FLAT_FINGER.search(s))


def has_sad(t):
    s = facekit.squash(t)
    return any(c in SAD_GLYPHS for c in s) or bool(TEARS.search(s))


def has_tender(t):
    s = facekit.squash(t)
    return any(c in TENDER_GLYPHS for c in s) or "//" in s or "⁄" in s or any(c in "⑅ෆ❁❣" for c in s)


def has_happy(t):
    return any(c in HAPPY_GLYPHS for c in facekit.squash(t))


CURATED_PATH = os.path.join(HERE, "curated.json")

# ---------- что удаляем целиком (дефектные: смысл не читается с первого взгляда) ----------
ORZ = re.compile(r"(?i)orz|otl|_\|[‾￣＼\\]\||\|[￣‾]\|[○◯]|_\|[＼\\][○◯]|」∠|∠\)|∠:|乙|[○◯]_(?!ﾟ)|_\|")
ORZ_NOT = ("ヽ( ﾟ_○ﾟ)人(ﾟ○_ﾟ )ﾉ",)  # это лицо с круглыми глазами, не поза
# иероглифы, которые работают частью лица или тела (рот, румянец, руки, чашка в руках)
BODY_KANJI = set("人艸皿益口囗罒凸因言公冫屮乂三灬旦且八丿乁乀从十彡入尸川厂曲血田目囿圄只日一炎")
# кана, которая работает рукой, глазом, ртом или эффектом, а не буквой слова
BODY_KANA = set("ヽノﾉヾゞﾞ゛ゝ゜ﾟヮロﾛェｪヘへﾍつっづとﾂｼﾒメﾐミー・ｰ･ﾊハツッシ")
LINES = re.compile(r"_{3,}|＿{3,}")


def is_kana(c):
    o = ord(c)
    return 0x3041 <= o <= 0x30FF or 0xFF66 <= o <= 0xFF9D


def is_kanji(c):
    o = ord(c)
    return 0x4E00 <= o <= 0x9FFF or 0x3400 <= o <= 0x4DBF


def removal_reason(text, deletions):
    """Причина удаления или None. Удаляем целиком, ничего не обрезаем."""
    if text in deletions:
        return "curated-delete"
    s = facekit.squash(text)
    if text not in ORZ_NOT and ORZ.search(s):
        return "orz-pose"
    if any(is_kanji(c) and c not in BODY_KANJI for c in text):
        return "kanji-caption"
    gs, _ = facekit.groups(text)
    face = max(gs, key=len) if gs else ""
    out = facekit.outside(text)
    if any(is_kana(c) and c not in BODY_KANA for c in out):
        return "kana-caption"
    if sum(1 for c in face if is_kana(c) and c not in BODY_KANA) >= 2:
        return "kana-caption"
    if LINES.search(s):
        return "line-junk"
    return None
DETERMINED = re.compile(r"[`｀ˋ][･・•‐ー-][ω_ー‿-][･・•‐ー-][´ˊ]")
ANNOYED = re.compile(r"[`｀][-‐]?[дДε皿益][-‐]?[´]")


def curated():
    with open(CURATED_PATH, encoding="utf-8") as f:
        return json.load(f)["overrides"]


def curated_deletions():
    with open(CURATED_PATH, encoding="utf-8") as f:
        return set(json.load(f).get("delete", []))


_CURATED = None


SAD_TEST_GLYPHS = set("◞◟︵╥﹏；")  # те же, что в Komoji.fitsHappy

# Глаза-полумесяцы «∪» это закрытые глаза, покой. Радости они не дают: решает рот.
CRESCENT = set("◡ᴗ‿⌣ᵕ︶˘⏝⁀")
SMILE_MOUTH = set("ᴗ‿◡⌣ᵕ︶˘∀▽∇ᗜヮ艸ڡ∪꒳ωε3зﾛ﹃ᴥˬ˳₄⩊▿ɜ")
SAD_MOUTH = set("︵﹏︿⌓‸へヘ")


CRESCENT_PAIR = re.compile(r"([◡ᴗ‿⌣ᵕ︶˘⁀])([^()◡ᴗ‿⌣ᵕ︶˘⁀✧☆★◕◠⌒^＾≧≦]{0,3})\1")


def crescent_eyes(text):
    """(есть ли глаза-полумесяцы, рот) для лица вида (◡_◡). Рот пустой, если его нет.
    ‿‿ подряд это двойная улыбка (рот), а не глаза."""
    _, _, _, core, _ = classify.parse(classify.strip_marks(text))
    c = "".join(ch for ch in core if not ch.isspace() and ch not in "*＊∗⁎๑˶⸝〃｡。,，\"'°゜ﾟᐡᐢ˳")
    for m in CRESCENT_PAIR.finditer(c):
        if m.group(1) == "‿" and not m.group(2):
            continue
        return True, m.group(2)
    return False, ""


def crescent_target(text):
    """Куда идёт лицо с глазами-полумесяцами (если оно сейчас в «Счастливых»)."""
    ok, mouth = crescent_eyes(text)
    if not ok:
        return None
    if has_sad(text) or any(m in SAD_MOUTH for m in mouth):
        return "SAD"
    if has_tender(text) or (mouth and any(m in SMILE_MOUTH for m in mouth)):
        return "TENDER"
    return "NEUTRAL"


def decide(text, current):
    """Возвращает (новая категория, причина). Если менять нечего, категория та же."""
    to, why = _decide(text, current)
    if to == "HAPPY":
        fix = crescent_target(text)
        if fix:
            return fix, "crescent-eyes"
    if to == "HAPPY" and current != "HAPPY" and any(c in SAD_TEST_GLYPHS for c in text):
        return "NEUTRAL", "sad-glyph-guard"
    return to, why


def _decide(text, current):
    global _CURATED
    if _CURATED is None:
        _CURATED = curated()
    if text in _CURATED:
        return _CURATED[text], "curated" if _CURATED[text] != current else ""
    s = facekit.squash(text)
    # Недовольное лицо без точек-глаз и пота: (｀д´). С точками (｀･ω･´) это «решительное», оно нейтральное.
    # (｀･ω･´) это «решительный», а не злой: в «Нейтральных» таких большинство, выравниваем.
    if current == "ANGRY" and DETERMINED.search(s) and not any(c in "皿益ಠꐦ#＃╬凸" for c in s):
        return "NEUTRAL", "determined-face"
    if current == "NEUTRAL" and ANNOYED.search(s) and not re.search(r"[;；･・•]", s):
        return "ANGRY", "annoyed-brows"
    rule, cf, sc, why = classify.classify(text)
    if rule == current or cf < 2:
        return current, ""
    # --- уходят из SAD: нет ни слёз, ни грустного рта
    if current == "SAD" and not has_sad(text):
        return rule, "no-sad-evidence"
    # --- приходят в SAD: явные признаки грусти
    if rule == "SAD":
        if has_sad(text) and not has_angry(text) and not (current == "TENDER" and has_tender(text)):
            return "SAD", "sad-evidence"
        return current, ""
    if current == "ANGRY" and not has_angry(text):
        return rule, "no-angry-evidence"
    if rule == "ANGRY":
        if has_angry(text) and not has_happy(text):
            return "ANGRY", "angry-evidence"
        return current, ""
    if current == "HAPPY" and rule == "NEUTRAL" and not has_happy(text):
        return "NEUTRAL", "no-happy-evidence"
    if current == "NEUTRAL" and rule in ("HAPPY", "TENDER") and cf >= 2.5:
        return rule, "neutral-with-evidence"
    return current, ""


def load():
    with open(JSON_PATH, encoding="utf-8") as f:
        return json.load(f)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--write", action="store_true")
    ap.add_argument("--dry", action="store_true")
    ap.add_argument("--dump", help="путь для JSON-отчёта о переносах")
    args = ap.parse_args()
    data = load()
    cats = {c["mood"]: c for c in data["categories"]}
    order = [c["mood"] for c in data["categories"]]
    new_items = {m: [] for m in order}
    new_flags = {m: [] for m in order}
    moves = collections.defaultdict(list)
    deletions = curated_deletions()
    removed = collections.defaultdict(list)
    for m in order:
        c = cats[m]
        flags = c.get("flags") or [-1] * len(c["items"])
        for t, fl in zip(c["items"], flags):
            why_del = removal_reason(t, deletions)
            if why_del:
                removed[(m, why_del)].append(t)
                continue
            to, reason = decide(t, m)
            new_items[to].append(t)
            new_flags[to].append(fl)
            if to != m:
                moves[(m, to, reason)].append(t)
    print("удалено:", sum(len(v) for v in removed.values()))
    for k, v in sorted(removed.items(), key=lambda kv: -len(kv[1])):
        print("  удалено", k, len(v))
    print("перенесено:", sum(len(v) for v in moves.values()))
    for k, v in sorted(moves.items(), key=lambda kv: -len(kv[1])):
        print(k, len(v))
    if args.dump:
        with open(args.dump, "w", encoding="utf-8") as f:
            json.dump({"|".join(k): v for k, v in moves.items()}
                      | {"DEL|" + "|".join(k): v for k, v in removed.items()}, f, ensure_ascii=False, indent=0)
    print({m: len(new_items[m]) for m in order})
    if args.write:
        for c in data["categories"]:
            c["items"] = new_items[c["mood"]]
            c["flags"] = new_flags[c["mood"]]
        with open(JSON_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, separators=(",", ":"))
        print("записано", os.path.normpath(JSON_PATH))


if __name__ == "__main__":
    main()
