"""Разбор каомодзи на части (лицо, глаза, рот, внешние эффекты). Общий код для recategorize.py."""
import re

OPEN = "(（ʕ₍꒰[【〔｛{⸜⁽ʢ⎛❨〈⟮｟⸨『「"
CLOSE = ")）ʔ₎꒱]】〕｝}⸝⁾ʡ⎞❩〉⟯｠⸩』」"
# Символы, которые на краю лица обычно щёки, пот, румянец, а не глаза.
EDGE_DECOR = set("*＊∗⁎๑˶⸝〃｡。,，\"'°゜彡ﾞ゛☆★✧♡♥❤ღ♪♫✿❀~〜～ﾟ")


def squash(text):
    return re.sub(r"\s+", "", text)


def groups(text):
    """Все верхнеуровневые скобочные группы (без скобок) и строка без пробелов."""
    s = squash(text)
    out, depth, start = [], 0, None
    for i, ch in enumerate(s):
        if ch in OPEN:
            if depth == 0:
                start = i
            depth += 1
        elif ch in CLOSE and depth > 0:
            depth -= 1
            if depth == 0:
                out.append(s[start + 1:i])
    if depth > 0 and start is not None:
        out.append(s[start + 1:])
    return out, s


def outside(text):
    """Всё, что вне скобочных групп: руки, эффекты, подписи."""
    s = squash(text)
    res, depth = [], 0
    for ch in s:
        if ch in OPEN:
            depth += 1
        elif ch in CLOSE and depth > 0:
            depth -= 1
        elif depth == 0:
            res.append(ch)
    return "".join(res)


def core_of(g):
    """Лицо без краевого декора."""
    a, b = 0, len(g)
    while a < b and g[a] in EDGE_DECOR:
        a += 1
    while b > a and g[b - 1] in EDGE_DECOR:
        b -= 1
    return g[a:b]


def face_parts(text):
    """(eye_l, mouth, eye_r, core, outside_str). Пустые строки, если разобрать не удалось."""
    gs, s = groups(text)
    out = outside(text)
    if not gs:
        c = core_of(s)
    else:
        c = core_of(max(gs, key=len))
    n = len(c)
    if n == 0:
        return "", "", "", c, out
    if n == 1:
        return "", c, "", c, out
    if n == 2:
        return c[0], "", c[1], c, out
    mid = n // 2
    return c[mid - 1], c[mid], c[mid + 1], c, out


def features(text):
    """Словарь признаков для линейной модели: позиционные и мешок символов."""
    f = {}
    el, m, er, core, out = face_parts(text)
    s = squash(text)
    f["m=" + m] = 1
    f["el=" + el] = 1
    f["er=" + er] = 1
    f["eyes=" + el + er] = 1
    f["face=" + el + m + er] = 1
    f["len=%d" % min(len(core), 9)] = 1
    for ch in set(core):
        f["c:" + ch] = 1
    for ch in set(out):
        f["o:" + ch] = 1
    for i in range(len(core) - 1):
        f["b:" + core[i:i + 2]] = 1
    for i in range(len(s) - 2):
        f["t:" + s[i:i + 3]] = 0.5
    return f
