"""Классификатор настроения каомодзи по лицу целиком: глаза + рот + щёки + внешние эффекты.

Идея: смотрим не на отдельные символы, а на сочетание частей лица. Каждая часть даёт
очки по настроениям (H счастье, S грусть, N нейтрально, A злость, T нежность), очки глаз
и рта суммируются. NEUTRAL это запасная категория: остальным нужны явные признаки.
"""
import re
import sys
import unicodedata

sys.path.insert(0, __file__.rsplit("/", 1)[0])
import facekit  # noqa: E402

MOODS = ["HAPPY", "SAD", "NEUTRAL", "ANGRY", "TENDER"]
IDX = {m: i for i, m in enumerate(MOODS)}


def vec(h=0, s=0, n=0, a=0, t=0):
    return (h, s, n, a, t)


def add(a, b, k=1.0):
    return tuple(x + k * y for x, y in zip(a, b))


ZERO = vec()

# ---------- глаза (учитываются по каждому глазу отдельно) ----------
EYES = {}


def eyes(chars, v):
    for c in chars:
        EYES[c] = v


eyes("^＾", vec(h=3))
eyes("≧≦", vec(h=3))
eyes("><＞＜", vec(h=1, n=1))
eyes("˃˂›‹", vec(h=1.2, t=0.3, n=0.5))
eyes("◕✪✧☆★✯❛ꕤ", vec(h=2.2, t=0.3))
eyes("ᵔ", vec(h=1.5, t=1.5))
eyes("◠⌒ꈍ", vec(h=2, t=0.5))
eyes("ᗜ∀▽∇▿", vec(h=1.2))  # рот-символы в роли глаз: радость слабее
eyes("◡‿ᴗ", vec(h=1.2, t=1))
eyes("ᗒᗕ", vec(h=1))
eyes("•･・ˊˋ´`｀ˇ˙·.｡。,'\"", vec(n=0.3))
eyes("oO0◎⊙◉○◯ﾟ°º⁰ᵒ□ロ⚆꒪◍●ꉂ", vec(n=1.5))
eyes("-ー‐ｰ‾￣¬−―─", vec(n=1.5))
eyes("˘", vec(t=1.4, n=0.6, h=0.4))
eyes("ᵕ꒳", vec(t=2))
eyes(";；", vec(s=1.0, n=1.0))
eyes("╥ಥ༎இТтＴTㅠㅜᯅ", vec(s=3))
eyes("ಠòóÒÓ╬ψΨꐦ", vec(a=3))
eyes("≖", vec(a=1.2, n=1))
eyes("♡♥❤ღ", vec(t=3))
eyes("×xXｘ", vec(s=1, n=1))
eyes("@＠〇⊚", vec(n=1.5))
eyes("ʘ", vec(n=1))
eyes("ˉ_", vec(n=0.5))

# ---------- рот ----------
MOUTH = {}


def mouths(chars, v):
    for c in chars:
        MOUTH[c] = v


mouths("∀▽∇▿", vec(h=3))
mouths("◡", vec(h=2.5, t=0.5))
mouths("‿", vec(h=2, t=1))
mouths("ᴗ", vec(h=1.5, t=1.2))
mouths("ᗜᗨヮꇴ", vec(h=2.5, t=0.4))
mouths("ڡ", vec(h=1, t=1.2, n=0.3))
mouths("∪", vec(h=1, t=1))
mouths("艸", vec(h=1.5, t=0.5, n=0.5))
mouths("ʖ", vec(h=1, n=1))
mouths("ω", vec(n=1, h=0.5, t=0.5))
mouths("_＿", vec(n=2))
mouths("-ー‐ｰ", vec(n=1.5))
mouths(".。", vec(n=1))
mouths("дД", vec(n=1.3, a=0.8, s=0.5))
mouths("皿益凸", vec(a=4))
mouths("ε", vec(t=1, n=0.5, a=0.5))
mouths("зЗ3₃³", vec(t=1, n=0.5, s=0.3))
mouths("︵﹏︿", vec(s=3.5))
mouths("⌓", vec(s=2.8, n=0.3))
mouths("‸", vec(s=2.2, n=0.3))
mouths("へヘ", vec(s=1.5, n=0.5, a=0.5))
mouths("〒ཀཫ⍛ᾥ", vec(s=3))
mouths("ᵕ꒳", vec(t=3))
mouths("˘︶", vec(t=1.5, n=0.5, h=0.5))
mouths("ㅂ", vec(h=1.5, a=0.4, t=0.5))
mouths("ㅁロ□", vec(n=2))
mouths("oO0", vec(n=1.5, h=0.5))
mouths("△", vec(s=1, n=1))
mouths("ェｪ", vec(n=1, s=0.5, t=0.5))
mouths("ㅅ", vec(t=1.5, n=0.5))
mouths("人", vec(n=1, t=1))
mouths("･・˙゜ﾟ°", vec(n=1.5))
mouths("^＾", vec(h=1.5, n=0.5))
mouths("ᴥ", vec(n=1, t=1, h=0.5))
mouths("♡♥❤ღ", vec(t=3))
mouths("ᴖ", vec(t=1, h=0.5, n=0.5))
mouths("ー", vec(n=1.5))
mouths("‹›<>", vec(n=0.5))
mouths("ˬ", vec(h=1.5, t=0.5))
mouths("⩊", vec(h=1, t=1, n=0.5))
mouths("ᗣ", vec(n=1))

# ---------- прочие признаки (внутри и вне лица) ----------
CORE_HINT = {}
OUT_HINT = {}


def hint(table, chars, v):
    for c in chars:
        table[c] = v


for tbl in (CORE_HINT, OUT_HINT):
    hint(tbl, "♪♫♬", vec(h=2, t=0.3))
    hint(tbl, "☆★✧✦✩✨", vec(h=1))
    hint(tbl, "♡♥❤ღ❥", vec(t=3))
    hint(tbl, "#＃╬凸ψꐦ┻", vec(a=2.5))
    hint(tbl, "?？⁇❓", vec(n=1.5))
    hint(tbl, "…‥", vec(n=1))
    hint(tbl, "ᶻ", vec(n=1, t=0.5))
    hint(tbl, "ﾉノヽﾍ", vec(h=0.6))
    hint(tbl, "٩۶و", vec(h=1.0))
    hint(tbl, "ᕙᕗᕦᕤ", vec(h=0.4, a=0.4))
    hint(tbl, "〃", vec(t=1.5, n=0.5))
    hint(tbl, "˶⸝", vec(t=1.5))
    hint(tbl, "꒳", vec(t=1))
    hint(tbl, "｡゜ﾟ", vec())
    hint(tbl, "⚠", vec(n=1.5))
    hint(tbl, "༼༽", vec(s=1, n=0.5))
    hint(tbl, "◞◟", vec(s=1.5))
    hint(tbl, "ᐢ", vec(t=0.3))
    hint(tbl, "✿❀❁", vec(h=0.8, t=0.8))
    hint(tbl, "。", vec())
    hint(tbl, "ꕤ", vec(h=1))
    hint(tbl, "ξ", vec(n=0.3))

SWEAT = set(";；")


def strip_marks(text):
    return "".join(ch for ch in text if unicodedata.category(ch) != "Mn")


ORZ = re.compile(r"(?i)(orz|otl|_\|[‾￣]\|[○◯]|_\|[￣]\|[○]|OTZ|STO|Orz)")
BLUSH = re.compile(r"(///|〃|⸝⸝|⸝|˶|⁄⁄|//)")
DOT_ELLIPSIS = re.compile(r"\.{2,}|。{2,}|…")
SOB = re.compile(r"(゜｡|｡゜|ﾟ｡|｡ﾟ|˚‧º·|·º‧˚)")
BROWS = re.compile(r"[`｀ˋ].{0,3}[´ˊ]")
FLIP = re.compile(r"┻━┻|┻┻|┻─┻")


def parse(t):
    """Как face_parts, но рот ищем среди «сильных» символов ближе к центру ядра."""
    _, _, _, core, out = facekit.face_parts(t)
    n = len(core)
    if n < 3:
        return facekit.face_parts(t)
    mid = (n - 1) / 2
    best, bd = None, 1e9
    for i, ch in enumerate(core):
        v = MOUTH.get(ch)
        if v and max(abs(x) for x in v) >= 1.5 and 0 < i < n - 1:
            d = abs(i - mid)
            if d < bd:
                best, bd = i, d
    i = best if best is not None else n // 2
    return core[i - 1], core[i], core[i + 1], core, out


def score(text):
    """Возвращает (очки по MOODS, факты для отладки)."""
    t = strip_marks(text)
    el, m, er, core, out = parse(t)
    sc = ZERO
    why = []

    # --- глаза (по центру лица) и рот
    v_el, v_er = EYES.get(el, ZERO), EYES.get(er, ZERO)
    v_m = MOUTH.get(m, ZERO)
    # Крайние символы лица: «брови/глаза» ´ ` в обрамлении ( ´∀` ). Они уже в core.
    sc = add(sc, v_el)
    sc = add(sc, v_er)
    sc = add(sc, v_m, 1.5)

    # --- парные слёзы: ; ... ; вокруг рта
    tear_pair = el in SWEAT and er in SWEAT
    if tear_pair:
        sc = add(sc, vec(s=2.5, n=-1.5))
        why.append("tears")

    # --- крайние символы ядра (внешние глаза): ´ ` › ‹ ; и т. п.
    if len(core) >= 3:
        e1, e2 = core[0], core[-1]
        if e1 != el:
            sc = add(sc, EYES.get(e1, ZERO), 0.7)
        if e2 != er:
            sc = add(sc, EYES.get(e2, ZERO), 0.7)

    # --- сильные символы рта/глаз в любом месте ядра (парсер мог промахнуться с центром)
    for i, ch in enumerate(core):
        if ch != m and ch in MOUTH and max(abs(x) for x in MOUTH[ch]) >= 2.5:
            sc = add(sc, MOUTH[ch], 0.8)
    if BROWS.search(core) and not tear_pair and m not in "∀▽∇◡‿ᴗᗜ" and not any(
            ch in "∀▽∇◡‿ᴗᗜ" for ch in core):
        sc = add(sc, vec(a=2.0, n=-0.3)); why.append("brows")

    # --- прочие символы ядра и внешние
    for ch in set(core):
        if ch in CORE_HINT:
            sc = add(sc, CORE_HINT[ch])
    for ch in set(out):
        if ch in OUT_HINT:
            sc = add(sc, OUT_HINT[ch], 0.8)

    # --- паттерны
    s = facekit.squash(t)
    if ORZ.search(s):
        sc = add(sc, vec(s=4)); why.append("orz")
    if SOB.search(s) and (el in SWEAT or m in "дДωε" or tear_pair):
        sc = add(sc, vec(s=1.5)); why.append("sob")
    if FLIP.search(s):
        sc = add(sc, vec(a=3)); why.append("flip")
    nb = len(BLUSH.findall(core)) + len(BLUSH.findall(out))
    if nb:
        sc = add(sc, vec(t=min(nb, 2) * 1.2))
    # одиночный пот ; снаружи глаз = нервничает, а не плачет
    sweat_only = (el in SWEAT) != (er in SWEAT) or (
        not tear_pair and any(ch in SWEAT for ch in core + out))
    if sweat_only and not tear_pair:
        sc = add(sc, vec(n=1.0, h=-0.3, t=-0.3)); why.append("sweat")
    return sc, why


def classify(text, current=None, margin=1.0):
    """Возвращает (mood, confidence, scores)."""
    sc, why = score(text)
    order = sorted(range(5), key=lambda i: -sc[i])
    top, second = order[0], order[1]
    # NEUTRAL-запасная: если у лидера нет внятных очков, это нейтральное
    if sc[top] < 1.5:
        top = IDX["NEUTRAL"]
        conf = 1.0
    else:
        conf = sc[top] - sc[second]
    return MOODS[top], conf, sc, why
