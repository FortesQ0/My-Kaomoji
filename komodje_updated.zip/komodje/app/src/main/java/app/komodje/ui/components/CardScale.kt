package app.komodje.ui.components

import androidx.compose.runtime.compositionLocalOf

/** Масштаб карточек (1f = 100%). Задаётся в настройках. */
val LocalCardScale = compositionLocalOf { 1f }
