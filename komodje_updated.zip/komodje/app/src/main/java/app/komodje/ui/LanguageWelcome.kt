package app.komodje.ui

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.komodje.ui.components.KomojeIcons
import app.komodje.ui.components.LogoMark
import app.komodje.ui.components.pressScale
import app.komodje.ui.components.rememberTick
import app.komodje.ui.theme.BarShape
import app.komodje.ui.theme.LeafShape
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.LogoShape
import app.komodje.ui.theme.Onest
import app.komodje.ui.theme.accentBrush
import app.komodje.ui.theme.backgroundBrush
import app.komodje.ui.theme.badgeBrush
import app.komodje.ui.theme.cardBrush
import kotlinx.coroutines.launch

/**
 * Экран первого запуска: логотип выпрыгивает на пружине, вокруг мерцают звёздочки,
 * затем строки языков по очереди въезжают снизу, а кнопка появляется последней.
 * Весь вход управляется одним прогрессом, который читается только при рисовании.
 * Предвыбран язык системы (если он есть в списке), иначе английский.
 */
@Composable
fun LanguageWelcome(initialTag: String, onContinue: (AppLanguage) -> Unit) {
    val p = LocalPalette.current
    var selectedTag by rememberSaveable { mutableStateOf(initialTag) }
    val selected = AppLanguages.firstOrNull { it.tag == selectedTag } ?: AppLanguages.first()

    val enter = remember { Animatable(0f) }
    val logoPop = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { logoPop.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = 200f)) }
        enter.animateTo(1f, tween(1200, easing = LinearEasing))
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(p.backgroundBrush())
            .statusBarsPadding()
            .navigationBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(20.dp))
        Box(Modifier.size(width = 200.dp, height = 124.dp), contentAlignment = Alignment.Center) {
            LogoMark(
                size = 92.dp,
                modifier = Modifier.graphicsLayer {
                    val s = 0.3f + 0.7f * logoPop.value
                    scaleX = s
                    scaleY = s
                    rotationZ = (1f - logoPop.value) * -14f
                    alpha = logoPop.value.coerceIn(0f, 1f)
                },
            )
            Twinkle(Modifier.align(Alignment.TopEnd).offset(x = (-8).dp, y = 6.dp), 20.dp, 0)
            Twinkle(Modifier.align(Alignment.BottomStart).offset(x = 12.dp, y = (-10).dp), 14.dp, 1)
            Twinkle(Modifier.align(Alignment.TopStart).offset(x = 26.dp, y = 14.dp), 10.dp, 2)
        }
        Spacer(Modifier.height(8.dp))
        Crossfade(targetState = selected.title, animationSpec = tween(220), label = "welcomeTitle") { title ->
            Text(
                text = title,
                color = p.ink,
                fontFamily = Onest,
                fontWeight = FontWeight.Bold,
                fontSize = 28.sp,
                letterSpacing = (-0.5).sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .padding(horizontal = 24.dp)
                    .graphicsLayer { alpha = ((enter.value - 0.08f) / 0.3f).coerceIn(0f, 1f) },
            )
        }
        Spacer(Modifier.height(18.dp))

        Column(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            AppLanguages.forEachIndexed { i, lang ->
                LanguageRow(
                    lang = lang,
                    selected = lang.tag == selectedTag,
                    onClick = { selectedTag = lang.tag },
                    modifier = Modifier.graphicsLayer {
                        val start = 0.14f + i * 0.045f
                        val t = ((enter.value - start) / 0.35f).coerceIn(0f, 1f)
                        val e = 1f - (1f - t) * (1f - t)
                        alpha = e
                        translationY = (1f - e) * 44f
                    },
                )
            }
        }

        ContinueButton(
            text = selected.action,
            onClick = { onContinue(selected) },
            modifier = Modifier
                .padding(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 14.dp)
                .graphicsLayer {
                    val t = ((enter.value - 0.7f) / 0.3f).coerceIn(0f, 1f)
                    alpha = t
                    translationY = (1f - t) * 30f
                },
        )
    }
}

/** Строка языка: слева листик-буллет с кодом, справа галочка у выбранного. */
@Composable
private fun LanguageRow(lang: AppLanguage, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val cardFill = remember(p) { p.cardBrush() }
    val flashFill = remember(p) { p.accentBrush() }
    val badgeFill = remember(p) { p.badgeBrush() }
    val sel = animateFloatAsState(if (selected) 1f else 0f, tween(260), label = "rowSel")
    val tick = rememberTick()
    val source = remember { MutableInteractionSource() }

    Row(
        modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .pressScale(source)
            .clip(LeafShape)
            .background(cardFill)
            .drawBehind { drawRect(flashFill, alpha = sel.value) }
            .clickable(interactionSource = source, indication = null) {
                tick()
                onClick()
            }
            .padding(start = 10.dp, end = 18.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(38.dp)
                .clip(LogoShape)
                .background(badgeFill),
            contentAlignment = Alignment.Center,
        ) {
            Text(lang.code, color = p.onBadge, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        Spacer(Modifier.width(14.dp))
        Text(
            text = lang.native,
            color = lerp(p.ink, p.onAccent, sel.value),
            fontFamily = Onest,
            fontWeight = FontWeight.SemiBold,
            fontSize = 19.sp,
            modifier = Modifier.weight(1f),
        )
        Icon(
            imageVector = KomojeIcons.Check,
            contentDescription = null,
            tint = p.onAccent,
            modifier = Modifier
                .size(22.dp)
                .graphicsLayer {
                    alpha = sel.value
                    val s = 0.6f + 0.4f * sel.value
                    scaleX = s
                    scaleY = s
                },
        )
    }
}

@Composable
private fun ContinueButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val fill = remember(p) { p.accentBrush() }
    val source = remember { MutableInteractionSource() }
    val tick = rememberTick()
    Box(
        modifier
            .fillMaxWidth()
            .height(58.dp)
            .pressScale(source)
            .clip(BarShape)
            .background(fill)
            .clickable(interactionSource = source, indication = null) {
                tick()
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        Crossfade(targetState = text, animationSpec = tween(200), label = "continueText") { label ->
            Text(
                text = label,
                color = p.onAccent,
                fontFamily = Onest,
                fontWeight = FontWeight.Bold,
                fontSize = 19.sp,
            )
        }
    }
}

/** Мерцающая звёздочка нашей формы. Анимация читается только при рисовании. */
@Composable
private fun Twinkle(modifier: Modifier, size: Dp, phase: Int) {
    val p = LocalPalette.current
    val transition = rememberInfiniteTransition(label = "twinkle")
    val v = transition.animateFloat(
        initialValue = 0.25f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(1100 + phase * 330, easing = FastOutSlowInEasing),
            RepeatMode.Reverse,
        ),
        label = "twinkleValue",
    )
    Icon(
        imageVector = KomojeIcons.Sparkle,
        contentDescription = null,
        tint = p.heart,
        modifier = modifier
            .size(size)
            .graphicsLayer {
                alpha = v.value
                val s = 0.75f + 0.35f * v.value
                scaleX = s
                scaleY = s
            },
    )
}
