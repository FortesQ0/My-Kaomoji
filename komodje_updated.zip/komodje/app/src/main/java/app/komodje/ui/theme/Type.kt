package app.komodje.ui.theme

import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.font.FontWeight
import app.komodje.R

/** Onest — один variable-файл, берём только плотные веса: тонких в интерфейсе нет. */
@OptIn(ExperimentalTextApi::class)
val Onest = FontFamily(
    listOf(500, 600, 700).map { w ->
        Font(
            resId = R.font.onest,
            weight = FontWeight(w),
            variationSettings = FontVariation.Settings(FontVariation.weight(w)),
        )
    }
)
