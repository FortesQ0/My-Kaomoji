package app.komodje.ui.components

import androidx.compose.ui.graphics.vector.ImageVector
import app.komodje.R
import app.komodje.domain.Mood

data class Category(val mood: Mood, val icon: ImageVector, val label: Int)

val Categories: List<Category> = listOf(
    Category(Mood.FAVORITE, KomojeIcons.Favorite, R.string.mood_favorite),
    Category(Mood.HAPPY, KomojeIcons.Happy, R.string.mood_happy),
    Category(Mood.SAD, KomojeIcons.Sad, R.string.mood_sad),
    Category(Mood.NEUTRAL, KomojeIcons.Neutral, R.string.mood_neutral),
    Category(Mood.ANGRY, KomojeIcons.Angry, R.string.mood_angry),
    Category(Mood.TENDER, KomojeIcons.Tender, R.string.mood_tender),
)
