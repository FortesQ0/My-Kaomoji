package app.komodje.domain

/**
 * Порядок текстов в «Любимых»: закреплённые (новые первыми), затем свои (новые первыми),
 * затем остальные любимые в порядке библиотеки. Без повторов; закреплённое, которого нет
 * в любимых, не показывается.
 */
fun orderFavorites(
    favorites: Set<String>,
    pinned: List<String>,
    own: List<String>,
    library: List<String>,
): List<String> {
    val result = LinkedHashSet<String>()
    pinned.filter { it in favorites }.forEach { result.add(it) }
    own.filter { it in favorites }.forEach { result.add(it) }
    library.filter { it in favorites }.forEach { result.add(it) }
    return result.toList()
}
