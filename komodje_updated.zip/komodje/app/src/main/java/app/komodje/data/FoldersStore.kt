package app.komodje.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import app.komodje.domain.Folder
import app.komodje.domain.FOLDER_BLANK_1
import app.komodje.domain.FOLDER_BLANK_2
import app.komodje.domain.USER_FOLDER_PREFIX
import app.komodje.domain.defaultFolders
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json

/**
 * Папки раздела «Любимые». Хранятся в том же DataStore одной строкой JSON.
 * Пока человек ничего не менял, отдаются три готовые папки; при первом изменении
 * весь список (вместе с готовыми) записывается в хранилище.
 */
class FoldersStore(private val context: Context) {

    private val key = stringPreferencesKey("folders")
    private val listSerializer = ListSerializer(Folder.serializer())
    private val json = Json { ignoreUnknownKeys = true }

    private fun decode(raw: String?): List<Folder> =
        if (raw.isNullOrEmpty()) {
            defaultFolders()
        } else {
            runCatching { json.decodeFromString(listSerializer, raw) }
                .map { migrate(it) }
                .getOrDefault(defaultFolders())
        }

    /**
     * У тех, кто уже ставил приложение, в хранилище лежат старые готовые папки «Грустные» и «Милые»
     * (id sad и cute). Они дублировали категории, поэтому превращаем их в «Папку без названия»,
     * сохраняя всё, что человек туда положил.
     */
    private fun migrate(list: List<Folder>): List<Folder> = list.map {
        when (it.id) {
            LEGACY_SAD -> it.copy(id = FOLDER_BLANK_1)
            LEGACY_CUTE -> it.copy(id = FOLDER_BLANK_2)
            else -> it
        }
    }

    val folders: Flow<List<Folder>> = context.dataStore.data.map { decode(it[key]) }

    private suspend fun update(change: (List<Folder>) -> List<Folder>) {
        context.dataStore.edit { prefs ->
            prefs[key] = json.encodeToString(listSerializer, change(decode(prefs[key])))
        }
    }

    /** Кладёт комоджи в папку. Если он там уже есть, ничего не меняет. */
    suspend fun add(folderId: String, text: String) = update { list ->
        list.map { f ->
            if (f.id == folderId && text !in f.items) f.copy(items = f.items + text) else f
        }
    }

    suspend fun remove(folderId: String, text: String) = update { list ->
        list.map { f -> if (f.id == folderId) f.copy(items = f.items - text) else f }
    }

    suspend fun create(name: String) {
        val clean = name.trim().take(MAX_NAME)
        if (clean.isEmpty()) return
        update { it + Folder(id = USER_FOLDER_PREFIX + System.currentTimeMillis(), name = clean) }
    }

    /** Переименовать можно любую папку, в том числе готовую. Пустое название игнорируется. */
    suspend fun rename(folderId: String, name: String) {
        val clean = name.trim().take(MAX_NAME)
        if (clean.isEmpty()) return
        update { list -> list.map { f -> if (f.id == folderId) f.copy(name = clean) else f } }
    }

    /** Удалить можно любую папку. Сами каомодзи остаются в «Любимых». */
    suspend fun delete(folderId: String) = update { list ->
        list.filterNot { it.id == folderId }
    }

    companion object {
        const val MAX_NAME = 20
        private const val LEGACY_SAD = "sad"
        private const val LEGACY_CUTE = "cute"
    }
}
