package app.komodje.data

import android.content.Context
import android.graphics.Paint
import app.komodje.domain.Komoji
import app.komodje.domain.Mood
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
internal data class LibraryDto(val categories: List<CategoryDto>)

/** flags идёт параллельно items: бит 1 = эффекты снаружи, бит 2 = два и более персонажей. */
@Serializable
internal data class CategoryDto(val mood: String, val items: List<String>, val flags: List<Int> = emptyList())

class KomojiRepository(private val context: Context) {

    private val library: Map<Mood, List<Komoji>> by lazy {
        val raw = context.assets.open("komoji.json").bufferedReader().use { it.readText() }
        val full: Map<Mood, List<Komoji>> = Json.decodeFromString<LibraryDto>(raw).categories
            .associate { c ->
                Mood.valueOf(c.mood) to c.items.mapIndexed { i, text -> Komoji(text, c.flags.getOrElse(i) { -1 }) }
            }

        // Прячем те каомодзи, символы которых этот телефон не умеет рисовать: иначе рот или глаз
        // пропадает и лицо выглядит сломанным. Проверка идёт по реальным шрифтам устройства.
        val paint = Paint()
        val known = HashMap<Int, Boolean>()
        fun drawable(text: String): Boolean {
            var i = 0
            while (i < text.length) {
                val cp = text.codePointAt(i)
                i += Character.charCount(cp)
                if (cp <= 0x7F) continue
                val ok = known.getOrPut(cp) { paint.hasGlyph(String(Character.toChars(cp))) }
                if (!ok) return false
            }
            return true
        }

        val shown = full.mapValues { (_, list) -> list.filter { drawable(it.text) } }
        val total = full.values.sumOf { it.size }
        // Страховка: если проверка вдруг отсекла почти всё (нестандартная оболочка), показываем как есть.
        if (shown.values.sumOf { it.size } * 10 < total * 3) full else shown
    }

    private val everything: List<Komoji> by lazy { library.values.flatten() }

    private val index: Map<String, Komoji> by lazy { everything.associateBy { it.text } }

    fun byMood(mood: Mood): List<Komoji> = library[mood].orEmpty()

    fun all(): List<Komoji> = everything

    /** Каомодзи по тексту: из библиотеки (с разметкой) или просто обёртка, если такого в библиотеке нет. */
    fun komoji(text: String): Komoji = index[text] ?: Komoji(text)
}
