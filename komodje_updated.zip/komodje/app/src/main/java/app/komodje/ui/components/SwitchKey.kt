package app.komodje.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import app.komodje.R
import app.komodje.ui.theme.BadgeShape
import app.komodje.ui.theme.LocalPalette

/** Кнопка «назад к обычной клавиатуре» — без неё IME превращается в ловушку. */
@Composable
fun SwitchKey(onClick: () -> Unit, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val source = remember { MutableInteractionSource() }
    Box(
        modifier
            .size(64.dp)
            .pressScale(source)
            .clip(BadgeShape)
            .background(p.card)
            .clickable(interactionSource = source, indication = null) {
                tick()
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = KomojeIcons.Keyboard,
            contentDescription = stringResource(R.string.switch_keyboard),
            tint = p.ink,
            modifier = Modifier.size(30.dp),
        )
    }
}
