package app.komodje.ui.components

import android.content.Context
import android.media.AudioAttributes
import android.os.Build
import android.view.HapticFeedbackConstants
import android.view.View
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.interaction.InteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView

/** Включена ли вибрация при нажатии (переключатель в настройках). Задаётся в MainActivity и клавиатуре. */
val LocalHapticsEnabled = compositionLocalOf { true }

private fun vibratorOf(context: Context): Vibrator? = runCatching {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        context.getSystemService(VibratorManager::class.java)?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }
}.getOrNull()

/**
 * Прямая вибрация мотором телефона. Системная тактильная отдача (performHapticFeedback) на многих
 * оболочках (Xiaomi, Tecno/HiOS и др.) молчит, если в системе выключена «вибрация при касании»,
 * а обычный vibrate() без атрибутов оболочка может молча отбросить. Поэтому импульс идёт с явными
 * атрибутами использования ALARM: такие вибрации оболочки не фильтруют. Длительность явная:
 * «тик» 40 мс, «бзз» 70 мс; если мотор умеет регулировать силу, то на максимуме.
 */
@Suppress("DEPRECATION")
private fun vibrate(vibrator: Vibrator?, strong: Boolean) {
    if (vibrator == null) return
    runCatching {
        if (!vibrator.hasVibrator()) return
        val amplitude = if (vibrator.hasAmplitudeControl()) 255 else VibrationEffect.DEFAULT_AMPLITUDE
        val effect = VibrationEffect.createOneShot(if (strong) 70L else 40L, amplitude)
        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        vibrator.vibrate(effect, attributes)
    }.onFailure {
        // Последняя попытка: самый простой вызов без атрибутов.
        runCatching { vibrator.vibrate(if (strong) 70L else 40L) }
    }
}

/** Второй, независимый путь: системная тактильная отдача окна (на части оболочек работает она). */
@Suppress("DEPRECATION")
private fun contextClick(view: View) {
    runCatching {
        view.performHapticFeedback(
            HapticFeedbackConstants.VIRTUAL_KEY,
            HapticFeedbackConstants.FLAG_IGNORE_VIEW_SETTING or HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING,
        )
    }
}

/** Лёгкий «тик»: короткий тап. Если вибрация выключена в настройках приложения, ничего не делает. */
@Composable
fun rememberTick(): () -> Unit {
    val context = LocalContext.current
    val view = LocalView.current
    val enabled = LocalHapticsEnabled.current
    return remember(context, view, enabled) {
        val vibrator = vibratorOf(context)
        val action: () -> Unit = {
            if (enabled) {
                vibrate(vibrator, strong = false)
                contextClick(view)
            }
        }
        action
    }
}

/** Чуть плотнее «тик»: срабатывание долгого нажатия, лайк. */
@Composable
fun rememberBuzz(): () -> Unit {
    val context = LocalContext.current
    val view = LocalView.current
    val enabled = LocalHapticsEnabled.current
    return remember(context, view, enabled) {
        val vibrator = vibratorOf(context)
        val action: () -> Unit = {
            if (enabled) {
                vibrate(vibrator, strong = true)
                contextClick(view)
            }
        }
        action
    }
}

/**
 * Эффект глубины для ЛЮБОГО нажатия. Плашка вместе со всем содержимым уменьшается и пружинно
 * возвращается (с лёгким «перелётом»). Короткий тап даёт сообщения «нажали» и «отпустили»
 * почти одновременно, поэтому сжатие всегда отыгрывается до конца (~90 мс), и только потом
 * идёт возврат. Если держать палец, плашка остаётся сжатой до отпускания.
 * Ставить нужно ПЕРЕД clip и background, иначе фон не будет уменьшаться.
 */
@Composable
fun Modifier.pressScale(source: InteractionSource, pressedScale: Float = 0.96f): Modifier {
    val scale = remember { Animatable(1f) }
    LaunchedEffect(source, pressedScale) {
        source.interactions.collect { interaction ->
            when (interaction) {
                is PressInteraction.Press ->
                    scale.animateTo(pressedScale, tween(90, easing = FastOutSlowInEasing))
                is PressInteraction.Release, is PressInteraction.Cancel ->
                    scale.animateTo(1f, spring(dampingRatio = 0.5f, stiffness = 520f))
                else -> Unit
            }
        }
    }
    return this.graphicsLayer {
        scaleX = scale.value
        scaleY = scale.value
    }
}
