package app.komodje.ui.components

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import kotlinx.coroutines.delay
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.layout.layout
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Animatable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.komodje.R
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.Onest

/** Высота плашек верхней строки: как у вкладок-фильтров. */
private val PlaqueHeight = 38.dp

/** Полупрозрачная плашка в стиле вкладок: лёгкая заливка и тонкая рамка цвета темы. */
@Composable
private fun Modifier.plaque(): Modifier {
    val p = LocalPalette.current
    return this
        .clip(TabShape)
        .background(p.card.copy(alpha = 0.6f))
        .border(1.dp, p.accentDeep.copy(alpha = 0.5f), TabShape)
}

/**
 * Верхняя строка над списком. Слева: «Создать свой смайлик» (только в «Любимых») или подпись
 * «Хиты дня», справа плашка поиска. По тапу плашка раскрывается в поле ввода на всю строку.
 */
@Composable
fun SearchRow(
    open: Boolean,
    query: String,
    onOpen: () -> Unit,
    onClose: () -> Unit,
    onQuery: (String) -> Unit,
    modifier: Modifier = Modifier,
    leading: (@Composable () -> Unit)? = null,
    label: @Composable () -> Unit,
) {
    Box(modifier.fillMaxWidth().height(44.dp), contentAlignment = Alignment.Center) {
        if (open) {
            SearchField(query, onQuery, onClose)
        } else {
            Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                if (leading != null) Box(Modifier.padding(start = 14.dp)) { leading() }
                Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.CenterStart) { label() }
                SearchButton(onOpen, Modifier.padding(end = 14.dp))
            }
        }
    }
}

/** Плашка поиска: слово «Поиск» и крупная залитая лупа справа. По ширине как вкладка «Компания». */
@Composable
fun SearchButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val source = remember { MutableInteractionSource() }
    Row(
        modifier
            .width(128.dp)
            .height(PlaqueHeight)
            .pressScale(source)
            .plaque()
            .clickable(interactionSource = source, indication = null) {
                tick()
                onClick()
            }
            .padding(start = 16.dp, end = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            stringResource(R.string.search_short),
            color = p.muted,
            fontFamily = Onest,
            fontWeight = FontWeight.SemiBold,
            fontSize = 14.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        Icon(
            KomojeIcons.Search,
            contentDescription = stringResource(R.string.search_hint),
            tint = p.ink,
            modifier = Modifier.size(24.dp),
        )
    }
}

/** «Создать свой смайлик»: той же высоты и стиля, что поиск. Когда места мало (папка открыта), только карандаш. */
@Composable
fun CreateOwnButton(compact: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val source = remember { MutableInteractionSource() }
    Row(
        modifier
            .height(PlaqueHeight)
            .animateContentSize()
            .pressScale(source)
            .plaque()
            .clickable(interactionSource = source, indication = null) {
                tick()
                onClick()
            }
            .padding(horizontal = if (compact) 11.dp else 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            KomojeIcons.Edit,
            contentDescription = stringResource(R.string.own_create),
            tint = p.ink,
            modifier = Modifier.size(20.dp),
        )
        if (!compact) {
            Spacer(Modifier.width(8.dp))
            Text(
                stringResource(R.string.own_create),
                color = p.ink,
                fontFamily = Onest,
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun SearchField(query: String, onQuery: (String) -> Unit, onClose: () -> Unit) {
    val p = LocalPalette.current
    val focus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    val tick = rememberTick()
    // Раскрытие: поле вытекает из плашки поиска справа налево, чуть перелетает край и пружинно
    // возвращается («отскакивает от спешки»). Содержимое проявляется вместе с шириной.
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        progress.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = 300f))
    }
    LaunchedEffect(Unit) {
        delay(120)
        runCatching { focus.requestFocus() }
    }
    Row(
        Modifier
            .padding(horizontal = 14.dp)
            .layout { measurable, constraints ->
                val full = constraints.maxWidth
                val start = minOf(128.dp.roundToPx(), full)
                val overshoot = 10.dp.roundToPx()
                val width = (start + (full - start) * progress.value).toInt().coerceIn(start / 2, full + overshoot)
                val placeable = measurable.measure(Constraints.fixed(width, PlaqueHeight.roundToPx()))
                layout(full, placeable.height) { placeable.place(full - width, 0) }
            }
            .graphicsLayer { alpha = (progress.value * 2.5f).coerceIn(0f, 1f) }
            .plaque()
            .padding(start = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(KomojeIcons.Search, contentDescription = null, tint = p.ink, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
            if (query.isEmpty()) {
                Text(
                    stringResource(R.string.search_hint),
                    color = p.muted.copy(alpha = 0.8f),
                    fontFamily = Onest,
                    fontWeight = FontWeight.Medium,
                    fontSize = 14.sp,
                    maxLines = 1,
                )
            }
            BasicTextField(
                value = query,
                onValueChange = onQuery,
                singleLine = true,
                textStyle = TextStyle(color = p.ink, fontSize = 15.sp),
                cursorBrush = SolidColor(p.accentDeep),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
                modifier = Modifier.fillMaxWidth().focusRequester(focus),
            )
        }
        val source = remember { MutableInteractionSource() }
        Box(
            Modifier
                .size(PlaqueHeight)
                .clickable(interactionSource = source, indication = null) {
                    tick()
                    focusManager.clearFocus()
                    onClose()
                },
            contentAlignment = Alignment.Center,
        ) {
            Icon(KomojeIcons.Close, contentDescription = null, tint = p.muted, modifier = Modifier.size(16.dp))
        }
    }
}
