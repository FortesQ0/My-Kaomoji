package app.komodje.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import app.komodje.domain.AccentTheme

@Immutable
data class Palette(
    val bgTop: Color,
    val bgMid: Color,
    val bgBottom: Color,
    val card: Color,
    val cardDeep: Color,
    val ink: Color,
    val muted: Color,
    /** Цветной блок: шапка, нижняя панель, вспышка карточки. accentDeep: конец градиента. */
    val accent: Color,
    val accentDeep: Color,
    /** Текст и иконки поверх цветного блока (тёмные на светлом акценте, светлые на тёмном). */
    val onAccent: Color,
    val onAccent2: Color,
    /** Тёмный лист: логотип, значок активной вкладки, кнопки. */
    val badge: Color,
    val badgeDeep: Color,
    /** Светлые иконки и текст на тёмном листе. */
    val onBadge: Color,
    val onBadgeDeep: Color,
    /** Цвет залитого сердечка. */
    val heart: Color,
)

private fun c(argb: Long) = Color(argb)

/** Шестнадцать палитр: восемь цветов, у каждого светлый и тёмный режим. Тёмные места везде в оттенке своего цвета, глубокого чёрного нет. */
fun paletteFor(accent: AccentTheme, dark: Boolean): Palette = when (accent) {
    AccentTheme.PEACH -> if (!dark) Palette(
        bgTop = c(0xFFFFF9F5), bgMid = c(0xFFFFF0E8), bgBottom = c(0xFFFFE4D6),
        card = c(0xFFFFFFFF), cardDeep = c(0xFFFFF8F4), ink = c(0xFF2B1812), muted = c(0xFFA68578),
        accent = c(0xFFFFE6DA), accentDeep = c(0xFFFFB896), onAccent = c(0xFF4A2A20), onAccent2 = c(0xFF22120D),
        badge = c(0xFF4A2A20), badgeDeep = c(0xFF2E1A13), onBadge = c(0xFFFFC9AE), onBadgeDeep = c(0xFFFF9B78),
        heart = c(0xFFFF7A59),
    ) else Palette(
        bgTop = c(0xFF241814), bgMid = c(0xFF1A110E), bgBottom = c(0xFF19110E),
        card = c(0xFF2E1F1A), cardDeep = c(0xFF281A16), ink = c(0xFFFFF0E8), muted = c(0xFFB89A8E),
        accent = c(0xFFF3CBB8), accentDeep = c(0xFFE39F7E), onAccent = c(0xFF4A2A20), onAccent2 = c(0xFF22120D),
        badge = c(0xFF28170F), badgeDeep = c(0xFF1C100B), onBadge = c(0xFFFFC9AE), onBadgeDeep = c(0xFFFF9B78),
        heart = c(0xFFFFA283),
    )

    AccentTheme.SAKURA -> if (!dark) Palette(
        bgTop = c(0xFFFFF8FA), bgMid = c(0xFFFFEFF4), bgBottom = c(0xFFFFE0EA),
        card = c(0xFFFFFFFF), cardDeep = c(0xFFFFF6F9), ink = c(0xFF3A1424), muted = c(0xFFB07A8E),
        accent = c(0xFFFFE8EF), accentDeep = c(0xFFFFB6CC), onAccent = c(0xFF4A1A2C), onAccent2 = c(0xFF2A0D19),
        badge = c(0xFF5A2540), badgeDeep = c(0xFF3A1829), onBadge = c(0xFFFFD0DF), onBadgeDeep = c(0xFFFF9FBD),
        heart = c(0xFFFF5C8A),
    ) else Palette(
        bgTop = c(0xFF28121C), bgMid = c(0xFF1B0C14), bgBottom = c(0xFF1B0E15),
        card = c(0xFF361C29), cardDeep = c(0xFF2F1823), ink = c(0xFFFFE9F0), muted = c(0xFFC195A8),
        accent = c(0xFFF2C4D4), accentDeep = c(0xFFE592AE), onAccent = c(0xFF3A1325), onAccent2 = c(0xFF1F0913),
        badge = c(0xFF331528), badgeDeep = c(0xFF211019), onBadge = c(0xFFFFC2D4), onBadgeDeep = c(0xFFFF8FB1),
        heart = c(0xFFFF86A8),
    )

    AccentTheme.SEA -> if (!dark) Palette(
        bgTop = c(0xFFF5FAFF), bgMid = c(0xFFE9F3FF), bgBottom = c(0xFFD8E8FB),
        card = c(0xFFFFFFFF), cardDeep = c(0xFFF3F8FF), ink = c(0xFF0E1B3A), muted = c(0xFF7389A8),
        accent = c(0xFFE0F0FF), accentDeep = c(0xFF93C4F7), onAccent = c(0xFF0E1F45), onAccent2 = c(0xFF081330),
        badge = c(0xFF1F3A6B), badgeDeep = c(0xFF1A2B52), onBadge = c(0xFFBFDDFF), onBadgeDeep = c(0xFF7DB6F5),
        heart = c(0xFF3B82F6),
    ) else Palette(
        bgTop = c(0xFF0E1638), bgMid = c(0xFF0A1030), bgBottom = c(0xFF0E1428),
        card = c(0xFF141E47), cardDeep = c(0xFF111A3F), ink = c(0xFFEAF1FF), muted = c(0xFF8FA2C8),
        accent = c(0xFFB5D6FA), accentDeep = c(0xFF6FA9E8), onAccent = c(0xFF0A1A38), onAccent2 = c(0xFF060F26),
        badge = c(0xFF14204A), badgeDeep = c(0xFF0E1632), onBadge = c(0xFFA8D0FF), onBadgeDeep = c(0xFF6EAAF0),
        heart = c(0xFF6FA8FF),
    )

    AccentTheme.BURGUNDY -> if (!dark) Palette(
        bgTop = c(0xFFFFF9F9), bgMid = c(0xFFFFEFF1), bgBottom = c(0xFFFBDDE3),
        card = c(0xFFFFFFFF), cardDeep = c(0xFFFFF6F7), ink = c(0xFF2A0C14), muted = c(0xFFA5707C),
        accent = c(0xFFBD5A72), accentDeep = c(0xFF7E2339), onAccent = c(0xFFFFEFF2), onAccent2 = c(0xFFFFC4CF),
        badge = c(0xFF3A1220), badgeDeep = c(0xFF22090F), onBadge = c(0xFFFFB3C1), onBadgeDeep = c(0xFFFF8FA3),
        heart = c(0xFFD83A5A),
    ) else Palette(
        bgTop = c(0xFF2B0E16), bgMid = c(0xFF1D0910), bgBottom = c(0xFF1C0C12),
        card = c(0xFF3A1823), cardDeep = c(0xFF33141E), ink = c(0xFFFFE8EC), muted = c(0xFFC595A0),
        accent = c(0xFFA24A62), accentDeep = c(0xFF6B1B31), onAccent = c(0xFFFFEEF1), onAccent2 = c(0xFFFFBFCB),
        badge = c(0xFF30101A), badgeDeep = c(0xFF1F0A10), onBadge = c(0xFFFFB3C1), onBadgeDeep = c(0xFFFF8FA3),
        heart = c(0xFFFF6B86),
    )

    AccentTheme.APPLE -> if (!dark) Palette(
        bgTop = c(0xFFFBFFF6), bgMid = c(0xFFF0FAE6), bgBottom = c(0xFFE0F2CE),
        card = c(0xFFFFFFFF), cardDeep = c(0xFFF8FFF2), ink = c(0xFF1F3016), muted = c(0xFF7E9570),
        accent = c(0xFFE3F6D8), accentDeep = c(0xFFA6DB86), onAccent = c(0xFF2A4420), onAccent2 = c(0xFF16280E),
        badge = c(0xFF2F4A25), badgeDeep = c(0xFF1F3318), onBadge = c(0xFFC9EDB4), onBadgeDeep = c(0xFF9ED67C),
        heart = c(0xFF4FB848),
    ) else Palette(
        bgTop = c(0xFF1C2816), bgMid = c(0xFF16200F), bgBottom = c(0xFF121A0D),
        card = c(0xFF26331F), cardDeep = c(0xFF212C1B), ink = c(0xFFEDF8E6), muted = c(0xFF9DB48F),
        accent = c(0xFFC9E8B4), accentDeep = c(0xFF8FCB6E), onAccent = c(0xFF1F3A15), onAccent2 = c(0xFF0F1F0A),
        badge = c(0xFF1F2D17), badgeDeep = c(0xFF18230F), onBadge = c(0xFFB9E79F), onBadgeDeep = c(0xFF86CC63),
        heart = c(0xFF8FDB6B),
    )

    AccentTheme.SUN -> if (!dark) Palette(
        bgTop = c(0xFFFFFDF3), bgMid = c(0xFFFFF8DC), bgBottom = c(0xFFFFEFB8),
        card = c(0xFFFFFFFF), cardDeep = c(0xFFFFFBEA), ink = c(0xFF33270B), muted = c(0xFFA38C4F),
        accent = c(0xFFFFF0B3), accentDeep = c(0xFFFFD84D), onAccent = c(0xFF4A3A08), onAccent2 = c(0xFF2A2004),
        badge = c(0xFF5A4510), badgeDeep = c(0xFF3A2D0B), onBadge = c(0xFFFFE590), onBadgeDeep = c(0xFFFFC83D),
        heart = c(0xFFF5A300),
    ) else Palette(
        bgTop = c(0xFF2B230C), bgMid = c(0xFF231C09), bgBottom = c(0xFF1D1708),
        card = c(0xFF382E10), cardDeep = c(0xFF31280E), ink = c(0xFFFFF6D6), muted = c(0xFFC4AD6B),
        accent = c(0xFFF2DC8A), accentDeep = c(0xFFE0B83A), onAccent = c(0xFF3A2D05), onAccent2 = c(0xFF211800),
        badge = c(0xFF2A210A), badgeDeep = c(0xFF1F1808), onBadge = c(0xFFFFE18A), onBadgeDeep = c(0xFFFFC93C),
        heart = c(0xFFFFC94A),
    )

    AccentTheme.LILAC -> if (!dark) Palette(
        bgTop = c(0xFFFCF9FF), bgMid = c(0xFFF3ECFE), bgBottom = c(0xFFE6D9FA),
        card = c(0xFFFFFFFF), cardDeep = c(0xFFF8F4FF), ink = c(0xFF2B1A42), muted = c(0xFF8F7AB0),
        accent = c(0xFFEADBFB), accentDeep = c(0xFFB997F0), onAccent = c(0xFF321A52), onAccent2 = c(0xFF1C0D33),
        badge = c(0xFF3F2566), badgeDeep = c(0xFF2A1847), onBadge = c(0xFFDCC8FF), onBadgeDeep = c(0xFFB692F5),
        heart = c(0xFF9B5DE5),
    ) else Palette(
        bgTop = c(0xFF221838), bgMid = c(0xFF1A1229), bgBottom = c(0xFF150F23),
        card = c(0xFF2E2145), cardDeep = c(0xFF281C3C), ink = c(0xFFF3EAFF), muted = c(0xFFB4A0D4),
        accent = c(0xFFD9C2F5), accentDeep = c(0xFFA57FE0), onAccent = c(0xFF2D1650), onAccent2 = c(0xFF170B2E),
        badge = c(0xFF241A38), badgeDeep = c(0xFF1B1230), onBadge = c(0xFFD3BBFF), onBadgeDeep = c(0xFFA47BF0),
        heart = c(0xFFB58BFF),
    )

    // Молоко: светлая тема белая, цветной блок и тёмный лист мягкий почти-чёрный с едва заметным фиолетовым;
    // тёмная тема наоборот, фон мягкий фиолетово-чёрный, цветной блок белый.
    AccentTheme.MILK -> if (!dark) Palette(
        bgTop = c(0xFFFFFFFF), bgMid = c(0xFFFAF8FD), bgBottom = c(0xFFF0ECF6),
        card = c(0xFFFFFFFF), cardDeep = c(0xFFFBF9FE), ink = c(0xFF251F30), muted = c(0xFF8B8497),
        accent = c(0xFF3A3347), accentDeep = c(0xFF2A2435), onAccent = c(0xFFF5F2FB), onAccent2 = c(0xFFD5CEE3),
        badge = c(0xFF3A3347), badgeDeep = c(0xFF2A2435), onBadge = c(0xFFF3EFFA), onBadgeDeep = c(0xFFCFC6E0),
        heart = c(0xFFE4577C),
    ) else Palette(
        bgTop = c(0xFF231F2C), bgMid = c(0xFF1D1925), bgBottom = c(0xFF18141F),
        card = c(0xFF2D2837), cardDeep = c(0xFF282331), ink = c(0xFFF6F3FB), muted = c(0xFFA8A0B8),
        accent = c(0xFFF4F1FA), accentDeep = c(0xFFD8D1E6), onAccent = c(0xFF2A2336), onAccent2 = c(0xFF17121F),
        badge = c(0xFF2A2435), badgeDeep = c(0xFF211C2B), onBadge = c(0xFFF0EBF8), onBadgeDeep = c(0xFFCEC4E2),
        heart = c(0xFFF27C9B),
    )
}

val LocalPalette = compositionLocalOf { paletteFor(AccentTheme.PEACH, dark = false) }

/** Фон экрана: три остановки, чуть темнее книзу. */
fun Palette.backgroundBrush(): Brush = Brush.verticalGradient(listOf(bgTop, bgMid, bgBottom))

/** Диагональный градиент цветного блока: шапка, нижняя панель, вспышка карточки. */
fun Palette.accentBrush(): Brush = Brush.linearGradient(listOf(accent, accentDeep))

/** Тёмный лист: логотип, значок активной вкладки, кнопки. */
fun Palette.badgeBrush(): Brush = Brush.linearGradient(listOf(badge, badgeDeep))

/** Едва заметный градиент самой карточки. */
fun Palette.cardBrush(): Brush = Brush.verticalGradient(listOf(card, cardDeep))

/** Градиент иконок на цветном блоке (нижняя панель). */
fun Palette.onAccentBrush(): Brush = Brush.verticalGradient(listOf(onAccent, onAccent2))

/** Градиент иконок на тёмном листе (значок активной вкладки). */
fun Palette.onBadgeBrush(): Brush = Brush.verticalGradient(listOf(onBadge, onBadgeDeep))
