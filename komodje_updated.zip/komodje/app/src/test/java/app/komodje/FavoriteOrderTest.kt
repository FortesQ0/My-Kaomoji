package app.komodje

import app.komodje.domain.orderFavorites
import org.junit.Assert.assertEquals
import org.junit.Test

class FavoriteOrderTest {

    private val library = listOf("a", "b", "c", "d", "e")

    @Test
    fun pinnedThenOwnThenLibrary() {
        val favs = setOf("a", "c", "e", "mine1", "mine2")
        val result = orderFavorites(favs, pinned = listOf("e", "mine2"), own = listOf("mine1", "mine2"), library = library)
        assertEquals(listOf("e", "mine2", "mine1", "a", "c"), result)
    }

    @Test
    fun pinnedNotInFavoritesIsHidden() {
        val result = orderFavorites(setOf("a"), pinned = listOf("zzz", "a"), own = emptyList(), library = library)
        assertEquals(listOf("a"), result)
    }

    @Test
    fun noPinsKeepsOwnFirst() {
        val result = orderFavorites(setOf("b", "x"), emptyList(), listOf("x"), library)
        assertEquals(listOf("x", "b"), result)
    }
}
