package app.komodje

import app.komodje.domain.BuilderSets
import app.komodje.domain.Part
import app.komodje.domain.Slot
import app.komodje.domain.assemble
import app.komodje.domain.decodeBuilder
import app.komodje.domain.encodeBuilder
import app.komodje.domain.mirrorOf
import app.komodje.domain.optionsFor
import app.komodje.domain.syncMirror
import app.komodje.domain.withChoice
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BuilderTest {

    @Test
    fun emptyAssemblesToEmptyString() {
        assertEquals("", assemble(emptyMap()))
    }

    @Test
    fun assemblesInSlotOrder() {
        val values = mapOf(
            Slot.OUTLINE_R to ")", Slot.EYE_L to "•", Slot.MOUTH to "ω", Slot.EYE_R to "•",
            Slot.OUTLINE_L to "(", Slot.EFFECT to "♡",
        )
        assertEquals("(•ω•)♡", assemble(values))
    }

    @Test
    fun mirrorFillsRightSide() {
        var v = withChoice(emptyMap(), Slot.OUTLINE_L, "ʕ", mirror = true)
        v = withChoice(v, Slot.HAND_L, "ヽ", mirror = true)
        v = withChoice(v, Slot.EYE_L, "´", mirror = true)
        assertEquals("ʔ", v[Slot.OUTLINE_R])
        assertEquals("ﾉ", v[Slot.HAND_R])
        assertEquals("`", v[Slot.EYE_R])
    }

    @Test
    fun symmetricSymbolMirrorsToItself() {
        val v = withChoice(emptyMap(), Slot.EYE_L, "•", mirror = true)
        assertEquals("•", v[Slot.EYE_R])
    }

    @Test
    fun separateModeTouchesOnlyOneSide() {
        val v = withChoice(emptyMap(), Slot.EYE_L, "^", mirror = false)
        assertEquals("^", v[Slot.EYE_L])
        assertEquals(null, v[Slot.EYE_R])
    }

    @Test
    fun clearingLeftWithMirrorClearsRight() {
        var v = withChoice(emptyMap(), Slot.EAR_L, "ᘛ", mirror = true)
        v = withChoice(v, Slot.EAR_L, null, mirror = true)
        assertTrue(v.isEmpty())
    }

    @Test
    fun mouthAndEffectHaveNoPair() {
        val v = withChoice(emptyMap(), Slot.MOUTH, "ω", mirror = true)
        assertEquals(mapOf(Slot.MOUTH to "ω"), v)
    }

    @Test
    fun syncMirrorCopiesLeftToRight() {
        val v = syncMirror(mapOf(Slot.OUTLINE_L to "(", Slot.OUTLINE_R to "]", Slot.EYE_R to "x"))
        assertEquals(")", v[Slot.OUTLINE_R])
        assertEquals(null, v[Slot.EYE_R])
    }

    @Test
    fun encodeDecodeRoundTrip() {
        val values = mapOf(Slot.OUTLINE_L to "(", Slot.MOUTH to "ω", Slot.EFFECT to "♡")
        assertEquals(values, decodeBuilder(encodeBuilder(values)))
        assertEquals(emptyMap<Slot, String>(), decodeBuilder(""))
        assertEquals(emptyMap<Slot, String>(), decodeBuilder("broken"))
    }

    @Test
    fun setsHaveNoDuplicates() {
        Part.entries.forEach { part ->
            val base = BuilderSets.baseFor(part)
            assertEquals("duplicates in $part", base.size, base.toSet().size)
            assertTrue("empty set $part", base.isNotEmpty())
        }
    }

    @Test
    fun pairedPartsKeepAllOptionsOnTheRight() {
        // У рук, контуров и ушей зеркала не сливаются (у глаз «ó» и «ò» справа совпадают, это нормально): справа столько же вариантов, сколько слева.
        listOf(Part.HAND, Part.OUTLINE, Part.EAR).forEach { part ->
            assertEquals("$part", optionsFor(part.left).size, optionsFor(part.right!!).size)
        }
    }

    @Test
    fun brackets_and_hands_actually_mirror() {
        BuilderSets.outline.forEach { assertNotEquals("no mirror for $it", it, mirrorOf(it)) }
        listOf("ヽ", "٩", "ᕦ", "☞", "⊂", "╰", "╭", "\\", "┌").forEach {
            assertNotEquals("no mirror for $it", it, mirrorOf(it))
        }
    }

    @Test
    fun mirrorTableIsConsistent() {
        BuilderSets.mirrors.forEach { (k, v) -> assertNotEquals(k, v) }
        assertEquals(BuilderSets.mirrors.size, BuilderSets.mirrors.keys.toSet().size)
    }
}
