// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje

import app.komodje.domain.Kaomoji
import app.komodje.domain.fitsHappy
import app.komodje.domain.isComplex
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class LibraryTest {

    private val library: Map<String, List<Kaomoji>> by lazy {
        val raw = File("src/main/assets/kaomoji.json").readText()
        Json.parseToJsonElement(raw).jsonObject["categories"]!!.jsonArray.associate {
            val o = it.jsonObject
            o["mood"]!!.jsonPrimitive.content to o["items"]!!.jsonArray.map { e -> Kaomoji(e.jsonPrimitive.content) }
        }
    }

    @Test
    fun hasFiveCategories() {
        assertEquals(setOf("HAPPY", "SAD", "NEUTRAL", "ANGRY", "TENDER"), library.keys)
    }

    @Test
    fun noPlainAsciiSmileys() {
        val bad = library.values.flatten().filterNot { it.isComplex() }
        assertTrue("Простые смайлики: $bad", bad.isEmpty())
    }

    @Test
    fun noDuplicates() {
        val all = library.values.flatten().map { it.text }
        assertEquals("Дубликаты", all.size, all.toSet().size)
    }

    @Test
    fun happyHasNoSadGlyphs() {
        val bad = library.getValue("HAPPY").filterNot { it.fitsHappy() }
        assertTrue("Грустные глифы в весёлых: $bad", bad.isEmpty())
    }

    @Test
    fun libraryIsLargeAndEveryMoodIsFilled() {
        assertTrue("Библиотека слишком мала", library.values.sumOf { it.size } > 5_000)
        library.forEach { (mood, items) -> assertTrue("Мало каомодзи в $mood", items.size > 300) }
    }

    @Test
    fun noOversizedOrBrokenItems() {
        val bad = library.values.flatten().filter {
            it.text.count { c -> !c.isWhitespace() } > 22 || '\uFFFD' in it.text || it.text != it.text.trim()
        }
        assertTrue("Слишком длинные или битые: $bad", bad.isEmpty())
    }

    @Test
    fun noInvisibleCharacters() {
        val invisible = Regex("[\u200B-\u200F\u2060\uFEFF\u00AD]")
        val bad = library.values.flatten().filter { invisible.containsMatchIn(it.text) }
        assertTrue("Невидимые символы: $bad", bad.isEmpty())
    }

    // ---- Категории по лицу целиком (см. tools/recategorize.py) ----

    private fun moodOf(text: String): String =
        library.entries.first { (_, items) -> items.any { it.text == text } }.key

    private fun withAny(chars: String): List<Pair<String, String>> =
        library.flatMap { (mood, items) -> items.filter { k -> k.text.any { it in chars } }.map { mood to it.text } }

    @Test
    fun knownFacesLandInTheirMood() {
        val expected = mapOf(
            "(ᗜ _ ᗜ)" to "NEUTRAL", // веселые глаза, но ровный рот
            "\\( >ᗜ< )/" to "HAPPY",
            "(≧▽≦)" to "HAPPY",
            "(＾▽＾)" to "HAPPY",
            "(；ω；)" to "SAD",
            "(╥﹏╥)" to "SAD",
            "(；ﾟДﾟ；)" to "NEUTRAL", // пот и шок это не грусть
            "☆(@_@)☆" to "NEUTRAL",
            "(´ー`)" to "NEUTRAL",
            "(｀・ω・´)" to "NEUTRAL", // «решительный», не злой
            "(｀д´)" to "ANGRY",
            "(ಠ益ಠ)" to "ANGRY",
            "(╯°益°)╯⩩" to "ANGRY",
            "(〃▽〃)" to "TENDER", // румянец
        )
        val wrong = expected.filter { (text, mood) -> moodOf(text) != mood }
        assertTrue("Не в тех категориях: $wrong", wrong.isEmpty())
    }

    @Test
    fun heartsLiveOnlyInTender() {
        val bad = withAny("♡♥❤ღ").filter { it.first != "TENDER" }
        assertTrue("Сердечки вне «Нежных»: $bad", bad.isEmpty())
    }

    @Test
    fun hardAngryGlyphsLiveOnlyInAngry() {
        val bad = withAny("皿ꐦ").filter { it.first != "ANGRY" }
        assertTrue("Злые глифы вне «Злых»: $bad", bad.isEmpty())
    }

    @Test
    fun tearEyesLiveOnlyInSad() {
        val bad = withAny("╥ಥ").filter { it.first != "SAD" }
        assertTrue("Слёзы вне «Грустных»: $bad", bad.isEmpty())
    }

    @Test
    fun shockWithSweatIsNotSad() {
        val shock = Regex("[;；][ﾟ°゜]|[ﾟ°゜][;；]")
        val bad = library.getValue("SAD").filter { shock.containsMatchIn(it.text.filterNot(Char::isWhitespace)) }
        assertTrue("Шок с потом в «Грустных»: $bad", bad.isEmpty())
    }

    // ---- Дефектные и «языковые» смайлики не допускаем (tools/recategorize.py, removal_reason) ----

    private val allTexts: List<String> get() = library.values.flatten().map { it.text }

    @Test
    fun noOrzPoses() {
        val orz = Regex("(?i)orz|otl|」\\s*∠|_\\|[￣‾＼\\\\]\\||乙")
        val bad = allTexts.filter { orz.containsMatchIn(it) }
        assertTrue("Позы orz: $bad", bad.isEmpty())
    }

    // Иероглифы, которые работают частью лица или тела (рот, румянец, руки, чашка в руках).
    private val bodyKanji = "人艸皿益口囗罒凸因言公冫屮乂三灬旦且八丿乁乀从十彡入尸川厂曲血田目囿圄只日一炎"

    @Test
    fun noKanjiCaptions() {
        val bad = allTexts.filter { t -> t.any { it.code in 0x4E00..0x9FFF && it !in bodyKanji } }
        assertTrue("Иероглифы-надписи: $bad", bad.isEmpty())
    }

    @Test
    fun noKanaCaptionsOutsideTheFace() {
        val bodyKana = "ヽノﾉヾゞﾞ゛ゝ゜ﾟヮロﾛェｪヘへﾍつっづとﾂｼﾒメﾐミー・ｰ･ﾊハツッシ"
        val open = "(（ʕ₍꒰[【〔｛{⸜⁽ʢ⎛❨〈⟮｟⸨『「"
        val close = ")）ʔ₎꒱]】〕｝}⸝⁾ʡ⎞❩〉⟯｠⸩』」"
        fun outside(t: String): String {
            var depth = 0
            val sb = StringBuilder()
            for (ch in t) when {
                ch in open -> depth++
                ch in close && depth > 0 -> depth--
                depth == 0 -> sb.append(ch)
            }
            return sb.toString()
        }
        val bad = allTexts.filter { t ->
            outside(t).any { (it.code in 0x3041..0x30FF || it.code in 0xFF66..0xFF9D) && it !in bodyKana }
        }
        assertTrue("Кана-надписи: $bad", bad.isEmpty())
    }

    @Test
    fun noUnderscoreLineJunk() {
        val bad = allTexts.filter { Regex("_{3,}|＿{3,}").containsMatchIn(it.filterNot(Char::isWhitespace)) }
        assertTrue("Палки из подчёркиваний: $bad", bad.isEmpty())
    }

    @Test
    fun closedCrescentEyesAreNeverHappy() {
        // ◡ ᴗ ‿ ᵕ ˘ в роли глаз это покой, а не радость. ‿‿ подряд это рот.
        val pair = Regex("([◡ᴗ‿⌣ᵕ︶˘⁀])[^()◡ᴗ‿⌣ᵕ︶˘⁀✧☆★◕◠⌒^＾≧≦]{0,3}\\1")
        val bad = library.getValue("HAPPY").map { it.text }.filter { t ->
            "‿‿" !in t && pair.containsMatchIn(t.filterNot { it.isWhitespace() || it == 'ᐡ' || it == 'ᐢ' })
        }
        assertTrue("Глаза-полумесяцы в «Счастливых»: $bad", bad.isEmpty())
    }

    @Test
    fun noDirectionControls() {
        // Знаки направления письма (LRE, RLE, RLO и так далее) ломают раскладку чужого поля ввода.
        val bad = library.values.flatten().filter { k -> k.text.any { it in '\u202A'..'\u202E' || it in '\u2066'..'\u2069' } }
        assertTrue("Знаки направления письма: $bad", bad.isEmpty())
    }
}
