// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje

import app.komodje.data.Backup
import app.komodje.ui.HomeViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class BackupTest {

    @Test
    fun cleanItemsDropsTooLongBlankAndDuplicates() {
        val ok = "a".repeat(HomeViewModel.MAX_OWN)
        val tooLong = "a".repeat(HomeViewModel.MAX_OWN + 1)
        assertEquals(listOf("(^_^)", ok), Backup.cleanItems(listOf("(^_^)", tooLong, " ", "(^_^)", ok)))
    }

    @Test
    fun readLimitedRejectsHugeInput() {
        assertNull(Backup.readLimited(ByteArray(1_000_001).inputStream()))
        assertNotNull(Backup.readLimited("(^_^)".toByteArray().inputStream()))
    }
}
