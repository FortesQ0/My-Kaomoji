// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.ui.theme

import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.view.PixelCopy
import android.view.Window
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.runtime.withFrameNanos
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Плавная смена темы без покадровой перерисовки интерфейса.
 *
 * Раньше цвета менялись по кадрам: каждый кадр заново пересобирался весь экран, и анимация рвалась.
 * Теперь: снимаем готовую картинку окна, мгновенно переключаем тему под ней и плавно растворяем
 * картинку. Интерфейс за анимацию пересобирается один раз, а растворение делает видеокарта, поэтому
 * оно идёт ровно на любой частоте экрана.
 */
class ThemeTransition {
    private var snapshot by mutableStateOf<ImageBitmap?>(null)
    private val alpha = Animatable(0f)
    private var job: Job? = null

    internal val image: ImageBitmap? get() = snapshot
    internal val progressAlpha: Float get() = alpha.value

    fun run(window: Window, scope: CoroutineScope, change: suspend () -> Unit) {
        job?.cancel()
        job = scope.launch {
            val bmp = capture(window)
            if (bmp == null) {
                change()
                return@launch
            }
            snapshot = bmp.asImageBitmap()
            alpha.snapTo(1f)
            change()
            // Даём новой теме дойти до экрана: пока картинка непрозрачна, мигания нет.
            repeat(3) { withFrameNanos { } }
            alpha.animateTo(0f, tween(520, easing = FastOutSlowInEasing))
            snapshot = null
        }
    }

    private suspend fun capture(window: Window): Bitmap? {
        val view = window.decorView
        val w = view.width
        val h = view.height
        if (w <= 0 || h <= 0) return null
        return try {
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val ok = suspendCancellableCoroutine { cont ->
                PixelCopy.request(window, bmp, { code -> if (cont.isActive) cont.resume(code == PixelCopy.SUCCESS) }, Handler(Looper.getMainLooper()))
            }
            if (ok) bmp else null
        } catch (_: Throwable) {
            null
        }
    }
}

/** Рисуется поверх всего экрана; касания пропускает насквозь. */
@Composable
fun ThemeTransitionOverlay(transition: ThemeTransition) {
    val img = transition.image ?: return
    Image(
        bitmap = img,
        contentDescription = null,
        contentScale = ContentScale.FillBounds,
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = transition.progressAlpha },
    )
}
