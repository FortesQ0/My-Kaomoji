// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.komodje.ui.theme.LocalPalette

/**
 * Залитая иконка слева от заголовка. Цвет берётся из акцента темы: градиент от accentDeep к чуть более глубокому
 * оттенку (чтобы читалась и на белой карточке, и на тёмной). Меняется вместе с выбранным цветом.
 */
@Composable
fun SectionIcon(icon: ImageVector, modifier: Modifier = Modifier, size: Dp = 28.dp) {
    val p = LocalPalette.current
    val brush = remember(p) { Brush.linearGradient(listOf(p.accentDeep, lerp(p.accentDeep, p.badge, 0.3f))) }
    Image(
        painter = rememberVectorPainter(icon),
        contentDescription = null,
        modifier = modifier
            .size(size)
            .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
            .drawWithContent {
                drawContent()
                drawRect(brush, blendMode = BlendMode.SrcIn)
            },
    )
}
