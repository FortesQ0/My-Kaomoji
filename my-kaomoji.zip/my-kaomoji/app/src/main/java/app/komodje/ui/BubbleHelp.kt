// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.ui

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import app.komodje.ui.components.DialogButton
import app.komodje.ui.components.KaomojiDialog
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import app.komodje.R
import app.komodje.bubble.BubbleService
import app.komodje.ui.components.HelpBubble
import app.komodje.ui.components.LogoMark
import app.komodje.ui.theme.LeafShape
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.Onest
import app.komodje.ui.theme.accentBrush
import app.komodje.ui.theme.backgroundBrush

/**
 * Считаемых шагов четыре; перед ними стоит стартовый экран-предупреждение (шаг 0 без номера).
 * Помощь на случай отказа системы («Система ругается?») живёт не отдельным шагом, а за значком «?» на шаге со службой.
 */
private const val BUBBLE_STEPS = 4
private const val S_WARN = 0
private const val S_INTRO = 1
private const val S_SERVICE = 2
private const val S_OVERLAY = 3
private const val S_READY = 4

/** Включена ли в системных настройках служба плавающего облачка. */
fun isBubbleServiceEnabled(context: Context): Boolean = runCatching {
    val enabled = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        ?: return@runCatching false
    val component = ComponentName(context, BubbleService::class.java)
    enabled.split(':').any {
        it.equals(component.flattenToString(), ignoreCase = true) ||
            it.equals(component.flattenToShortString(), ignoreCase = true)
    }
}.getOrDefault(false)

/** Сразу страница нашей службы с одним переключателем (Android 14+). Если телефон так не умеет, откроется общий список. */
private fun openAccessibilitySettings(context: Context) {
    val component = ComponentName(context, BubbleService::class.java).flattenToString()
    val direct = runCatching {
        context.startActivity(
            Intent("android.settings.ACCESSIBILITY_DETAILS_SETTINGS")
                .putExtra(Intent.EXTRA_COMPONENT_NAME, component)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }.isSuccess
    if (!direct) runCatching {
        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

/**
 * Экран «О приложении»: там в меню ⋮ стоит «Разрешить ограниченные настройки». Без этого Android
 * (особенно на Xiaomi/HyperOS) не даёт включить службу у приложения, установленного не из магазина.
 */
private fun openAppInfo(context: Context) {
    runCatching {
        context.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                .setData(android.net.Uri.fromParts("package", context.packageName, null))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }
}

/** Разрешено ли приложению показывать окна поверх других. */
private fun canDrawOverOthers(context: Context): Boolean =
    runCatching { Settings.canDrawOverlays(context) }.getOrDefault(false)

private fun openOverlaySettings(context: Context) {
    val uri = android.net.Uri.parse("package:${context.packageName}")
    // Сначала напрямую страница «Показать над другими приложениями» с одним переключателем нашего приложения
    // (без списка с поиском), потом обычный системный переход, и только в крайнем случае сведения о приложении.
    val attempts = listOf(
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, uri)
            .setClassName("com.android.settings", "com.android.settings.Settings\$AppDrawOverlaySettingsActivity"),
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, uri),
    )
    for (intent in attempts) {
        if (runCatching { context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess) return
    }
    openAppInfo(context)
}

/** Снята ли с приложения экономия батареи. */
private fun isBatteryUnrestricted(context: Context): Boolean = runCatching {
    context.getSystemService(android.os.PowerManager::class.java).isIgnoringBatteryOptimizations(context.packageName)
}.getOrDefault(false)

/** Экономия батареи: сразу окно «разрешить работу в фоне» для нашего приложения, иначе общий список. */
private fun openBatterySettings(context: Context) {
    val direct = runCatching {
        context.startActivity(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, android.net.Uri.parse("package:${context.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }.isSuccess
    if (direct) return
    val opened = runCatching {
        context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }.isSuccess
    if (!opened) openAppInfo(context)
}

/** Значок «?» рядом с названием блока облачка. */
@Composable
fun BubbleHelpButton(onClick: () -> Unit) {
    HelpBubble(onClick = onClick, showDot = false)
}

/**
 * Инструкция из трёх шагов в том же стиле, что и у клавиатуры: что это, как включить службу, как пользоваться.
 * Картинки нарисованы тут же и красятся в цвета выбранной темы. Вернулись из настроек с включённой службой:
 * сами переходим к третьему шагу.
 */
@Composable
fun BubbleHelpDialog(onClose: () -> Unit) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    var step by rememberSaveable { mutableStateOf(0) }
    var enabled by remember { mutableStateOf(isBubbleServiceEnabled(ctx)) }
    var overlayOn by remember { mutableStateOf(canDrawOverOthers(ctx)) }
    var batteryOk by remember { mutableStateOf(isBatteryUnrestricted(ctx)) }
    var hintOpen by rememberSaveable { mutableStateOf(false) }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                val now = isBubbleServiceEnabled(ctx)
                // Служба включилась: идём дальше, к «Поверх других окон».
                if (now && !enabled && step == S_SERVICE) step = S_OVERLAY
                enabled = now
                overlayOn = canDrawOverOthers(ctx)
                batteryOk = isBatteryUnrestricted(ctx)
            }
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }

    if (hintOpen) BubbleHint(onClose = { hintOpen = false })
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .padding(horizontal = 20.dp)
                .fillMaxWidth()
                .clip(LeafShape)
                .background(p.card)
                .padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(p.backgroundBrush()),
                contentAlignment = Alignment.Center,
            ) {
                // Каждая картинка лежит в одной и той же рамке по центру: при смене шага ничего не смещается.
                Crossfade(
                    targetState = step,
                    modifier = Modifier.fillMaxSize(),
                    animationSpec = tween(250),
                    label = "bubbleArt",
                ) { s ->
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        when (s) {
                            S_WARN -> ArtWarn()
                            S_INTRO -> ArtBubble()
                            S_SERVICE -> ArtSettingsCard(enabled, twoLines = false)
                            S_OVERLAY -> ArtSettingsCard(overlayOn, twoLines = true)
                            else -> ArtPanelOpen()
                        }
                    }
                }
                // «?» на шаге «Включите службу»: помощь, если система отказала. Виден всегда, пока человек на этом шаге.
                if (step == S_SERVICE) {
                    Box(
                        Modifier
                            .align(Alignment.BottomEnd)
                            .padding(10.dp)
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(p.accentBrush())
                            .clickable { hintOpen = true },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("?", color = p.onAccent, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            // На стартовом экране номер и точки не нужны: прячем, но место оставляем, чтобы ничего не прыгало.
            Box(Modifier.alpha(if (step == S_WARN) 0f else 1f), contentAlignment = Alignment.Center) {
                Dots((step - 1).coerceAtLeast(0), BUBBLE_STEPS)
            }
            Spacer(Modifier.height(6.dp))
            Text(
                if (step == S_WARN) " " else "$step / $BUBBLE_STEPS",
                color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 12.sp,
            )
            Spacer(Modifier.height(10.dp))

            AnimatedContent(
                targetState = step,
                transitionSpec = {
                    if (targetState > initialState) {
                        (slideInHorizontally(tween(280)) { it / 3 } + fadeIn(tween(280))) togetherWith
                            (slideOutHorizontally(tween(280)) { -it / 3 } + fadeOut(tween(160)))
                    } else {
                        (slideInHorizontally(tween(280)) { -it / 3 } + fadeIn(tween(280))) togetherWith
                            (slideOutHorizontally(tween(280)) { it / 3 } + fadeOut(tween(160)))
                    }
                },
                label = "bubbleText",
            ) { s ->
                val title = when (s) {
                    S_WARN -> null
                    S_INTRO -> R.string.bubble_step1_title
                    S_SERVICE -> R.string.bubble_step2_title
                    S_OVERLAY -> R.string.bubble_overlay_title
                    else -> R.string.bubble_step3_title
                }
                val body = when (s) {
                    S_WARN -> R.string.bubble_warn
                    S_INTRO -> R.string.bubble_step1_body
                    S_SERVICE -> R.string.bubble_step2_body
                    S_OVERLAY -> R.string.bubble_overlay_body
                    else -> R.string.bubble_step3_body
                }
                Column(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(min = 150.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    if (title != null) {
                        Text(
                            stringResource(title),
                            color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold,
                            fontSize = 22.sp, textAlign = TextAlign.Center,
                        )
                        Spacer(Modifier.height(8.dp))
                    }
                    Text(
                        stringResource(body),
                        color = p.ink.copy(alpha = 0.72f), fontFamily = Onest, fontWeight = FontWeight.Medium,
                        fontSize = 15.sp, lineHeight = 21.sp, textAlign = TextAlign.Center,
                    )
                }
            }
            Spacer(Modifier.height(10.dp))

            when {
                step == S_SERVICE && enabled -> EnabledBadge(stringResource(R.string.bubble_service_on))
                step == S_SERVICE -> PillButton(
                    text = stringResource(R.string.bubble_open_settings),
                    onClick = { openAccessibilitySettings(ctx) },
                    modifier = Modifier.fillMaxWidth(),
                    filled = true,
                )
                step == S_OVERLAY && overlayOn -> EnabledBadge(stringResource(R.string.bubble_overlay_on))
                step == S_OVERLAY -> PillButton(
                    text = stringResource(R.string.bubble_overlay_btn),
                    onClick = { openOverlaySettings(ctx) },
                    modifier = Modifier.fillMaxWidth(),
                    filled = true,
                )
                step == S_READY && batteryOk -> EnabledBadge(stringResource(R.string.bubble_overlay_on))
                step == S_READY -> PillButton(
                    text = stringResource(R.string.bubble_battery_btn),
                    onClick = { openBatterySettings(ctx) },
                    modifier = Modifier.fillMaxWidth(),
                    filled = true,
                )
            }
            if (step in S_SERVICE..S_READY) Spacer(Modifier.height(10.dp))

            val hasAction = (step == S_SERVICE && !enabled) || (step == S_OVERLAY && !overlayOn) || (step == S_READY && !batteryOk)
            val last = step == S_READY
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (step > 0) {
                    PillButton(
                        text = stringResource(R.string.back),
                        onClick = { step -= 1 },
                        modifier = Modifier.weight(1f),
                        filled = false,
                    )
                }
                PillButton(
                    text = stringResource(if (last) R.string.kb_done else R.string.kb_next),
                    onClick = { if (last) onClose() else step += 1 },
                    modifier = Modifier.weight(1f),
                    filled = !hasAction,
                )
            }
        }
    }
}

/**
 * Подсказка «Система ругается?»: что делать, если Android не даёт включить службу. Сверху картинка того, что искать,
 * ниже понятные шаги простыми словами и кнопка, которая сразу открывает «Сведения о приложении».
 */
@Composable
private fun BubbleHint(onClose: () -> Unit) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    KaomojiDialog(onClose = onClose) {
        Column(Modifier.heightIn(max = 600.dp).verticalScroll(rememberScrollState())) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(p.backgroundBrush()),
                contentAlignment = Alignment.Center,
            ) { ArtRestricted() }
            Spacer(Modifier.height(14.dp))
            Text(
                stringResource(R.string.bubble_hint_title),
                color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 20.sp,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                stringResource(R.string.bubble_hint_intro),
                color = p.ink.copy(alpha = 0.72f), fontFamily = Onest, fontWeight = FontWeight.Medium,
                fontSize = 14.sp, lineHeight = 20.sp,
            )
            Spacer(Modifier.height(10.dp))
            listOf(
                R.string.bubble_hint_1, R.string.bubble_hint_2, R.string.bubble_hint_3, R.string.bubble_hint_4,
            ).forEachIndexed { i, res ->
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.Top) {
                    Box(
                        Modifier.size(24.dp).clip(CircleShape).background(p.accent.copy(alpha = 0.35f)),
                        contentAlignment = Alignment.Center,
                    ) { Text("${i + 1}", color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                    Spacer(Modifier.width(10.dp))
                    Text(
                        stringResource(res),
                        color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 15.sp, lineHeight = 21.sp,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            DialogButton(
                label = stringResource(R.string.bubble_open_appinfo),
                filled = true,
                modifier = Modifier.fillMaxWidth(),
                onClick = { openAppInfo(ctx) },
            )
            Spacer(Modifier.height(8.dp))
            DialogButton(
                label = stringResource(R.string.kb_done),
                filled = false,
                secondary = true,
                modifier = Modifier.fillMaxWidth(),
                onClick = onClose,
            )
        }
    }
}

/** Облачко с логотипом в цвете темы. */
@Composable
private fun BubbleDot(size: androidx.compose.ui.unit.Dp) {
    val p = LocalPalette.current
    val fill = remember(p) { p.accentBrush() }
    Box(
        Modifier.size(size).clip(CircleShape).background(fill),
        contentAlignment = Alignment.Center,
    ) { LogoMark(size = size * 0.66f, onAccentBg = true) }
}

/** Схема телефона: сверху поле с «выдуманным» текстом и одним каомодзи, снизу клавиатура, над ней облачко. */
@Composable
private fun ArtBubble() {
    val p = LocalPalette.current
    Box(Modifier.size(width = 240.dp, height = 140.dp).clip(RoundedCornerShape(18.dp)).background(p.card)) {
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .padding(top = 12.dp)
                .fillMaxWidth(0.86f)
                .height(28.dp)
                .clip(CircleShape)
                .background(p.ink.copy(alpha = 0.08f))
                .padding(horizontal = 12.dp),
            contentAlignment = Alignment.CenterStart,
        ) {
            Text(
                "Ovhankaï starréil nõru (＾▽＾)",
                color = p.ink.copy(alpha = 0.75f), fontFamily = Onest, fontWeight = FontWeight.Medium,
                fontSize = 11.sp, maxLines = 1,
            )
        }
        // Клавиатура: три ряда клавиш и длинный пробел.
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(p.ink.copy(alpha = 0.09f))
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            listOf(10, 9, 7).forEach { n ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp, Alignment.CenterHorizontally)) {
                    repeat(n) {
                        Box(Modifier.weight(1f).height(9.dp).clip(RoundedCornerShape(3.dp)).background(p.card))
                    }
                }
            }
            Box(Modifier.fillMaxWidth(0.55f).height(9.dp).align(Alignment.CenterHorizontally).clip(RoundedCornerShape(3.dp)).background(p.card))
        }
        Box(Modifier.align(Alignment.BottomEnd).padding(end = 14.dp, bottom = 62.dp)) { BubbleDot(36.dp) }
    }
}

/** Стартовый экран: по центру виноватое каомодзи. */
@Composable
private fun ArtWarn() {
    val p = LocalPalette.current
    Text(
        "(っ ᵕ﹏ᵕ ς)",
        color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Medium,
        fontSize = 36.sp, maxLines = 1, textAlign = TextAlign.Center,
    )
}

/** Схема экрана «О приложении»: кнопка назад, ⋮ с кольцом, карточка приложения и меню с нужной строкой. */
@Composable
private fun ArtRestricted() {
    val p = LocalPalette.current
    Box(Modifier.size(width = 240.dp, height = 140.dp).clip(RoundedCornerShape(18.dp)).background(p.card)) {
        // Круглые кнопки: назад слева, ⋮ справа.
        Box(
            Modifier.align(Alignment.TopStart).padding(start = 10.dp, top = 8.dp).size(28.dp)
                .clip(CircleShape).background(p.ink.copy(alpha = 0.08f)),
            contentAlignment = Alignment.Center,
        ) { Text("‹", color = p.ink.copy(alpha = 0.7f), fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        Box(Modifier.align(Alignment.TopStart).padding(start = 46.dp, top = 19.dp).size(width = 70.dp, height = 7.dp).clip(CircleShape).background(p.ink.copy(alpha = 0.18f)))
        Box(
            Modifier.align(Alignment.TopEnd).padding(top = 8.dp, end = 10.dp).size(28.dp)
                .clip(CircleShape).background(p.accent.copy(alpha = 0.35f)),
            contentAlignment = Alignment.Center,
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(2.5.dp)) {
                repeat(3) { Box(Modifier.size(3.5.dp).clip(CircleShape).background(p.ink.copy(alpha = 0.8f))) }
            }
        }
        // Карточка приложения: значок, название, версия.
        Row(
            Modifier
                .align(Alignment.TopStart)
                .padding(start = 10.dp, end = 10.dp, top = 48.dp)
                .fillMaxWidth()
                .height(52.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(p.ink.copy(alpha = 0.06f))
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            BubbleDot(32.dp)
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Box(Modifier.size(width = 64.dp, height = 8.dp).clip(CircleShape).background(p.ink.copy(alpha = 0.3f)))
                Box(Modifier.size(width = 30.dp, height = 6.dp).clip(CircleShape).background(p.ink.copy(alpha = 0.14f)))
            }
        }
        // Всплывающая плашка под ⋮ с нужным пунктом (две строки, как в системе).
        Column(
            Modifier
                .align(Alignment.TopEnd)
                .padding(top = 30.dp, end = 10.dp)
                .width(150.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(p.accent.copy(alpha = 0.85f))
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp),
        ) {
            Box(Modifier.fillMaxWidth(0.95f).height(7.dp).clip(CircleShape).background(p.ink.copy(alpha = 0.55f)))
            Box(Modifier.fillMaxWidth(0.6f).height(7.dp).clip(CircleShape).background(p.ink.copy(alpha = 0.55f)))
        }
    }
}

/** Переключатель в стиле системного. */
@Composable
private fun ArtToggle(on: Boolean) {
    val p = LocalPalette.current
    Box(
        Modifier.size(width = 32.dp, height = 18.dp).clip(CircleShape)
            .background(if (on) p.heart else p.ink.copy(alpha = 0.18f)),
        contentAlignment = if (on) Alignment.CenterEnd else Alignment.CenterStart,
    ) { Box(Modifier.padding(2.dp).size(14.dp).clip(CircleShape).background(p.card)) }
}

/**
 * Схема системного экрана с одним переключателем: сверху карточка приложения, под ней строка с переключателем
 * (для «Поверх других окон» подпись в две строки), ниже серое пояснение. Как на настоящем телефоне.
 */
@Composable
private fun ArtSettingsCard(on: Boolean, twoLines: Boolean) {
    val p = LocalPalette.current
    Column(
        Modifier.size(width = 240.dp, height = 140.dp).clip(RoundedCornerShape(18.dp)).background(p.card).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(
            Modifier.fillMaxWidth().height(40.dp).clip(RoundedCornerShape(14.dp))
                .background(p.ink.copy(alpha = 0.06f)).padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(9.dp),
        ) {
            BubbleDot(26.dp)
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Box(Modifier.size(width = 56.dp, height = 7.dp).clip(CircleShape).background(p.ink.copy(alpha = 0.32f)))
                Box(Modifier.size(width = 26.dp, height = 5.dp).clip(CircleShape).background(p.ink.copy(alpha = 0.14f)))
            }
        }
        Row(
            Modifier.fillMaxWidth().height(if (twoLines) 44.dp else 36.dp).clip(RoundedCornerShape(14.dp))
                .background(p.accent.copy(alpha = 0.4f)).padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Box(Modifier.fillMaxWidth(0.92f).height(7.dp).clip(CircleShape).background(p.ink.copy(alpha = 0.4f)))
                if (twoLines) Box(Modifier.fillMaxWidth(0.6f).height(7.dp).clip(CircleShape).background(p.ink.copy(alpha = 0.4f)))
            }
            Spacer(Modifier.width(10.dp))
            ArtToggle(on)
        }
        Column(Modifier.padding(horizontal = 4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Box(Modifier.fillMaxWidth(0.95f).height(5.dp).clip(CircleShape).background(p.ink.copy(alpha = 0.1f)))
            Box(Modifier.fillMaxWidth(0.7f).height(5.dp).clip(CircleShape).background(p.ink.copy(alpha = 0.1f)))
        }
    }
}

/** Схема раскрытой панели: над клавиатурой несколько карточек каомодзи. */
@Composable
private fun ArtPanelOpen() {
    val p = LocalPalette.current
    Box(Modifier.size(width = 240.dp, height = 140.dp).clip(RoundedCornerShape(18.dp)).background(p.card)) {
        Column(
            Modifier.align(Alignment.TopCenter).padding(top = 12.dp).fillMaxWidth(0.84f),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            listOf("(＾▽＾)", "\\( >ᴗ< )/", "( ‾ ᴗ ‾ )b").forEach { face ->
                Box(
                    Modifier.fillMaxWidth().height(24.dp).clip(RoundedCornerShape(12.dp)).background(p.ink.copy(alpha = 0.07f))
                        .padding(horizontal = 12.dp),
                    contentAlignment = Alignment.CenterStart,
                ) { Text(face, color = p.ink, fontSize = 13.sp, maxLines = 1) }
            }
        }
        Box(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(26.dp).background(p.ink.copy(alpha = 0.10f)),
        )
        Box(Modifier.align(Alignment.BottomEnd).padding(end = 12.dp, bottom = 30.dp)) { BubbleDot(30.dp) }
    }
}
