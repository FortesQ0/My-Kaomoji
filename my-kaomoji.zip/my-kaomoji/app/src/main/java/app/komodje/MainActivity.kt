// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje

import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.ui.res.stringResource
import app.komodje.ui.components.ConfirmDialog
import app.komodje.data.Backup
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import java.util.Locale
import androidx.compose.ui.platform.LocalContext
import android.content.res.Resources
import android.content.res.Configuration
import android.content.ContextWrapper
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import app.komodje.ui.LANGUAGE_EXIT_MS
import app.komodje.ui.components.FirstRunIntro
import app.komodje.ui.components.Motion
import androidx.compose.animation.core.LinearEasing
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalConfiguration
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.komodje.domain.Mood
import app.komodje.ui.AppHeader
import app.komodje.ui.HomeScreen
import app.komodje.ui.HomeViewModel
import app.komodje.ui.LanguageWelcome
import app.komodje.ui.OwnEditorScreen
import app.komodje.ui.SettingsScreen
import app.komodje.ui.components.LocalCardScale
import app.komodje.ui.components.cardScaleFactor
import app.komodje.ui.components.LocalHapticsEnabled
import app.komodje.ui.supportedLanguageFor
import app.komodje.ui.theme.MyKaomojiTheme
import app.komodje.ui.theme.ThemeTransition
import app.komodje.ui.theme.ThemeTransitionOverlay
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.backgroundBrush
import app.komodje.ui.theme.isDark
import app.komodje.ui.theme.paletteFor
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private val vm: HomeViewModel by viewModels {
        HomeViewModel.factory((application as MyKaomojiApp).container)
    }

    /** Растёт, когда ярлык с иконки просит открыть вкладку: экран настроек при этом закрывается. */
    private var shortcutTick by mutableIntStateOf(0)
    // Папка из присланного файла .kaomoji: ждёт, пока человек подтвердит добавление.
    private var incomingFolder by mutableStateOf<Pair<String, List<String>>?>(null)

    /**
     * Просим у системы самую высокую частоту экрана при текущем разрешении. Без запроса оболочки
     * (HiOS и подобные) часто держат стороннее приложение на 60 Гц, и прокрутка кажется рваной.
     * Это только пожелание: система вольна его не выполнить, ничего не ломается.
     */
    private fun requestMaxRefreshRate() {
        runCatching {
            @Suppress("DEPRECATION")
            val screen = if (Build.VERSION.SDK_INT >= 30) display else windowManager.defaultDisplay
            if (screen == null) return
            val current = screen.mode
            val best = screen.supportedModes
                .filter { it.physicalWidth == current.physicalWidth && it.physicalHeight == current.physicalHeight }
                .maxByOrNull { it.refreshRate } ?: return
            val lp = window.attributes
            lp.preferredDisplayModeId = best.modeId
            lp.preferredRefreshRate = best.refreshRate
            window.attributes = lp
        }
    }

    /**
     * Язык, выбранный в этом запуске. Применяется внутри приложения сразу и без пересоздания окна (иначе на миг
     * мелькали чёрный экран и голый фон). В систему записывается позже, в onStop, когда приложение уже свернуто.
     */
    private var languageOverride by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Если язык выбрали, но приложение закрыли раньше, чем он записался в систему, берём сохранённый.
        languageOverride = getSharedPreferences(LANGUAGE_PREFS, MODE_PRIVATE).getString(LANGUAGE_PENDING, null)
        if (savedInstanceState == null) {
            handleShortcut(intent)
            handleIncoming(intent)
        }
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT))
        requestMaxRefreshRate()
        val settings = (application as MyKaomojiApp).container.settings
        setContent {
            // StateFlow со стартовым значением из хранилища: после смены языка (пересоздание
            // Activity) экран сразу рисуется с настоящей темой и ничего не «прыгает».
            val mode by settings.themeMode.collectAsStateWithLifecycle()
            val accent by settings.accent.collectAsStateWithLifecycle()
            val languageChosen by settings.languageChosen.collectAsStateWithLifecycle()
            val autoReturn by settings.autoReturn.collectAsStateWithLifecycle()
            val haptics by settings.haptics.collectAsStateWithLifecycle()
            val cardScale by settings.cardScale.collectAsStateWithLifecycle()
            val keyboardHelpSeen by settings.keyboardHelpSeen.collectAsStateWithLifecycle()
            val scope = rememberCoroutineScope()
            val transition = remember { ThemeTransition() }
            var showSettings by rememberSaveable { mutableStateOf(false) }
            var showEditor by rememberSaveable { mutableStateOf(false) }
            var leavingWelcome by remember { mutableStateOf(false) }
            val dark = mode.isDark()
            // Строки и раскладка берутся из выбранного языка, а не из языка системы (см. languageOverride).
            val baseContext = LocalContext.current
            val baseConfig = LocalConfiguration.current
            val overrideTag = languageOverride
            val localized = remember(overrideTag, baseContext, baseConfig) {
                if (overrideTag == null) {
                    null
                } else {
                    val cfg = Configuration(baseConfig).apply { setLocale(Locale.forLanguageTag(overrideTag)) }
                    val res = baseContext.createConfigurationContext(cfg).resources
                    val wrapper = object : ContextWrapper(baseContext) {
                        override fun getResources(): Resources = res
                    }
                    wrapper to cfg
                }
            }
            LaunchedEffect(shortcutTick) {
                if (shortcutTick > 0) {
                    showSettings = false
                    showEditor = false
                }
            }

            // Тёмная шапка (бордо, море) требует светлых значков в статус-баре, светлая требует тёмных.
            val lightStatusIcons = remember(accent, dark, languageChosen) {
                // До выбора языка сверху обычный фон страницы, а не цветная шапка.
                if (!languageChosen) dark else paletteFor(accent, dark).onAccent.luminance() > 0.5f
            }
            LaunchedEffect(lightStatusIcons) {
                enableEdgeToEdge(
                    statusBarStyle = if (lightStatusIcons) {
                        SystemBarStyle.dark(Color.TRANSPARENT)
                    } else {
                        SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                    },
                )
            }

            MyKaomojiTheme(dark = dark, accent = accent) {
              CompositionLocalProvider(
                  LocalHapticsEnabled provides haptics,
                  LocalCardScale provides cardScaleFactor(cardScale),
                  LocalContext provides (localized?.first ?: baseContext),
                  LocalConfiguration provides (localized?.second ?: baseConfig),
              ) {
                val p = LocalPalette.current
                val systemLanguage = LocalConfiguration.current.locales[0].language
                BackHandler(enabled = showSettings && languageChosen) { showSettings = false }
                BackHandler(enabled = showEditor && languageChosen) { showEditor = false }
                incomingFolder?.let { (folderName, folderItems) ->
                    ConfirmDialog(
                        title = stringResource(R.string.folder_import_title),
                        message = stringResource(R.string.folder_import_message, folderName, folderItems.size),
                        confirm = stringResource(R.string.folder_import_add),
                        onConfirm = {
                            incomingFolder = null
                            scope.launch { Backup.importFolder(applicationContext, folderName, folderItems) }
                        },
                        onClose = { incomingFolder = null },
                    )
                }

                // Фон страницы лежит под обоими экранами: при перекрёстном затухании сквозь них никогда не видно окно.
                Box(Modifier.fillMaxSize().background(p.backgroundBrush())) {
                // Без Crossfade: экран выбора уходит сам (растворяется), главный проявляется сам. Фон под ними общий.
                languageChosen.let { chosen ->
                    if (!chosen) {
                        // Первый запуск: сначала выбор языка (предвыбран язык системы или английский).
                        LanguageWelcome(
                            initialTag = supportedLanguageFor(systemLanguage).tag,
                            leaving = leavingWelcome,
                            onContinue = { lang ->
                                if (!leavingWelcome) {
                                    leavingWelcome = true
                                    scope.launch {
                                        // Сначала экран выбора плавно уходит, и только потом применяется язык и открывается
                                        // главный экран (окно при этом не пересоздаётся).
                                        delay(LANGUAGE_EXIT_MS.toLong())
                                        FirstRunIntro.pending = true
                                        settings.markLanguageChosen()
                                        setLanguage(lang.tag)
                                    }
                                }
                            },
                        )
                    } else {
                        // Сразу после выбора языка главный экран проявляется из того же фона, а не выскакивает.
                        val appear = remember { Animatable(if (FirstRunIntro.pending) 0f else 1f) }
                        LaunchedEffect(Unit) {
                            if (FirstRunIntro.pending) {
                                // Два кадра ждём, пока тяжёлый главный экран соберётся невидимым (список и нижняя панель
                                // читают флаг при первой сборке, раньше этого эффекта), и только потом запускаем
                                // общий каскад: нижняя панель, список, вкладки, шапка.
                                repeat(2) { withFrameNanos { } }
                                delay(FirstRunIntro.WARMUP_MS)
                                FirstRunIntro.pending = false
                                appear.animateTo(1f, tween(FirstRunIntro.TOTAL_MS, easing = LinearEasing))
                            }
                        }
                        Box(Modifier.fillMaxSize().background(p.backgroundBrush())) {
                        Column(
                            Modifier
                                .fillMaxSize()
                                .navigationBarsPadding()
                        ) {
                            // Шапка входит последней в каскаде первого входа (снизу вверх); в обычном запуске видна сразу.
                            Box(
                                Modifier.graphicsLayer {
                                    val t = ((appear.value * FirstRunIntro.TOTAL_MS - 3 * FirstRunIntro.STEP_MS) /
                                        FirstRunIntro.ELEMENT_MS).coerceIn(0f, 1f)
                                    val e = Motion.Gentle.transform(t)
                                    // До старта слой почти невидим, но уже рисуется (прогрев), потом мягко проявляется.
                                    alpha = if (appear.value >= 1f) 1f else maxOf(e * e, FirstRunIntro.WARM_ALPHA)
                                    translationY = (1f - e) * 20.dp.toPx()
                                },
                            ) {
                                AppHeader(
                                    settingsOpen = showSettings,
                                    onAction = {
                                        // Из конструктора шестерёнка ведёт в настройки.
                                        if (showEditor) {
                                            showEditor = false
                                            showSettings = true
                                        } else {
                                            showSettings = !showSettings
                                        }
                                    },
                                )
                            }
                            Box(Modifier.weight(1f)) {
                                Crossfade(
                                    targetState = if (showSettings) 1 else if (showEditor) 2 else 0,
                                    animationSpec = tween(200),
                                    label = "screen",
                                ) { screen ->
                                    if (screen == 2) {
                                        OwnEditorScreen(vm = vm, onClose = { showEditor = false })
                                    } else if (screen == 1) {
                                        SettingsScreen(
                                            themeMode = mode,
                                            onThemeMode = { m -> if (m != mode) transition.run(window, scope) { settings.setThemeMode(m) } },
                                            accent = accent,
                                            onAccent = { a -> if (a != accent) transition.run(window, scope) { settings.setAccent(a) } },
                                            autoReturn = autoReturn,
                                            onAutoReturn = { scope.launch { settings.setAutoReturn(it) } },
                                            haptics = haptics,
                                            onHaptics = { scope.launch { settings.setHaptics(it) } },
                                            cardScale = cardScale,
                                            onCardScale = { scope.launch { settings.setCardScale(it) } },
                                            keyboardHelpSeen = keyboardHelpSeen,
                                            onKeyboardHelpSeen = { scope.launch { settings.markKeyboardHelpSeen() } },
                                            onSetLanguage = ::setLanguage,
                                        )
                                    } else {
                                        HomeScreen(vm = vm, onCreateOwn = { showEditor = true })
                                    }
                                }
                            }
                        }
                        }
                    }
                }
                ThemeTransitionOverlay(transition)
                }
              }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShortcut(intent)
        handleIncoming(intent)
    }

    /** Открыт файл папки (.kaomoji): читаем и показываем вопрос «Добавить папку?». */
    private fun handleIncoming(intent: Intent?) {
        if (intent?.action != Intent.ACTION_VIEW) return
        val uri = intent.data ?: return
        val text = runCatching {
            contentResolver.openInputStream(uri)?.use { Backup.readLimited(it) }
        }.getOrNull() ?: return
        Backup.parseFolder(text)?.let { incomingFolder = it }
    }

    /** Ярлык на иконке приложения: открыть нужную вкладку (Избранные, Радостные и т. д.). */
    private fun handleShortcut(intent: Intent?) {
        val name = intent?.getStringExtra(EXTRA_MOOD) ?: return
        // Один раз: после пересоздания Activity (поворот, смена языка) ярлык повторно не применяем.
        intent.removeExtra(EXTRA_MOOD)
        val mood = runCatching { Mood.valueOf(name) }.getOrNull() ?: return
        vm.select(mood)
        shortcutTick++
    }

    override fun onStop() {
        super.onStop()
        // Приложение свернули: самое время записать выбранный язык в систему (окно при этом может пересоздаться незаметно).
        val prefs = getSharedPreferences(LANGUAGE_PREFS, MODE_PRIVATE)
        prefs.getString(LANGUAGE_PENDING, null)?.let { tag ->
            prefs.edit().remove(LANGUAGE_PENDING).apply()
            AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
        }
        // Запоминаем вкладку, фильтры и место в списке на случай, если систему закроет приложение.
        vm.persistHome()
        // Значок на рабочем столе меняем только когда приложение свернули: на глазах оно не закрывается,
        // и цвет темы можно спокойно рассмотреть.
        runCatching {
            app.komodje.ui.AppIcon.apply(applicationContext, (application as MyKaomojiApp).container.settings.accent.value)
        }
    }

    private fun setLanguage(tag: String) {
        languageOverride = tag
        getSharedPreferences(LANGUAGE_PREFS, MODE_PRIVATE).edit().putString(LANGUAGE_PENDING, tag).apply()
    }

    companion object {
        const val EXTRA_MOOD = "app.komodje.extra.MOOD"
        private const val LANGUAGE_PREFS = "language"
        private const val LANGUAGE_PENDING = "pending"

    }
}
