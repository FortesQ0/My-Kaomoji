// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.ui

import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import app.komodje.AppContainer
import app.komodje.data.FavoritesStore
import app.komodje.data.FoldersStore
import app.komodje.data.KaomojiRepository
import app.komodje.data.SettingsStore
import app.komodje.data.UsageStore
import app.komodje.domain.Feel
import app.komodje.domain.Folder
import app.komodje.domain.Kaomoji
import app.komodje.domain.KaomojiFilter
import app.komodje.domain.accepts
import app.komodje.domain.Mood
import app.komodje.domain.dailyPicks
import app.komodje.domain.orderFavorites
import app.komodje.domain.topPicks
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import kotlin.random.Random

@Immutable
data class HomeState(
    val mood: Mood = Mood.HAPPY,
    val favorites: Set<String> = emptySet(),
    val items: List<Kaomoji> = emptyList(),
    /** Быстрый ряд над списком (только в клавиатуре): любимые и частые. */
    val top: List<String> = emptyList(),
    /** Включённые вкладки-фильтры над списком (только в приложении). Пусто = «Все». */
    val filters: Set<KaomojiFilter> = emptySet(),
    /** «Хиты дня»: подсвеченные карточки, они же стоят в списке первыми. */
    val picks: Set<String> = emptySet(),
    /** Папки раздела «Любимые» и id открытой папки (если открыта). */
    val folders: List<Folder> = emptyList(),
    val openFolder: String? = null,
    /** Строка поиска (только в приложении). Пусто = поиска нет. */
    val query: String = "",
    /** Закреплённые в «Любимых» (стоят первыми). */
    val pinned: Set<String> = emptySet(),
    /** «Недавние»: последние скопированные из списков, новые первыми. Пусто, пока ничего не копировали. */
    val recent: List<Kaomoji> = emptyList(),
    /** Ненулевое значение = «кубик» брошен: коллекция перемешана этим зерном. Растёт при каждом броске. */
    val shuffle: Long = 0L,
)

class HomeViewModel(
    private val repository: KaomojiRepository,
    private val favoritesStore: FavoritesStore,
    private val usageStore: UsageStore,
    private val settings: SettingsStore,
    private val foldersStore: FoldersStore,
    private val rememberMood: Boolean,
    /** Вкладки, «Хиты дня» и папки: только в приложении, в клавиатуре порядок обычный. */
    private val richUi: Boolean,
) : ViewModel() {

    // В приложении (не в клавиатуре) помним вкладку, фильтры и прокрутку с прошлого раза.
    private val saved = if (richUi) settings.homeSnapshot() else null

    private val selected = MutableStateFlow(
        saved?.mood ?: if (rememberMood) settings.imeMood() else Mood.HAPPY,
    )
    private val filter = MutableStateFlow(saved?.filters ?: emptySet())
    private val scrollByMood = (saved?.scroll ?: emptyMap()).toMutableMap()
    private val openFolder = MutableStateFlow<String?>(null)
    private val top = MutableStateFlow<List<String>>(emptyList())
    private val query = MutableStateFlow("")
    private val shuffle = MutableStateFlow(0L)

    init {
        refreshTop()
    }

    private data class Selection(
        val mood: Mood,
        val filter: Set<KaomojiFilter>,
        val folderId: String?,
        val query: String,
        val shuffle: Long,
    )

    private val selection = combine(selected, filter, openFolder, query, shuffle) { mood, f, folderId, q, sh ->
        Selection(mood, f, folderId, q, sh)
    }

    /** Любимые для показа: закреплённые, затем свои (новые первыми), затем из библиотеки в её порядке. */
    private fun favoriteItems(favs: Set<String>, own: List<String>, pinned: List<String>): List<Kaomoji> {
        val texts = orderFavorites(favs, pinned, own, repository.allTexts())
        return texts.map(repository::kaomoji)
    }

    private data class FavData(val favs: Set<String>, val own: List<String>, val pinned: List<String>)

    private val favData = combine(favoritesStore.favorites, favoritesStore.own, favoritesStore.pinned) { f, o, p ->
        FavData(f, o, p)
    }

    private data class Content(val state: HomeState, val selection: Selection)

    // Изменения «Недавних» касаются только маленькой полосы, поэтому тяжёлый расчёт
    // (фильтры, перемешивание, «Хиты дня») их не ждёт.
    private val content = combine(
        selection,
        favData,
        top,
        foldersStore.folders,
    ) { sel, fav, topRow, folders ->
        val favs = fav.favs
        val own = fav.own
        val pinned = fav.pinned
        val folder = folders.firstOrNull { it.id == sel.folderId }
        val needle = if (richUi) repository.normalizeSearchQuery(sel.query) else ""
        val base: List<Kaomoji> = when {
            needle.isNotEmpty() -> {
                // Поиск идёт по всем настроениям; на закрытой вкладке «Любимые» только по любимым.
                val pool = when {
                    sel.mood == Mood.FAVORITE && folder != null -> folder.items.map(repository::kaomoji)
                    sel.mood == Mood.FAVORITE -> favoriteItems(favs, own, pinned)
                    else -> repository.all()
                }
                repository.search(pool, needle, sel.query)
            }
            sel.mood == Mood.FAVORITE && folder != null -> folder.items.map(repository::kaomoji)
            sel.mood == Mood.FAVORITE -> favoriteItems(favs, own, pinned)
            else -> repository.byMood(sel.mood)
        }
        val filtered = if (sel.filter.isEmpty()) base else base.filter { sel.filter.accepts(it.resolvedFlags) }

        // «Хиты дня» есть только в приложении, не в «Любимых» и не при поиске.
        val picks = if (richUi && sel.mood != Mood.FAVORITE && needle.isEmpty()) {
            val today = LocalDate.now()
            val feel = Feel.holiday(today)
            (feel?.let { repository.holidayPicks(filtered, it, today.toEpochDay()) })
                ?: dailyPicks(filtered.map { it.text }, today.toEpochDay())
        } else {
            emptyList()
        }
        val chosen = picks.toSet()
        val rest = if (picks.isEmpty()) filtered else filtered.filter { it.text !in chosen }
        // Коллекция перемешивается, «Хиты дня» остаются сверху.
        val shuffled = sel.shuffle != 0L && richUi && sel.mood != Mood.FAVORITE && needle.isEmpty()
        val collection = if (shuffled) rest.shuffled(java.util.Random(sel.shuffle)) else rest
        val ordered = if (picks.isEmpty()) collection else picks.map(repository::kaomoji) + collection

        Content(
            state = HomeState(
                mood = sel.mood,
                favorites = favs,
                items = ordered,
                top = topRow,
                filters = sel.filter,
                picks = picks.toSet(),
                folders = folders,
                openFolder = folder?.id,
                query = sel.query,
                pinned = pinned.toSet(),
                shuffle = sel.shuffle,
            ),
            selection = sel,
        )
    }

    val state: StateFlow<HomeState> = combine(content, usageStore.recent) { current, recentTexts ->
        val sel = current.selection
        val needle = if (richUi) sel.query.filterNot { it.isWhitespace() } else ""
        val recent = if (richUi && sel.mood != Mood.FAVORITE && needle.isEmpty()) {
            recentTexts.map(repository::kaomoji)
                .filter { sel.filter.isEmpty() || sel.filter.accepts(it.resolvedFlags) }
        } else {
            emptyList()
        }
        current.state.copy(recent = recent)
    }
        // Вся работа со списками идёт вне главного потока, включая фильтрацию «Недавних».
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeState())

    fun setQuery(value: String) {
        query.value = value.take(40)
    }

    fun select(mood: Mood) {
        selected.value = mood
        openFolder.value = null
        shuffle.value = 0L
        if (rememberMood) viewModelScope.launch { settings.setImeMood(mood) }
        persistHome()
    }

    /** Где остановились в списке этой вкладки (номер первой видимой карточки). */
    fun scrollFor(mood: Mood): Int = scrollByMood[mood] ?: 0

    /** Только запоминаем в памяти; на диск уходит при смене вкладки/фильтров и при уходе из приложения. */
    fun rememberScroll(mood: Mood, index: Int) {
        if (index > 0) scrollByMood[mood] = index else scrollByMood.remove(mood)
    }

    /** Записать состояние главного экрана (вкладка, фильтры, прокрутка). Только для приложения. */
    fun persistHome() {
        if (!richUi) return
        val mood = selected.value
        val filters = filter.value
        val scroll = scrollByMood.toMap()
        viewModelScope.launch { settings.saveHome(mood, filters, scroll) }
    }

    /**
     * Тап по вкладке: включить или выключить. «Все» сбрасывает выбор. «Одиночные» и «Компания»
     * взаимоисключающие (включается либо та, либо другая), «С эффектами» сочетается с любой из них.
     */
    fun toggleFilter(value: KaomojiFilter) {
        val current = filter.value
        filter.value = when {
            value == KaomojiFilter.ALL -> emptySet()
            value in current -> current - value
            value == KaomojiFilter.SINGLE -> current - KaomojiFilter.GROUP + KaomojiFilter.SINGLE
            value == KaomojiFilter.GROUP -> current - KaomojiFilter.SINGLE + KaomojiFilter.GROUP
            else -> current + value
        }
        // Другой набор фильтров = другой список, старое место прокрутки не подходит.
        scrollByMood.clear()
        shuffle.value = 0L
        persistHome()
    }

    /** Тап по папке: открыть её, а если она уже открыта, закрыть. */
    fun toggleFolder(id: String) {
        openFolder.value = if (openFolder.value == id) null else id
    }

    fun createFolder(name: String) {
        viewModelScope.launch { foldersStore.create(name) }
    }

    fun renameFolder(id: String, name: String) {
        viewModelScope.launch { foldersStore.rename(id, name) }
    }

    fun reorderFolders(ids: List<String>) {
        viewModelScope.launch { foldersStore.reorder(ids) }
    }

    fun deleteFolder(id: String) {
        if (openFolder.value == id) openFolder.value = null
        viewModelScope.launch { foldersStore.delete(id) }
    }

    fun addToFolder(folderId: String, text: String) {
        viewModelScope.launch { foldersStore.add(folderId, text) }
    }

    fun removeFromFolder(folderId: String, text: String) {
        viewModelScope.launch { foldersStore.remove(folderId, text) }
    }

    /**
     * Пересобирает быстрый ряд. Вызывается при открытии клавиатуры, а не после каждого тапа:
     * иначе карточки прыгали бы из-под пальца.
     */
    fun refreshTop() {
        viewModelScope.launch {
            val favorites = favoritesStore.favorites.first()
            val counts = usageStore.counts.first()
            top.value = withContext(Dispatchers.Default) {
                topPicks(repository.allTexts(), favorites, counts, TOP_COUNT)
            }
        }
    }

    /** Комоджи скопирован или вставлен: идёт в счётчик «частых». */
    fun picked(text: String) = usageStore.record(text)

    /** Скопировано из списка на главном экране: идёт в «Недавние». Из редактора и клавиатуры не вызывается. */
    fun copiedFromList(text: String) = usageStore.recordRecent(text)

    /** Бросок «кубика»: коллекция перемешивается заново, место прокрутки забывается. */
    fun rollDice() {
        scrollByMood.clear()
        shuffle.value = Random.nextLong().let { if (it == 0L) 1L else it }
    }

    /** Своё каомодзи из окошка «Создать свой смайлик». Результат: false, если уже есть в любимых. */
    fun addOwn(raw: String, onResult: (Boolean) -> Unit) {
        val text = raw.replace('\n', ' ').trim().take(MAX_OWN)
        if (text.isEmpty()) return
        viewModelScope.launch { onResult(favoritesStore.addOwn(text)) }
    }

    fun togglePin(text: String) {
        viewModelScope.launch { favoritesStore.togglePin(text) }
    }

    fun toggleFavorite(text: String) {
        viewModelScope.launch { favoritesStore.toggle(text) }
    }

    companion object {
        private const val TOP_COUNT = 8
        const val MAX_OWN = 40

        fun factory(container: AppContainer, rememberMood: Boolean = false) = viewModelFactory {
            initializer {
                HomeViewModel(
                    container.repository,
                    container.favorites,
                    container.usage,
                    container.settings,
                    container.folders,
                    rememberMood,
                    richUi = !rememberMood,
                )
            }
        }
    }
}
