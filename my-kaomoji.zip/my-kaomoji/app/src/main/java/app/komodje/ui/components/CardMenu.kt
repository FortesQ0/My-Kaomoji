// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.res.stringResource
import app.komodje.R
import app.komodje.domain.Folder
import app.komodje.ui.theme.LocalPalette

/**
 * Меню долгого нажатия в разделе «Любимые»: всплывает рядом с карточкой. Положить в папку,
 * закрепить, убрать из открытой папки или убрать из любимых. Если комоджи уже лежит в папке, справа галочка.
 * «Убрать…» красные, с залитой корзиной справа: так же, как «Удалить» в меню папки.
 */
@Composable
fun CardMenu(
    text: String,
    anchor: Rect,
    folders: List<Folder>,
    openFolder: String?,
    isFavorite: Boolean,
    isPinned: Boolean,
    onTogglePin: () -> Unit,
    onAddTo: (Folder) -> Unit,
    onRemoveFromFolder: () -> Unit,
    onUnfavorite: () -> Unit,
    onSelectMultiple: () -> Unit,
    onClose: () -> Unit,
) {
    val p = LocalPalette.current
    AnchoredMenu(anchor = anchor, onClose = onClose) {
        if (folders.isNotEmpty()) {
            MenuLabel(stringResource(R.string.folder_add_title))
            folders.forEach { f ->
                MenuItem(
                    label = folderTitle(f),
                    onClick = { onAddTo(f) },
                    trailing = if (text in f.items) KaomojiIcons.Check else null,
                    trailingTint = p.heart,
                )
            }
        }
        if (openFolder != null || isFavorite) MenuDivider()
        if (openFolder != null) {
            MenuItem(
                label = stringResource(R.string.folder_remove),
                onClick = onRemoveFromFolder,
                danger = true,
                trailing = KaomojiIcons.Trash,
            )
        }
        // «Закрепить» только в основном списке «Любимых», не в папке.
        if (isFavorite && openFolder == null) {
            MenuItem(
                label = stringResource(if (isPinned) R.string.unpin else R.string.pin),
                onClick = onTogglePin,
                trailing = KaomojiIcons.Pin,
                trailingTint = p.accentDeep,
            )
        }
        // «Выбрать / несколько» в две строки: включает режим выбора, где карточки отмечаются тапом.
        if (isFavorite) {
            MenuItem(
                label = stringResource(R.string.select_multi),
                onClick = onSelectMultiple,
                trailing = KaomojiIcons.Cards,
                trailingTint = p.accentDeep,
            )
            MenuItem(
                label = stringResource(R.string.folder_unfavorite),
                onClick = onUnfavorite,
                danger = true,
                trailing = KaomojiIcons.Trash,
            )
        }
    }
}
