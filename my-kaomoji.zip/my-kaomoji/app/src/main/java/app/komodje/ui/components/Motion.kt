// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.ui.components

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween

/**
 * Единый ритм анимаций. Все новые движения берут длительности и кривые отсюда:
 * быстрые (нажатия, подсветка) и обычные (появление, смена состояния) идут на мягком «торможении
 * в конце», а пружина без рывков (почти без перелёта) нужна там, где предмет «встаёт на место».
 */
object Motion {
    const val QUICK = 180
    const val STANDARD = 320
    const val SLOW = 480

    /** Быстрый старт, долгое мягкое торможение: ощущение «плавно села». */
    val Ease = CubicBezierEasing(0.22f, 1f, 0.36f, 1f)

    /** Мягкий разгон и мягкое торможение: для неспешных переездов (после броска кубика). */
    val Gentle = CubicBezierEasing(0.45f, 0f, 0.2f, 1f)

    fun <T> quick() = tween<T>(QUICK, easing = Ease)
    fun <T> standard() = tween<T>(STANDARD, easing = Ease)
    fun <T> slow() = tween<T>(SLOW, easing = Ease)

    /** Мягкая пружина: чуть живая, но без дрожания. */
    fun <T> settle() = spring<T>(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow)
}

/**
 * Единое «приветствие» после выбора языка (только первый вход): все элементы главного экрана плавно всплывают
 * снизу вверх: нижняя панель, список с кубиком и поиском, вкладки, шапка. Флаг ставит MainActivity перед показом
 * главного экрана; экран читает его при первой сборке.
 */
object FirstRunIntro {
    @Volatile var pending = false
    const val ELEMENT_MS = 560f
    const val STEP_MS = 120f
    /** Четыре элемента: время последнего = 3 шага + длительность элемента. */
    const val TOTAL_MS = 560 + 120 * 3
}
