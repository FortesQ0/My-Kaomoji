// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.bubble

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import app.komodje.CrashReport
import app.komodje.MyKaomojiApp
import app.komodje.R
import app.komodje.ui.HomeViewModel
import app.komodje.ui.components.KaomojiPanel
import app.komodje.ui.components.LocalCardScale
import app.komodje.ui.components.LocalHapticsEnabled
import app.komodje.ui.components.LogoMark
import app.komodje.ui.components.pressScale
import app.komodje.ui.components.softShadow
import app.komodje.ui.theme.MyKaomojiTheme
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.accentBrush
import app.komodje.ui.theme.backgroundBrush
import app.komodje.ui.theme.isDark

/**
 * Плавающее облачко с каомодзи. Когда в любом приложении открыта клавиатура и курсор стоит в поле ввода,
 * над клавиатурой появляется круглое облачко с логотипом. Нажали: раскрывается компактная панель каомодзи
 * в нашем стиле. Выбрали: каомодзи вставляется в поле.
 *
 * Работает только если человек сам включил эту службу в «Специальных возможностях» и включил переключатель
 * в настройках приложения. Текст из других приложений нигде не сохраняется: служба видит только, есть ли поле
 * ввода, и записывает в него выбранное каомодзи. Окно служба-облачко рисует без отдельного разрешения
 * «поверх других приложений».
 */
class BubbleService : AccessibilityService(), LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {

    private val registry = LifecycleRegistry(this)
    private val savedState = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()

    override val lifecycle: Lifecycle get() = registry
    override val savedStateRegistry: SavedStateRegistry get() = savedState.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = store

    private val handler = Handler(Looper.getMainLooper())
    private val evaluate = Runnable { safeEvaluate() }
    // Подстраховка: если система не прислала событие (так делают оболочки с агрессивной экономией), раз в пару секунд
    // всё равно проверяем, нужно ли показать или спрятать облачко.
    private val heartbeat = object : Runnable {
        override fun run() {
            safeEvaluate()
            handler.postDelayed(this, HEARTBEAT_MS)
        }
    }
    private var window: WindowManager? = null
    // Два отдельных окна: облачко (маленькое, никогда не меняет размер и не двигается само) и панель
    // (широкое, создаётся при раскрытии и убирается после анимации закрытия). Так облачко не «прыгает».
    private var view: ComposeView? = null
    private var panelView: ComposeView? = null
    private var vm: HomeViewModel? = null
    // open: человек хочет видеть панель.
    private var open by mutableStateOf(false)
    private var bottomOffset = 0

    // Куда человек перетащил облачко: смещение от стандартного места (в пикселях). Живёт, пока служба запущена.
    private var userX = 0
    private var userY = 0
    private var screenW = 0
    private var screenH = 0
    private var density = 1f
    private var panelHeightDp by mutableStateOf(360)

    override fun onCreate() {
        super.onCreate()
        savedState.performAttach()
        savedState.performRestore(null)
        registry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        window = getSystemService(WINDOW_SERVICE) as WindowManager
        registry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        registry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
        CrashReport.note(this, "облачко: служба подключена")
        handler.removeCallbacks(heartbeat)
        handler.postDelayed(heartbeat, HEARTBEAT_MS)
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        CrashReport.note(this, "облачко: система отключила службу")
        handler.removeCallbacks(heartbeat)
        hide()
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // События идут пачками: разбираемся один раз, когда всё улеглось.
        handler.removeCallbacks(evaluate)
        handler.postDelayed(evaluate, 120)
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        CrashReport.note(this, "облачко: служба остановлена")
        handler.removeCallbacks(evaluate)
        handler.removeCallbacks(heartbeat)
        hide()
        registry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        store.clear()
        super.onDestroy()
    }

    /** Любая ошибка при показе облачка не должна ронять службу: иначе Android сам её отключит. */
    private fun safeEvaluate() {
        try {
            evaluateNow()
        } catch (error: Throwable) {
            CrashReport.note(this, "облачко: ошибка ${error.javaClass.simpleName}: ${error.message}")
            runCatching { hide() }
        }
    }

    private fun evaluateNow() {
        val container = (application as MyKaomojiApp).container
        if (!container.settings.bubbleEnabled.value) {
            hide()
            return
        }
        val ime = runCatching { windows.firstOrNull { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD } }.getOrNull()
        if (ime == null) {
            hide()
            return
        }
        val root = runCatching { rootInActiveWindow }.getOrNull()
        val field = runCatching { root?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) }.getOrNull()
        val ours = root?.packageName == packageName || ime?.root?.packageName == packageName
        val usable = ime != null && field != null && field.isEditable && !field.isPassword && !ours
        if (!usable) {
            hide()
            return
        }
        val bounds = Rect()
        ime?.getBoundsInScreen(bounds)
        show(bounds.top)
    }

    private fun baseParams(width: Int) = WindowManager.LayoutParams(
        width,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT,
    ).apply { gravity = Gravity.BOTTOM or Gravity.END }

    /** Окно облачка: всегда одного размера, место задаёт только клавиатура и перетаскивание. */
    private fun bubbleParams() = baseParams(WindowManager.LayoutParams.WRAP_CONTENT).apply {
        x = userX
        y = bottomOffset + userY
    }

    /** Окно панели: во всю ширину, стоит над облачком. */
    private fun panelParams() = baseParams(WindowManager.LayoutParams.MATCH_PARENT).apply {
        x = 0
        y = bottomOffset + userY + (BUBBLE_DP * density).toInt()
    }

    private fun show(keyboardTop: Int) {
        val wm = window ?: return
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        screenW = dm.widthPixels
        screenH = dm.heightPixels
        density = dm.density
        // Панель не выше 42 % экрана: компактная, но вкладки и карточки помещаются целиком.
        panelHeightDp = (dm.heightPixels / dm.density * 0.42f).toInt().coerceIn(340, 420)
        bottomOffset = (dm.heightPixels - keyboardTop).coerceAtLeast(0) + (6 * dm.density).toInt()
        val current = view
        if (current != null) {
            runCatching { wm.updateViewLayout(current, bubbleParams()) }
            panelView?.let { runCatching { wm.updateViewLayout(it, panelParams()) } }
            return
        }
        val created = themedView { BubbleContent() }
        val added = runCatching { wm.addView(created, bubbleParams()) }.isSuccess
        if (added) view = created
    }

    /** Окно с содержимым Compose в теме приложения. */
    private fun themedView(content: @Composable () -> Unit): ComposeView = ComposeView(this).apply {
        setViewTreeLifecycleOwner(this@BubbleService)
        setViewTreeViewModelStoreOwner(this@BubbleService)
        setViewTreeSavedStateRegistryOwner(this@BubbleService)
        setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
        setContent {
            val settings = (application as MyKaomojiApp).container.settings
            val mode by settings.themeMode.collectAsStateWithLifecycle()
            val accent by settings.accent.collectAsStateWithLifecycle()
            val haptics by settings.haptics.collectAsStateWithLifecycle()
            MyKaomojiTheme(dark = mode.isDark(), accent = accent) {
                CompositionLocalProvider(
                    LocalHapticsEnabled provides haptics,
                    LocalCardScale provides 0.66f,
                ) { content() }
            }
        }
    }

    private fun hide() {
        open = false
        removePanel()
        val current = view ?: return
        view = null
        runCatching { current.disposeComposition() }
        runCatching { window?.removeViewImmediate(current) }
    }

    private fun addPanel() {
        val wm = window ?: return
        if (panelView != null) return
        val created = themedView { PanelContent() }
        val added = runCatching { wm.addView(created, panelParams()) }.isSuccess
        if (added) panelView = created else open = false
    }

    private fun removePanel() {
        val current = panelView ?: return
        panelView = null
        runCatching { current.disposeComposition() }
        runCatching { window?.removeViewImmediate(current) }
    }

    /** Перетаскивание: палец сдвинулся на (dx, dy) пикселей. Оба окна двигаются вместе. */
    private fun moveBy(dx: Float, dy: Float) {
        val bubble = view ?: return
        val wm = window ?: return
        val total = bubble.height + (panelView?.height ?: 0)
        val maxY = (screenH - total).coerceAtLeast(0)
        userY = (userY - dy.toInt()).coerceIn(-bottomOffset, (maxY - bottomOffset).coerceAtLeast(-bottomOffset))
        val maxX = (screenW - bubble.width).coerceAtLeast(0)
        userX = (userX - dx.toInt()).coerceIn(-(8 * density).toInt(), maxX)
        runCatching { wm.updateViewLayout(bubble, bubbleParams()) }
        panelView?.let { runCatching { wm.updateViewLayout(it, panelParams()) } }
    }

    private fun changeExpanded(value: Boolean) {
        if (value) {
            if (open) return
            vm?.refreshTop()
            open = true
            addPanel()
        } else {
            // Панель сама доиграет анимацию закрытия и уберёт своё окно. Облачко при этом не трогаем.
            open = false
        }
    }

    private fun homeViewModel(): HomeViewModel = vm ?: ViewModelProvider(
        this,
        HomeViewModel.factory((application as MyKaomojiApp).container, rememberMood = true),
    )[HomeViewModel::class.java].also { vm = it }

    /** Вставляет каомодзи в поле, где стоит курсор. Если поле не даёт записать текст, вставляет из буфера обмена. */
    private fun insert(text: String) {
        val node = runCatching { rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) }.getOrNull() ?: return
        val current = if (node.isShowingHintText) "" else node.text?.toString().orEmpty()
        val start = node.textSelectionStart.takeIf { it in 0..current.length } ?: current.length
        val end = node.textSelectionEnd.takeIf { it in 0..current.length } ?: start
        val from = minOf(start, end)
        val to = maxOf(start, end)
        val updated = current.replaceRange(from, to, text)
        val set = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, updated)
        }
        val ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, set)
        if (ok) {
            val caret = from + text.length
            val sel = Bundle().apply {
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, caret)
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, caret)
            }
            node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel)
        } else {
            val clipboard = getSystemService(ClipboardManager::class.java)
            clipboard?.setPrimaryClip(ClipData.newPlainText("kaomoji", text))
            node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        }
    }

    /** Только облачко: окно под него не меняет размер, поэтому никуда не «прыгает». */
    @Composable
    private fun BubbleContent() {
        val source = remember { MutableInteractionSource() }
        val p = LocalPalette.current
        val fill = remember(p) { p.accentBrush() }
        Box(Modifier.padding(horizontal = 8.dp)) {
            Box(
                Modifier
                    .size(BUBBLE_DP.dp)
                    .pressScale(source)
                    .softShadow(CircleShape, elevation = 4.dp, drawn = false)
                    .clip(CircleShape)
                    .background(fill)
                    .pointerInput(Unit) {
                        // Облачко можно перетащить, нажатие по-прежнему раскрывает панель.
                        detectDragGestures { change, drag ->
                            change.consume()
                            moveBy(drag.x, drag.y)
                        }
                    }
                    .clickable(interactionSource = source, indication = null) { changeExpanded(!open) },
                contentAlignment = Alignment.Center,
            ) { LogoMark(size = 34.dp, onAccentBg = true) }
        }
    }

    /** Панель каомодзи в своём окне: появляется и уходит плавно, после ухода окно убирается. */
    @Composable
    private fun PanelContent() {
        val p = LocalPalette.current
        // 0 = панель спрятана, 1 = раскрыта. Меняется только прозрачность и масштаб слоя: размеры не пересчитываются.
        val progress = remember { Animatable(0f) }
        LaunchedEffect(open) {
            if (open) {
                // Даём панели собраться (тяжёлая часть) до начала движения, чтобы анимация не «спотыкалась».
                repeat(2) { withFrameNanos { } }
                progress.animateTo(1f, tween(190, easing = FastOutSlowInEasing))
            } else {
                progress.animateTo(0f, tween(150, easing = FastOutSlowInEasing))
                // Окно убираем уже вне этой корутины и только если панель так и не открыли заново.
                handler.post { if (!open) removePanel() }
            }
        }
        val model = remember { homeViewModel() }
        val state by model.state.collectAsStateWithLifecycle()
        Box(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp)
                .padding(bottom = 8.dp)
                .height(panelHeightDp.dp)
                .graphicsLayer {
                    val t = progress.value
                    alpha = t
                    val k = 0.88f + 0.12f * t
                    scaleX = k
                    scaleY = k
                    translationY = (1f - t) * 14.dp.toPx()
                    transformOrigin = TransformOrigin(1f, 1f)
                }
                .softShadow(RoundedCornerShape(26.dp), elevation = 6.dp, drawn = false)
                .clip(RoundedCornerShape(26.dp))
                .background(p.backgroundBrush()),
        ) {
            KaomojiPanel(
                state = state,
                onSelect = model::select,
                onPick = { text ->
                    insert(text)
                    model.picked(text)
                },
                onHold = model::toggleFavorite,
                feedback = stringResource(R.string.inserted),
                modifier = Modifier.fillMaxWidth().height(panelHeightDp.dp).padding(top = 22.dp),
                topRow = state.top,
            )
            // Ручка сверху: за неё панель можно перетащить выше или ниже (облачко едет вместе с ней).
            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .height(24.dp)
                    .pointerInput(Unit) {
                        detectDragGestures { change, drag ->
                            change.consume()
                            moveBy(0f, drag.y)
                        }
                    },
                contentAlignment = Alignment.Center,
            ) {
                Box(Modifier.size(width = 38.dp, height = 4.dp).clip(CircleShape).background(p.ink.copy(alpha = 0.22f)))
            }
        }
    }
}

private const val BUBBLE_DP = 52
private const val HEARTBEAT_MS = 2500L
