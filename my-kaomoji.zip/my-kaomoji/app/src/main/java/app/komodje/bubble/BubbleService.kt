// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.bubble

import android.accessibilityservice.AccessibilityService
import android.animation.ValueAnimator
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.PixelFormat
import android.graphics.Rect
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.os.Handler
import android.content.res.Configuration
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.PathInterpolator
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import app.komodje.CrashReport
import app.komodje.MyKaomojiApp
import app.komodje.R
import app.komodje.ui.HomeViewModel
import app.komodje.ui.components.KaomojiPanel
import app.komodje.ui.components.LocalCardScale
import app.komodje.ui.components.LocalHapticsEnabled
import app.komodje.ui.components.LogoMark
import app.komodje.ui.components.pressScale
import app.komodje.ui.components.softShadow
import app.komodje.ui.theme.MyKaomojiTheme
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.accentBrush
import app.komodje.ui.theme.backgroundBrush
import app.komodje.ui.theme.isDark

/**
 * Плавающее облачко с каомодзи. Когда в любом приложении открыта клавиатура и курсор стоит в поле ввода,
 * над клавиатурой появляется круглое облачко с логотипом. Нажали: раскрывается компактная панель каомодзи
 * в нашем стиле. Выбрали: каомодзи вставляется в поле.
 *
 * Работает только если человек сам включил эту службу в «Специальных возможностях» и включил переключатель
 * в настройках приложения. Текст из других приложений нигде не сохраняется: служба видит только, есть ли поле
 * ввода, и записывает в него выбранное каомодзи. Окно служба-облачко рисует без отдельного разрешения
 * «поверх других приложений».
 */
class BubbleService : AccessibilityService(), LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {

    private val registry = LifecycleRegistry(this)
    private val savedState = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()

    override val lifecycle: Lifecycle get() = registry
    override val savedStateRegistry: SavedStateRegistry get() = savedState.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = store

    private val handler = Handler(Looper.getMainLooper())
    private var evalPending = false
    private val evaluate = Runnable {
        evalPending = false
        safeEvaluate()
    }
    /** Проверка не чаще раза в пару десятков мс: события идут пачками, но ждать их конца нельзя, это и есть задержка. */
    private fun scheduleEvaluate(delayMs: Long) {
        if (evalPending) return
        evalPending = true
        handler.postDelayed(evaluate, delayMs)
    }
    // Подстраховка: если система не прислала событие (так делают оболочки с агрессивной экономией), раз в пару секунд
    // всё равно проверяем, нужно ли показать или спрятать облачко.
    private val heartbeat = object : Runnable {
        override fun run() {
            safeEvaluate()
            handler.postDelayed(this, HEARTBEAT_MS)
        }
    }
    private var window: WindowManager? = null
    // Два отдельных окна: облачко (маленькое, никогда не меняет размер и не двигается само) и панель
    // (широкое, создаётся при раскрытии и убирается после анимации закрытия). Так облачко не «прыгает».
    private var view: ComposeView? = null
    private var panelView: ComposeView? = null
    private var vm: HomeViewModel? = null
    // open: человек хочет видеть панель.
    private var open by mutableStateOf(false)
    private var bottomOffset = 0
    // Окно облачка создаётся один раз и живёт, пока служба включена: показ и скрытие только переключают видимость,
    // поэтому облачко появляется сразу, а не после создания окна и первой отрисовки.
    private var bubbleShown = false
    private var bubbleVisible by mutableStateOf(false)
    // Последняя «устоявшаяся» высота клавиатуры: облачко сразу встаёт на это место, а не ждёт конца анимации клавиатуры.
    private var knownTop = -1
    private var offsetAnim: ValueAnimator? = null
    private var offsetTarget = -1
    // Высота клавиатуры «устаканилась»: пока она едет, облачко не показываем и не двигаем (иначе оно прыгает рывками).
    private var lastKeyboardTop = -1
    private var keyboardTopSince = 0L

    // Куда человек перетащил облачко: смещение от стандартного места (в пикселях). Живёт, пока служба запущена.
    private var userX = 0
    private var userY = 0
    private var screenW = 0
    private var screenH = 0
    private var density = 1f
    private var panelHeightDp by mutableStateOf(360)
    // Высота панели по умолчанию для этого экрана; на деле она может стать ниже, если места рядом с облачком мало.
    private var panelDefaultDp = 360
    // Панель открывается под облачком (облачко у верхнего края) или над ним. Решается при каждом раскрытии.
    private var panelBelow by mutableStateOf(false)
    // Откуда панель вырастает по горизонтали: 0 = от левого края, 1 = от правого (где стоит облачко).
    private var panelOriginX by mutableStateOf(1f)

    override fun onCreate() {
        super.onCreate()
        savedState.performAttach()
        savedState.performRestore(null)
        registry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        window = getSystemService(WINDOW_SERVICE) as WindowManager
        live = this
        registry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        registry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
        CrashReport.note(this, "облачко: служба подключена")
        handler.removeCallbacks(heartbeat)
        handler.postDelayed(heartbeat, HEARTBEAT_MS)
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        CrashReport.note(this, "облачко: система отключила службу")
        live = null
        handler.removeCallbacks(grantLoop)
        handler.removeCallbacks(heartbeat)
        release()
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // События идут пачками: разбираемся почти сразу и не чаще раза в 25 мс. Любая ошибка здесь не должна
        // ронять службу (после сбоя оболочки сами её выключают, отсюда «то работает, то нет»).
        runCatching { scheduleEvaluate(25) }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        // Поворот экрана или смена размера: запомненная высота клавиатуры больше не годится.
        knownTop = -1
        super.onConfigurationChanged(newConfig)
    }

    override fun onInterrupt() = Unit

    // ---- Автовключение «Поверх других окон» ----------------------------------------------------------------
    // Гайд открывает системные настройки и просит службу, пока они на экране, самой найти My Kaomoji и включить
    // разрешение: человек нажимает одну кнопку. Действует только в окнах настроек и только GRANT_WINDOW_MS после
    // нажатия; нажимает лишь строку и переключатель нашего приложения.
    private var armedUntil = 0L
    private var lastClick = 0L
    private var scrolls = 0

    private val grantLoop = object : Runnable {
        override fun run() {
            if (SystemClock.uptimeMillis() > armedUntil) return
            runCatching { grantStep() }
            handler.postDelayed(this, 400)
        }
    }

    private fun startGrant() {
        armedUntil = SystemClock.uptimeMillis() + GRANT_WINDOW_MS
        lastClick = 0L
        scrolls = 0
        handler.removeCallbacks(grantLoop)
        handler.postDelayed(grantLoop, 700)
    }

    private fun grantStep() {
        if (Settings.canDrawOverlays(this)) {
            armedUntil = 0L
            // Возвращаем человека в приложение: гайд сам покажет «Разрешено».
            runCatching {
                startActivity(
                    Intent(this, app.komodje.MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                )
            }
            return
        }
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString().orEmpty()
        // Работаем только в системных настройках, не в нашем приложении и не в чужих.
        if (pkg == packageName || !(pkg.contains("settings", true) || pkg.contains("securitycenter", true) || pkg.contains("permission", true))) return
        val now = SystemClock.uptimeMillis()
        if (now - lastClick < 700) return

        val labels = listOf("My Kaomoji", "my.kaomoji")
        val ours = labels.flatMap { root.findAccessibilityNodeInfosByText(it).orEmpty() }
        val toggles = collectToggles(root)
        // Страница нашего приложения: на ней есть наш заголовок и ровно один переключатель.
        if (ours.isNotEmpty() && toggles.size == 1) {
            val t = toggles[0]
            if (!t.isChecked) clickNode(t)
            lastClick = now
            return
        }
        // Список приложений: нажимаем нашу строку (или переключатель внутри неё).
        if (ours.isNotEmpty()) {
            val row = ours[0]
            val inRow = generateSequence(row) { it.parent }.take(5).firstNotNullOfOrNull { holder ->
                collectToggles(holder).singleOrNull()
            }
            if (inRow != null) {
                if (!inRow.isChecked) clickNode(inRow)
            } else {
                clickNode(row)
            }
            lastClick = now
            return
        }
        // Строки не видно: пролистываем список вперёд.
        if (scrolls < 8) {
            findScrollable(root)?.let {
                it.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
                scrolls++
                lastClick = now
            }
        }
    }

    private fun collectToggles(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 12) return
            if (n.isCheckable && n.isVisibleToUser) out += n
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        return out
    }

    private fun findScrollable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        fun walk(n: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
            if (n == null || depth > 12) return null
            if (n.isScrollable) return n
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)?.let { return it }
            return null
        }
        return walk(root, 0)
    }

    private fun clickNode(node: AccessibilityNodeInfo) {
        var cur: AccessibilityNodeInfo? = node
        var hops = 0
        while (cur != null && hops < 6) {
            if (cur.isClickable) {
                cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                return
            }
            cur = cur.parent
            hops++
        }
    }

    companion object {
        @Volatile
        private var live: BubbleService? = null

        /** Гайд просит службу включить «Поверх других окон» за человека (если служба уже включена). */
        fun armOverlayGrant() {
            live?.handler?.post { live?.startGrant() }
        }
    }

    override fun onDestroy() {
        CrashReport.note(this, "облачко: служба остановлена")
        live = null
        handler.removeCallbacks(grantLoop)
        handler.removeCallbacks(evaluate)
        handler.removeCallbacks(heartbeat)
        release()
        registry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        store.clear()
        super.onDestroy()
    }

    /** Любая ошибка при показе облачка не должна ронять службу: иначе Android сам её отключит. */
    private fun safeEvaluate() {
        try {
            evaluateNow()
        } catch (error: Throwable) {
            CrashReport.note(this, "облачко: ошибка ${error.javaClass.simpleName}: ${error.message}")
            runCatching { hide() }
        }
    }

    private fun evaluateNow() {
        val container = (application as MyKaomojiApp).container
        if (!container.settings.bubbleEnabled.value) {
            release()
            return
        }
        // Окно облачка готово заранее (скрытое), чтобы показ был мгновенным.
        ensureView()
        val ime = runCatching { windows.firstOrNull { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD } }.getOrNull()
        if (ime == null) {
            hide()
            return
        }
        val root = runCatching { rootInActiveWindow }.getOrNull()
        val field = runCatching { root?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) }.getOrNull()
        val ours = root?.packageName == packageName || ime?.root?.packageName == packageName
        val usable = ime != null && field != null && field.isEditable && !field.isPassword && !ours
        if (!usable) {
            hide()
            return
        }
        val bounds = Rect()
        ime?.getBoundsInScreen(bounds)
        val now = SystemClock.uptimeMillis()
        if (bounds.top != lastKeyboardTop) {
            lastKeyboardTop = bounds.top
            keyboardTopSince = now
        }
        val settled = now - keyboardTopSince >= KEYBOARD_SETTLE_MS
        // Пока клавиатура едет, берём запомненную высоту: облачко встаёт сразу на место. Если запомненной ещё нет,
        // ждём, пока высота устоится (иначе облачко прыгало бы по промежуточным значениям).
        val top = when {
            settled -> bounds.top.also { knownTop = it }
            knownTop > 0 -> knownTop
            else -> -1
        }
        if (top > 0) show(top)
        if (!settled) scheduleEvaluate(60)
    }

    private fun baseParams(width: Int, touchable: Boolean = true) = WindowManager.LayoutParams(
        width,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            // Скрытое облачко не должно перехватывать нажатия.
            (if (touchable) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE),
        PixelFormat.TRANSLUCENT,
    ).apply { gravity = Gravity.BOTTOM or Gravity.END }

    /** Окно облачка: всегда одного размера, место задаёт только клавиатура и перетаскивание. */
    private fun bubbleParams() = baseParams(WindowManager.LayoutParams.WRAP_CONTENT, touchable = bubbleShown).apply {
        x = userX
        y = bottomOffset + userY
    }

    /** Окно панели: во всю ширину, стоит над облачком или под ним (см. chooseDirection). */
    private fun panelParams() = baseParams(WindowManager.LayoutParams.MATCH_PARENT).apply {
        x = 0
        y = if (panelBelow) {
            (bottomOffset + userY - panelTotalPx()).coerceAtLeast(0)
        } else {
            bottomOffset + userY + bubblePx()
        }
    }

    private fun bubblePx(): Int = (BUBBLE_DP * density).toInt()

    /** Полная высота окна панели: сама панель и нижний отступ. */
    private fun panelTotalPx(): Int = ((panelHeightDp + PANEL_PAD_DP) * density).toInt()

    /**
     * Выбирает, куда раскрыть панель: вверх от облачка, если сверху хватает места, иначе вниз.
     * Если не хватает ни там, ни там (например, в альбомной ориентации), берётся сторона, где места больше,
     * и панель становится ниже, но целиком остаётся на экране.
     */
    private fun chooseDirection() {
        val edge = (EDGE_DP * density).toInt()
        val base = bottomOffset + userY
        val above = screenH - (base + bubblePx()) - edge
        val below = base - edge
        panelHeightDp = panelDefaultDp
        val need = panelTotalPx()
        panelBelow = when {
            above >= need -> false
            below >= need -> true
            else -> below > above
        }
        val room = if (panelBelow) below else above
        if (room < need) {
            panelHeightDp = ((room / density) - PANEL_PAD_DP).toInt().coerceIn(MIN_PANEL_DP, panelDefaultDp)
        }
        updateOrigin()
    }

    /** Панель растёт из облачка: точка роста по горизонтали следует за ним. */
    private fun updateOrigin() {
        val width = view?.width?.takeIf { it > 0 } ?: ((BUBBLE_DP + 16) * density).toInt()
        val centerX = screenW - userX - width / 2f
        val inset = 8 * density
        val boxWidth = (screenW - 2 * inset).coerceAtLeast(1f)
        panelOriginX = ((centerX - inset) / boxWidth).coerceIn(0f, 1f)
    }

    private fun updateMetrics(wm: WindowManager) {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        screenW = dm.widthPixels
        screenH = dm.heightPixels
        density = dm.density
        // Панель не выше 42 % экрана: компактная, но вкладки и карточки помещаются целиком.
        panelDefaultDp = (dm.heightPixels / dm.density * 0.42f).toInt().coerceIn(340, 420)
    }

    /** Создаёт окно облачка (скрытое и не принимающее нажатия), если его ещё нет. */
    private fun ensureView(): Boolean {
        val existing = view
        if (existing != null) {
            // Система могла тихо убрать окно (смена конфигурации, нехватка памяти): тогда создаём его заново.
            if (existing.isAttachedToWindow) return true
            CrashReport.note(this, "облачко: окно пропало, создаю заново")
            view = null
            bubbleShown = false
            bubbleVisible = false
            runCatching { existing.disposeComposition() }
            runCatching { window?.removeViewImmediate(existing) }
        }
        val wm = window ?: return false
        updateMetrics(wm)
        val created = themedView { BubbleContent() }
        created.visibility = View.INVISIBLE
        val added = runCatching { wm.addView(created, bubbleParams()) }.onFailure {
            CrashReport.note(this, "облачко: не удалось добавить окно: ${it.javaClass.simpleName}")
        }.isSuccess
        if (added) view = created
        return added
    }

    private fun show(keyboardTop: Int) {
        val wm = window ?: return
        updateMetrics(wm)
        val target = (screenH - keyboardTop).coerceAtLeast(0) + (6 * density).toInt()
        if (!ensureView()) return
        val current = view ?: return
        if (bubbleShown) {
            // Уже на экране: если высота клавиатуры изменилась, плавно переезжаем на новое место.
            moveOffsetTo(target)
            return
        }
        // Показ без ожидания: ставим на место, делаем видимым и принимающим нажатия.
        offsetAnim?.cancel()
        offsetAnim = null
        bottomOffset = target
        offsetTarget = target
        bubbleShown = true
        current.visibility = View.VISIBLE
        applyLayout()
        bubbleVisible = true
    }

    /** Окно с содержимым Compose в теме приложения. */
    private fun themedView(content: @Composable () -> Unit): ComposeView = ComposeView(this).apply {
        setViewTreeLifecycleOwner(this@BubbleService)
        setViewTreeViewModelStoreOwner(this@BubbleService)
        setViewTreeSavedStateRegistryOwner(this@BubbleService)
        setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
        setContent {
            val settings = (application as MyKaomojiApp).container.settings
            val mode by settings.themeMode.collectAsStateWithLifecycle()
            val accent by settings.accent.collectAsStateWithLifecycle()
            val haptics by settings.haptics.collectAsStateWithLifecycle()
            MyKaomojiTheme(dark = mode.isDark(), accent = accent) {
                CompositionLocalProvider(
                    LocalHapticsEnabled provides haptics,
                    LocalCardScale provides 0.66f,
                ) { content() }
            }
        }
    }

    /** Прячет облачко и панель, но окно облачка оставляет (чтобы потом показать мгновенно). */
    private fun hide() {
        lastKeyboardTop = -1
        offsetTarget = -1
        offsetAnim?.cancel()
        offsetAnim = null
        open = false
        removePanel()
        if (!bubbleShown) return
        bubbleShown = false
        bubbleVisible = false
        view?.visibility = View.INVISIBLE
        applyLayout()
    }

    /** Полностью убирает окно облачка (служба выключена или остановлена). */
    private fun release() {
        hide()
        val current = view ?: return
        view = null
        runCatching { current.disposeComposition() }
        runCatching { window?.removeViewImmediate(current) }
    }

    private fun applyLayout() {
        val wm = window ?: return
        view?.let { runCatching { wm.updateViewLayout(it, bubbleParams()) } }
        panelView?.let { runCatching { wm.updateViewLayout(it, panelParams()) } }
    }

    /** Плавно меняет отступ от низа экрана (под высоту клавиатуры), вместо того чтобы прыгнуть. */
    private fun moveOffsetTo(target: Int) {
        // Цель та же, что уже едем: не перезапускаем анимацию (события приходят пачками).
        if (target == offsetTarget) return
        offsetTarget = target
        val from = bottomOffset
        offsetAnim?.cancel()
        offsetAnim = ValueAnimator.ofInt(from, target).apply {
            duration = 200
            interpolator = PathInterpolator(0.4f, 0f, 0.2f, 1f)
            addUpdateListener {
                bottomOffset = it.animatedValue as Int
                applyLayout()
            }
            start()
        }
    }

    private fun addPanel() {
        val wm = window ?: return
        if (panelView != null) return
        val created = themedView { PanelContent() }
        val added = runCatching { wm.addView(created, panelParams()) }.isSuccess
        if (added) panelView = created else open = false
    }

    private fun removePanel() {
        val current = panelView ?: return
        panelView = null
        runCatching { current.disposeComposition() }
        runCatching { window?.removeViewImmediate(current) }
    }

    /** Перетаскивание: палец сдвинулся на (dx, dy) пикселей. Оба окна двигаются вместе. */
    private fun moveBy(dx: Float, dy: Float) {
        val bubble = view ?: return
        val wm = window ?: return
        // Стопка «облачко + панель» всегда должна целиком помещаться на экране, куда бы панель ни раскрылась.
        val panelH = if (panelView != null) panelTotalPx() else 0
        val minBase = if (panelBelow) panelH else 0
        val maxBase = (if (panelBelow) screenH - bubble.height else screenH - bubble.height - panelH).coerceAtLeast(minBase)
        userY = (userY - dy.toInt()).coerceIn(minBase - bottomOffset, maxBase - bottomOffset)
        val maxX = (screenW - bubble.width).coerceAtLeast(0)
        userX = (userX - dx.toInt()).coerceIn(-(8 * density).toInt(), maxX)
        updateOrigin()
        runCatching { wm.updateViewLayout(bubble, bubbleParams()) }
        panelView?.let { runCatching { wm.updateViewLayout(it, panelParams()) } }
    }

    private fun changeExpanded(value: Boolean) {
        if (value) {
            if (open) return
            vm?.refreshTop()
            chooseDirection()
            open = true
            addPanel()
        } else {
            // Панель сама доиграет анимацию закрытия и уберёт своё окно. Облачко при этом не трогаем.
            open = false
        }
    }

    private fun homeViewModel(): HomeViewModel = vm ?: ViewModelProvider(
        this,
        HomeViewModel.factory((application as MyKaomojiApp).container, rememberMood = true),
    )[HomeViewModel::class.java].also { vm = it }

    /**
     * Вставляет каомодзи в поле, где стоит курсор. Если поле пустое и показывает подсказку («Сообщение» в Telegram),
     * оно отдаёт службе текст подсказки как обычный текст, а курсор не отдаёт. Тогда читать и править текст нельзя
     * (в поле дописывалась подсказка), и каомодзи вставляется через буфер обмена, прямо в позицию курсора.
     */
    private fun insert(text: String) {
        val node = runCatching { rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) }.getOrNull() ?: return
        val raw = node.text?.toString().orEmpty()
        val hint = node.hintText?.toString()
        val looksLikeHint = node.isShowingHintText || (!hint.isNullOrEmpty() && raw == hint)
        val cursorKnown = node.textSelectionStart >= 0 && node.textSelectionEnd >= 0
        if (looksLikeHint || !cursorKnown) {
            pasteViaClipboard(node, text, allowSetText = looksLikeHint)
            return
        }
        val start = node.textSelectionStart.coerceIn(0, raw.length)
        val end = node.textSelectionEnd.coerceIn(0, raw.length)
        val from = minOf(start, end)
        val to = maxOf(start, end)
        val updated = raw.replaceRange(from, to, text)
        val set = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, updated)
        }
        val ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, set)
        if (ok) {
            val caret = from + text.length
            val sel = Bundle().apply {
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, caret)
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, caret)
            }
            node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel)
        } else {
            pasteViaClipboard(node, text, allowSetText = false)
        }
    }

    private fun pasteViaClipboard(node: AccessibilityNodeInfo, text: String, allowSetText: Boolean) {
        val clipboard = getSystemService(ClipboardManager::class.java)
        clipboard?.setPrimaryClip(ClipData.newPlainText("kaomoji", text))
        val pasted = node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        if (!pasted && allowSetText) {
            // Вставка не сработала, а поле точно пустое (виден только текст подсказки): записываем само каомодзи.
            val set = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            }
            node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, set)
        }
    }

    /** Только облачко: окно под него не меняет размер, поэтому никуда не «прыгает». */
    @Composable
    private fun BubbleContent() {
        val source = remember { MutableInteractionSource() }
        val p = LocalPalette.current
        val fill = remember(p) { p.accentBrush() }
        // Облачко появляется почти мгновенно (короткое проявление уже на своём месте), прячется сразу.
        val appear = remember { Animatable(0f) }
        LaunchedEffect(bubbleVisible) {
            if (bubbleVisible) appear.animateTo(1f, tween(80)) else appear.snapTo(0f)
        }
        Box(Modifier.padding(horizontal = 8.dp).graphicsLayer { alpha = appear.value }) {
            Box(
                Modifier
                    .size(BUBBLE_DP.dp)
                    .pressScale(source)
                    .softShadow(CircleShape, elevation = 4.dp, drawn = false)
                    .clip(CircleShape)
                    .background(fill)
                    .pointerInput(Unit) {
                        // Облачко можно перетащить, нажатие по-прежнему раскрывает панель.
                        detectDragGestures { change, drag ->
                            change.consume()
                            moveBy(drag.x, drag.y)
                        }
                    }
                    .clickable(interactionSource = source, indication = null) { changeExpanded(!open) },
                contentAlignment = Alignment.Center,
            ) { LogoMark(size = 34.dp, onAccentBg = true) }
        }
    }

    /** Панель каомодзи в своём окне: появляется и уходит плавно, после ухода окно убирается. */
    @Composable
    private fun PanelContent() {
        val p = LocalPalette.current
        // 0 = панель спрятана, 1 = раскрыта. Меняется только прозрачность и масштаб слоя: размеры не пересчитываются.
        val progress = remember { Animatable(0f) }
        LaunchedEffect(open) {
            if (open) {
                // Даём панели собраться (тяжёлая часть) до начала движения, чтобы анимация не «спотыкалась».
                repeat(2) { withFrameNanos { } }
                progress.animateTo(1f, tween(190, easing = FastOutSlowInEasing))
            } else {
                progress.animateTo(0f, tween(150, easing = FastOutSlowInEasing))
                // Окно убираем уже вне этой корутины и только если панель так и не открыли заново.
                handler.post { if (!open) removePanel() }
            }
        }
        val model = remember { homeViewModel() }
        val state by model.state.collectAsStateWithLifecycle()
        Box(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp)
                // Отступ от облачка с той стороны, где оно стоит.
                .padding(
                    top = if (panelBelow) PANEL_PAD_DP.dp else 0.dp,
                    bottom = if (panelBelow) 0.dp else PANEL_PAD_DP.dp,
                )
                .height(panelHeightDp.dp)
                .graphicsLayer {
                    val t = progress.value
                    alpha = t
                    val k = 0.88f + 0.12f * t
                    scaleX = k
                    scaleY = k
                    // Панель выезжает от облачка: снизу вверх, если раскрывается вверх, и сверху вниз, если вниз.
                    translationY = (1f - t) * 14.dp.toPx() * (if (panelBelow) -1f else 1f)
                    transformOrigin = TransformOrigin(panelOriginX, if (panelBelow) 0f else 1f)
                }
                .softShadow(RoundedCornerShape(26.dp), elevation = 6.dp, drawn = false)
                .clip(RoundedCornerShape(26.dp))
                .background(p.backgroundBrush()),
        ) {
            KaomojiPanel(
                state = state,
                onSelect = model::select,
                onPick = { text ->
                    insert(text)
                    model.picked(text)
                },
                onHold = model::toggleFavorite,
                feedback = stringResource(R.string.inserted),
                modifier = Modifier.fillMaxWidth().height(panelHeightDp.dp).padding(top = 22.dp),
                topRow = state.top,
            )
            // Ручка сверху: за неё панель можно перетащить выше или ниже (облачко едет вместе с ней).
            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .height(24.dp)
                    .pointerInput(Unit) {
                        detectDragGestures { change, drag ->
                            change.consume()
                            moveBy(0f, drag.y)
                        }
                    },
                contentAlignment = Alignment.Center,
            ) {
                Box(Modifier.size(width = 38.dp, height = 4.dp).clip(CircleShape).background(p.ink.copy(alpha = 0.22f)))
            }
        }
    }
}

private const val BUBBLE_DP = 52

/** Нижний отступ окна панели (он же в PanelContent). */
private const val PANEL_PAD_DP = 8

/** Запас до края экрана, который панель не занимает (строка состояния, жестовая полоса). */
private const val EDGE_DP = 24

/** Самая низкая панель, когда места мало. */
private const val MIN_PANEL_DP = 180
private const val HEARTBEAT_MS = 2500L

/** Сколько мс высота клавиатуры должна не меняться, прежде чем показать облачко. */
private const val KEYBOARD_SETTLE_MS = 150L

/** Сколько мс после нажатия кнопки в гайде служба может сама нажимать в настройках. */
private const val GRANT_WINDOW_MS = 15000L
