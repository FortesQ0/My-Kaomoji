// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.widget

import android.content.Context
import android.content.res.Configuration
import android.os.BatteryManager
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.ColorFilter
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.LocalSize
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionParametersOf
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.updateAll
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxHeight
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextAlign
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import app.komodje.MyKaomojiApp
import app.komodje.R
import app.komodje.domain.ThemeMode
import app.komodje.domain.topPicks
import app.komodje.ui.theme.paletteFor
import kotlinx.coroutines.flow.first
import java.time.LocalDateTime

// Набор небольших виджетов в стиле приложения: цвета берутся из выбранного акцента и режима, как у главного экрана.
// «Каомодзи дня» 2×2, «Любимые» 4×1, «Кубик» 2×1, «Поздравление» 2×2, «Талисман» 2×2.

private val KindKey = ActionParameters.Key<String>("widget_kind")

/** Цвета виджета из палитры приложения. */
internal class Look(val bg: Color, val tile: Color, val ink: Color, val muted: Color, val badge: Color, val onBadge: Color)

internal suspend fun lookOf(context: Context): Look {
    val container = (context.applicationContext as MyKaomojiApp).container
    val night = (context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    val dark = when (container.settings.readThemeMode()) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> night
    }
    val p = paletteFor(container.settings.readAccent(), dark)
    return Look(p.accent, p.card, p.ink, p.muted, p.badge, p.onBadge)
}

private fun seedOf(context: Context, key: String): Int =
    context.getSharedPreferences("widgets", Context.MODE_PRIVATE).getInt(key, 0)

private fun bumpSeed(context: Context, key: String) {
    val prefs = context.getSharedPreferences("widgets", Context.MODE_PRIVATE)
    prefs.edit().putInt(key, prefs.getInt(key, 0) + 1).apply()
}

private fun pickRandom(library: List<String>, seed: Long, count: Int): List<String> {
    if (library.isEmpty()) return emptyList()
    val random = java.util.Random(seed)
    val picked = LinkedHashSet<Int>()
    while (picked.size < minOf(count, library.size)) picked += random.nextInt(library.size)
    return picked.map { library[it] }
}

private suspend fun libraryOf(context: Context): List<String> =
    (context.applicationContext as MyKaomojiApp).container.repository.allTexts()

private fun today(): Long = java.time.LocalDate.now().toEpochDay()

/** Размер шрифта так, чтобы самое длинное каомодзи влезло в плитку целиком. */
private fun fit(widthDp: Float, longest: Int, min: Float, max: Float): Float =
    ((widthDp - 12f) / (longest.coerceAtLeast(1) * 0.62f)).coerceIn(min, max)

// ---------- Общие кусочки ----------

@Composable
private fun Shell(look: Look, content: @Composable () -> Unit) {
    Box(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(ColorProvider(look.bg))
            .cornerRadius(22.dp)
            .padding(6.dp),
    ) { content() }
}

@Composable
private fun KTile(text: String, look: Look, fontSize: Float, modifier: GlanceModifier, bold: Boolean = false) {
    Box(
        modifier = modifier
            .background(ColorProvider(look.tile))
            .cornerRadius(16.dp)
            .padding(horizontal = 4.dp)
            .clickable(onClick = actionRunCallback<CopyAction>(actionParametersOf(PickKeyShared to text))),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = text,
            maxLines = 2,
            style = TextStyle(
                color = ColorProvider(look.ink),
                fontSize = fontSize.sp,
                fontWeight = if (bold) FontWeight.Bold else FontWeight.Medium,
                textAlign = TextAlign.Center,
            ),
        )
    }
}

@Composable
private fun DiceButton(kind: String, look: Look, size: Int, modifier: GlanceModifier = GlanceModifier) {
    Box(
        modifier = modifier
            .size(size.dp)
            .background(ColorProvider(look.badge))
            .cornerRadius(14.dp)
            .clickable(onClick = actionRunCallback<RerollAction>(actionParametersOf(KindKey to kind))),
        contentAlignment = Alignment.Center,
    ) {
        Image(
            provider = ImageProvider(R.drawable.ic_widget_dice),
            contentDescription = null,
            modifier = GlanceModifier.size((size * 0.58f).dp),
            colorFilter = ColorFilter.tint(ColorProvider(look.onBadge)),
        )
    }
}

// ---------- Каомодзи дня (2×2) ----------

class DayWidget : GlanceAppWidget() {
    override val sizeMode: SizeMode = SizeMode.Exact
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val look = lookOf(context)
        val text = pickRandom(libraryOf(context), today() * 31 + seedOf(context, "day"), 1).firstOrNull().orEmpty()
        val label = context.getString(R.string.widget_name_day)
        provideContent {
            Shell(look) {
                val w = LocalSize.current.width.value - 12f
                Column(GlanceModifier.fillMaxSize()) {
                    Row(GlanceModifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            label,
                            modifier = GlanceModifier.defaultWeight().padding(start = 6.dp),
                            maxLines = 1,
                            style = TextStyle(color = ColorProvider(look.ink), fontSize = 12.sp, fontWeight = FontWeight.Bold),
                        )
                        DiceButton("day", look, 28)
                    }
                    Spacer(GlanceModifier.height(5.dp))
                    KTile(text, look, fit(w, text.length, 16f, 34f), GlanceModifier.fillMaxWidth().defaultWeight())
                }
            }
        }
    }
}

class DayWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = DayWidget()
}

// ---------- Любимые лентой (4×1) ----------

class StripWidget : GlanceAppWidget() {
    override val sizeMode: SizeMode = SizeMode.Exact
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val look = lookOf(context)
        val container = (context.applicationContext as MyKaomojiApp).container
        val library = libraryOf(context)
        val seed = seedOf(context, "strip")
        val picks = if (seed == 0) {
            topPicks(library, container.favorites.favorites.first(), container.usage.counts.first(), 3)
        } else {
            pickRandom(library, today() * 17 + seed, 3)
        }
        provideContent {
            Shell(look) {
                val w = (LocalSize.current.width.value - 12f - 4 * 5f - 44f) / 3f
                val size = fit(w, picks.maxOfOrNull { it.length } ?: 1, 11f, 20f)
                Row(GlanceModifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                    picks.forEach {
                        KTile(it, look, size, GlanceModifier.defaultWeight().fillMaxHeight())
                        Spacer(GlanceModifier.width(5.dp))
                    }
                    DiceButton("strip", look, 40)
                }
            }
        }
    }
}

class StripWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = StripWidget()
}

// ---------- Кубик (2×1) ----------

class DiceWidget : GlanceAppWidget() {
    override val sizeMode: SizeMode = SizeMode.Exact
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val look = lookOf(context)
        val seed = seedOf(context, "dice")
        val text = pickRandom(libraryOf(context), System.currentTimeMillis() / 3_600_000L * 13 + seed, 1).firstOrNull().orEmpty()
        provideContent {
            Shell(look) {
                val w = LocalSize.current.width.value - 12f - 44f
                Row(GlanceModifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                    KTile(text, look, fit(w, text.length, 12f, 22f), GlanceModifier.defaultWeight().fillMaxHeight())
                    Spacer(GlanceModifier.width(5.dp))
                    DiceButton("dice", look, 40)
                }
            }
        }
    }
}

class DiceWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = DiceWidget()
}

// ---------- Поздравление (2×2) ----------

class GreetingWidget : GlanceAppWidget() {
    override val sizeMode: SizeMode = SizeMode.Exact
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val look = lookOf(context)
        val face = pickRandom(libraryOf(context), today() * 7 + seedOf(context, "greet"), 1).firstOrNull().orEmpty()
        val greeting = context.getString(greetingRes(LocalDateTime.now()))
        provideContent {
            Shell(look) {
                val w = LocalSize.current.width.value - 12f
                Column(GlanceModifier.fillMaxSize()) {
                    Row(GlanceModifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            greeting,
                            modifier = GlanceModifier.defaultWeight().padding(start = 6.dp),
                            maxLines = 2,
                            style = TextStyle(color = ColorProvider(look.ink), fontSize = 13.sp, fontWeight = FontWeight.Bold),
                        )
                        DiceButton("greet", look, 28)
                    }
                    Spacer(GlanceModifier.height(5.dp))
                    // Тап копирует поздравление вместе с каомодзи: можно сразу вставить в чат.
                    Box(
                        modifier = GlanceModifier
                            .fillMaxWidth()
                            .defaultWeight()
                            .background(ColorProvider(look.tile))
                            .cornerRadius(16.dp)
                            .padding(horizontal = 4.dp)
                            .clickable(onClick = actionRunCallback<CopyAction>(actionParametersOf(PickKeyShared to "$greeting $face"))),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = face,
                            maxLines = 2,
                            style = TextStyle(
                                color = ColorProvider(look.ink),
                                fontSize = fit(w, face.length, 16f, 30f).sp,
                                fontWeight = FontWeight.Medium,
                                textAlign = TextAlign.Center,
                            ),
                        )
                    }
                }
            }
        }
    }
}

private fun greetingRes(now: LocalDateTime): Int {
    val m = now.monthValue
    val d = now.dayOfMonth
    return when {
        (m == 1 && d == 1) || (m == 12 && d == 31) -> R.string.w_newyear
        (m == 3 && d == 8) || (m == 2 && d == 14) || (m == 12 && d == 25) -> R.string.w_holiday
        now.hour in 5..10 -> R.string.w_morning
        now.hour in 11..16 -> R.string.w_day
        now.hour in 17..22 -> R.string.w_evening
        else -> R.string.w_night
    }
}

class GreetingWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = GreetingWidget()
}

// ---------- Талисман (2×2) ----------

class MascotWidget : GlanceAppWidget() {
    override val sizeMode: SizeMode = SizeMode.Exact
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val look = lookOf(context)
        val battery = context.getSystemService(BatteryManager::class.java)
        val level = battery?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 100
        val charging = battery?.isCharging == true
        val hour = LocalDateTime.now().hour
        // Лицо зависит от заряда и времени суток: на зарядке радуется, при низком заряде грустит, ночью спит.
        val (face, caption) = when {
            charging -> "٩(◕‿◕)۶" to R.string.w_charging
            level <= 15 -> "(｡•́︿•̀｡)" to R.string.w_lowbat
            hour in 5..10 -> "(*´▽`*)" to R.string.w_morning
            hour in 11..16 -> "(≧◡≦)" to R.string.w_day
            hour in 17..22 -> "(´• ω •`)ﾉ" to R.string.w_evening
            else -> "(－ω－) zzZ" to R.string.w_night
        }
        val text = context.getString(caption)
        provideContent {
            Shell(look) {
                val w = LocalSize.current.width.value - 12f
                Column(GlanceModifier.fillMaxSize()) {
                    Box(
                        modifier = GlanceModifier
                            .fillMaxWidth()
                            .defaultWeight()
                            .background(ColorProvider(look.tile))
                            .cornerRadius(16.dp)
                            .padding(horizontal = 4.dp)
                            .clickable(onClick = actionRunCallback<CopyAction>(actionParametersOf(PickKeyShared to face))),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = face,
                            maxLines = 1,
                            style = TextStyle(
                                color = ColorProvider(look.ink),
                                fontSize = fit(w, face.length, 16f, 34f).sp,
                                fontWeight = FontWeight.Medium,
                                textAlign = TextAlign.Center,
                            ),
                        )
                    }
                    Spacer(GlanceModifier.height(5.dp))
                    Text(
                        text,
                        modifier = GlanceModifier.fillMaxWidth(),
                        maxLines = 2,
                        style = TextStyle(
                            color = ColorProvider(look.ink),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                        ),
                    )
                }
            }
        }
    }
}

class MascotWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = MascotWidget()
}

// ---------- Кубик: перебросить значение ----------

class RerollAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        val kind = parameters[KindKey] ?: return
        bumpSeed(context, kind)
        val app = context.applicationContext
        when (kind) {
            "day" -> DayWidget().updateAll(app)
            "strip" -> StripWidget().updateAll(app)
            "dice" -> DiceWidget().updateAll(app)
            "greet" -> GreetingWidget().updateAll(app)
        }
    }
}

/** Обновить все новые виджеты (смена темы или акцента). */
suspend fun refreshMoreWidgets(context: Context) {
    val app = context.applicationContext
    runCatching { DayWidget().updateAll(app) }
    runCatching { StripWidget().updateAll(app) }
    runCatching { DiceWidget().updateAll(app) }
    runCatching { GreetingWidget().updateAll(app) }
    runCatching { MascotWidget().updateAll(app) }
}
