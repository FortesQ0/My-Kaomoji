// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.widget

import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.os.BatteryManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.ColorFilter
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.LocalContext
import androidx.glance.LocalSize
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionParametersOf
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.updateAll
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.ContentScale
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxHeight
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextAlign
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import app.komodje.MyKaomojiApp
import app.komodje.R
import app.komodje.domain.ThemeMode
import app.komodje.domain.topPicks
import app.komodje.ui.theme.paletteFor
import kotlinx.coroutines.flow.first
import java.time.LocalDateTime

// Виджеты в стиле приложения. Идея одна на все: цельная плашка с мягким градиентом акцента (без вложенных
// белых коробок), главное крупно по центру, второстепенное мелко, маленькие круглые действия.
// «Любимое» 1×1, «Каомодзи дня» 1×1, «Любимые лентой» 2×1, «Поздравление» 2×1, «Талисман» 2×1.

private val KindKey = ActionParameters.Key<String>("widget_kind")

/** Цвета виджета из палитры приложения. */
internal class Look(
    val from: Color,
    val to: Color,
    val ink: Color,
    val muted: Color,
    val badge: Color,
    val onBadge: Color,
)

internal suspend fun lookOf(context: Context): Look {
    val container = (context.applicationContext as MyKaomojiApp).container
    val night = (context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    val dark = when (container.settings.readThemeMode()) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> night
    }
    val p = paletteFor(container.settings.readAccent(), dark)
    // Светлая тема: от лёгкого оттенка к насыщенному; тёмная: тёмная основа с едва заметным акцентом.
    val dim = p.card.luminance() < 0.5f
    val from = lerp(p.card, p.accent, if (dim) 0.10f else 0.22f)
    val to = lerp(p.card, p.accent, if (dim) 0.40f else 0.72f)
    return Look(from, to, p.ink, p.muted, p.badge, p.onBadge)
}

private fun seedOf(context: Context, key: String): Int =
    context.getSharedPreferences("widgets", Context.MODE_PRIVATE).getInt(key, 0)

private fun bumpSeed(context: Context, key: String) {
    val prefs = context.getSharedPreferences("widgets", Context.MODE_PRIVATE)
    prefs.edit().putInt(key, prefs.getInt(key, 0) + 1).apply()
}

/** Случайные без повторов. Соседние числа дают совсем разные результаты (раньше кубик менял значение на «соседнее»). */
private fun pickRandom(library: List<String>, seed: Long, count: Int): List<String> {
    if (library.isEmpty()) return emptyList()
    val random = java.util.SplittableRandom(seed * -7046029254386353131L + 0x1234567L)
    val picked = LinkedHashSet<Int>()
    while (picked.size < minOf(count, library.size)) picked += random.nextInt(library.size)
    return picked.map { library[it] }
}

private suspend fun libraryOf(context: Context): List<String> =
    (context.applicationContext as MyKaomojiApp).container.repository.allTexts()

private fun today(): Long = java.time.LocalDate.now().toEpochDay()

/** Размер шрифта так, чтобы самое длинное каомодзи влезло в отведённую ширину. */
private fun fit(widthDp: Float, longest: Int, min: Float, max: Float): Float =
    (widthDp / (longest.coerceAtLeast(1) * 0.6f)).coerceIn(min, max)

// ---------- Картинки: плашка с градиентом и круглая кнопка ----------

/** Плашка «листом»: большие скругления слева сверху и справа снизу, маленькие на других углах, градиент по диагонали. */
private fun plateBitmap(widthDp: Float, heightDp: Float, density: Float, look: Look): Bitmap {
    val scale = minOf(density, 3f)
    val w = (widthDp * scale).toInt().coerceIn(48, 960)
    val h = (heightDp * scale).toInt().coerceIn(48, 960)
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bmp)
    val big = minOf(26f * scale, h / 2.2f)
    val small = big * 0.42f
    val path = Path().apply {
        addRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), floatArrayOf(big, big, small, small, big, big, small, small), Path.Direction.CW)
    }
    val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), look.from.toArgb(), look.to.toArgb(), Shader.TileMode.CLAMP)
    }
    canvas.drawPath(path, fill)
    // Тонкий светлый кант: плашка не сливается с обоями.
    val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1f * scale
        color = look.ink.copy(alpha = 0.08f).toArgb()
    }
    canvas.drawPath(path, edge)
    return bmp
}

private fun dotBitmap(color: Color, sizeDp: Float, density: Float): Bitmap {
    val px = (sizeDp * minOf(density, 3f)).toInt().coerceIn(16, 256)
    val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color.toArgb() }
    Canvas(bmp).drawCircle(px / 2f, px / 2f, px / 2f, paint)
    return bmp
}

// ---------- Общие кусочки ----------

/** Цельная плашка под всем содержимым виджета. */
@Composable
internal fun Plate(look: Look, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val size = LocalSize.current
    val density = ctx.resources.displayMetrics.density
    val bmp = remember(look, size) {
        plateBitmap(size.width.value.coerceAtLeast(40f), size.height.value.coerceAtLeast(40f), density, look)
    }
    Box(GlanceModifier.fillMaxSize()) {
        Image(
            provider = ImageProvider(bmp),
            contentDescription = null,
            modifier = GlanceModifier.fillMaxSize(),
            contentScale = ContentScale.FillBounds,
        )
        Box(GlanceModifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 6.dp), contentAlignment = Alignment.Center) {
            content()
        }
    }
}

/** Маленькая круглая кнопка с кубиком. */
@Composable
private fun DiceDot(kind: String, look: Look, sizeDp: Int) {
    val ctx = LocalContext.current
    val density = ctx.resources.displayMetrics.density
    val circle = remember(look, sizeDp) { dotBitmap(look.badge, sizeDp.toFloat(), density) }
    Box(
        modifier = GlanceModifier
            .size(sizeDp.dp)
            .clickable(onClick = actionRunCallback<RerollAction>(actionParametersOf(KindKey to kind))),
        contentAlignment = Alignment.Center,
    ) {
        Image(ImageProvider(circle), null, GlanceModifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
        Image(
            provider = ImageProvider(R.drawable.ic_widget_dice),
            contentDescription = null,
            modifier = GlanceModifier.size((sizeDp * 0.56f).dp),
            colorFilter = ColorFilter.tint(ColorProvider(look.onBadge)),
        )
    }
}

@Composable
private fun FaceText(text: String, look: Look, fontSize: Float, bold: Boolean = false, lines: Int = 2) {
    Text(
        text = text,
        maxLines = lines,
        style = TextStyle(
            color = ColorProvider(look.ink),
            fontSize = fontSize.sp,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Medium,
            textAlign = TextAlign.Center,
        ),
    )
}

/** Виджет 1×1: каомодзи по центру, тап копирует; если задан kind, в углу маленький кубик. */
@Composable
internal fun FaceWidget(look: Look, text: String, copyText: String, rerollKind: String?) {
    Plate(look) {
        val w = LocalSize.current.width.value - 20f
        Box(
            modifier = GlanceModifier
                .fillMaxSize()
                .clickable(onClick = actionRunCallback<CopyAction>(actionParametersOf(PickKeyShared to copyText))),
            contentAlignment = Alignment.Center,
        ) { FaceText(text, look, fit(w, text.length, 11f, 26f)) }
        if (rerollKind != null) {
            Box(GlanceModifier.fillMaxSize(), contentAlignment = Alignment.BottomEnd) { DiceDot(rerollKind, look, 22) }
        }
    }
}

// ---------- Каомодзи дня (1×1) ----------

class DayWidget : GlanceAppWidget() {
    override val sizeMode: SizeMode = SizeMode.Exact
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val look = lookOf(context)
        val text = pickRandom(libraryOf(context), today() * 31 + seedOf(context, "day"), 1).firstOrNull().orEmpty()
        provideContent { FaceWidget(look, text, text, rerollKind = "day") }
    }
}

class DayWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = DayWidget()
}

// ---------- Любимые лентой (2×1) ----------

class StripWidget : GlanceAppWidget() {
    override val sizeMode: SizeMode = SizeMode.Exact
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val look = lookOf(context)
        val container = (context.applicationContext as MyKaomojiApp).container
        val library = libraryOf(context)
        val seed = seedOf(context, "strip")
        val picks = if (seed == 0) {
            topPicks(library, container.favorites.favorites.first(), container.usage.counts.first(), 2)
        } else {
            pickRandom(library, today() * 17 + seed, 2)
        }
        provideContent {
            Plate(look) {
                val w = (LocalSize.current.width.value - 20f - 26f) / 2f
                val size = fit(w, picks.maxOfOrNull { it.length } ?: 1, 10f, 20f)
                Row(GlanceModifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                    picks.forEach { face ->
                        Box(
                            modifier = GlanceModifier
                                .defaultWeight()
                                .fillMaxHeight()
                                .clickable(onClick = actionRunCallback<CopyAction>(actionParametersOf(PickKeyShared to face))),
                            contentAlignment = Alignment.Center,
                        ) { FaceText(face, look, size) }
                    }
                    Spacer(GlanceModifier.width(4.dp))
                    DiceDot("strip", look, 22)
                }
            }
        }
    }
}

class StripWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = StripWidget()
}

// ---------- Поздравление (2×1) ----------

class GreetingWidget : GlanceAppWidget() {
    override val sizeMode: SizeMode = SizeMode.Exact
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val look = lookOf(context)
        val face = pickRandom(libraryOf(context), today() * 7 + seedOf(context, "greet"), 1).firstOrNull().orEmpty()
        val greeting = context.getString(greetingRes(LocalDateTime.now()))
        provideContent {
            Plate(look) {
                val w = (LocalSize.current.width.value - 20f) / 2f
                // Тап копирует поздравление вместе с каомодзи: можно сразу вставить в чат.
                Row(
                    GlanceModifier
                        .fillMaxSize()
                        .clickable(onClick = actionRunCallback<CopyAction>(actionParametersOf(PickKeyShared to "$greeting $face"))),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(GlanceModifier.defaultWeight().fillMaxHeight(), contentAlignment = Alignment.CenterStart) {
                        Text(
                            greeting,
                            maxLines = 3,
                            style = TextStyle(color = ColorProvider(look.ink), fontSize = 12.sp, fontWeight = FontWeight.Bold),
                        )
                    }
                    Spacer(GlanceModifier.width(6.dp))
                    Box(GlanceModifier.defaultWeight().fillMaxHeight(), contentAlignment = Alignment.Center) {
                        FaceText(face, look, fit(w, face.length, 11f, 22f))
                    }
                }
            }
        }
    }
}

private fun greetingRes(now: LocalDateTime): Int {
    val m = now.monthValue
    val d = now.dayOfMonth
    return when {
        (m == 1 && d == 1) || (m == 12 && d == 31) -> R.string.w_newyear
        (m == 3 && d == 8) || (m == 2 && d == 14) || (m == 12 && d == 25) -> R.string.w_holiday
        now.hour in 5..10 -> R.string.w_morning
        now.hour in 11..16 -> R.string.w_day
        now.hour in 17..22 -> R.string.w_evening
        else -> R.string.w_night
    }
}

class GreetingWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = GreetingWidget()
}

// ---------- Талисман (2×1) ----------

class MascotWidget : GlanceAppWidget() {
    override val sizeMode: SizeMode = SizeMode.Exact
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val look = lookOf(context)
        val battery = context.getSystemService(BatteryManager::class.java)
        val level = battery?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 100
        val charging = battery?.isCharging == true
        val hour = LocalDateTime.now().hour
        // Лицо зависит от заряда и времени суток: на зарядке радуется, при низком заряде грустит, ночью спит.
        val (face, caption) = when {
            charging -> "٩(◕‿◕)۶" to R.string.w_charging
            level <= 15 -> "(｡•́︿•̀｡)" to R.string.w_lowbat
            hour in 5..10 -> "(*´▽`*)" to R.string.w_morning
            hour in 11..16 -> "(≧◡≦)" to R.string.w_day
            hour in 17..22 -> "(´• ω •`)ﾉ" to R.string.w_evening
            else -> "(－ω－) zzZ" to R.string.w_night
        }
        val text = context.getString(caption)
        provideContent {
            Plate(look) {
                val w = (LocalSize.current.width.value - 20f) / 2f
                Row(
                    GlanceModifier
                        .fillMaxSize()
                        .clickable(onClick = actionRunCallback<CopyAction>(actionParametersOf(PickKeyShared to face))),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(GlanceModifier.defaultWeight().fillMaxHeight(), contentAlignment = Alignment.Center) {
                        FaceText(face, look, fit(w, face.length, 11f, 22f), lines = 1)
                    }
                    Spacer(GlanceModifier.width(6.dp))
                    Box(GlanceModifier.defaultWeight().fillMaxHeight(), contentAlignment = Alignment.CenterStart) {
                        Text(
                            text,
                            maxLines = 3,
                            style = TextStyle(color = ColorProvider(look.ink), fontSize = 11.sp, fontWeight = FontWeight.Bold),
                        )
                    }
                }
            }
        }
    }
}

class MascotWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = MascotWidget()
}

// ---------- Кубик: перебросить значение ----------

class RerollAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        val kind = parameters[KindKey] ?: return
        bumpSeed(context, kind)
        val app = context.applicationContext
        when (kind) {
            "day" -> DayWidget().updateAll(app)
            "strip" -> StripWidget().updateAll(app)
        }
    }
}

/** Обновить все виджеты (смена темы или акцента). */
suspend fun refreshMoreWidgets(context: Context) {
    val app = context.applicationContext
    runCatching { DayWidget().updateAll(app) }
    runCatching { StripWidget().updateAll(app) }
    runCatching { GreetingWidget().updateAll(app) }
    runCatching { MascotWidget().updateAll(app) }
}
