// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.domain

import androidx.compose.runtime.Immutable

enum class Mood { FAVORITE, HAPPY, SAD, NEUTRAL, ANGRY, TENDER }

/**
 * flags: бит 1 = есть эффекты снаружи, бит 2 = два и более персонажей; -1 = не размечено,
 * тогда считаем по тексту.
 */
@Immutable
data class Kaomoji(val text: String, val flags: Int = -1) {
    val resolvedFlags: Int get() = if (flags >= 0) flags else flagsOf(text)
}

/** Отсекает «просто скобки» и чистый ASCII-смайлик: нужен хотя бы один не-ASCII символ. */
fun Kaomoji.isComplex(): Boolean =
    text.length >= 3 && text.any { it.code > 127 }

private val sadGlyphs = setOf('◞', '◟', '︵', '╥', '﹏', '；')

/** Грубый линт настроения: в «весёлых» не должно быть грустных глифов. */
fun Kaomoji.fitsHappy(): Boolean = text.none { it in sadGlyphs }

/** Тема оформления: своя настройка поверх системной. */
enum class ThemeMode { SYSTEM, LIGHT, DARK }

/** Акцентный цвет приложения. top/bottom: цвета превью-плитки в настройках (ARGB). */
enum class AccentTheme(val top: Long, val bottom: Long) {
    PEACH(0xFFFFE6DA, 0xFFFFB896),
    SAKURA(0xFFFFE8EF, 0xFFFFB6CC),
    SEA(0xFFE0F0FF, 0xFF93C4F7),
    BURGUNDY(0xFFBD5A72, 0xFF7E2339),
    APPLE(0xFFE3F6D8, 0xFFA6DB86),
    SUN(0xFFFFF0B3, 0xFFFFD84D),
    LILAC(0xFFEADBFB, 0xFFB997F0),
    MILK(0xFFFFFFFF, 0xFFD9D3E6),
}
