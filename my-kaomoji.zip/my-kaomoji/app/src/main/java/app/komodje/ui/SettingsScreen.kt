// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.heightIn
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.Stable
import androidx.compose.runtime.State
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.Density
import app.komodje.ui.components.DialogButton
import app.komodje.ui.components.cardScaleFactor
import app.komodje.ui.components.DonateSheet
import app.komodje.ui.components.FitText
import app.komodje.ui.components.KaomojiCard
import app.komodje.ui.components.KaomojiDialog
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import app.komodje.notify.DailyKaomoji
import app.komodje.data.Backup
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import android.widget.Toast
import android.os.Build
import android.content.pm.PackageManager
import android.Manifest
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onSizeChanged
import kotlin.math.roundToInt
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import app.komodje.CrashReport
import app.komodje.MyKaomojiApp
import app.komodje.ui.components.rememberBuzz
import app.komodje.ui.components.SectionIcon
import app.komodje.R
import app.komodje.domain.AccentTheme
import app.komodje.domain.ThemeMode
import app.komodje.ui.components.KaomojiIcons
import app.komodje.ui.components.pressScale
import app.komodje.ui.components.softShadow
import app.komodje.ui.components.rememberTick
import app.komodje.ui.theme.LeafShape
import app.komodje.ui.theme.LogoShape
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.Onest
import app.komodje.ui.theme.badgeBrush

private const val AUTHOR_URL = "https://t.me/Nasral_v_Multivarky"
private const val AUTHOR_HANDLE = "@Nasral_v_Multivarky"
/** Страница релизов на GitHub: там лежит свежий APK. */
private const val RELEASES_URL = "https://github.com/FortesQ0/My-Kaomoji/releases/latest"
internal const val SIGNATURE_KAOMOJI = "૮ ˶ᵔ ᵕ ᵔ˶ ა ♡"

/**
 * Экран настроек. Шапка с кнопкой «назад» общая и живёт в MainActivity.
 * Подпись внизу стоит по центру свободного места под карточками: если места мало,
 * она просто идёт следом, и экран прокручивается.
 */
@Composable
fun SettingsScreen(
    themeMode: ThemeMode,
    onThemeMode: (ThemeMode) -> Unit,
    accent: AccentTheme,
    onAccent: (AccentTheme) -> Unit,
    autoReturn: Boolean,
    onAutoReturn: (Boolean) -> Unit,
    haptics: Boolean,
    onHaptics: (Boolean) -> Unit,
    cardScale: Int,
    onCardScale: (Int) -> Unit,
    keyboardHelpSeen: Boolean,
    onKeyboardHelpSeen: () -> Unit,
    onSetLanguage: (String) -> Unit,
) {
    val p = LocalPalette.current
    val uri = LocalUriHandler.current
    val density = LocalDensity.current
    val currentTag = supportedLanguageFor(LocalConfiguration.current.locales[0].language).tag
    val finishScope = rememberCoroutineScope()
    val finishCtx = LocalContext.current
    val finishStore = remember { (finishCtx.applicationContext as MyKaomojiApp).container.settings }
    var helpOpen by rememberSaveable { mutableStateOf(false) }
    var bubbleHelpOpen by rememberSaveable { mutableStateOf(false) }
    var aboutOpen by rememberSaveable { mutableStateOf(false) }
    var versionOpen by rememberSaveable { mutableStateOf(false) }
    var faqOpen by rememberSaveable { mutableStateOf(false) }
    var donateOpen by rememberSaveable { mutableStateOf(false) }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        if (helpOpen) KeyboardHelpDialog(onClose = { helpOpen = false })
        if (bubbleHelpOpen) BubbleHelpDialog(
            onClose = { bubbleHelpOpen = false },
            onFinish = {
                // «Готово»: окно уже плавно погасло; закрываем его и включаем тумблер «Плавающее облачко» сами.
                bubbleHelpOpen = false
                finishScope.launch {
                    delay(180)
                    finishStore.setBubbleEnabled(true)
                }
            },
        )
        if (aboutOpen) AboutDialog(onClose = { aboutOpen = false })
        if (versionOpen) VersionDialog(onClose = { versionOpen = false })
        if (faqOpen) FaqDialog(onClose = { faqOpen = false })
        if (donateOpen) DonateSheet(onClose = { donateOpen = false })
        var cardsPx by remember { mutableIntStateOf(0) }
        var footerPx by remember { mutableIntStateOf(0) }
        // Зазоры считаются в фазе раскладки, а не в композиции: пока раскрывается список языков, размер карточек
        // меняется каждый кадр, и иначе перерисовывался бы весь экран настроек (отсюда были низкие кадры).
        val viewportPx = with(density) { maxHeight.toPx() }
        val minGapPx = with(density) { 24.dp.toPx() }
        val gapModifier = Modifier.layout { _, constraints ->
            val free = viewportPx - cardsPx - footerPx - minGapPx
            val gapPx = (free / 2f).coerceAtLeast(minGapPx).roundToInt()
            layout(constraints.minWidth, gapPx) {}
        }

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(start = 14.dp, end = 14.dp, top = 14.dp, bottom = 10.dp),
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .onSizeChanged { cardsPx = it.height },
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                // Язык: слева название, справа плашка с текущим языком; по тапу раскрывается список
                SettingsCard(animatesSize = true) {
                    var languagesOpen by rememberSaveable { mutableStateOf(false) }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CardTitle(stringResource(R.string.settings_language), Modifier.weight(1f), icon = KaomojiIcons.SectionGlobe)
                        LanguageSelector(
                            lang = supportedLanguageFor(currentTag.substringBefore('-')),
                            open = languagesOpen,
                            onClick = { languagesOpen = !languagesOpen },
                        )
                    }
                    AnimatedVisibility(
                        visible = languagesOpen,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut(),
                    ) {
                        Column {
                            Spacer(Modifier.height(12.dp))
                            LanguageGrid(
                                selectedTag = currentTag,
                                onSelect = {
                                    languagesOpen = false
                                    onSetLanguage(it)
                                },
                            )
                        }
                    }
                }

                // Цвет: восемь плиток-листьев с градиентом, два ряда по четыре
                SettingsCard {
                    CardTitle(stringResource(R.string.settings_accent), icon = KaomojiIcons.SectionPalette)
                    Spacer(Modifier.height(14.dp))
                    AccentPicker(selected = accent, onSelect = onAccent)
                }

                // Режим: светлая, тёмная, системная
                val modes = listOf(ThemeMode.LIGHT, ThemeMode.DARK, ThemeMode.SYSTEM)
                SettingsCard {
                    CardTitle(stringResource(R.string.settings_theme), icon = KaomojiIcons.SectionTheme)
                    Spacer(Modifier.height(12.dp))
                    Segmented(
                        options = listOf(
                            stringResource(R.string.theme_light),
                            stringResource(R.string.theme_dark),
                            stringResource(R.string.theme_system),
                        ),
                        selected = modes.indexOf(themeMode),
                        onSelect = { onThemeMode(modes[it]) },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }

                // Масштаб карточек
                SettingsCard {
                    ScaleCard(percent = cardScale, onCommit = onCardScale)
                }

                // Вибрация при нажатии: лёгкий отклик на карточках, вкладках и папках
                SettingsCard(onClick = { onHaptics(!haptics) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CardTitle(stringResource(R.string.settings_haptics), Modifier.weight(1f), icon = KaomojiIcons.SectionVibrate)
                        Spacer(Modifier.width(14.dp))
                        MyKaomojiSwitch(checked = haptics)
                    }
                }

                // Каомодзи дня: утреннее уведомление, отдельная настройка
                val appCtx = LocalContext.current
                val dailyScope = rememberCoroutineScope()
                val dailyPresets = remember { listOf(8, 9, 12, 18, 21).map { it * 60 } }
                var timeDialog by remember { mutableStateOf(false) }
                var dailyOn by remember { mutableStateOf(false) }
                var dailyHour by remember { mutableIntStateOf(DailyKaomoji.DEFAULT_HOUR * 60) }
                LaunchedEffect(Unit) {
                    dailyOn = DailyKaomoji.isEnabled(appCtx)
                    dailyHour = DailyKaomoji.minuteOfDay(appCtx)
                }
                val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
                    if (granted) {
                        dailyOn = true
                        dailyScope.launch { DailyKaomoji.configure(appCtx, true, dailyHour) }
                    }
                }
                SettingsCard(
                    animatesSize = true,
                    onClick = {
                        if (dailyOn) {
                            dailyOn = false
                            dailyScope.launch { DailyKaomoji.configure(appCtx, false, dailyHour) }
                        } else if (Build.VERSION.SDK_INT >= 33 &&
                            ContextCompat.checkSelfPermission(appCtx, Manifest.permission.POST_NOTIFICATIONS) !=
                            PackageManager.PERMISSION_GRANTED
                        ) {
                            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            dailyOn = true
                            dailyScope.launch { DailyKaomoji.configure(appCtx, true, dailyHour) }
                        }
                    },
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            CardTitle(stringResource(R.string.daily_title), icon = KaomojiIcons.SectionBell)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                stringResource(R.string.daily_hint),
                                color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Medium,
                                fontSize = 13.sp, lineHeight = 18.sp,
                            )
                        }
                        Spacer(Modifier.width(14.dp))
                        MyKaomojiSwitch(checked = dailyOn)
                    }
                    AnimatedVisibility(
                        visible = dailyOn,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut(),
                    ) {
                        Column {
                            Spacer(Modifier.height(12.dp))
                            Segmented(
                                options = dailyPresets.map { "${it / 60}:00" },
                                // Своё время не совпадает ни с одним пресетом: указатель гаснет.
                                selected = dailyPresets.indexOf(dailyHour),
                                onSelect = {
                                    dailyHour = dailyPresets[it]
                                    dailyScope.launch { DailyKaomoji.configure(appCtx, true, dailyHour) }
                                },
                                modifier = Modifier.fillMaxWidth(),
                            )
                            Spacer(Modifier.height(8.dp))
                            CustomTimePill(
                                label = stringResource(R.string.daily_custom),
                                time = "%d:%02d".format(dailyHour / 60, dailyHour % 60),
                                active = dailyHour !in dailyPresets,
                                onClick = { timeDialog = true },
                            )
                        }
                    }
                }

                if (timeDialog) {
                    TimeDialog(
                        initialMinutes = dailyHour,
                        onDone = { minutes ->
                            timeDialog = false
                            dailyHour = minutes
                            dailyScope.launch { DailyKaomoji.configure(appCtx, true, dailyHour) }
                        },
                        onClose = { timeDialog = false },
                    )
                }

                // Резервная копия: файл со всем содержимым приложения (плюс автокопия Google делается сама)
                val backupScope = rememberCoroutineScope()
                val savedText = stringResource(R.string.backup_saved)
                val restoredText = stringResource(R.string.backup_restored)
                val failedText = stringResource(R.string.backup_failed)
                val saveLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.CreateDocument("application/json"),
                ) { uri ->
                    if (uri != null) backupScope.launch {
                        val ok = runCatching {
                            val text = Backup.exportAll(appCtx)
                            appCtx.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) } != null
                        }.getOrDefault(false)
                        Toast.makeText(appCtx, if (ok) savedText else failedText, Toast.LENGTH_SHORT).show()
                    }
                }
                val restoreLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.OpenDocument(),
                ) { uri ->
                    if (uri != null) backupScope.launch {
                        val ok = runCatching {
                            val text = appCtx.contentResolver.openInputStream(uri)?.use { Backup.readLimited(it) }
                            text != null && Backup.importAll(appCtx, text)
                        }.getOrDefault(false)
                        Toast.makeText(appCtx, if (ok) restoredText else failedText, Toast.LENGTH_SHORT).show()
                    }
                }
                // Клавиатура: вернуться на прошлую клавиатуру после вставки
                val kbOk by rememberResumeState { isKeyboardEnabled(finishCtx) }
                val kbFx = rememberDenyFx()
                val kbScope = rememberCoroutineScope()
                // Переключатель «включён» только при включённой в системе клавиатуре, иначе он не включается (см. DenyFx).
                val kbShown = autoReturn && kbOk
                SettingsCard(
                    animatesSize = true,
                    onClick = {
                        when {
                            kbShown -> onAutoReturn(false)
                            kbOk -> onAutoReturn(true)
                            else -> kbScope.launch { kbFx.play() }
                        }
                    },
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CardTitle(stringResource(R.string.settings_keyboard), icon = KaomojiIcons.SectionKeyboard)
                                Spacer(Modifier.width(10.dp))
                                KeyboardHelpButton(
                                    showDot = !keyboardHelpSeen,
                                    onClick = {
                                        helpOpen = true
                                        onKeyboardHelpSeen()
                                    },
                                )
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(
                                stringResource(R.string.settings_auto_return),
                                color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 14.sp,
                            )
                            AnimatedVisibility(kbFx.message) {
                                Text(
                                    stringResource(R.string.keyboard_need_perms),
                                    modifier = Modifier.padding(top = 6.dp),
                                    color = p.heart, fontFamily = Onest, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                                )
                            }
                        }
                        Spacer(Modifier.width(14.dp))
                        MyKaomojiSwitch(
                            checked = kbShown || kbFx.denied,
                            modifier = Modifier.graphicsLayer { translationX = kbFx.shake.value.dp.toPx() },
                        )
                    }
                }

                // Плавающее облачко: каомодзи поверх любого приложения. По умолчанию выключено.
                BubbleSettingsCard(onHelp = { bubbleHelpOpen = true })

                // Резервная копия: сразу после облачка; «Автор» и «Поддержать» ниже, в самом конце.
                SettingsCard {
                    CardTitle(stringResource(R.string.backup_title), icon = KaomojiIcons.SectionCloudUp)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        stringResource(R.string.backup_hint),
                        color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Medium,
                        fontSize = 13.sp, lineHeight = 18.sp,
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        BackupButton(
                            stringResource(R.string.backup_save),
                            Modifier.weight(1f),
                        ) { saveLauncher.launch("my-kaomoji-backup.json") }
                        BackupButton(
                            stringResource(R.string.backup_restore),
                            Modifier.weight(1f),
                        ) { restoreLauncher.launch(arrayOf("*/*")) }
                    }
                }

                // Автор: ссылка на Telegram
                SettingsCard(onClick = { runCatching { uri.openUri(AUTHOR_URL) } }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                stringResource(R.string.settings_author),
                                color = p.muted, fontFamily = Onest, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                AUTHOR_HANDLE,
                                color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 18.sp,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                        }
                        LeafButton(onClick = { runCatching { uri.openUri(AUTHOR_URL) } }) {
                            Icon(KaomojiIcons.ArrowOut, null, tint = p.onBadge, modifier = Modifier.size(22.dp))
                        }
                    }
                }

                // Поддержать: нижняя панель со способами (пока оформление, ссылки подключим позже)
                SettingsCard(onClick = { donateOpen = true }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                stringResource(R.string.settings_donate),
                                color = p.muted, fontFamily = Onest, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                stringResource(R.string.donate_title),
                                color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 18.sp,
                                maxLines = 2, overflow = TextOverflow.Ellipsis,
                            )
                        }
                        Spacer(Modifier.width(10.dp))
                        LeafButton(onClick = { donateOpen = true }) {
                            Icon(KaomojiIcons.Coffee, null, tint = p.onBadge, modifier = Modifier.size(22.dp))
                        }
                    }
                }
            }

            Spacer(gapModifier)
            Box(
                Modifier
                    .fillMaxWidth()
                    .onSizeChanged { footerPx = it.height },
                contentAlignment = Alignment.Center,
            ) {
                Footer(
                    onAbout = { aboutOpen = true },
                    onVersion = { versionOpen = true },
                    onFaq = { faqOpen = true },
                )
            }
            Spacer(gapModifier)
        }
    }
}

/** Плитки языков по два в ряд. Выбранная заливается тёмным листом с градиентом. */
@Composable
private fun LanguageGrid(selectedTag: String, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        AppLanguages.chunked(2).forEach { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                pair.forEach { lang ->
                    LanguageChip(
                        lang = lang,
                        selected = lang.tag == selectedTag,
                        onClick = { onSelect(lang.tag) },
                        modifier = Modifier.weight(1f),
                    )
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun LanguageChip(lang: AppLanguage, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val fill = remember(p) { p.badgeBrush() }
    val sel = animateFloatAsState(
        targetValue = if (selected) 1f else 0f,
        animationSpec = tween(240),
        label = "langSel",
    )
    val tick = rememberTick()
    val source = remember { MutableInteractionSource() }
    Box(
        modifier
            .height(44.dp)
            .pressScale(source)
            .clip(ChipShape)
            .background(p.ink.copy(alpha = 0.08f))
            .drawBehind { drawRect(fill, alpha = sel.value) }
            .clickable(interactionSource = source, indication = null) {
                tick()
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = lang.native,
            color = lerp(p.ink, p.onBadge, sel.value),
            fontFamily = Onest,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            maxLines = 1,
        )
    }
}

/** Плашка-селектор языка: текущий язык и стрелка, которая переворачивается при раскрытии. */
@Composable
private fun LanguageSelector(lang: AppLanguage, open: Boolean, onClick: () -> Unit) {
    val p = LocalPalette.current
    val fill = remember(p) { p.badgeBrush() }
    val turn = animateFloatAsState(
        targetValue = if (open) 180f else 0f,
        animationSpec = tween(240),
        label = "langChevron",
    )
    val tick = rememberTick()
    val source = remember { MutableInteractionSource() }
    Row(
        Modifier
            .height(44.dp)
            .pressScale(source)
            .clip(ChipShape)
            .background(fill)
            .clickable(interactionSource = source, indication = null) {
                tick()
                onClick()
            }
            .padding(start = 18.dp, end = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = lang.native,
            color = p.onBadge,
            fontFamily = Onest,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            maxLines = 1,
        )
        Spacer(Modifier.width(6.dp))
        Icon(
            imageVector = KaomojiIcons.ChevronDown,
            contentDescription = null,
            tint = p.onBadge,
            modifier = Modifier
                .size(22.dp)
                .graphicsLayer { rotationZ = turn.value },
        )
    }
}

/** Состояние, которое пересчитывается каждый раз, когда человек возвращается в приложение (например, из системных настроек). */
@Composable
private fun rememberResumeState(compute: () -> Boolean): State<Boolean> {
    val owner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    val current by rememberUpdatedState(compute)
    val state = remember { mutableStateOf(compute()) }
    DisposableEffect(owner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) state.value = current()
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }
    return state
}

/**
 * Отказ включить модуль без системных разрешений: тумблер плавно включается, дрожит (с виброоткликом) и плавно
 * возвращается назад, а под названием на несколько секунд появляется подсказка про «?».
 */
@Stable
private class DenyFx(private val buzz: () -> Unit) {
    var denied by mutableStateOf(false)
        private set
    var message by mutableStateOf(false)
        private set
    val shake = Animatable(0f)
    private var busy = false

    suspend fun play() {
        if (busy) return
        busy = true
        denied = true
        // Рычажок плавно доезжает до «включено», слегка покачивается и так же плавно возвращается.
        delay(320)
        buzz()
        val soft = androidx.compose.animation.core.FastOutSlowInEasing
        repeat(2) {
            shake.animateTo(4f, tween(120, easing = soft))
            shake.animateTo(-4f, tween(120, easing = soft))
        }
        shake.animateTo(0f, tween(140, easing = soft))
        delay(120)
        denied = false
        message = true
        busy = false
        delay(4500)
        message = false
    }
}

@Composable
private fun rememberDenyFx(): DenyFx {
    val buzz = rememberBuzz()
    return remember(buzz) { DenyFx(buzz) }
}

/** Переключатель в стиле приложения. Сам не кликабелен: нажатие ловит вся карточка. */
@Composable
private fun MyKaomojiSwitch(checked: Boolean, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val fill = remember(p) { p.badgeBrush() }
    val t = animateFloatAsState(
        targetValue = if (checked) 1f else 0f,
        animationSpec = tween(300, easing = androidx.compose.animation.core.FastOutSlowInEasing),
        label = "switchState",
    )
    Box(
        modifier
            .size(width = 56.dp, height = 32.dp)
            .clip(CircleShape)
            .background(p.ink.copy(alpha = 0.08f))
            .drawBehind { drawRect(fill, alpha = t.value) },
    ) {
        Box(
            Modifier
                .offset(x = 4.dp + 24.dp * t.value, y = 4.dp)
                .size(24.dp)
                .clip(CircleShape)
                .background(lerp(p.muted, p.onBadge, t.value)),
        )
    }
}

private val ChipShape = RoundedCornerShape(topStart = 18.dp, topEnd = 8.dp, bottomEnd = 18.dp, bottomStart = 8.dp)

@Composable
private fun SettingsCard(
    onClick: (() -> Unit)? = null,
    /**
     * Карточка раскрывается и меняет высоту каждый кадр (список языков, время). Тень-картинка под точный размер
     * на каждом кадре строилась бы заново (bitmap + размытие на процессоре): отсюда были низкие кадры.
     * Для таких карточек берём системную тень, ей размер не мешает.
     */
    animatesSize: Boolean = false,
    content: @Composable () -> Unit,
) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val source = remember { MutableInteractionSource() }
    val base = Modifier
        .fillMaxWidth()
        .pressScale(source, pressedScale = 0.975f)
        .softShadow(LeafShape, drawn = !animatesSize)
        .clip(LeafShape)
        .background(p.card)
    Column(
        (if (onClick != null) {
            base.clickable(interactionSource = source, indication = null) {
                tick()
                onClick()
            }
        } else {
            base
        })
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) { content() }
}

@Composable
private fun CardTitle(text: String, modifier: Modifier = Modifier, icon: ImageVector? = null) {
    val p = LocalPalette.current
    if (icon == null) {
        Text(
            text, modifier = modifier,
            color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 18.sp,
        )
    } else {
        // Залитая иконка в цвете акцента слева от заголовка.
        Row(modifier, verticalAlignment = Alignment.CenterVertically) {
            SectionIcon(icon)
            Spacer(Modifier.width(10.dp))
            Text(
                text,
                color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 18.sp,
            )
        }
    }
}

/**
 * Сегменты-«таблетка». Тёмный лист-указатель плавно переезжает на пружине к выбранному
 * сегменту, а цвет текста перетекает вслед за ним. Ширина сегментов одинаковая.
 */
@Composable
private fun Segmented(
    options: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val p = LocalPalette.current
    val fill = remember(p) { p.badgeBrush() }
    BoxWithConstraints(
        modifier
            .clip(CircleShape)
            .background(p.ink.copy(alpha = 0.08f))
    ) {
        val pad = 4.dp
        val segW = (maxWidth - pad * 2) / options.size
        val indicatorAlpha by animateFloatAsState(if (selected >= 0) 1f else 0f, tween(180), label = "segAlpha")
        val x by animateDpAsState(
            targetValue = segW * selected.coerceAtLeast(0),
            animationSpec = spring(dampingRatio = 0.75f, stiffness = 520f),
            label = "segSlide",
        )
        Box(
            Modifier
                .padding(pad)
                .offset(x = x)
                .width(segW)
                .height(36.dp)
                .graphicsLayer { alpha = indicatorAlpha }
                .clip(CircleShape)
                .background(fill)
        )
        Row(Modifier.padding(pad)) {
            options.forEachIndexed { i, label ->
                val fg by animateColorAsState(
                    if (i == selected) p.onBadge else p.ink, tween(220), label = "segText",
                )
                val tick = rememberTick()
                val source = remember { MutableInteractionSource() }
                Box(
                    Modifier
                        .weight(1f)
                        .height(36.dp)
                        .pressScale(source, pressedScale = 0.94f)
                        .clip(CircleShape)
                        .clickable(interactionSource = source, indication = null) {
                            tick()
                            onSelect(i)
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        label, color = fg, fontFamily = Onest, fontWeight = FontWeight.Bold,
                        fontSize = 14.sp, maxLines = 1,
                    )
                }
            }
        }
    }
}

/** Плашка «Своё время»: показывает выбранное время и открывает ввод, если нужного пресета нет. */
@Composable
private fun CustomTimePill(label: String, time: String, active: Boolean, onClick: () -> Unit) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val source = remember { MutableInteractionSource() }
    val fill = remember(p) { p.badgeBrush() }
    Row(
        Modifier
            .fillMaxWidth()
            .height(44.dp)
            .pressScale(source, pressedScale = 0.97f)
            .clip(CircleShape)
            .background(p.ink.copy(alpha = 0.08f))
            .then(if (active) Modifier.background(fill) else Modifier)
            .clickable(interactionSource = source, indication = null) {
                tick()
                onClick()
            }
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            label,
            color = if (active) p.onBadge else p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold,
            fontSize = 14.sp, modifier = Modifier.weight(1f),
        )
        Text(
            time,
            color = if (active) p.onBadge else p.muted, fontFamily = Onest, fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
        )
    }
}

/** Выбор своего времени: два барабана «часы : минуты», как в системных часах. Листаешь и выбираешь, ничего не печатаешь. */
@Composable
private fun TimeDialog(initialMinutes: Int, onDone: (Int) -> Unit, onClose: () -> Unit) {
    val p = LocalPalette.current
    var hour by remember { mutableIntStateOf((initialMinutes / 60).coerceIn(0, 23)) }
    var minute by remember { mutableIntStateOf((initialMinutes % 60).coerceIn(0, 59)) }
    KaomojiDialog(onClose = onClose) {
        Text(
            stringResource(R.string.daily_time_title),
            color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 18.sp,
            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(12.dp))
        Box(Modifier.fillMaxWidth().height(TIME_ROW * 3), contentAlignment = Alignment.Center) {
            // Полоса выбранной строки лежит под барабанами.
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(TIME_ROW)
                    .clip(RoundedCornerShape(16.dp))
                    .background(p.accent.copy(alpha = 0.18f)),
            )
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TimeWheel(count = 24, start = hour, onValue = { hour = it }, modifier = Modifier.weight(1f))
                Text(
                    ":", color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 28.sp,
                    modifier = Modifier.padding(horizontal = 4.dp),
                )
                TimeWheel(count = 60, start = minute, onValue = { minute = it }, modifier = Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(16.dp))
        DialogButton(
            label = stringResource(R.string.daily_time_done),
            filled = true,
            modifier = Modifier.fillMaxWidth(),
            onClick = { onDone(hour * 60 + minute) },
        )
    }
}

private val TIME_ROW = 48.dp

/** Один барабан: список с примагничиванием, посередине выбранное число. Нажатие по числу выбирает его. */
@Composable
private fun TimeWheel(count: Int, start: Int, onValue: (Int) -> Unit, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val listState = androidx.compose.foundation.lazy.rememberLazyListState(initialFirstVisibleItemIndex = start)
    val fling = androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior(listState)
    val rowPx = with(androidx.compose.ui.platform.LocalDensity.current) { TIME_ROW.toPx() }
    val selected by remember {
        androidx.compose.runtime.derivedStateOf {
            (listState.firstVisibleItemIndex + if (listState.firstVisibleItemScrollOffset > rowPx / 2) 1 else 0)
                .coerceIn(0, count - 1)
        }
    }
    LaunchedEffect(Unit) {
        androidx.compose.runtime.snapshotFlow { selected }.collect { onValue(it) }
    }
    val scope = rememberCoroutineScope()
    androidx.compose.foundation.lazy.LazyColumn(
        state = listState,
        flingBehavior = fling,
        contentPadding = PaddingValues(vertical = TIME_ROW),
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier.height(TIME_ROW * 3),
    ) {
        items(count) { i ->
            val on = i == selected
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(TIME_ROW)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                    ) { scope.launch { listState.animateScrollToItem(i) } },
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    "%02d".format(i),
                    color = if (on) p.ink else p.muted,
                    fontFamily = Onest,
                    fontWeight = if (on) FontWeight.Bold else FontWeight.Medium,
                    fontSize = if (on) 26.sp else 20.sp,
                )
            }
        }
    }
}

/** Восемь плиток-листьев в два ряда. Выбранная увеличивается и получает обводку и галочку. */
private val AccentTileWidth = 64.dp

@Composable
private fun AccentPicker(selected: AccentTheme, onSelect: (AccentTheme) -> Unit) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        AccentTheme.values().toList().chunked(4).forEach { row ->
            // Крайние плитки касаются левой и правой невидимых линий карточки (как заголовки и переключатели).
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                row.forEach { a ->
                    Box(Modifier.width(AccentTileWidth), contentAlignment = Alignment.TopCenter) {
                        AccentTile(a, active = a == selected, onClick = { onSelect(a) })
                    }
                }
                repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun AccentTile(a: AccentTheme, active: Boolean, onClick: () -> Unit) {
    val p = LocalPalette.current
    val scale = animateFloatAsState(
        targetValue = if (active) 1f else 0.86f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 500f),
        label = "swatch",
    )
    val name = when (a) {
        AccentTheme.PEACH -> R.string.accent_peach
        AccentTheme.SAKURA -> R.string.accent_sakura
        AccentTheme.SEA -> R.string.accent_sea
        AccentTheme.BURGUNDY -> R.string.accent_burgundy
        AccentTheme.APPLE -> R.string.accent_apple
        AccentTheme.SUN -> R.string.accent_sun
        AccentTheme.LILAC -> R.string.accent_lilac
        AccentTheme.MILK -> R.string.accent_milk
    }
    val mark = if (a == AccentTheme.BURGUNDY) Color.White else Color(0xFF2B1812)
    val tick = rememberTick()
    val source = remember { MutableInteractionSource() }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        // Маски на всём столбце нет: раньше clip(LogoShape) срезал углами края подписи цвета.
        modifier = Modifier
            .fillMaxWidth()
            .pressScale(source)
            .clickable(interactionSource = source, indication = null) {
                tick()
                onClick()
            },
    ) {
        Box(
            Modifier
                .size(width = AccentTileWidth, height = 62.dp)
                .graphicsLayer { scaleX = scale.value; scaleY = scale.value }
                .clip(LogoShape)
                .background(Brush.linearGradient(listOf(Color(a.top), Color(a.bottom))))
                // Тонкая рамка у светлых плиток (молоко), чтобы не сливались с карточкой.
                .border(if (active) 3.dp else 1.dp, if (active) p.ink else p.ink.copy(alpha = 0.12f), LogoShape),
            contentAlignment = Alignment.Center,
        ) {
            if (active) Icon(KaomojiIcons.Check, null, tint = mark, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.height(6.dp))
        FitText(
            text = stringResource(name),
            color = if (active) p.ink else p.muted,
            fontFamily = Onest,
            fontWeight = FontWeight.SemiBold,
            maxSize = 12.sp,
            minSize = 9.sp,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp),
        )
    }
}

private val ScaleTicks = listOf(50, 75, 100, 125, 150)
private val PreviewTexts = listOf("(◕‿◕)", "ʕ•ᴥ•ʔ", "(╥﹏╥)", "(≧◡≦) ♡")

/** Масштаб карточек: окошко-превью, ползунок с метками и значение в процентах (тап = 100%). */
@Composable
private fun ScaleCard(percent: Int, onCommit: (Int) -> Unit) {
    val p = LocalPalette.current
    var live by remember(percent) { mutableIntStateOf(percent) }
    val tick = rememberTick()
    Row(verticalAlignment = Alignment.CenterVertically) {
        CardTitle(stringResource(R.string.settings_scale), Modifier.weight(1f), icon = KaomojiIcons.SectionScale)
        val source = remember { MutableInteractionSource() }
        Text(
            "$live%",
            color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 16.sp,
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .clickable(interactionSource = source, indication = null) {
                    if (live != 100) tick()
                    live = 100
                    onCommit(100)
                }
                .padding(horizontal = 8.dp, vertical = 4.dp),
        )
    }
    Spacer(Modifier.height(12.dp))
    ScalePreview(cardScaleFactor(live))
    Spacer(Modifier.height(6.dp))
    ScaleSlider(value = live, onChange = { live = it }, onDone = { onCommit(live) })
}

@Composable
private fun ScalePreview(scale: Float) {
    val p = LocalPalette.current
    val density = LocalDensity.current
    val scaled = remember(density, scale) { Density(density.density * scale, density.fontScale) }
    val absorb = remember { MutableInteractionSource() }
    Box(
        Modifier
            .fillMaxWidth()
            .height(180.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(p.ink.copy(alpha = 0.06f)),
    ) {
        CompositionLocalProvider(LocalDensity provides scaled) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .wrapContentHeight(align = Alignment.Top, unbounded = true)
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                // Карточек с запасом: при малом масштабе окошко целиком заполнено, пустого поля внизу нет.
                List(18) { PreviewTexts[it % PreviewTexts.size] }.forEach { text ->
                    KaomojiCard(
                        text = text,
                        favorite = false,
                        feedback = "",
                        onTap = {},
                        onHold = {},
                        onFavorite = {},
                        onCopied = {},
                    )
                }
            }
        }
        // Превью только показывает размер: касания внутри не должны ничего делать.
        Box(Modifier.fillMaxSize().clickable(interactionSource = absorb, indication = null) {})
    }
}

/**
 * Плавный ползунок 50..150% с метками на концах, четвертях и середине. Рядом с меткой (±3%)
 * значение «прилипает» к ней и даёт лёгкий отклик.
 */
@Composable
private fun ScaleSlider(value: Int, onChange: (Int) -> Unit, onDone: () -> Unit) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val onChangeNow by rememberUpdatedState(onChange)
    val onDoneNow by rememberUpdatedState(onDone)
    val tickNow by rememberUpdatedState(tick)
    var lastSnap by remember { mutableIntStateOf(-1) }

    fun valueAt(x: Float, width: Float, pad: Float): Int {
        val frac = ((x - pad) / (width - 2 * pad)).coerceIn(0f, 1f)
        val raw = (50 + frac * 100).toInt().coerceIn(50, 150)
        return ScaleTicks.firstOrNull { kotlin.math.abs(it - raw) <= 3 } ?: raw
    }

    fun push(v: Int) {
        val snapped = v in ScaleTicks
        if (snapped && v != lastSnap) tickNow()
        lastSnap = if (snapped) v else -1
        onChangeNow(v)
    }

    Canvas(
        Modifier
            .fillMaxWidth()
            .height(36.dp)
            .pointerInput(Unit) {
                val pad = 14.dp.toPx()
                detectTapGestures { o ->
                    push(valueAt(o.x, size.width.toFloat(), pad))
                    onDoneNow()
                }
            }
            .pointerInput(Unit) {
                val pad = 14.dp.toPx()
                detectHorizontalDragGestures(
                    onDragStart = { o -> push(valueAt(o.x, size.width.toFloat(), pad)) },
                    onDragEnd = { onDoneNow() },
                    onDragCancel = { onDoneNow() },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        push(valueAt(change.position.x, size.width.toFloat(), pad))
                    },
                )
            },
    ) {
        val pad = 14.dp.toPx()
        val w = size.width - 2 * pad
        val cy = size.height / 2f
        val th = 8.dp.toPx()
        fun xOf(v: Int) = pad + w * (v - 50) / 100f
        val x = xOf(value)
        val r = th / 2f
        drawRoundRect(
            color = p.ink.copy(alpha = 0.12f),
            topLeft = Offset(pad, cy - r),
            size = androidx.compose.ui.geometry.Size(w, th),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(r, r),
        )
        drawRoundRect(
            color = p.accent,
            topLeft = Offset(pad, cy - r),
            size = androidx.compose.ui.geometry.Size((x - pad).coerceAtLeast(th), th),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(r, r),
        )
        // Крайние точки сдвинуты внутрь линии, чтобы не выступать за её закруглённые концы.
        val dotR = 2.5.dp.toPx()
        val inset = r
        ScaleTicks.forEach { v ->
            val tx = xOf(v).coerceIn(pad + inset, pad + w - inset)
            drawCircle(
                color = if (v <= value) p.onAccent.copy(alpha = 0.9f) else p.muted.copy(alpha = 0.55f),
                radius = dotR,
                center = Offset(tx, cy),
            )
        }
        drawCircle(color = p.card, radius = 13.dp.toPx(), center = Offset(x, cy))
        drawCircle(color = p.accentDeep, radius = 10.dp.toPx(), center = Offset(x, cy))
    }
}

/** Подпись: облачко с фразой, под ним смайлик «говорит», ниже бренд со звездой. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun Footer(onAbout: () -> Unit, onVersion: () -> Unit, onFaq: () -> Unit) {
    val p = LocalPalette.current
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        SpeechBubble(stringResource(R.string.signature))
        Spacer(Modifier.height(4.dp))
        Text(SIGNATURE_KAOMOJI, color = p.ink, fontSize = 34.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        // Единый блок: строка бренда без растяжки (слова стоят рядом) и три плашки. Ширину задаёт самое
        // широкое из двух, второе подстраивается; размеры подобраны близкими, чтобы читалось одним блоком.
        Column(Modifier.width(IntrinsicSize.Max), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(R.string.app_name),
                    color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 17.sp,
                    maxLines = 1, softWrap = false,
                )
                Icon(KaomojiIcons.Sparkle, null, tint = p.heart, modifier = Modifier.padding(horizontal = 7.dp).size(17.dp))
                Text(
                    stringResource(R.string.tagline),
                    color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 17.sp,
                    maxLines = 1, softWrap = false,
                )
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FooterPill(stringResource(R.string.about_pill), onAbout, Modifier.weight(1f))
                FooterPill(stringResource(R.string.pill_version), onVersion, Modifier.weight(1f))
                FooterPill(stringResource(R.string.faq_title), onFaq, Modifier.weight(1f))
            }
        }
    }
}

/** Маленькая округлая плашка внизу настроек («О проекте», «Версия», «FAQ»): тихая, не бросается в глаза. */
@Composable
private fun FooterPill(label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val source = remember { MutableInteractionSource() }
    Row(
        modifier
            .pressScale(source)
            .clip(CircleShape)
            .background(p.ink.copy(alpha = 0.06f))
            .clickable(interactionSource = source, indication = null) {
                tick()
                onClick()
            }
            .padding(horizontal = 6.dp, vertical = 9.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(KaomojiIcons.Sparkle, null, tint = p.muted.copy(alpha = 0.7f), modifier = Modifier.size(12.dp))
        Spacer(Modifier.width(5.dp))
        Text(
            label,
            color = p.muted.copy(alpha = 0.85f), fontFamily = Onest, fontWeight = FontWeight.SemiBold,
            fontSize = 13.sp, maxLines = 1, softWrap = false,
        )
    }
}

/** Мини-окно «О проекте»: пара слов о приложении и источники библиотек. Больше нигде не упоминаются. */
@Composable
private fun AboutDialog(onClose: () -> Unit) {
    val p = LocalPalette.current
    val faint = p.muted.copy(alpha = 0.85f)
    KaomojiDialog(onClose = onClose) {
        Text(
            stringResource(R.string.about_pill),
            color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 18.sp,
        )
        Spacer(Modifier.height(10.dp))
        Text(
            stringResource(R.string.about_text),
            color = faint, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 13.sp,
            lineHeight = 19.sp,
        )
        Spacer(Modifier.height(14.dp))
        Text(
            stringResource(R.string.about_sources_title).uppercase(),
            color = faint, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 11.sp,
            letterSpacing = 1.2.sp,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            stringResource(R.string.about_source_kaomojiya),
            color = faint, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 13.sp,
            lineHeight = 19.sp,
        )
        Spacer(Modifier.height(14.dp))
        Text(
            stringResource(R.string.about_rights),
            color = faint, fontFamily = Onest, fontWeight = FontWeight.SemiBold, fontSize = 12.sp,
        )
        Spacer(Modifier.height(18.dp))
        DialogButton(
            label = stringResource(R.string.folder_help_ok),
            filled = true,
            modifier = Modifier.fillMaxWidth(),
            onClick = onClose,
        )
    }
}

/** Облачко в манга-стиле: тёмная обводка и хвостик вниз, к смайлику. Выскакивает пружиной. */
@Composable
private fun SpeechBubble(text: String) {
    val p = LocalPalette.current
    val pop = remember { Animatable(0f) }
    LaunchedEffect(Unit) { pop.animateTo(1f, spring(dampingRatio = 0.5f, stiffness = 280f)) }
    val tailH = 12.dp

    Box(
        Modifier
            .graphicsLayer {
                val s = 0.8f + 0.2f * pop.value
                scaleX = s
                scaleY = s
                alpha = pop.value.coerceIn(0f, 1f)
                transformOrigin = TransformOrigin(0.5f, 1f)
            }
            .drawBehind {
                val tail = tailH.toPx()
                val r = 20.dp.toPx()
                val tw = 14.dp.toPx()
                val w = size.width
                val h = size.height - tail
                val cx = w / 2f
                val path = Path().apply {
                    moveTo(r, 0f)
                    lineTo(w - r, 0f)
                    arcTo(Rect(w - 2 * r, 0f, w, 2 * r), -90f, 90f, false)
                    lineTo(w, h - r)
                    arcTo(Rect(w - 2 * r, h - 2 * r, w, h), 0f, 90f, false)
                    lineTo(cx + tw / 2f, h)
                    lineTo(cx, h + tail)
                    lineTo(cx - tw / 2f, h)
                    lineTo(r, h)
                    arcTo(Rect(0f, h - 2 * r, 2 * r, h), 90f, 90f, false)
                    lineTo(0f, r)
                    arcTo(Rect(0f, 0f, 2 * r, 2 * r), 180f, 90f, false)
                    close()
                }
                drawPath(path, p.card)
                drawPath(path, p.ink, style = Stroke(width = 2.dp.toPx(), join = StrokeJoin.Round))
            }
            .padding(start = 24.dp, end = 24.dp, top = 12.dp, bottom = 12.dp + tailH)
    ) {
        Text(
            text,
            color = p.ink, fontFamily = Onest, fontWeight = FontWeight.SemiBold, fontSize = 16.sp,
            textAlign = TextAlign.Center,
        )
    }
}

/**
 * Окно «Версия»: логотип, номер версии, «Скачать новую версию» (страница релизов на GitHub),
 * «Отправить отчёт» и «Понятно».
 */
@Composable
private fun VersionDialog(onClose: () -> Unit) {
    val p = LocalPalette.current
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val versionName = remember {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull().orEmpty()
    }
    val faint = p.muted.copy(alpha = 0.9f)
    val links = LocalUriHandler.current
    val reportScope = rememberCoroutineScope()
    KaomojiDialog(onClose = onClose) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            app.komodje.ui.components.LogoMark(size = 52.dp)
            Spacer(Modifier.width(14.dp))
            Column {
                Text(
                    stringResource(R.string.app_name),
                    color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 20.sp,
                )
                Text(
                    stringResource(R.string.version_name, versionName),
                    color = faint, fontFamily = Onest, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                )
            }
        }
        Spacer(Modifier.height(18.dp))
        DialogButton(
            label = stringResource(R.string.version_download),
            filled = true,
            modifier = Modifier.fillMaxWidth(),
            onClick = { runCatching { links.openUri(RELEASES_URL) } },
        )
        Spacer(Modifier.height(10.dp))
        DialogButton(
            label = stringResource(R.string.report_pill),
            filled = false,
            secondary = true,
            modifier = Modifier.fillMaxWidth(),
            onClick = { reportScope.launch { CrashReport.share(ctx) } },
        )
        Spacer(Modifier.height(10.dp))
        DialogButton(
            label = stringResource(R.string.folder_help_ok),
            filled = false,
            modifier = Modifier.fillMaxWidth(),
            onClick = onClose,
        )
    }
}

private val FAQ = listOf(
    R.string.faq_q1 to R.string.faq_a1,
    R.string.faq_q2 to R.string.faq_a2,
    R.string.faq_q3 to R.string.faq_a3,
    R.string.faq_q4 to R.string.faq_a4,
    R.string.faq_q5 to R.string.faq_a5,
    R.string.faq_q6 to R.string.faq_a6,
    R.string.faq_q7 to R.string.faq_a7,
)

/** FAQ: только реальные вопросы людей. Вопросы раскрываются по одному, остальные сворачиваются. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FaqDialog(onClose: () -> Unit) {
    val p = LocalPalette.current
    val faqScope = rememberCoroutineScope()
    var open by remember { mutableIntStateOf(-1) }
    val tick = rememberTick()
    KaomojiDialog(onClose = onClose) {
        Text(
            stringResource(R.string.faq_title),
            color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 20.sp,
        )
        Spacer(Modifier.height(12.dp))
        Column(
            Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            FAQ.forEachIndexed { i, (q, a) ->
                val isOpen = open == i
                val turn by animateFloatAsState(if (isOpen) 180f else 0f, label = "faqTurn")
                val requester = remember { BringIntoViewRequester() }
                Column(
                    Modifier
                        .fillMaxWidth()
                        .bringIntoViewRequester(requester)
                        // Пока ответ раскрывается, список прокручивается следом: текст всегда виден целиком.
                        .onSizeChanged { if (isOpen) faqScope.launch { requester.bringIntoView() } }
                        .clip(RoundedCornerShape(18.dp))
                        .background(p.ink.copy(alpha = 0.05f))
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                            tick()
                            open = if (isOpen) -1 else i
                        }
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            stringResource(q),
                            color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                            lineHeight = 19.sp, modifier = Modifier.weight(1f),
                        )
                        Spacer(Modifier.width(8.dp))
                        Icon(
                            KaomojiIcons.ChevronDown, null, tint = p.muted,
                            modifier = Modifier.size(18.dp).graphicsLayer { rotationZ = turn },
                        )
                    }
                    AnimatedVisibility(isOpen, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
                        Text(
                            stringResource(a),
                            color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 13.sp,
                            lineHeight = 19.sp, modifier = Modifier.padding(top = 8.dp),
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        DialogButton(
            label = stringResource(R.string.folder_help_ok),
            filled = true,
            modifier = Modifier.fillMaxWidth(),
            onClick = onClose,
        )
    }
}

/** Кнопка в карточке резервной копии: акцентная плашка с контрастной надписью. */
@Composable
private fun BackupButton(label: String, modifier: Modifier, onClick: () -> Unit) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val source = remember { MutableInteractionSource() }
    Box(
        modifier
            .pressScale(source)
            .clip(RoundedCornerShape(16.dp))
            .background(p.accent)
            .clickable(interactionSource = source, indication = null) {
                tick()
                onClick()
            }
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            color = p.onAccent, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1,
        )
    }
}

/**
 * Блок «Плавающее облачко»: переключатель (по умолчанию выключен) и «?» с инструкцией.
 * Само облачко показывает служба специальных возможностей, её человек включает в системных настройках.
 */
@Composable
private fun BubbleSettingsCard(onHelp: () -> Unit) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    val store = remember { (ctx.applicationContext as MyKaomojiApp).container.settings }
    val on by store.bubbleEnabled.collectAsState()
    val scope = rememberCoroutineScope()
    val serviceOn by rememberResumeState { isBubbleServiceEnabled(ctx) }
    val overlayOk by rememberResumeState { canDrawOverOthers(ctx) }
    val fx = rememberDenyFx()
    // Нужны два ключевых разрешения: служба доступности и «Поверх других окон». Без них тумблер не включается.
    val permsOk = serviceOn && overlayOk
    val shown = on && permsOk
    SettingsCard(
        animatesSize = true,
        onClick = {
            scope.launch {
                when {
                    shown -> store.setBubbleEnabled(false)
                    permsOk -> store.setBubbleEnabled(true)
                    else -> fx.play()
                }
            }
        },
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CardTitle(stringResource(R.string.bubble_title), icon = KaomojiIcons.SectionCloud)
                    Spacer(Modifier.width(10.dp))
                    val helpSeen by store.bubbleHelpSeen.collectAsState()
                    BubbleHelpButton(showDot = !helpSeen) {
                        scope.launch { store.markBubbleHelpSeen() }
                        onHelp()
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    stringResource(if (on && !serviceOn) R.string.bubble_needs else R.string.bubble_hint),
                    color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 14.sp,
                )
                AnimatedVisibility(fx.message) {
                    Text(
                        stringResource(R.string.bubble_need_perms),
                        modifier = Modifier.padding(top = 6.dp),
                        color = p.heart, fontFamily = Onest, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                    )
                }
            }
            Spacer(Modifier.width(14.dp))
            MyKaomojiSwitch(
                checked = shown || fx.denied,
                modifier = Modifier.graphicsLayer { translationX = fx.shake.value.dp.toPx() },
            )
        }
    }
}
