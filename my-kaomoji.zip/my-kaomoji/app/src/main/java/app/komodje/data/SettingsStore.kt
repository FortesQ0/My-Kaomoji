// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.data

import android.content.Context
import app.komodje.ui.components.CardScaleBase
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import app.komodje.domain.AccentTheme
import app.komodje.domain.KaomojiFilter
import app.komodje.domain.Mood
import app.komodje.domain.ThemeMode
import app.komodje.widget.refreshWidgets
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.runBlocking

/**
 * Настройки оформления. Хранятся в том же DataStore, что и любимые.
 *
 * Значения отдаются как StateFlow с уже прочитанным стартовым значением. Поэтому после
 * пересоздания Activity (например, при смене языка) экран сразу рисуется с настоящей темой,
 * а не «прыгает» со значения по умолчанию.
 */
class SettingsStore(private val context: Context) {

    private val themeKey = stringPreferencesKey("theme_mode")
    private val accentKey = stringPreferencesKey("accent_theme")
    private val languageKey = booleanPreferencesKey("language_chosen")
    private val autoReturnKey = booleanPreferencesKey("ime_auto_return")
    private val bubbleKey = booleanPreferencesKey("floating_bubble")
    private val imeMoodKey = stringPreferencesKey("ime_mood")
    private val helpSeenKey = booleanPreferencesKey("keyboard_help_seen")
    private val bubbleHelpSeenKey = booleanPreferencesKey("bubble_help_seen")
    private val folderHelpDoneKey = booleanPreferencesKey("folder_help_done")
    private val hapticsKey = booleanPreferencesKey("haptics")
    /** Старый ключ: масштаб в «внутренних» процентах (до 0.1.8 на экране показывалось то же число). */
    private val oldScaleKey = intPreferencesKey("card_scale")
    /** Новый ключ: показанные проценты, где 100% = прежние 92% (см. CardScaleBase). */
    private val scaleKey = intPreferencesKey("card_scale_v2")
    private val homeMoodKey = stringPreferencesKey("home_mood")
    private val homeFiltersKey = stringPreferencesKey("home_filters")
    private val homeScrollKey = stringPreferencesKey("home_scroll")
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val initial: Preferences = runBlocking { context.dataStore.data.first() }

    private fun Preferences.mode(): ThemeMode =
        this[themeKey]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: ThemeMode.LIGHT

    private fun Preferences.accentTheme(): AccentTheme =
        this[accentKey]?.let { runCatching { AccentTheme.valueOf(it) }.getOrNull() } ?: AccentTheme.SAKURA

    val themeMode: StateFlow<ThemeMode> = context.dataStore.data
        .map { it.mode() }
        .stateIn(scope, SharingStarted.Eagerly, initial.mode())

    val accent: StateFlow<AccentTheme> = context.dataStore.data
        .map { it.accentTheme() }
        .stateIn(scope, SharingStarted.Eagerly, initial.accentTheme())

    /** Показан ли уже экран выбора языка при первом запуске. */
    val languageChosen: StateFlow<Boolean> = context.dataStore.data
        .map { it[languageKey] ?: false }
        .stateIn(scope, SharingStarted.Eagerly, initial[languageKey] ?: false)

    /** Плавающее облачко с каомодзи поверх других приложений. По умолчанию выключено. */
    val bubbleEnabled: StateFlow<Boolean> = context.dataStore.data
        .map { it[bubbleKey] ?: false }
        .stateIn(scope, SharingStarted.Eagerly, initial[bubbleKey] ?: false)

    /** После вставки в клавиатуре вернуться на прошлую клавиатуру. По умолчанию включено. */
    val autoReturn: StateFlow<Boolean> = context.dataStore.data
        .map { it[autoReturnKey] ?: false }
        .stateIn(scope, SharingStarted.Eagerly, initial[autoReturnKey] ?: false)

    /** Лёгкая вибрация при нажатиях. По умолчанию включена. */
    val haptics: StateFlow<Boolean> = context.dataStore.data
        .map { it[hapticsKey] ?: true }
        .stateIn(scope, SharingStarted.Eagerly, initial[hapticsKey] ?: true)

    /**
     * Масштаб карточек в показанных процентах (50..150), по умолчанию 100. Прежние 92% теперь «100%»:
     * старое значение один раз пересчитывается как old / 0.92, остальное считается от него.
     */
    private fun Preferences.shownScale(): Int {
        val v2 = this[scaleKey]
        val shown = when {
            v2 != null -> v2
            this[oldScaleKey] != null -> Math.round(this[oldScaleKey]!! / CardScaleBase)
            else -> 100
        }
        return shown.coerceIn(50, 150)
    }

    val cardScale: StateFlow<Int> = context.dataStore.data
        .map { it.shownScale() }
        .stateIn(scope, SharingStarted.Eagerly, initial.shownScale())

    suspend fun setCardScale(percent: Int) {
        context.dataStore.edit { it[scaleKey] = percent.coerceIn(50, 150) }
    }

    /** Открывали ли инструкцию по клавиатуре: пока нет, у значка «?» горит точка. */
    val keyboardHelpSeen: StateFlow<Boolean> = context.dataStore.data
        .map { it[helpSeenKey] ?: false }
        .stateIn(scope, SharingStarted.Eagerly, initial[helpSeenKey] ?: false)

    suspend fun markKeyboardHelpSeen() {
        context.dataStore.edit { it[helpSeenKey] = true }
    }

    /** Открывали ли инструкцию по облачку: пока нет, у значка «?» горит точка (как у клавиатуры). */
    val bubbleHelpSeen: StateFlow<Boolean> = context.dataStore.data
        .map { it[bubbleHelpSeenKey] ?: false }
        .stateIn(scope, SharingStarted.Eagerly, initial[bubbleHelpSeenKey] ?: false)

    suspend fun markBubbleHelpSeen() {
        context.dataStore.edit { it[bubbleHelpSeenKey] = true }
    }

    /** Подтверждена ли подсказка по папкам кнопкой «Понятно»: после этого значок «?» не показываем. */
    val folderHelpDone: StateFlow<Boolean> = context.dataStore.data
        .map { it[folderHelpDoneKey] ?: false }
        .stateIn(scope, SharingStarted.Eagerly, initial[folderHelpDoneKey] ?: false)

    suspend fun markFolderHelpDone() {
        context.dataStore.edit { it[folderHelpDoneKey] = true }
    }

    suspend fun setHaptics(on: Boolean) {
        context.dataStore.edit { it[hapticsKey] = on }
    }

    suspend fun setBubbleEnabled(on: Boolean) {
        context.dataStore.edit { it[bubbleKey] = on }
    }

    suspend fun setAutoReturn(on: Boolean) {
        context.dataStore.edit { it[autoReturnKey] = on }
    }

    /** Последняя открытая категория клавиатуры. Читается один раз при создании клавиатуры. */
    fun imeMood(): Mood {
        val prefs = runBlocking { context.dataStore.data.first() }
        return prefs[imeMoodKey]?.let { runCatching { Mood.valueOf(it) }.getOrNull() } ?: Mood.HAPPY
    }

    suspend fun setImeMood(mood: Mood) {
        context.dataStore.edit { it[imeMoodKey] = mood.name }
    }

    /** Состояние главного экрана на момент прошлого выхода: вкладка, фильтры, прокрутка по вкладкам. */
    class HomeSnapshot(val mood: Mood, val filters: Set<KaomojiFilter>, val scroll: Map<Mood, Int>)

    /** Читается один раз при создании экрана (из уже прочитанного стартового снимка, без ожидания). */
    fun homeSnapshot(): HomeSnapshot {
        val mood = initial[homeMoodKey]?.let { runCatching { Mood.valueOf(it) }.getOrNull() } ?: Mood.HAPPY
        val filters = initial[homeFiltersKey].orEmpty().split(',')
            .mapNotNull { runCatching { KaomojiFilter.valueOf(it) }.getOrNull() }
            .filter { it != KaomojiFilter.ALL }
            .toSet()
        val scroll = initial[homeScrollKey].orEmpty().split(',').mapNotNull { part ->
            val (name, index) = part.split(':').takeIf { it.size == 2 } ?: return@mapNotNull null
            val m = runCatching { Mood.valueOf(name) }.getOrNull() ?: return@mapNotNull null
            val i = index.toIntOrNull()?.takeIf { it >= 0 } ?: return@mapNotNull null
            m to i
        }.toMap()
        return HomeSnapshot(mood, filters, scroll)
    }

    suspend fun saveHome(mood: Mood, filters: Set<KaomojiFilter>, scroll: Map<Mood, Int>) {
        context.dataStore.edit {
            it[homeMoodKey] = mood.name
            it[homeFiltersKey] = filters.joinToString(",") { f -> f.name }
            it[homeScrollKey] = scroll.entries.joinToString(",") { e -> "${e.key.name}:${e.value}" }
        }
    }

    /** Свежие значения прямо из хранилища: виджет не должен ждать, пока обновится StateFlow. */
    suspend fun readThemeMode(): ThemeMode = context.dataStore.data.first().mode()

    suspend fun readAccent(): AccentTheme = context.dataStore.data.first().accentTheme()

    suspend fun markLanguageChosen() {
        context.dataStore.edit { it[languageKey] = true }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[themeKey] = mode.name }
        refreshWidgets(context)
    }

    suspend fun setAccent(accent: AccentTheme) {
        context.dataStore.edit { it[accentKey] = accent.name }
        refreshWidgets(context)
    }
}
