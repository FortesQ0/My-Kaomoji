// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.MapSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json

/**
 * Сколько раз каждый комоджи копировали или вставляли (приложение, клавиатура, виджет).
 * Нужен для «частых»: ряд над списком в клавиатуре и виджет на главном экране.
 * Хранится в том же DataStore, что и любимые: одна строка JSON «текст → число».
 */
class UsageStore(private val context: Context) {

    private val key = stringPreferencesKey("usage_counts")
    private val mapSerializer = MapSerializer(String.serializer(), Int.serializer())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private fun decode(raw: String?): Map<String, Int> =
        if (raw.isNullOrEmpty()) {
            emptyMap()
        } else {
            runCatching { Json.decodeFromString(mapSerializer, raw) }.getOrDefault(emptyMap())
        }

    val counts: Flow<Map<String, Int>> = context.dataStore.data.map { decode(it[key]) }

    // «Недавние»: последние скопированные из списков на главном экране, новые первыми.
    private val recentKey = stringPreferencesKey("recent_copies")
    private val listSerializer = ListSerializer(String.serializer())

    private fun decodeRecent(raw: String?): List<String> =
        if (raw.isNullOrEmpty()) {
            emptyList()
        } else {
            runCatching { Json.decodeFromString(listSerializer, raw) }.getOrDefault(emptyList())
        }

    val recent: Flow<List<String>> = context.dataStore.data.map { decodeRecent(it[recentKey]).take(RECENT_LIMIT) }

    /** Копирование из списка на главном экране: новый текст встаёт в начало, остаётся RECENT_LIMIT штук. */
    fun recordRecent(text: String) {
        scope.launch {
            context.dataStore.edit { prefs ->
                val current = decodeRecent(prefs[recentKey])
                // Уже в списке: место не меняем, иначе карточки прыгали бы из-под пальца.
                if (text !in current) {
                    prefs[recentKey] = Json.encodeToString(listSerializer, (listOf(text) + current).take(RECENT_LIMIT))
                }
            }
        }
    }

    suspend fun recordNow(text: String) {
        context.dataStore.edit { prefs ->
            val next = decode(prefs[key]).toMutableMap()
            next[text] = (next[text] ?: 0) + 1
            prefs[key] = Json.encodeToString(mapSerializer, next)
        }
    }

    /** Без ожидания: из интерфейса клавиатуры и приложения. Не отменяется вместе с экраном. */
    fun record(text: String) {
        scope.launch { recordNow(text) }
    }

    companion object {
        const val RECENT_LIMIT = 5
    }
}
