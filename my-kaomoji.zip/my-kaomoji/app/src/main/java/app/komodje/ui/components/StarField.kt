// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

/** Длина одного большого круга анимации, секунд. Скорости и покачивания подобраны так, чтобы в конце круга всё совпадало с началом. */
private const val LOOP_SECONDS = 120

/**
 * Единые часы звёзд на весь запуск приложения. Время не привязано к тому, сколько раз плашка «Хитов дня»
 * создавалась заново (при переключении закладок она исчезает и появляется), поэтому звёзды не откатываются
 * и не начинают заново: они идут так, будто плашка всё время была на экране.
 */
private object StarClock {
    private var seconds = 0.0
    private var last = 0L

    /**
     * Продвигает часы по кадрам, но не больше чем на 40 мс за кадр. Если экран на мгновение «задумался»
     * (например, открылась тяжёлая закладка), звёзды не перескакивают вперёд, а спокойно идут дальше.
     */
    fun tick(frameNanos: Long) {
        if (last != 0L) seconds += ((frameNanos - last) / 1_000_000_000.0).coerceIn(0.0, 0.04)
        last = frameNanos
    }

    /** Положение внутри большого круга, от 0 до 1. */
    fun phase(): Float = ((seconds % LOOP_SECONDS) / LOOP_SECONDS).toFloat()
}

/**
 * Россыпь четырёхконечных полупрозрачных звёзд по всей подложке, которая медленно «плывёт» вверх.
 * Звезда уходит за верхний край плашки (её срезает скругление) и тут же появляется снизу из-за нижнего края:
 * путь звезды равен высоте плашки плюс её размер, поэтому перескок всегда происходит за границей плашки и не виден.
 * Прозрачность постоянная, звёзды не гаснут: меняется только положение и лёгкое покачивание вправо-влево.
 * У каждой звезды своя скорость, размер и фаза, поэтому движение не выглядит единым блоком.
 * Анимация одна на всю плашку, читается только при рисовании и останавливается, когда плашка уходит с экрана.
 * Только залитые, без обводок и теней. Позиции считаются один раз на размер.
 */
@Composable
fun Modifier.starField(color: Color, maxAlpha: Float = 0.26f, seed: Int = 11): Modifier {
    // Кадровый тик нужен только для перерисовки; само положение берётся из общих часов StarClock.
    val frame = remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        while (true) withFrameNanos {
            StarClock.tick(it)
            frame.longValue = it
        }
    }
    return this.drawWithCache {
        val w = size.width
        val h = size.height
        val rnd = Random(seed)
        val dp = 1.dp.toPx()
        val area = (w / dp) * (h / dp)
        val count = (area / 3500f).toInt().coerceIn(10, 60)
        val laneCount = (w / (46f * dp)).toInt().coerceIn(1, 14)
        val laneWidth = w / laneCount

        val x0 = FloatArray(count)
        val radius = FloatArray(count)
        val alpha = FloatArray(count)
        val loopLen = FloatArray(count)
        val offset = FloatArray(count)
        val cycles = IntArray(count)
        val lane = IntArray(count)
        val swayAmp = FloatArray(count)
        val swayCycles = IntArray(count)
        val swayPhase = FloatArray(count)
        val laneCycles = IntArray(laneCount) { 3 + rnd.nextInt(2) }
        // У каждой дорожки свой сдвиг по высоте и по ширине: звёзды не выстраиваются в ряды и колонны.
        val laneShift = FloatArray(laneCount) { rnd.nextFloat() }
        val laneJitter = FloatArray(laneCount) { (rnd.nextFloat() - 0.5f) * 2f * 6f * dp }
        for (i in 0 until count) {
            val sz = rnd.nextFloat()
            // Больше мелких, чем крупных.
            val r = (7f + 14f * sz * sz) * dp
            radius[i] = r
            lane[i] = i % laneCount
            x0[i] = (lane[i] + 0.5f) * laneWidth + laneJitter[lane[i]]
            // Путь звезды за круг: высота плашки и по звезде сверху и снизу, чтобы вход и выход были за кромкой.
            loopLen[i] = h + 2f * r
            val starsInLane = (count + laneCount - 1) / laneCount
            val laneIndex = i / laneCount
            offset[i] = ((laneIndex + laneShift[lane[i]]) / starsInLane) * loopLen[i]
            // 3–4 полных прохода за круг: один проход занимает около 30–40 секунд.
            cycles[i] = laneCycles[lane[i]]
            swayAmp[i] = (3f + 4f * rnd.nextFloat()) * dp
            // 6..12 покачиваний за круг: период 10..20 секунд.
            swayCycles[i] = 6 + rnd.nextInt(7)
            swayPhase[i] = rnd.nextFloat() * (2f * PI.toFloat())
            // Чуть ярче у правого края, к левому гаснет мягким градиентом.
            val side = (x0[i] / w).coerceIn(0f, 1f)
            alpha[i] = maxAlpha * (0.55f + 0.45f * sz) * (0.55f + 0.45f * side)
        }
        // Звезда единичного размера: четыре луча, стороны вогнуты к центру.
        val unit = Path().apply {
            moveTo(0f, -1f)
            quadraticBezierTo(0.12f, -0.12f, 1f, 0f)
            quadraticBezierTo(0.12f, 0.12f, 0f, 1f)
            quadraticBezierTo(-0.12f, 0.12f, -1f, 0f)
            quadraticBezierTo(-0.12f, -0.12f, 0f, -1f)
            close()
        }
        onDrawBehind {
            // Чтение состояния подписывает рисование на кадровый тик: без него звёзды не двигались бы.
            @Suppress("UNUSED_VARIABLE")
            val tick = frame.longValue
            val t = StarClock.phase()
            val twoPi = 2f * PI.toFloat()
            for (i in 0 until count) {
                // Сдвиг вверх накапливается и заворачивается по длине пути: звезда выходит сверху и входит снизу.
                val travelled = (offset[i] + cycles[i] * loopLen[i] * t) % loopLen[i]
                val y = h + radius[i] - travelled
                val x = x0[i] + swayAmp[i] * sin(twoPi * swayCycles[i] * t + swayPhase[i])
                withTransform({
                    translate(x, y)
                    scale(radius[i], radius[i], pivot = Offset.Zero)
                }) { drawPath(unit, color.copy(alpha = alpha[i])) }
            }
        }
    }
}
