// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.ui.components

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.komodje.R
import app.komodje.ui.SIGNATURE_KAOMOJI
import app.komodje.ui.theme.LeafShape
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.LogoShape
import app.komodje.ui.theme.Onest
import app.komodje.ui.theme.badgeBrush
import androidx.compose.foundation.layout.offset
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay

/** Способ поддержать. Ссылки и кошельки подключим позже: пока строки только оформлены. */
private enum class DonateMethod(val icon: ImageVector, val title: Int, val hint: Int) {
    TELEGRAM(KaomojiIcons.Plane, R.string.donate_telegram, R.string.donate_telegram_hint),
    CRYPTO(KaomojiIcons.Coin, R.string.donate_crypto, R.string.donate_crypto_hint),
    CARD(KaomojiIcons.Card, R.string.donate_card, R.string.donate_card_hint),
}

/** Страница доната на lava.top: принимает карты РФ и зарубежные. */
/** Бот для донатов Telegram Stars. */
private const val TELEGRAM_DONATE_URL = "https://t.me/Donate_my_kaomoji_bot"
private const val CARD_DONATE_URL = "https://app.lava.top/fortescue?tabId=donate"

/** Верхние углы панели одинаковые: слева и справа. */
private val SheetShape = RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp, bottomEnd = 0.dp, bottomStart = 0.dp)

/**
 * Нижняя панель «Купить мне чашку кофе»: поднимается снизу, под ней мягко темнеет фон,
 * способы появляются по одному. Закрывается тапом по затемнению, кнопкой «назад» или свайпом системы.
 */
@Composable
fun DonateSheet(onClose: () -> Unit) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    val links = androidx.compose.ui.platform.LocalUriHandler.current
    // Системная панель снизу: в окне диалога её отступ иногда равен нулю, поэтому спрашиваем ещё окно приложения.
    val density = androidx.compose.ui.platform.LocalDensity.current
    val dialogInset = WindowInsets.navigationBars.getBottom(density)
    val appInset = remember(ctx) {
        var c: android.content.Context = ctx
        while (c is android.content.ContextWrapper && c !is android.app.Activity) c = c.baseContext
        val root = (c as? android.app.Activity)?.window?.decorView
        val ins = root?.let { androidx.core.view.ViewCompat.getRootWindowInsets(it) }
        ins?.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars())?.bottom ?: 0
    }
    val bottomInset = with(density) { maxOf(dialogInset, appInset).toDp() }
    var cryptoOpen by remember { mutableStateOf(false) }
    if (cryptoOpen) UsdtDialog(onClose = { cryptoOpen = false })
    // Закрытие идёт через обратную анимацию: сначала уезжает панель, потом закрывается окно.
    val visible = remember { MutableTransitionState(false).apply { targetState = true } }
    LaunchedEffect(visible.currentState, visible.targetState) {
        if (!visible.currentState && !visible.targetState) onClose()
    }
    val dismiss = { visible.targetState = false }

    Dialog(onDismissRequest = dismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
            val scrimSource = remember { MutableInteractionSource() }
            AnimatedVisibility(
                visibleState = visible,
                enter = fadeIn(Motion.standard()),
                exit = fadeOut(Motion.standard()),
            ) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.32f))
                        .clickable(interactionSource = scrimSource, indication = null) { dismiss() },
                )
            }
            AnimatedVisibility(
                visibleState = visible,
                enter = slideInVertically(Motion.slow()) { it / 3 } + fadeIn(Motion.standard()),
                exit = slideOutVertically(Motion.standard()) { it / 3 } + fadeOut(Motion.quick()),
            ) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(SheetShape)
                        .background(p.bgTop)
                        // Тап по самой панели не должен закрывать её через затемнение.
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
                        // Низ панели не уходит под жестовую полосу и край экрана: запас 64 dp плюс больший из системных отступов.
                        .padding(start = 20.dp, end = 20.dp, top = 10.dp, bottom = 64.dp + bottomInset),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Box(
                        Modifier
                            .width(38.dp)
                            .height(4.dp)
                            .clip(CircleShape)
                            .background(p.muted.copy(alpha = 0.35f)),
                    )
                    Spacer(Modifier.height(18.dp))
                    SheetHeader()
                    Spacer(Modifier.height(18.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        DonateMethod.entries.forEachIndexed { index, method ->
                            Staggered(index) {
                                MethodRow(
                                    method,
                                    soon = stringResource(R.string.donate_soon),
                                    ready = true,
                                ) {
                                    when (method) {
                                        // Telegram Stars: бот выставляет счёт, оплата внутри Telegram.
                                        DonateMethod.TELEGRAM -> runCatching { links.openUri(TELEGRAM_DONATE_URL) }
                                        DonateMethod.CRYPTO -> cryptoOpen = true
                                        // Карты (российские и зарубежные): страница доната на lava.top в браузере.
                                        DonateMethod.CARD -> runCatching { links.openUri(CARD_DONATE_URL) }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SheetHeader() {
    val p = LocalPalette.current
    val fill = remember(p) { p.badgeBrush() }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(52.dp).clip(LogoShape).background(fill),
            contentAlignment = Alignment.Center,
        ) {
            Icon(KaomojiIcons.Coffee, contentDescription = null, tint = p.onBadge, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                stringResource(R.string.donate_title),
                color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 20.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(2.dp))
            Text(
                stringResource(R.string.donate_sheet_hint),
                color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 14.sp,
                lineHeight = 19.sp,
            )
        }
    }
}

/** Строки способов въезжают по очереди: прозрачность и лёгкий подъём. */
@Composable
private fun Staggered(index: Int, content: @Composable () -> Unit) {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(160L + index * 70L)
        progress.animateTo(1f, Motion.standard())
    }
    Box(
        Modifier.graphicsLayer {
            alpha = progress.value
            translationY = (1f - progress.value) * 24f
        },
    ) { content() }
}

@Composable
private fun MethodRow(method: DonateMethod, soon: String, ready: Boolean, onClick: () -> Unit) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val source = remember { MutableInteractionSource() }
    val fill = remember(p) { p.badgeBrush() }
    Row(
        Modifier
            .fillMaxWidth()
            .pressScale(source, pressedScale = 0.975f)
            .softShadow(LeafShape)
            .clip(LeafShape)
            .background(p.card)
            .clickable(interactionSource = source, indication = null) {
                tick()
                onClick()
            }
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(42.dp).clip(LogoShape).background(fill),
            contentAlignment = Alignment.Center,
        ) {
            Icon(method.icon, contentDescription = null, tint = p.onBadge, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                stringResource(method.title),
                color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 16.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Text(
                stringResource(method.hint),
                color = p.muted, fontFamily = Onest, fontWeight = FontWeight.Medium, fontSize = 13.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.width(10.dp))
        if (ready) {
            Icon(KaomojiIcons.Sparkle, contentDescription = null, tint = p.heart, modifier = Modifier.size(18.dp))
        } else {
            Box(
                Modifier
                    .clip(CircleShape)
                    .background(p.ink.copy(alpha = 0.06f))
                    .padding(horizontal = 10.dp, vertical = 5.dp),
            ) {
                Text(
                    soon,
                    color = p.muted, fontFamily = Onest, fontWeight = FontWeight.SemiBold, fontSize = 12.sp,
                    maxLines = 1,
                )
            }
        }
    }
}

/**
 * Экран «Криптовалюта»: сеть, QR, адрес и предупреждение читаются одним блоком. Чтобы не ошибиться,
 * сеть названа плашкой, адрес показан целиком группами по 6 символов, а тап по адресу (как и кнопка
 * «Копировать») кладёт его в буфер и подтверждает это сообщением. «Поделиться» отправляет открытку.
 */
@Composable
private fun UsdtDialog(onClose: () -> Unit) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    val tick = rememberTick()
    val buzz = rememberBuzz()
    val scope = rememberCoroutineScope()
    val copiedMsg = stringResource(R.string.usdt_copied)
    val shareTitle = stringResource(R.string.usdt_share)
    val thanks = stringResource(R.string.usdt_thanks)
    val networkLine = stringResource(R.string.usdt_network, UsdtQr.NETWORK)
    val copyAddress = {
        buzz()
        val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("USDT", UsdtQr.ADDRESS))
        Toast.makeText(ctx, copiedMsg, Toast.LENGTH_SHORT).show()
    }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                // Весь блок чуть ниже центра экрана.
                .offset(y = 28.dp)
                .padding(horizontal = 18.dp)
                .fillMaxWidth()
                .softShadow(RoundedCornerShape(30.dp), 10.dp)
                .clip(RoundedCornerShape(30.dp))
                .background(p.bgTop)
                .padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                stringResource(R.string.usdt_title),
                color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 20.sp,
            )
            Spacer(Modifier.height(12.dp))
            // QR всегда чёрный на белом: так его уверенно читают любые кошельки и банки.
            // Белая плашка уже, внутри один блок: QR, сеть, адрес.
            Column(
                Modifier
                    .fillMaxWidth(0.84f)
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color.White)
                    .padding(horizontal = 14.dp, vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                QrCode(UsdtQr.MODULES, Modifier.fillMaxWidth().aspectRatio(1f))
                Spacer(Modifier.height(10.dp))
                // Сеть одной плашкой «Сеть: Tron (TRC-20)» стоит прямо под QR, вместе с адресом читается единым блоком.
                Box(
                    Modifier
                        .clip(CircleShape)
                        .background(Color(0xFF111111).copy(alpha = 0.07f))
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                ) {
                    Text(
                        networkLine,
                        color = Color(0xFF111111), fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                }
                Spacer(Modifier.height(8.dp))
                // Тап по адресу копирует его так же, как кнопка «Копировать».
                val addressSource = remember { MutableInteractionSource() }
                Text(
                    UsdtQr.ADDRESS.chunked(6).joinToString(" "),
                    color = Color(0xFF111111), fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold, fontSize = 14.sp, lineHeight = 20.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable(interactionSource = addressSource, indication = null) { copyAddress() }
                        .padding(horizontal = 4.dp, vertical = 2.dp),
                )
            }
            Spacer(Modifier.height(8.dp))
            // Предупреждение о сети: самая частая ошибка при переводах. Стоит вплотную к блоку с адресом.
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(p.heart.copy(alpha = 0.12f))
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(KaomojiIcons.Sparkle, null, tint = p.heart, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(10.dp))
                Text(
                    stringResource(R.string.usdt_warning),
                    color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Medium,
                    fontSize = 13.sp, lineHeight = 18.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f),
                )
                // Пустое место справа равно значку слева: текст выходит ровно по центру.
                Spacer(Modifier.width(26.dp))
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                DialogButton(
                    label = stringResource(R.string.usdt_copy),
                    filled = true,
                    icon = KaomojiIcons.Copy,
                    modifier = Modifier.weight(1f),
                    onClick = { copyAddress() },
                )
                DialogButton(
                    label = stringResource(R.string.usdt_share),
                    filled = false,
                    icon = KaomojiIcons.Send,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        tick()
                        // Открытка: QR, «Спасибо за поддержку», каомодзи и адрес; адрес идёт ещё и текстом.
                        // Текст к картинке: благодарность с каомодзи, длинная линия, сеть и адрес отдельной строкой; блоки через пустую строку.
                        val rule = "—".repeat(22)
                        val shareText = "$thanks $SIGNATURE_KAOMOJI\n\n$rule\n\n$networkLine\n\n${UsdtQr.ADDRESS}"
                        scope.launch {
                            val chooser = withContext(Dispatchers.IO) {
                                runCatching {
                                    val bmp = ShareCard.render(thanks, networkLine)
                                    ShareCard.buildIntent(ctx, bmp, shareTitle, shareText)
                                }.getOrNull()
                            }
                            if (chooser != null) {
                                runCatching { ctx.startActivity(chooser) }
                            } else {
                                // Картинку собрать не вышло: отправляем хотя бы адрес текстом.
                                val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(android.content.Intent.EXTRA_TEXT, shareText)
                                }
                                ctx.startActivity(android.content.Intent.createChooser(send, shareTitle))
                            }
                        }
                    },
                )
            }
            Spacer(Modifier.height(8.dp))
            DialogButton(
                label = stringResource(R.string.folder_help_ok),
                filled = false,
                modifier = Modifier.fillMaxWidth(),
                onClick = onClose,
            )
        }
    }
}

/** Рисует QR из таблицы модулей: чёрные квадраты со всех сторон окружены белой «тихой зоной» самой карточкой. */
@Composable
private fun QrCode(modules: List<String>, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val n = modules.size
        val cell = size.minDimension / n
        for (y in 0 until n) for (x in 0 until n) {
            if (modules[y][x] == '1') {
                drawRect(
                    Color(0xFF111111),
                    topLeft = Offset(x * cell, y * cell),
                    size = Size(cell + 0.6f, cell + 0.6f),
                )
            }
        }
    }
}
