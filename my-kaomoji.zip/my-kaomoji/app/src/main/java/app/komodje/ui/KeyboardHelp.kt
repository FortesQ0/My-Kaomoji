// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.ui

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import app.komodje.R
import app.komodje.ui.components.HelpBubble
import app.komodje.ui.components.KaomojiIcons
import app.komodje.ui.components.pressScale
import app.komodje.ui.components.rememberTick
import app.komodje.ui.components.LogoMark
import app.komodje.ui.theme.BadgeShape
import app.komodje.ui.theme.BarShape
import app.komodje.ui.theme.LeafShape
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.Onest
import app.komodje.ui.theme.backgroundBrush
import app.komodje.ui.theme.badgeBrush
import kotlinx.coroutines.delay

private const val STEPS = 3

/** Включена ли клавиатура My Kaomoji в системных настройках. */
fun isKeyboardEnabled(context: Context): Boolean = runCatching {
    context.getSystemService(InputMethodManager::class.java)
        .enabledInputMethodList
        .any { it.packageName == context.packageName }
}.getOrDefault(false)

private fun openKeyboardSettings(context: Context) {
    runCatching { context.startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
}

private fun showKeyboardPicker(context: Context) {
    runCatching { context.getSystemService(InputMethodManager::class.java).showInputMethodPicker() }
}

/** Значок «?» рядом с названием блока. Красная точка, пока инструкцию ни разу не открывали. */
@Composable
fun KeyboardHelpButton(showDot: Boolean, onClick: () -> Unit) {
    HelpBubble(onClick = onClick, showDot = showDot)
}

/**
 * Мини-инструкция из трёх шагов: что это, как включить, как переключиться.
 * Тексты берутся из ресурсов, поэтому идут на языке, выбранном в приложении.
 * Картинки нарисованы тут же и красятся в цвета выбранной темы.
 * Вернулись из системных настроек с включённой клавиатурой: сами переходим к третьему шагу.
 */
@Composable
fun KeyboardHelpDialog(onClose: () -> Unit) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    var step by rememberSaveable { mutableStateOf(0) }
    var enabled by remember { mutableStateOf(isKeyboardEnabled(ctx)) }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                val now = isKeyboardEnabled(ctx)
                if (now && !enabled && step == 1) step = 2
                enabled = now
            }
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .padding(horizontal = 20.dp)
                .fillMaxWidth()
                .clip(LeafShape)
                .background(p.card)
                .padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(p.backgroundBrush()),
                contentAlignment = Alignment.Center,
            ) {
                Crossfade(targetState = step, animationSpec = tween(250), label = "helpArt") { s ->
                    when (s) {
                        0 -> ArtPanel()
                        1 -> ArtSettings()
                        else -> ArtSwitch()
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            Dots(step)
            Spacer(Modifier.height(14.dp))

            AnimatedContent(
                targetState = step,
                transitionSpec = {
                    if (targetState > initialState) {
                        (slideInHorizontally(tween(280)) { it / 3 } + fadeIn(tween(280))) togetherWith
                            (slideOutHorizontally(tween(280)) { -it / 3 } + fadeOut(tween(160)))
                    } else {
                        (slideInHorizontally(tween(280)) { -it / 3 } + fadeIn(tween(280))) togetherWith
                            (slideOutHorizontally(tween(280)) { it / 3 } + fadeOut(tween(160)))
                    }
                },
                label = "helpText",
            ) { s ->
                val title = when (s) {
                    0 -> R.string.kb_step1_title
                    1 -> R.string.kb_step2_title
                    else -> R.string.kb_step3_title
                }
                val body = when (s) {
                    0 -> R.string.kb_step1_body
                    1 -> R.string.kb_step2_body
                    else -> R.string.kb_step3_body
                }
                Column(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(min = 124.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        stringResource(title),
                        color = p.ink, fontFamily = Onest, fontWeight = FontWeight.Bold,
                        fontSize = 22.sp, textAlign = TextAlign.Center,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        stringResource(body),
                        color = p.ink.copy(alpha = 0.72f), fontFamily = Onest, fontWeight = FontWeight.Medium,
                        fontSize = 15.sp, lineHeight = 21.sp, textAlign = TextAlign.Center,
                    )
                }
            }
            Spacer(Modifier.height(10.dp))

            // Главное действие шага: открыть настройки / выбрать клавиатуру
            when {
                step == 1 && enabled -> EnabledBadge(stringResource(R.string.kb_enabled))
                step == 1 || (step == 2 && !enabled) -> PillButton(
                    text = stringResource(R.string.kb_open_settings),
                    onClick = { openKeyboardSettings(ctx) },
                    modifier = Modifier.fillMaxWidth(),
                )
                step == 2 -> PillButton(
                    text = stringResource(R.string.kb_choose_keyboard),
                    onClick = { showKeyboardPicker(ctx) },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            if (step > 0) Spacer(Modifier.height(10.dp))

            val hasAction = (step == 1 && !enabled) || step == 2
            val last = step == STEPS - 1
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (step > 0) {
                    PillButton(
                        text = stringResource(R.string.back),
                        onClick = { step -= 1 },
                        modifier = Modifier.weight(1f),
                        filled = false,
                    )
                }
                PillButton(
                    text = stringResource(if (last) R.string.kb_done else R.string.kb_next),
                    onClick = { if (last) onClose() else step += 1 },
                    modifier = Modifier.weight(1f),
                    filled = !hasAction,
                )
            }
        }
    }
}

@Composable
internal fun PillButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    filled: Boolean = true,
    /** Неактивная кнопка серая и не нажимается; включается плавно. */
    enabled: Boolean = true,
) {
    val p = LocalPalette.current
    val fill = remember(p) { p.badgeBrush() }
    val on by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (enabled) 1f else 0f,
        animationSpec = tween(250),
        label = "pillEnabled",
    )
    val tick = rememberTick()
    val source = remember { MutableInteractionSource() }
    Box(
        modifier
            .height(50.dp)
            .pressScale(source)
            .clip(BarShape)
            .background(p.ink.copy(alpha = 0.08f))
            .drawBehind { if (filled) drawRect(fill, alpha = on) }
            .clickable(interactionSource = source, indication = null, enabled = enabled) {
                tick()
                onClick()
            }
            .padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text,
            color = if (filled) lerp(p.ink.copy(alpha = 0.35f), p.onBadge, on) else p.ink,
            fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1,
        )
    }
}

@Composable
internal fun EnabledBadge(text: String) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .height(50.dp)
            .clip(BarShape)
            .background(p.accent),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        Icon(KaomojiIcons.Check, null, tint = p.onAccent, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, color = p.onAccent, fontFamily = Onest, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1)
    }
}

@Composable
internal fun Dots(step: Int, count: Int = STEPS) {
    val p = LocalPalette.current
    // Одна общая «позиция» между точками: ширина и цвет каждой точки считаются из неё. Анимация всегда
    // доезжает ровно до номера страницы, поэтому «колбаса» не может застрять на полпути.
    val pos = remember { androidx.compose.animation.core.Animatable(step.toFloat()) }
    LaunchedEffect(step) {
        pos.animateTo(step.toFloat(), tween(260, easing = androidx.compose.animation.core.FastOutSlowInEasing))
    }
    val off = remember(p) { p.ink.copy(alpha = 0.18f) }
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        repeat(count) { i ->
            val near = (1f - kotlin.math.abs(pos.value - i)).coerceIn(0f, 1f)
            Box(
                Modifier
                    .height(8.dp)
                    .width((8f + 16f * near).dp)
                    .clip(CircleShape)
                    .background(androidx.compose.ui.graphics.lerp(off, p.heart, near)),
            )
        }
    }
}

// ---------- Иллюстрации: схемы, нарисованные в стиле приложения ----------

private val MiniShape = RoundedCornerShape(topStart = 14.dp, topEnd = 6.dp, bottomEnd = 14.dp, bottomStart = 6.dp)

/** Шаг 1: быстрый ряд и список карточек, как в клавиатуре. */
@Composable
private fun ArtPanel() {
    val p = LocalPalette.current
    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("(ﾉ ◕ ᗜ ◕ )ﾉ", "ʕ ≧ ᴥ ≦ ʔ", "✧ ᗜ ✧").forEach { text ->
                Box(
                    Modifier
                        .height(30.dp)
                        .clip(MiniShape)
                        .background(p.accent)
                        .padding(horizontal = 8.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(text, color = p.onAccent, fontSize = 12.sp, maxLines = 1, softWrap = false)
                }
            }
        }
        listOf("( ⌒ ᗜ ⌒ )", "(ᵔ ᵕ ᵔ )ﾉ").forEach { text ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(36.dp)
                    .clip(MiniShape)
                    .background(p.card)
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(text, color = p.ink, fontSize = 15.sp, maxLines = 1, softWrap = false)
                Spacer(Modifier.weight(1f))
                Icon(KaomojiIcons.HeartOutline, null, tint = p.muted, modifier = Modifier.size(15.dp))
            }
        }
    }
}

/** Шаг 2: строки системных настроек, переключатель My Kaomoji сам включается и выключается. */
@Composable
private fun ArtSettings() {
    val t = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(700)
            t.animateTo(1f, tween(450))
            delay(1700)
            t.animateTo(0f, tween(450))
            delay(500)
        }
    }
    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        SettingsRowMock(name = "Gboard", progress = 1f, logo = false)
        SettingsRowMock(name = stringResource(R.string.ime_label), progress = t.value, logo = true)
    }
}

@Composable
private fun SettingsRowMock(name: String, progress: Float, logo: Boolean) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .height(54.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(p.card)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (logo) {
            LogoMark(size = 32.dp)
        } else {
            Box(Modifier.size(32.dp).clip(RoundedCornerShape(10.dp)).background(p.ink.copy(alpha = 0.10f)))
        }
        Spacer(Modifier.width(10.dp))
        Text(
            name,
            color = p.ink, fontFamily = Onest, fontWeight = FontWeight.SemiBold, fontSize = 16.sp,
            modifier = Modifier.weight(1f),
        )
        MiniSwitch(progress)
    }
}

@Composable
private fun MiniSwitch(progress: Float) {
    val p = LocalPalette.current
    val fill = remember(p) { p.badgeBrush() }
    val t = progress.coerceIn(0f, 1f)
    Box(
        Modifier
            .size(width = 48.dp, height = 28.dp)
            .clip(CircleShape)
            .background(p.ink.copy(alpha = 0.12f))
            .drawBehind { drawRect(fill, alpha = t) },
    ) {
        Box(
            Modifier
                .offset(x = 4.dp + 20.dp * t, y = 4.dp)
                .size(20.dp)
                .clip(CircleShape)
                .background(lerp(p.muted, p.onBadge, t)),
        )
    }
}

/** Шаг 3: окно выбора клавиатуры и пульсирующий значок переключения в углу. */
@Composable
private fun ArtSwitch() {
    val p = LocalPalette.current
    val pulse = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            pulse.animateTo(1f, tween(700))
            pulse.animateTo(0f, tween(700))
        }
    }
    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(p.card)
                .padding(5.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            PickerRowMock("Gboard", selected = false)
            PickerRowMock(stringResource(R.string.ime_label), selected = true)
        }
        Row(Modifier.fillMaxWidth().height(46.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(14.dp))
                    .background(p.ink.copy(alpha = 0.10f)),
            )
            Box(
                Modifier
                    .size(46.dp)
                    .graphicsLayer {
                        val s = 1f + 0.10f * pulse.value
                        scaleX = s
                        scaleY = s
                    }
                    .clip(BadgeShape)
                    .background(p.accent)
                    .border(2.dp, p.heart.copy(alpha = 0.25f + 0.75f * pulse.value), BadgeShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(KaomojiIcons.Keyboard, null, tint = p.onAccent, modifier = Modifier.size(26.dp))
            }
        }
    }
}

@Composable
private fun PickerRowMock(name: String, selected: Boolean) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .height(32.dp)
            .clip(RoundedCornerShape(11.dp))
            .background(if (selected) p.accent else p.card)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            name,
            color = if (selected) p.onAccent else p.ink,
            fontFamily = Onest, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
            modifier = Modifier.weight(1f),
        )
        if (selected) Icon(KaomojiIcons.Check, null, tint = p.onAccent, modifier = Modifier.size(18.dp))
    }
}
