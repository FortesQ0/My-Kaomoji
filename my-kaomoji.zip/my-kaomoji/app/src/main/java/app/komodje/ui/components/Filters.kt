// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.ui.components

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.Color
import app.komodje.ui.theme.gradientTint
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.komodje.R
import app.komodje.domain.KaomojiFilter
import app.komodje.ui.theme.LocalPalette
import app.komodje.domain.AccentTheme
import app.komodje.ui.theme.LocalAccentTheme
import app.komodje.ui.theme.Onest
import app.komodje.ui.theme.accentBrush

internal val TabShape = RoundedCornerShape(topStart = 18.dp, topEnd = 8.dp, bottomEnd = 18.dp, bottomStart = 8.dp)

/** Значок вкладки: у «Все» его нет. Рисуем сами (см. KaomojiIcons), а не системными эмодзи. */
private fun KaomojiFilter.icon(): ImageVector? = when (this) {
    KaomojiFilter.ALL -> null
    KaomojiFilter.SINGLE -> KaomojiIcons.Person
    KaomojiFilter.GROUP -> KaomojiIcons.People
    KaomojiFilter.EFFECTS -> KaomojiIcons.Sparkle
}

private fun KaomojiFilter.label(): Int = when (this) {
    KaomojiFilter.ALL -> R.string.filter_all
    KaomojiFilter.SINGLE -> R.string.filter_single
    KaomojiFilter.GROUP -> R.string.filter_group
    KaomojiFilter.EFFECTS -> R.string.filter_effects
}

/**
 * Мини-вкладки над списком: только подписи, листовые формы, выбранная заливается цветом темы.
 * Если не влезают (длинные переводы), ряд прокручивается вбок.
 */
@Composable
fun FilterTabs(selected: Set<KaomojiFilter>, onSelect: (KaomojiFilter) -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        KaomojiFilter.entries.forEach { f ->
            FilterTab(
                label = stringResource(f.label()),
                icon = f.icon(),
                selected = if (f == KaomojiFilter.ALL) selected.isEmpty() else f in selected,
                onClick = { onSelect(f) },
            )
        }
    }
}

@Composable
internal fun FilterTab(label: String, icon: ImageVector?, selected: Boolean, onClick: () -> Unit) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val interaction = remember { MutableInteractionSource() }
    val fill = remember(p) { p.accentBrush() }
    val sel by animateFloatAsState(
        targetValue = if (selected) 1f else 0f,
        animationSpec = tween(220),
        label = "tabSel",
    )
    Box(
        Modifier
            .height(38.dp)
            .pressScale(interaction)
            .softShadow(TabShape, 2.dp)
            .clip(TabShape)
            .background(p.card)
            .drawBehind { drawRect(fill, alpha = sel) }
            .clickable(interactionSource = interaction, indication = null) {
                tick()
                onClick()
            }
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        val tint = lerp(p.ink, p.onAccent, sel)
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(19.dp))
                Spacer(Modifier.width(6.dp))
            }
            Text(
                text = label,
                color = tint,
                fontFamily = Onest,
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp,
                maxLines = 1,
                softWrap = false,
            )
        }
    }
}

/** Полупрозрачная подпись под вкладками: «Хиты дня» (или название открытой папки). */
@Composable
fun SectionLabel(
    text: String,
    modifier: Modifier = Modifier,
    icon: ImageVector = KaomojiIcons.Sparkle,
    topPadding: Dp = 8.dp,
) {
    val p = LocalPalette.current
    // Микроградиент: от приглушённого цвета подписи к лёгкому оттенку темы. Тот же градиент и на иконке.
    val milk = LocalAccentTheme.current == AccentTheme.MILK
    val brush = remember(p.muted, p.heart, p.ink, milk) {
        // «Молоко»: от приглушённого к почти белому (в тёмной теме) или к мягкому графитовому (в светлой).
        val end = if (milk) lerp(p.muted, p.ink, 0.65f) else lerp(p.muted, p.heart, 0.55f)
        Brush.horizontalGradient(listOf(p.muted.copy(alpha = 0.9f), end.copy(alpha = 0.95f)))
    }
    val iconBrush = remember(p.muted, p.heart, p.ink, milk) {
        val end = if (milk) lerp(p.muted, p.ink, 0.65f) else lerp(p.muted, p.heart, 0.55f)
        Brush.linearGradient(listOf(p.muted.copy(alpha = 0.9f), end.copy(alpha = 0.95f)))
    }
    Row(
        modifier
            .fillMaxWidth()
            .padding(start = 22.dp, end = 22.dp, top = topPadding),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier
                .size(22.dp)
                .gradientTint(iconBrush),
        )
        Spacer(Modifier.width(8.dp))
        Crossfade(targetState = text, animationSpec = tween(220), label = "sectionLabel") { value ->
            Text(
                text = value,
                style = TextStyle(
                    brush = brush,
                    fontFamily = Onest,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 20.sp,
                    letterSpacing = 0.4.sp,
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}
