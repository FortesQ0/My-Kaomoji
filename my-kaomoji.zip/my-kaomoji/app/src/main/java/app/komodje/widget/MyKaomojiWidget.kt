// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.widget

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.glance.GlanceId
import androidx.glance.action.ActionParameters
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.updateAll
import app.komodje.MyKaomojiApp
import app.komodje.R
import app.komodje.domain.topPicks
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

internal val PickKey = ActionParameters.Key<String>("kaomoji_text")
internal val PickKeyShared = PickKey

/**
 * Виджет 1×1: самое любимое (или частое) каомодзи на цельной плашке с градиентом акцента.
 * Тап копирует. Цвета берутся из выбранного в приложении акцента и режима.
 */
class MyKaomojiWidget : GlanceAppWidget() {

    override val sizeMode: SizeMode = SizeMode.Exact

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val look = lookOf(context)
        val container = (context.applicationContext as MyKaomojiApp).container
        val favorites = container.favorites.favorites.first()
        val counts = container.usage.counts.first()
        val pick = topPicks(container.repository.allTexts(), favorites, counts, 1).firstOrNull().orEmpty()
        provideContent { FaceWidget(look, pick, pick, rerollKind = null) }
    }
}

class MyKaomojiWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = MyKaomojiWidget()
}

/** Тап по плитке: копируем в буфер и считаем использование. Сам виджет не перерисовывается, плитки не прыгают. */
class CopyAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        val text = parameters[PickKey]
        if (text.isNullOrEmpty()) return

        context.getSystemService(ClipboardManager::class.java)
            .setPrimaryClip(ClipData.newPlainText("kaomoji", text))
        (context.applicationContext as? MyKaomojiApp)?.container?.usage?.recordNow(text)

        // С Android 13 систему показывает своё подтверждение копирования.
        if (Build.VERSION.SDK_INT < 33) {
            withContext(Dispatchers.Main) {
                Toast.makeText(context, context.getString(R.string.copied), Toast.LENGTH_SHORT).show()
            }
        }
    }
}

private val refreshScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

/** Перерисовать все виджеты на экране (если их нет, ничего не делает). */
suspend fun refreshWidgets(context: Context) {
    runCatching { MyKaomojiWidget().updateAll(context.applicationContext) }
    refreshMoreWidgets(context)
}

fun refreshWidgetsAsync(context: Context) {
    val app = context.applicationContext
    refreshScope.launch { refreshWidgets(app) }
}
