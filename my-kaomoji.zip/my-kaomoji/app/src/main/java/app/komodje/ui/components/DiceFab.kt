// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp
import app.komodje.ui.theme.LocalPalette
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

/**
 * Круглая кнопка с игральной костью справа внизу над нижними закладками. Тап: кнопка подпрыгивает,
 * кость крутится и меняет грань, а в начале броска просит перемешать коллекцию (onRoll).
 * Грани рисуем сами (скруглённый квадрат с вырезами-точками): точки ровные и берут цвет темы.
 */
@Composable
fun DiceFab(onRoll: () -> Unit, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val source = remember { MutableInteractionSource() }
    val scope = rememberCoroutineScope()
    val spin = remember { Animatable(0f) }
    val hop = remember { Animatable(0f) }
    val squash = remember { Animatable(1f) }
    // Грань помним на весь запуск: при смене закладки кнопка пересоздаётся, а значение сбрасываться не должно.
    var face by remember { mutableIntStateOf(DiceMemory.face) }
    var busy by remember { mutableStateOf(false) }
    // Плоское стекло в духе Apple Glass: прозрачная заливка, тонкий светлый край и лёгкий блик сверху.
    // Без толстой обводки, внутреннего свечения и глубоких теней: плашка не должна выглядеть шаром.
    val dark = p.bgTop.luminance() < 0.5f
    val glass = remember(p, dark) {
        if (dark) {
            Brush.verticalGradient(listOf(p.accent.copy(alpha = 0.30f), p.accentDeep.copy(alpha = 0.46f)))
        } else {
            Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.62f), Color.White.copy(alpha = 0.34f)))
        }
    }
    val sheen = remember(dark) {
        Brush.verticalGradient(listOf(Color.White.copy(alpha = if (dark) 0.16f else 0.40f), Color.Transparent))
    }
    val rimBrush = remember(dark) {
        Brush.verticalGradient(
            listOf(
                Color.White.copy(alpha = if (dark) 0.34f else 0.85f),
                Color.White.copy(alpha = if (dark) 0.06f else 0.20f),
            ),
        )
    }
    val tint = remember(p, dark) {
        if (dark) lerp(p.onBadge, Color.White, 0.45f) else lerp(p.badge, p.badgeDeep, 0.4f)
    }
    val side = remember(tint, p, dark) { lerp(tint, if (dark) p.badge else Color.White, 0.45f) }

    Box(
        modifier
            .graphicsLayer {
                translationY = -hop.value * 16.dp.toPx()
                val s = 1f + 0.1f * hop.value
                scaleX = s
                scaleY = s
            }
            .pressScale(source, pressedScale = 0.9f)
            .size(62.dp)
            .softShadow(CircleShape, elevation = 2.dp)
            .clip(CircleShape)
            .drawBehind {
                val w = size.width
                val h = size.height
                drawCircle(glass)
                // Блик: верхняя половина чуть светлее и плавно гаснет к середине.
                drawRect(sheen, size = Size(w, h * 0.55f))
                // Тонкий светлый край, толщина 1 dp.
                val sw = 1.dp.toPx()
                drawCircle(rimBrush, radius = w / 2f - sw / 2f, style = Stroke(sw))
            }
            .clickable(interactionSource = source, indication = null) {
                if (busy) return@clickable
                busy = true
                tick()
                scope.launch {
                    // Кубик переворачивается: каждая смена грани происходит в момент, когда он стоит ребром
                    // (сжат по высоте до тонкой полоски), поэтому точки не «щёлкают», а плавно перекатываются.
                    // Перевороты замедляются, последний ставит итоговую грань, после него значение не меняется.
                    val result = nextFace(face)
                    launch {
                        hop.snapTo(0f)
                        hop.animateTo(1f, tween(330, easing = FastOutSlowInEasing))
                        hop.animateTo(0f, spring(dampingRatio = 0.6f, stiffness = 500f))
                    }
                    val flips = launch {
                        val durations = intArrayOf(100, 110, 125, 145, 170)
                        var shown = face
                        durations.forEachIndexed { index, d ->
                            squash.animateTo(0.06f, tween(d / 2, easing = FastOutLinearInEasing))
                            shown = if (index == durations.lastIndex) result else nextFace(shown, avoid = result)
                            face = shown
                            DiceMemory.face = shown
                            squash.animateTo(1f, tween(d - d / 2, easing = LinearOutSlowInEasing))
                        }
                    }
                    launch {
                        delay(200)
                        onRoll()
                    }
                    spin.snapTo(0f)
                    spin.animateTo(720f, tween(800, easing = Motion.Ease))
                    spin.snapTo(0f)
                    flips.join()
                    busy = false
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(
            Modifier
                .size(32.dp)
                .graphicsLayer {
                    rotationZ = spin.value
                    scaleY = squash.value
                },
        ) { drawCube(face, tint, side) }
    }
}

private fun nextFace(current: Int, avoid: Int = current): Int {
    var next = Random.nextInt(1, 7)
    while (next == current || next == avoid) next = Random.nextInt(1, 7)
    return next
}

/** Центры точек в сетке 3x3 (0..2 по каждой оси) для каждой грани. */
private fun pips(face: Int): List<Pair<Int, Int>> = when (face) {
    1 -> listOf(1 to 1)
    2 -> listOf(0 to 0, 2 to 2)
    3 -> listOf(0 to 0, 1 to 1, 2 to 2)
    4 -> listOf(0 to 0, 2 to 0, 0 to 2, 2 to 2)
    5 -> listOf(0 to 0, 2 to 0, 1 to 1, 0 to 2, 2 to 2)
    else -> listOf(0 to 0, 2 to 0, 0 to 1, 2 to 1, 0 to 2, 2 to 2)
}

private fun DrawScope.drawDie(face: Int, color: Color) {
    val s = size.minDimension
    val path = Path().apply {
        fillType = PathFillType.EvenOdd
        addRoundRect(RoundRect(Rect(0f, 0f, s, s), CornerRadius(s * 0.28f)))
        val step = s * 0.29f
        val r = s * 0.085f
        pips(face).forEach { (gx, gy) ->
            val c = Offset(s / 2f + (gx - 1) * step, s / 2f + (gy - 1) * step)
            addOval(Rect(c.x - r, c.y - r, c.x + r, c.y + r))
        }
    }
    drawPath(path, color)
}

/**
 * Кубик «как 3D», оставаясь плоским рисунком: за лицевой гранью стопкой рисуются смещённые копии
 * светлее (боковой корпус), поэтому видна толщина. Лицо сдвинуто так, чтобы весь куб стоял по центру.
 */
private fun DrawScope.drawCube(face: Int, color: Color, side: Color) {
    val full = size.minDimension
    val depth = full * 0.1f
    val s = full - depth
    val steps = 6
    for (i in steps downTo 1) {
        val o = depth * i / steps
        drawRoundRect(
            color = if (i == steps) lerp(side, color, 0.25f) else side,
            topLeft = Offset(o, o),
            size = Size(s, s),
            cornerRadius = CornerRadius(s * 0.28f),
        )
    }
    withTransform({
        scale(s / full, s / full, pivot = Offset.Zero)
    }) { drawDie(face, color) }
}

/** Последняя выпавшая грань кубика: живёт, пока приложение запущено. */
internal object DiceMemory { var face: Int = 5 }
