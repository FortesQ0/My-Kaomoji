plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
}

android {
    namespace = "app.komodje"
    compileSdk = 35

    defaultConfig {
        applicationId = "my.kaomoji"
        minSdk = 28
        targetSdk = 35
        versionCode = 45
        versionName = "0.2.32"
    }

    buildTypes {
        debug {
            // Тот же debug-APK (подпись и workflow те же), но без отладочных накладных расходов ART.
            isDebuggable = false
            // Сжатие и оптимизация кода (R8) без переименования: имена остаются, поэтому
            // сохранённые данные, виджет, клавиатура и ярлыки работают как раньше.
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.foundation)
    implementation(libs.compose.material3)
    implementation(libs.lifecycle.viewmodel.compose)
    implementation(libs.lifecycle.runtime.compose)
    implementation(libs.datastore.preferences)
    implementation(libs.kotlinx.serialization.json)
    implementation(libs.androidx.glance.appwidget)
    // Применяет готовые профили прогрева Compose при первом запуске: первые прокрутки идут плавнее.
    implementation("androidx.profileinstaller:profileinstaller:1.4.1")
    testImplementation(libs.junit)
}
