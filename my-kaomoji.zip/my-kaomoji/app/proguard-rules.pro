# Имена не переименовываем: сжатие и оптимизация остаются, а всё, что ищется по имени
# (данные в хранилище, перечисления, сериализация, клавиатура, значки), не ломается.
-dontobfuscate

# Сериализация kotlinx: сгенерированные сериализаторы и их компаньоны.
-keepattributes *Annotation*, InnerClasses, Signature, EnclosingMethod
-dontnote kotlinx.serialization.**
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class kotlinx.serialization.json.** { kotlinx.serialization.KSerializer serializer(...); }
-keep,includedescriptorclasses class app.komodje.**$$serializer { *; }
-keepclassmembers class app.komodje.** {
    *** Companion;
}
-keepclasseswithmembers class app.komodje.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# Все свои классы приложения не удаляем: они небольшие, а вылет из-за вырезанного нужного стоит дороже.
-keep class app.komodje.** { *; }

# Перечисления: значения по имени.
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}
