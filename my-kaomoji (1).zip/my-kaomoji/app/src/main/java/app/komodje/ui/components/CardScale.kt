// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.ui.components

import androidx.compose.runtime.compositionLocalOf

/**
 * Реальный множитель размера карточек (1f = нормальный размер). Задаётся в настройках через
 * [cardScaleFactor]: показанные «100%» это 0,92 от прежнего размера.
 */
val LocalCardScale = compositionLocalOf { 1f }

/** Реальный множитель при показанных 100%: ровно то, что раньше называлось 92%. */
const val CardScaleBase = 0.92f

/** Показанные проценты из настроек -> реальный множитель для плотности. */
fun cardScaleFactor(shownPercent: Int): Float = shownPercent / 100f * CardScaleBase
