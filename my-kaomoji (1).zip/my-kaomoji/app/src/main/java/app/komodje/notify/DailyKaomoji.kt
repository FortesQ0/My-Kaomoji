// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.notify

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import app.komodje.MyKaomojiApp
import app.komodje.MainActivity
import app.komodje.R
import app.komodje.data.dataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.util.Calendar
import kotlin.random.Random

/**
 * «Каомодзи дня»: утреннее уведомление с каомодзи и коротким пожеланием. Включается отдельной настройкой.
 * Будильник неточный (без особых разрешений), поэтому время может плыть на несколько минут.
 */
object DailyKaomoji {
    const val CHANNEL = "daily_kaomoji"
    private const val REQUEST = 4101
    private const val NOTIFICATION_ID = 4102
    private val enabledKey = booleanPreferencesKey("daily_enabled")
    private val hourKey = intPreferencesKey("daily_hour")
    private val minuteKey = intPreferencesKey("daily_minute_of_day")
    const val DEFAULT_HOUR = 9

    suspend fun isEnabled(context: Context): Boolean = context.dataStore.data.first()[enabledKey] ?: false

    suspend fun hour(context: Context): Int = minuteOfDay(context) / 60

    /** Время уведомления в минутах от полуночи. Старые настройки хранили только час: берём его. */
    suspend fun minuteOfDay(context: Context): Int {
        val prefs = context.dataStore.data.first()
        return prefs[minuteKey] ?: ((prefs[hourKey] ?: DEFAULT_HOUR) * 60)
    }

    suspend fun configure(context: Context, enabled: Boolean, minuteOfDay: Int) {
        context.dataStore.edit {
            it[enabledKey] = enabled
            it[minuteKey] = minuteOfDay
            it[hourKey] = minuteOfDay / 60
        }
        if (enabled) scheduleNext(context, minuteOfDay) else cancel(context)
    }

    suspend fun rescheduleFromSettings(context: Context) {
        if (isEnabled(context)) scheduleNext(context, minuteOfDay(context)) else cancel(context)
    }

    private fun pending(context: Context): PendingIntent = PendingIntent.getBroadcast(
        context, REQUEST, Intent(context, DailyReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    fun scheduleNext(context: Context, minuteOfDay: Int) {
        val at = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, minuteOfDay / 60)
            set(Calendar.MINUTE, minuteOfDay % 60)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis() + 60_000) add(Calendar.DAY_OF_YEAR, 1)
        }
        val alarms = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at.timeInMillis, pending(context))
    }

    fun cancel(context: Context) {
        val alarms = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarms.cancel(pending(context))
    }

    /** Каомодзи и пожелание дня: выбор зависит от даты, так что в течение суток он один и тот же. */
    fun show(context: Context) {
        val all = (context.applicationContext as MyKaomojiApp).container.repository.all()
        if (all.isEmpty()) return
        val day = LocalDate.now().toEpochDay()
        val kaomoji = all[Random(day).nextInt(all.size)].text
        val wishes = context.resources.getStringArray(R.array.daily_wishes)
        val wish = wishes[Random(day + 1).nextInt(wishes.size)]
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL, context.getString(R.string.daily_channel), NotificationManager.IMPORTANCE_LOW),
        )
        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val copy = PendingIntent.getBroadcast(
            context, 1,
            Intent(context, CopyReceiver::class.java).putExtra(CopyReceiver.EXTRA_TEXT, kaomoji),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(kaomoji)
            .setContentText(wish)
            .setStyle(NotificationCompat.BigTextStyle().bigText(wish))
            .setContentIntent(open)
            .setAutoCancel(true)
            .addAction(0, context.getString(R.string.daily_copy), copy)
            .build()
        runCatching {
            if (NotificationManagerCompat.from(context).areNotificationsEnabled()) {
                NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification)
            }
        }
    }
}

class DailyReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.Default).launch {
            try {
                if (DailyKaomoji.isEnabled(context)) {
                    DailyKaomoji.show(context)
                    DailyKaomoji.scheduleNext(context, DailyKaomoji.minuteOfDay(context))
                }
            } finally {
                pending.finish()
            }
        }
    }
}

/** Кнопка «Скопировать» в уведомлении: копирует каомодзи, не открывая приложение. */
class CopyReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val text = intent.getStringExtra(EXTRA_TEXT) ?: return
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("kaomoji", text))
        val pending = goAsync()
        CoroutineScope(Dispatchers.Default).launch {
            try {
                (context.applicationContext as MyKaomojiApp).container.usage.recordNow(text)
            } finally {
                pending.finish()
            }
        }
    }

    companion object { const val EXTRA_TEXT = "text" }
}

/** После перезагрузки телефона и обновления приложения будильник нужно поставить заново. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.Default).launch {
            try {
                DailyKaomoji.rescheduleFromSettings(context)
            } finally {
                pending.finish()
            }
        }
    }
}
