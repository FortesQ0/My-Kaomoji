// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.ui.theme

import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.font.FontWeight
import app.komodje.R

/** Onest — один variable-файл, берём только плотные веса: тонких в интерфейсе нет. */
@OptIn(ExperimentalTextApi::class)
val Onest = FontFamily(
    listOf(500, 600, 700).map { w ->
        Font(
            resId = R.font.onest,
            weight = FontWeight(w),
            variationSettings = FontVariation.Settings(FontVariation.weight(w)),
        )
    }
)

/** Unbounded: широкий жирный шрифт для большой надписи «Хиты дня». Один variable-файл, берём вес 900. */
@OptIn(ExperimentalTextApi::class)
val UnboundedBlack = FontFamily(
    Font(
        resId = R.font.unbounded,
        weight = FontWeight.Black,
        variationSettings = FontVariation.Settings(FontVariation.weight(900)),
    ),
)
