// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.ui.components

import android.view.View
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.Onest
import app.komodje.ui.theme.accentBrush
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/** Границы элемента в координатах ЭКРАНА: так их можно передать в окно меню, которое живёт отдельно. */
fun LayoutCoordinates.screenBounds(view: View): Rect {
    val r = boundsInRoot()
    val loc = IntArray(2)
    view.getLocationOnScreen(loc)
    return r.translate(loc[0].toFloat(), loc[1].toFloat())
}

/** Красный для «опасных» пунктов меню (удалить, убрать). */
private val DangerTop = Color(0xFFF2686E)
private val DangerBottom = Color(0xFFD43A41)
private val DangerText = Color(0xFFE5484D)

private val MenuShape = RoundedCornerShape(topStart = 24.dp, topEnd = 10.dp, bottomEnd = 24.dp, bottomStart = 10.dp)
private val ItemShape = RoundedCornerShape(topStart = 16.dp, topEnd = 7.dp, bottomEnd = 16.dp, bottomStart = 7.dp)
private val MenuWidth = 248.dp
private val CompactMenuWidth = 196.dp

/**
 * Всплывающее меню рядом с элементом (в духе Apple): фон слегка затемняется, меню плавно
 * «вырастает» из точки у элемента. Размытия фона нет: на Android до 12 его не сделать.
 * Меню ставится под элементом, а если внизу нет места, над ним. Нажатие мимо закрывает его.
 *
 * [anchor] берётся из LayoutCoordinates.screenBounds(), в координатах экрана.
 */
@Composable
fun AnchoredMenu(
    anchor: Rect,
    onClose: () -> Unit,
    /** Ставить меню над элементом (если там есть место), а не под ним: элемент остаётся виден целиком. */
    preferAbove: Boolean = false,
    /** Компактная плашка: уже, и фон затемняется слабее, чтобы элемент рядом было хорошо видно. */
    compact: Boolean = false,
    /** Зазор между меню и элементом. У папок большой: папка при удержании подпрыгивает, название должно остаться видно. */
    gap: androidx.compose.ui.unit.Dp = 10.dp,
    content: @Composable ColumnScope.() -> Unit,
) {
    val p = LocalPalette.current
    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false),
    ) {
        val view = LocalView.current
        // Своё затемнение вместо системного: так оно плавно появляется вместе с меню.
        val window = (view.parent as? DialogWindowProvider)?.window
        SideEffect { window?.setDimAmount(0f) }

        val progress = remember { Animatable(0f) }
        LaunchedEffect(Unit) { progress.animateTo(1f, spring(dampingRatio = 0.74f, stiffness = 560f)) }
        val originY = remember { floatArrayOf(0f) }

        Box(
            Modifier
                .fillMaxSize()
                .drawBehind { drawRect(Color.Black.copy(alpha = (if (compact) 0.14f else 0.34f) * progress.value.coerceIn(0f, 1f))) }
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClose),
        ) {
            Layout(
                modifier = Modifier.fillMaxSize(),
                content = {
                    Column(
                        Modifier
                            .width(if (compact) CompactMenuWidth else MenuWidth)
                            .graphicsLayer {
                                val t = progress.value
                                val s = 0.82f + 0.18f * t
                                scaleX = s
                                scaleY = s
                                alpha = (t * 1.6f).coerceIn(0f, 1f)
                                transformOrigin = TransformOrigin(0.5f, originY[0])
                            }
                            .shadow(18.dp, MenuShape)
                            .clip(MenuShape)
                            .background(p.card)
                            // Нажатия по самому меню не должны закрывать его через фон.
                            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = {})
                            .verticalScroll(rememberScrollState())
                            .padding(vertical = 6.dp),
                        content = content,
                    )
                },
            ) { measurables, constraints ->
                val margin = 14.dp.roundToPx()
                val gapPx = gap.roundToPx()
                val placeable = measurables.first().measure(
                    Constraints(
                        maxWidth = (constraints.maxWidth - 2 * margin).coerceAtLeast(0),
                        maxHeight = (constraints.maxHeight - 2 * margin).coerceAtLeast(0),
                    ),
                )
                // Окно меню может начинаться не в углу экрана: сводим координаты к его началу.
                val loc = IntArray(2)
                view.getLocationOnScreen(loc)
                val top = anchor.top - loc[1]
                val bottom = anchor.bottom - loc[1]
                val centerX = anchor.center.x - loc[0]

                val w = placeable.width
                val h = placeable.height
                val maxX = (constraints.maxWidth - w - margin).coerceAtLeast(margin)
                val x = (centerX - w / 2f).roundToInt().coerceIn(margin, maxX)
                val belowY = bottom.roundToInt() + gapPx
                val aboveY = top.roundToInt() - gapPx - h
                val fitsBelow = belowY + h <= constraints.maxHeight - margin
                val fitsAbove = aboveY >= margin
                val above = if (preferAbove) fitsAbove else !fitsBelow && fitsAbove
                val below = !above && fitsBelow
                val y = when {
                    above -> aboveY
                    below -> belowY
                    else -> ((constraints.maxHeight - h) / 2).coerceAtLeast(margin)
                }
                originY[0] = when {
                    below -> 0f
                    above -> 1f
                    else -> 0.5f
                }
                layout(constraints.maxWidth, constraints.maxHeight) { placeable.place(x, y) }
            }
        }
    }
}

/** Мелкая подпись над группой пунктов. */
@Composable
fun MenuLabel(text: String) {
    val p = LocalPalette.current
    Text(
        text = text,
        color = p.muted,
        fontFamily = Onest,
        fontWeight = FontWeight.SemiBold,
        fontSize = 13.sp,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 4.dp),
    )
}

@Composable
fun MenuDivider() {
    val p = LocalPalette.current
    Box(
        Modifier
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .fillMaxWidth()
            .height(1.dp)
            .background(p.ink.copy(alpha = 0.08f)),
    )
}

/**
 * Пункт меню. При нажатии то же, что и при копировании: лёгкая вибрация, плашка чуть
 * уменьшается, заливается цветом «выбрано» (для опасных пунктов красным) с бликом сверху для
 * объёма, и лишь через долю секунды выполняется действие и меню закрывается.
 */
@Composable
fun MenuItem(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    danger: Boolean = false,
    trailing: ImageVector? = null,
    /** Цвет значка справа в спокойном состоянии. Для опасных пунктов всегда красный. */
    trailingTint: Color? = null,
    /** Низкий пункт для компактной плашки. */
    compact: Boolean = false,
) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val interaction = remember { MutableInteractionSource() }
    val scope = rememberCoroutineScope()
    val flash = remember { Animatable(0f) }
    var busy by remember { mutableStateOf(false) }
    val fill = remember(p, danger) {
        if (danger) Brush.verticalGradient(listOf(DangerTop, DangerBottom)) else p.accentBrush()
    }
    val idleText = if (danger) DangerText else p.ink
    val flashText = if (danger) Color.White else p.onAccent
    val idleIcon = if (danger) DangerText else (trailingTint ?: p.ink)

    Row(
        modifier
            .padding(horizontal = 6.dp)
            .fillMaxWidth()
            .heightIn(min = if (compact) 42.dp else 50.dp)
            .pressScale(interaction)
            .clip(ItemShape)
            .drawBehind {
                drawRect(fill, alpha = flash.value)
                drawRect(
                    Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.30f), Color.Transparent),
                        endY = size.height * 0.55f,
                    ),
                    alpha = flash.value,
                )
            }
            .clickable(interactionSource = interaction, indication = null) {
                if (!busy) {
                    busy = true
                    tick()
                    scope.launch {
                        flash.snapTo(1f)
                        delay(230)
                        onClick()
                        busy = false
                    }
                }
            }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = label,
            color = lerp(idleText, flashText, flash.value),
            fontFamily = Onest,
            fontWeight = FontWeight.SemiBold,
            fontSize = if (compact) 15.sp else 16.sp,
            maxLines = if (label.contains('\n')) 2 else 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        if (trailing != null) {
            Icon(
                imageVector = trailing,
                contentDescription = null,
                tint = lerp(idleIcon, flashText, flash.value),
                modifier = Modifier.size(20.dp),
            )
        }
    }
}
