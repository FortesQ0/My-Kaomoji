// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.ui.components

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import kotlinx.coroutines.delay
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.layout.layout
import androidx.compose.animation.core.EaseInOutCubic
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.Animatable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.komodje.R
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.Onest

/** Высота плашек верхней строки: как у вкладок-фильтров. */
private val PlaqueHeight = 38.dp

/**
 * 0f: плашки лежат на обычном фоне и акцентные; 1f: лежат на подложке «Хитов дня» и белые.
 * Значение меняется плавно (подложка уезжает при прокрутке), поэтому цвета считаем через lerp.
 */
val LocalPlateMix = compositionLocalOf { 0f }

private val PlaqueDark = Color(0xFF2A2133)

/** Как выглядит плашка, когда лежит на подложке: цвет заливки, надписи и приглушённой надписи. */
data class PlateStyle(val fill: Color, val ink: Color, val muted: Color)

val LocalPlateStyle = compositionLocalOf { PlateStyle(Color.White, PlaqueDark, PlaqueDark.copy(alpha = 0.6f)) }

/** Цвет надписи и значков на плашке: контрастный и на белом, и на акценте. */
@Composable
private fun plaqueInk(): Color {
    val p = LocalPalette.current
    return lerp(p.onAccent, LocalPlateStyle.current.ink, LocalPlateMix.current)
}

@Composable
private fun plaqueMuted(): Color {
    val p = LocalPalette.current
    return lerp(p.onAccent.copy(alpha = 0.7f), LocalPlateStyle.current.muted, LocalPlateMix.current)
}

/** Плашка в стиле вкладок: на подложке белая, на светлом фоне акцентная; тонкая рамка. */
@Composable
private fun Modifier.plaque(): Modifier {
    val p = LocalPalette.current
    val mix = LocalPlateMix.current
    return this
        .clip(TabShape)
        .background(lerp(p.accent, LocalPlateStyle.current.fill, mix))
        .border(1.dp, lerp(p.accentDeep.copy(alpha = 0.5f), Color.Black.copy(alpha = 0.08f), mix), TabShape)
}

/**
 * Верхняя строка над списком. Слева: «Создать свой смайлик» (только в «Любимых») или подпись
 * «Хиты дня», справа плашка поиска. По тапу плашка раскрывается в поле ввода на всю строку.
 */
@Composable
fun SearchRow(
    open: Boolean,
    query: String,
    onOpen: () -> Unit,
    onClose: () -> Unit,
    onQuery: (String) -> Unit,
    modifier: Modifier = Modifier,
    leading: (@Composable () -> Unit)? = null,
    label: @Composable () -> Unit,
) {
    Box(modifier.fillMaxWidth().height(44.dp), contentAlignment = Alignment.Center) {
        if (open) {
            SearchField(query, onQuery, onClose)
        } else {
            Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                if (leading != null) Box(Modifier.padding(start = 14.dp)) { leading() }
                // Подпись стоит ровно посередине по высоте плашки поиска справа.
                Box(
                    Modifier.weight(1f).height(PlaqueHeight),
                    contentAlignment = Alignment.CenterStart,
                ) { label() }
                SearchButton(onOpen, Modifier.padding(end = 14.dp))
            }
        }
    }
}

/** Плашка поиска: слово «Поиск» и крупная залитая лупа справа. По ширине как вкладка «Компания». */
@Composable
fun SearchButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val source = remember { MutableInteractionSource() }
    Row(
        modifier
            .width(128.dp)
            .height(PlaqueHeight)
            .pressScale(source)
            .plaque()
            .clickable(interactionSource = source, indication = null) {
                tick()
                onClick()
            }
            .padding(start = 16.dp, end = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            stringResource(R.string.search_short),
            color = plaqueInk(),
            fontFamily = Onest,
            fontWeight = FontWeight.SemiBold,
            fontSize = 14.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        Icon(
            KaomojiIcons.Search,
            contentDescription = stringResource(R.string.search_hint),
            tint = plaqueInk(),
            modifier = Modifier.size(24.dp),
        )
    }
}

/** «Создать свой смайлик»: той же высоты и стиля, что поиск. Когда места мало (папка открыта), только карандаш. */
@Composable
fun CreateOwnButton(compact: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val source = remember { MutableInteractionSource() }
    Row(
        modifier
            .height(PlaqueHeight)
            .animateContentSize()
            .pressScale(source)
            .plaque()
            .clickable(interactionSource = source, indication = null) {
                tick()
                onClick()
            }
            .padding(horizontal = if (compact) 11.dp else 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            KaomojiIcons.Edit,
            contentDescription = stringResource(R.string.own_create),
            tint = plaqueInk(),
            modifier = Modifier.size(20.dp),
        )
        if (!compact) {
            Spacer(Modifier.width(8.dp))
            Text(
                stringResource(R.string.own_create),
                color = plaqueInk(),
                fontFamily = Onest,
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun SearchField(query: String, onQuery: (String) -> Unit, onClose: () -> Unit) {
    val p = LocalPalette.current
    val focus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    val tick = rememberTick()
    // Текст живёт прямо в поле (вместе с областью набора, которую ведёт клавиатура) и уходит в поиск с короткой
    // задержкой. Раньше поле получало текст обратно из общего состояния с опозданием, и клавиатура при быстром
    // наборе видела «откат»: буквы переставлялись и уезжали вправо.
    var field by remember { mutableStateOf(TextFieldValue(query, TextRange(query.length))) }
    LaunchedEffect(field.text) {
        if (field.text != query) {
            delay(90)
            onQuery(field.text)
        }
    }
    // Раскрытие: поле плавно вытекает из плашки поиска справа налево. Без перелёта и отскока,
    // кривая ease-in-out: медленный старт, мягкое торможение в конце. Содержимое проявляется
    // чуть позже ширины, чтобы движение читалось как «разворот», а не рывок.
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        progress.animateTo(1f, tween(durationMillis = 460, easing = EaseInOutCubic))
    }
    LaunchedEffect(Unit) {
        delay(260)
        runCatching { focus.requestFocus() }
    }
    Row(
        Modifier
            .padding(horizontal = 14.dp)
            .layout { measurable, constraints ->
                val full = constraints.maxWidth
                val start = minOf(128.dp.roundToPx(), full)
                val width = (start + (full - start) * progress.value).toInt().coerceIn(start / 2, full)
                val placeable = measurable.measure(Constraints.fixed(width, PlaqueHeight.roundToPx()))
                layout(full, placeable.height) { placeable.place(full - width, 0) }
            }
            .graphicsLayer { alpha = ((progress.value - 0.1f) / 0.6f).coerceIn(0f, 1f) }
            .plaque()
            .padding(start = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(KaomojiIcons.Search, contentDescription = null, tint = plaqueInk(), modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
            if (field.text.isEmpty()) {
                Text(
                    stringResource(R.string.search_hint),
                    color = plaqueMuted(),
                    fontFamily = Onest,
                    fontWeight = FontWeight.Medium,
                    fontSize = 14.sp,
                    maxLines = 1,
                )
            }
            BasicTextField(
                value = field,
                onValueChange = { field = it },
                singleLine = true,
                textStyle = TextStyle(color = plaqueInk(), fontSize = 15.sp),
                cursorBrush = SolidColor(plaqueInk()),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
                modifier = Modifier.fillMaxWidth().focusRequester(focus),
            )
        }
        val source = remember { MutableInteractionSource() }
        Box(
            Modifier
                .size(PlaqueHeight)
                .clickable(interactionSource = source, indication = null) {
                    tick()
                    focusManager.clearFocus()
                    onClose()
                },
            contentAlignment = Alignment.Center,
        ) {
            Icon(KaomojiIcons.Close, contentDescription = null, tint = plaqueMuted(), modifier = Modifier.size(16.dp))
        }
    }
}

/** Верхняя строка в режиме выбора: «Выбрано: N» и крестик. Стоит на месте поиска, того же вида. */
@Composable
fun SelectionBar(count: Int, onClose: () -> Unit, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val source = remember { MutableInteractionSource() }
    Box(modifier.fillMaxWidth().height(44.dp), contentAlignment = Alignment.Center) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp)
                .height(PlaqueHeight)
                .plaque()
                .padding(start = 18.dp, end = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                stringResource(R.string.select_count, count),
                color = p.onAccent,
                fontFamily = Onest,
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
                maxLines = 1,
                modifier = Modifier.weight(1f),
            )
            Box(
                Modifier
                    .size(30.dp)
                    .pressScale(source)
                    .clickable(interactionSource = source, indication = null) {
                        tick()
                        onClose()
                    },
                contentAlignment = Alignment.Center,
            ) {
                Icon(KaomojiIcons.Close, null, tint = p.onAccent, modifier = Modifier.size(20.dp))
            }
        }
    }
}
