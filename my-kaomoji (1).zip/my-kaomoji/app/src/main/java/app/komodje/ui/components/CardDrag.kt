// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.ui.components

import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntSize

/**
 * Финал перетаскивания: палец поднят. Над папкой ([folder] не null) карточка уменьшается и падает в неё,
 * мимо папки (null) возвращается на своё место.
 */
class DragRelease(
    val folder: String?,
    /** Центр исходной карточки в системе корня окна: сюда карточка возвращается, если отпустили мимо. */
    val backCenter: Offset,
    /** Вызывается, когда карточка долетела до папки: тут она реально кладётся в папку. */
    val commit: () -> Unit,
)

/**
 * Состояние перетаскивания карточки из «Любимых» в папку. Живёт на главном экране и общее для карточки,
 * ряда папок и «призрака» под пальцем. Все координаты в системе корня окна.
 */
@Stable
class CardDragState {
    /** Какую карточку тянут (null: ничего не тянут). Остаётся, пока «призрак» доигрывает финал. */
    var text by mutableStateOf<String?>(null)

    /** Сколько карточек едет вместе с ней (в режиме выбора). */
    var count by mutableStateOf(1)

    /** Где сейчас палец. */
    var pos by mutableStateOf(Offset.Zero)

    /** Над какой папкой палец (id) или null. */
    var hover by mutableStateOf<String?>(null)

    /** Границы папок в ряду: заполняет сам ряд. */
    val rects = HashMap<String, Rect>()

    /** Размер исходной карточки в пикселях, точка захвата внутри неё и плотность, в которой она нарисована. */
    var cardSize by mutableStateOf(IntSize.Zero)
    var grab by mutableStateOf(Offset.Zero)
    var cardDensity by mutableStateOf<Density?>(null)

    /** Палец поднят: «призрак» играет финал (падение в папку или возврат). */
    var release by mutableStateOf<DragRelease?>(null)

    /** Папка, в которую только что упала карточка. Счётчик растёт при каждом падении: папка «пружинит». */
    var landed by mutableStateOf<String?>(null)
    var landedTick by mutableIntStateOf(0)

    fun folderAt(p: Offset): String? = rects.entries.firstOrNull { it.value.contains(p) }?.key

    /** Сразу убрать «призрак» без анимации. */
    fun reset() {
        text = null
        hover = null
        release = null
    }
}
