// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.ui.components

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.material3.Text
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp
import app.komodje.ui.theme.Onest
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import app.komodje.ui.theme.BadgeRingShape
import app.komodje.ui.theme.BadgeShape
import app.komodje.ui.theme.BarShape
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.accentBrush
import app.komodje.ui.theme.badgeBrush
import app.komodje.ui.theme.gradientTint
import app.komodje.ui.theme.onAccentBrush
import app.komodje.ui.theme.onBadgeBrush

/**
 * Персиковая панель-«лист» с градиентом. Активная вкладка поднимается над ней тёмным
 * листом-значком с вырезом по кольцу; значок перетекает между вкладками на spring.
 * Подписей нет: категорию говорит само лицо на значке.
 */
@Composable
fun KaomojiBottomBar(
    items: List<Category>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val barBrush = remember(p) { p.accentBrush() }
    val badgeFill = remember(p) { p.badgeBrush() }
    val tabBrush = remember(p) { p.onAccentBrush() }
    val activeBrush = remember(p) { p.onBadgeBrush() }
    val barH = 66.dp
    val badge = 62.dp

    BoxWithConstraints(modifier.height(86.dp)) {
        val itemW = maxWidth / items.size
        val x by animateDpAsState(
            targetValue = itemW * selected + (itemW - badge) / 2,
            animationSpec = spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMediumLow),
            label = "badge",
        )

        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(barH)
                .clip(BarShape)
                .background(barBrush)
        )

        Row(Modifier.fillMaxSize()) {
            items.forEachIndexed { i, c ->
                val active = i == selected
                val iconAlpha = animateFloatAsState(if (active) 0f else 1f, tween(160), label = "ia")
                val source = remember { MutableInteractionSource() }
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .pressScale(source, pressedScale = 0.88f)
                        .clickable(
                            interactionSource = source,
                            indication = null,
                        ) {
                            tick()
                            onSelect(i)
                        },
                ) {
                    Icon(
                        imageVector = c.icon,
                        contentDescription = stringResource(c.label),
                        tint = Color.Black,
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 18.dp)
                            .size(32.dp)
                            .graphicsLayer { alpha = iconAlpha.value * 0.92f }
                            .gradientTint(tabBrush),
                    )
                }
            }
        }

        Box(
            Modifier
                .offset(x = x)
                .size(badge)
                .clip(BadgeRingShape)
                .background(p.bgBottom),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                Modifier
                    .size(badge - 8.dp)
                    .clip(BadgeShape)
                    .background(badgeFill),
                contentAlignment = Alignment.Center,
            ) {
                Crossfade(targetState = selected, animationSpec = tween(180), label = "badgeIcon") { idx ->
                    Icon(
                        imageVector = items[idx].icon,
                        contentDescription = null,
                        tint = Color.Black,
                        modifier = Modifier.size(30.dp).gradientTint(activeBrush),
                    )
                }
            }
        }
    }
}

