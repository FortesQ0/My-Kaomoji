// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject

/**
 * Файл-копия: всё, что хранится в приложении (избранное, папки, закрепы, недавние, тема, масштаб, язык
 * и остальные настройки), одним JSON. Плюс маленький файл одной папки для «Поделиться».
 * Реквизиты доната в хранилище не лежат, поэтому в файл не попадают.
 */
object Backup {
    private const val APP = "my-kaomoji-backup"
    private const val FOLDER_APP = "my-kaomoji-folder"
    private const val MAX_ITEMS = 1000

    suspend fun exportAll(context: Context): String {
        val prefs = context.dataStore.data.first().asMap()
        val arr = JSONArray()
        for ((key, value) in prefs) {
            val o = JSONObject().put("k", key.name)
            when (value) {
                is String -> o.put("t", "s").put("v", value)
                is Boolean -> o.put("t", "b").put("v", value)
                is Int -> o.put("t", "i").put("v", value)
                is Long -> o.put("t", "l").put("v", value)
                is Float -> o.put("t", "f").put("v", value.toDouble())
                is Double -> o.put("t", "d").put("v", value)
                is Set<*> -> o.put("t", "set").put("v", JSONArray(value.map { it.toString() }))
                else -> continue
            }
            arr.put(o)
        }
        return JSONObject().put("app", APP).put("version", 1).put("data", arr).toString()
    }

    /** Заменяет все данные приложения содержимым файла. false, если файл не подошёл (тогда ничего не меняется). */
    suspend fun importAll(context: Context, text: String): Boolean {
        val root = runCatching { JSONObject(text) }.getOrNull() ?: return false
        // Принимаем и копии, сделанные прежними версиями: у них та же схема, отличается только метка.
        if (!root.optString("app").endsWith("-backup")) return false
        val arr = root.optJSONArray("data") ?: return false
        context.dataStore.edit { prefs ->
            prefs.clear()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val name = o.optString("k")
                if (name.isEmpty()) continue
                when (o.optString("t")) {
                    "s" -> prefs[stringPreferencesKey(name)] = o.getString("v")
                    "b" -> prefs[booleanPreferencesKey(name)] = o.getBoolean("v")
                    "i" -> prefs[intPreferencesKey(name)] = o.getInt("v")
                    "l" -> prefs[longPreferencesKey(name)] = o.getLong("v")
                    "f" -> prefs[floatPreferencesKey(name)] = o.getDouble("v").toFloat()
                    "d" -> prefs[doublePreferencesKey(name)] = o.getDouble("v")
                    "set" -> {
                        val a = o.getJSONArray("v")
                        prefs[stringSetPreferencesKey(name)] = (0 until a.length()).map { a.getString(it) }.toSet()
                    }
                }
            }
        }
        return true
    }

    fun folderToJson(name: String, items: List<String>): String =
        JSONObject().put("app", FOLDER_APP).put("version", 1).put("name", name)
            .put("items", JSONArray(items.take(MAX_ITEMS))).toString()

    /** Имя папки и её каомодзи из файла «Поделиться», либо null, если файл не похож на папку. */
    fun parseFolder(text: String): Pair<String, List<String>>? {
        val root = runCatching { JSONObject(text) }.getOrNull() ?: return null
        if (!root.optString("app").endsWith("-folder")) return null
        val name = root.optString("name").trim().take(FoldersStore.MAX_NAME)
        val arr = root.optJSONArray("items") ?: return null
        val items = (0 until minOf(arr.length(), MAX_ITEMS)).map { arr.optString(it) }.filter { it.isNotBlank() }.distinct()
        if (name.isEmpty() || items.isEmpty()) return null
        return name to items
    }

    /** Добавляет папку из файла: новая папка с этим именем, а её каомодзи попадают и в «Любимые». */
    suspend fun importFolder(context: Context, name: String, items: List<String>) {
        FavoritesStore(context).addAll(items)
        FoldersStore(context).createWith(name, items)
    }
}
