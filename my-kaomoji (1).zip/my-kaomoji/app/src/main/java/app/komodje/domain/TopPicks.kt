// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.domain

/**
 * Что показывать в быстрых местах: виджет и ряд над списком в клавиатуре.
 * Порядок: любимые (чаще используемые выше), потом остальные, которыми уже пользовались,
 * потом начало библиотеки, чтобы набор никогда не был пустым.
 * Тексты, которых нет в библиотеке (она могла измениться), пропускаются.
 */
fun topPicks(library: List<String>, favorites: Set<String>, counts: Map<String, Int>, limit: Int): List<String> {
    val position = HashMap<String, Int>()
    library.forEachIndexed { i, text -> if (text !in position) position[text] = i }

    val byUse = compareByDescending<String> { counts[it] ?: 0 }
        .thenBy { position[it] ?: Int.MAX_VALUE }

    val favs = favorites.filter { it in position }.sortedWith(byUse)
    val used = counts.keys
        .filter { it in position && it !in favorites && (counts[it] ?: 0) > 0 }
        .sortedWith(byUse)
    val rest = library.filter { it !in favorites && (counts[it] ?: 0) <= 0 }

    return (favs + used + rest).distinct().take(limit)
}
