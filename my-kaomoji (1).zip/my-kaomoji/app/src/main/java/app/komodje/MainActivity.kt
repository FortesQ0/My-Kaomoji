// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje

import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.ui.res.stringResource
import app.komodje.ui.components.ConfirmDialog
import app.komodje.data.Backup
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalConfiguration
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.komodje.domain.Mood
import app.komodje.ui.AppHeader
import app.komodje.ui.HomeScreen
import app.komodje.ui.HomeViewModel
import app.komodje.ui.LanguageWelcome
import app.komodje.ui.OwnEditorScreen
import app.komodje.ui.SettingsScreen
import app.komodje.ui.components.LocalCardScale
import app.komodje.ui.components.cardScaleFactor
import app.komodje.ui.components.LocalHapticsEnabled
import app.komodje.ui.supportedLanguageFor
import app.komodje.ui.theme.MyKaomojiTheme
import app.komodje.ui.theme.ThemeTransition
import app.komodje.ui.theme.ThemeTransitionOverlay
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.backgroundBrush
import app.komodje.ui.theme.isDark
import app.komodje.ui.theme.paletteFor
import app.komodje.widget.refreshWidgetsAsync
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private val vm: HomeViewModel by viewModels {
        HomeViewModel.factory((application as MyKaomojiApp).container)
    }

    /** Растёт, когда ярлык с иконки просит открыть вкладку: экран настроек при этом закрывается. */
    private var shortcutTick by mutableIntStateOf(0)
    // Папка из присланного файла .kaomoji: ждёт, пока человек подтвердит добавление.
    private var incomingFolder by mutableStateOf<Pair<String, List<String>>?>(null)

    /**
     * Просим у системы самую высокую частоту экрана при текущем разрешении. Без запроса оболочки
     * (HiOS и подобные) часто держат стороннее приложение на 60 Гц, и прокрутка кажется рваной.
     * Это только пожелание: система вольна его не выполнить, ничего не ломается.
     */
    private fun requestMaxRefreshRate() {
        runCatching {
            @Suppress("DEPRECATION")
            val screen = if (Build.VERSION.SDK_INT >= 30) display else windowManager.defaultDisplay
            if (screen == null) return
            val current = screen.mode
            val best = screen.supportedModes
                .filter { it.physicalWidth == current.physicalWidth && it.physicalHeight == current.physicalHeight }
                .maxByOrNull { it.refreshRate } ?: return
            val lp = window.attributes
            lp.preferredDisplayModeId = best.modeId
            lp.preferredRefreshRate = best.refreshRate
            window.attributes = lp
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) {
            handleShortcut(intent)
            handleIncoming(intent)
        }
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT))
        requestMaxRefreshRate()
        val settings = (application as MyKaomojiApp).container.settings
        setContent {
            // StateFlow со стартовым значением из хранилища: после смены языка (пересоздание
            // Activity) экран сразу рисуется с настоящей темой и ничего не «прыгает».
            val mode by settings.themeMode.collectAsStateWithLifecycle()
            val accent by settings.accent.collectAsStateWithLifecycle()
            val languageChosen by settings.languageChosen.collectAsStateWithLifecycle()
            val autoReturn by settings.autoReturn.collectAsStateWithLifecycle()
            val haptics by settings.haptics.collectAsStateWithLifecycle()
            val cardScale by settings.cardScale.collectAsStateWithLifecycle()
            val keyboardHelpSeen by settings.keyboardHelpSeen.collectAsStateWithLifecycle()
            val scope = rememberCoroutineScope()
            val transition = remember { ThemeTransition() }
            var showSettings by rememberSaveable { mutableStateOf(false) }
            var showEditor by rememberSaveable { mutableStateOf(false) }
            val dark = mode.isDark()
            LaunchedEffect(shortcutTick) {
                if (shortcutTick > 0) {
                    showSettings = false
                    showEditor = false
                }
            }

            // Тёмная шапка (бордо, море) требует светлых значков в статус-баре, светлая требует тёмных.
            val lightStatusIcons = remember(accent, dark, languageChosen) {
                // До выбора языка сверху обычный фон страницы, а не цветная шапка.
                if (!languageChosen) dark else paletteFor(accent, dark).onAccent.luminance() > 0.5f
            }
            LaunchedEffect(lightStatusIcons) {
                enableEdgeToEdge(
                    statusBarStyle = if (lightStatusIcons) {
                        SystemBarStyle.dark(Color.TRANSPARENT)
                    } else {
                        SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                    },
                )
            }

            MyKaomojiTheme(dark = dark, accent = accent) {
              CompositionLocalProvider(
                  LocalHapticsEnabled provides haptics,
                  LocalCardScale provides cardScaleFactor(cardScale),
              ) {
                val p = LocalPalette.current
                val systemLanguage = LocalConfiguration.current.locales[0].language
                BackHandler(enabled = showSettings && languageChosen) { showSettings = false }
                BackHandler(enabled = showEditor && languageChosen) { showEditor = false }
                incomingFolder?.let { (folderName, folderItems) ->
                    ConfirmDialog(
                        title = stringResource(R.string.folder_import_title),
                        message = stringResource(R.string.folder_import_message, folderName, folderItems.size),
                        confirm = stringResource(R.string.folder_import_add),
                        onConfirm = {
                            incomingFolder = null
                            scope.launch { Backup.importFolder(applicationContext, folderName, folderItems) }
                        },
                        onClose = { incomingFolder = null },
                    )
                }

                Box(Modifier.fillMaxSize()) {
                Crossfade(targetState = languageChosen, animationSpec = tween(350), label = "welcome") { chosen ->
                    if (!chosen) {
                        // Первый запуск: сначала выбор языка (предвыбран язык системы или английский).
                        LanguageWelcome(
                            initialTag = supportedLanguageFor(systemLanguage).tag,
                            onContinue = { lang ->
                                scope.launch {
                                    // Как в 0.2.23: язык применяется сразу, пока экран выбора ещё на виду.
                                    // После пересоздания окна главный экран плавно проявляется (fadeInMain).
                                    fadeInMain = true
                                    settings.markLanguageChosen()
                                    setLanguage(lang.tag)
                                }
                            },
                        )
                    } else {
                        // Сразу после выбора языка главный экран проявляется из того же фона, а не выскакивает.
                        val appear = remember { Animatable(if (fadeInMain) 0f else 1f) }
                        LaunchedEffect(Unit) {
                            if (fadeInMain) {
                                fadeInMain = false
                                appear.animateTo(1f, tween(420, easing = FastOutSlowInEasing))
                            }
                        }
                        Box(Modifier.fillMaxSize().background(p.backgroundBrush())) {
                        Column(
                            Modifier
                                .fillMaxSize()
                                .graphicsLayer { alpha = appear.value }
                                .navigationBarsPadding()
                        ) {
                            AppHeader(
                                settingsOpen = showSettings,
                                onAction = {
                                    // Из конструктора шестерёнка ведёт в настройки.
                                    if (showEditor) {
                                        showEditor = false
                                        showSettings = true
                                    } else {
                                        showSettings = !showSettings
                                    }
                                },
                            )
                            Box(Modifier.weight(1f)) {
                                Crossfade(
                                    targetState = if (showSettings) 1 else if (showEditor) 2 else 0,
                                    animationSpec = tween(200),
                                    label = "screen",
                                ) { screen ->
                                    if (screen == 2) {
                                        OwnEditorScreen(vm = vm, onClose = { showEditor = false })
                                    } else if (screen == 1) {
                                        SettingsScreen(
                                            themeMode = mode,
                                            onThemeMode = { m -> if (m != mode) transition.run(window, scope) { settings.setThemeMode(m) } },
                                            accent = accent,
                                            onAccent = { a -> if (a != accent) transition.run(window, scope) { settings.setAccent(a) } },
                                            autoReturn = autoReturn,
                                            onAutoReturn = { scope.launch { settings.setAutoReturn(it) } },
                                            haptics = haptics,
                                            onHaptics = { scope.launch { settings.setHaptics(it) } },
                                            cardScale = cardScale,
                                            onCardScale = { scope.launch { settings.setCardScale(it) } },
                                            keyboardHelpSeen = keyboardHelpSeen,
                                            onKeyboardHelpSeen = { scope.launch { settings.markKeyboardHelpSeen() } },
                                            onSetLanguage = ::setLanguage,
                                        )
                                    } else {
                                        HomeScreen(vm = vm, onCreateOwn = { showEditor = true })
                                    }
                                }
                            }
                        }
                        }
                    }
                }
                ThemeTransitionOverlay(transition)
                }
              }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShortcut(intent)
        handleIncoming(intent)
    }

    /** Ярлык на иконке приложения: открыть нужную вкладку (Избранные, Радостные и т. д.). */
    /** Открыт файл папки (.kaomoji): читаем и показываем вопрос «Добавить папку?». */
    private fun handleIncoming(intent: Intent?) {
        if (intent?.action != Intent.ACTION_VIEW) return
        val uri = intent.data ?: return
        val text = runCatching {
            contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
        }.getOrNull() ?: return
        Backup.parseFolder(text)?.let { incomingFolder = it }
    }

    private fun handleShortcut(intent: Intent?) {
        val name = intent?.getStringExtra(EXTRA_MOOD) ?: return
        // Один раз: после пересоздания Activity (поворот, смена языка) ярлык повторно не применяем.
        intent.removeExtra(EXTRA_MOOD)
        val mood = runCatching { Mood.valueOf(name) }.getOrNull() ?: return
        vm.select(mood)
        shortcutTick++
    }

    override fun onStop() {
        super.onStop()
        // Запоминаем вкладку, фильтры и место в списке на случай, если систему закроет приложение.
        vm.persistHome()
        // Ушли из приложения: самое время обновить виджет под новые «частые».
        refreshWidgetsAsync(applicationContext)
        // Значок на рабочем столе меняем только когда приложение свернули: на глазах оно не закрывается,
        // и цвет темы можно спокойно рассмотреть.
        runCatching {
            app.komodje.ui.AppIcon.apply(applicationContext, (application as MyKaomojiApp).container.settings.accent.value)
        }
    }

    private fun setLanguage(tag: String) {
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
    }

    companion object {
        const val EXTRA_MOOD = "app.komodje.extra.MOOD"

        /** Выбрали язык при первом запуске: после пересоздания Activity главный экран плавно проявляется. */
        @Volatile
        var fadeInMain = false
    }
}
