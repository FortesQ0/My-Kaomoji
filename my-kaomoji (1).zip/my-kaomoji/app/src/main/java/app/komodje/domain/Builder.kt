// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.domain

/**
 * Конструктор каомодзи: смайлик собирается из слотов слева направо.
 * Порядок слотов в [Slot] и есть порядок в готовой строке.
 *
 * Слоты EAR_L/EAR_R оставлены только ради совместимости формата сохранения (число слотов
 * не меняем). Раздела «Ухо» в редакторе больше нет: [Part] для них не существует.
 */
enum class Slot { HAND_L, EAR_L, OUTLINE_L, CHEEK_L, EYE_L, MOUTH, EYE_R, CHEEK_R, OUTLINE_R, EAR_R, HAND_R, EFFECT }

/** Часть тела: левый слот и (если есть) парный правый. Рот и эффект без пары. */
enum class Part(val left: Slot, val right: Slot?) {
    // Порядок вкладок в редакторе: от внутреннего к внешнему.
    MOUTH(Slot.MOUTH, null),
    EYE(Slot.EYE_L, Slot.EYE_R),
    CHEEK(Slot.CHEEK_L, Slot.CHEEK_R),
    OUTLINE(Slot.OUTLINE_L, Slot.OUTLINE_R),
    HAND(Slot.HAND_L, Slot.HAND_R),
    EFFECT(Slot.EFFECT, null),
}

/** Стартовые наборы (только левая сторона для парных частей). Символы только из BMP, без эмодзи. */
object BuilderSets {
    val hand = listOf(
        "ヽ", "٩", "ᕦ", "☞", "⊂", "╰", "╭", "\\", "┌", "∩", "σ", "o",
        "ᕙ", "ʅ", "ง", "ლ", "つ", "୨", "ᕕ",
    )
    val outline = listOf(
        "(", "（", "ʕ", "₍", "꒰", "[", "【", "⸜", "⁽",
        "〔", "『", "「", "⟮", "❨", "〈", "｟", "⸨", "⎛",
    )
    val cheek = listOf("///", "〃", "⸝⸝", "˶", "*", "°", "⸝", "･", "≡")
    val eye = listOf(
        "•", "^", "ᵔ", "-", "´", "ˊ", "ó", "ò", "T", "；", "°", "◕", "●", "⊙", "☆", "★", "♡",
        "ಥ", "ಠ", "╥", "ʘ", "◉", "◔", "ꈍ", "x", "ˇ", "≧",
        ">", "˘", "≖", "◍", "⊚", "◯", "ᵒ", "⁰", "ㅇ", "ᗒ", "◠", "✿", "♥", "ᴗ", "。",
    )
    val mouth = listOf(
        "_", "‿", "ᴗ", "ω", "▽", "∀", "o", "O", "д", "ᴥ", "ε", "︿", "﹏", "ー", "‸", "皿", "ェ", "□",
        "△", "∇", "w", "ڡ", "◡", "⌓",
        "︶", "ᵕ", "ヮ", "益", "ᆺ", "▾", "ᗜ", "ꇴ", "﹃", "ᨓ", "〜", "∪",
    )
    val effect = listOf(
        "♡", "♥", "✧", "☆", "★", "♪", "♫", "…", "!", "?!", "ᶻᶻ", "ღ", "✿", "❀", "~", "‼", "#", "///",
        "✦", "✩", "❥", "♬", "☼", "⁂", "☁", "☾", "⁺", "₊",
    ).distinct()

    /** Таблица зеркал (лево → право). Всё, чего здесь нет, зеркалится в себя. */
    val mirrors: Map<String, String> = mapOf(
        "ヽ" to "ﾉ", "٩" to "۶", "ᕦ" to "ᕤ", "☞" to "☜", "⊂" to "⊃", "╰" to "╯", "╭" to "╮",
        "\\" to "/", "┌" to "┐", "≧" to "≦", "<" to ">", ">" to "<", "´" to "`", "ˊ" to "ˋ", "ó" to "ò",
        "ʕ" to "ʔ", "(" to ")", "（" to "）", "₍" to "₎", "꒰" to "꒱", "[" to "]", "【" to "】",
        "⸜" to "⸝", "⁽" to "⁾", "ᘛ" to "ᘚ",
        "ᕙ" to "ᕗ", "ʅ" to "ʃ", "ง" to "ว", "つ" to "⊂", "ᕕ" to "ᕗ",
        "〔" to "〕", "『" to "』", "「" to "」", "⟮" to "⟯", "❨" to "❩", "〈" to "〉", "｟" to "｠", "⸨" to "⸩", "⎛" to "⎞",
        "◜" to "◝", "ᗒ" to "ᗕ",
    )

    fun baseFor(part: Part): List<String> = when (part) {
        Part.HAND -> hand
        Part.OUTLINE -> outline
        Part.CHEEK -> cheek
        Part.EYE -> eye
        Part.MOUTH -> mouth
        Part.EFFECT -> effect
    }
}

fun mirrorOf(symbol: String): String = BuilderSets.mirrors[symbol] ?: symbol

/** Какие символы можно выбрать для слота: правые слоты получают зеркальные образы левого набора. */
fun optionsFor(slot: Slot): List<String> {
    val part = Part.entries.firstOrNull { it.left == slot || it.right == slot } ?: return emptyList()
    val base = BuilderSets.baseFor(part)
    return if (slot == part.right) base.map(::mirrorOf).distinct() else base
}

/** Готовая строка из выбранных частей. */
fun assemble(values: Map<Slot, String>): String =
    Slot.entries.joinToString("") { values[it].orEmpty() }

/**
 * Ставит (или снимает, если [choice] = null) символ в слот. При включённом зеркале выбор левой
 * стороны парной части сразу ставит зеркальный символ справа.
 */
fun withChoice(values: Map<Slot, String>, slot: Slot, choice: String?, mirror: Boolean): Map<Slot, String> {
    val result = values.toMutableMap()
    fun put(s: Slot, v: String?) {
        if (v == null) result.remove(s) else result[s] = v
    }
    put(slot, choice)
    if (mirror) {
        val part = Part.entries.firstOrNull { it.left == slot || it.right == slot }
        if (part?.right != null && slot == part.left) put(part.right, choice?.let(::mirrorOf))
    }
    return result
}

/** Включили зеркало: правые стороны подтягиваются под левые. */
fun syncMirror(values: Map<Slot, String>): Map<Slot, String> {
    val result = values.toMutableMap()
    Part.entries.forEach { part ->
        val right = part.right ?: return@forEach
        val left = values[part.left]
        if (left == null) result.remove(right) else result[right] = mirrorOf(left)
    }
    return result
}

private const val SEPARATOR = '\u001F'

/** Для сохранения состояния конструктора при повороте экрана. */
fun encodeBuilder(values: Map<Slot, String>): String =
    Slot.entries.joinToString(SEPARATOR.toString()) { values[it].orEmpty() }

fun decodeBuilder(encoded: String): Map<Slot, String> {
    if (encoded.isEmpty()) return emptyMap()
    val parts = encoded.split(SEPARATOR)
    if (parts.size != Slot.entries.size) return emptyMap()
    return Slot.entries.zip(parts).filter { it.second.isNotEmpty() }.associate { it.first to it.second }
}
