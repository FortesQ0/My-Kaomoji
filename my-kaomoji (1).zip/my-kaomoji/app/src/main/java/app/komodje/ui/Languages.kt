// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje.ui

import androidx.compose.runtime.Immutable

/**
 * Язык приложения. Названия пишутся на самих языках, без дублей.
 * title и action показываются на экране первого запуска сразу на выбранном языке,
 * ещё до того, как приложение переключится на него.
 */
@Immutable
data class AppLanguage(
    val tag: String,
    val code: String,
    val native: String,
    val title: String,
    val action: String,
) {
    val language: String get() = tag.substringBefore('-')
}

/** Порядок: английский первым, дальше по распространённости в магазине, азиатские в конце. */
val AppLanguages = listOf(
    AppLanguage("en", "EN", "English", "Choose your language", "Continue"),
    AppLanguage("es", "ES", "Español", "Elige tu idioma", "Continuar"),
    AppLanguage("ru", "RU", "Русский", "Выберите язык", "Продолжить"),
    AppLanguage("fr", "FR", "Français", "Choisissez votre langue", "Continuer"),
    AppLanguage("de", "DE", "Deutsch", "Sprache wählen", "Weiter"),
    AppLanguage("it", "IT", "Italiano", "Scegli la lingua", "Continua"),
    AppLanguage("pt", "PT", "Português", "Escolha o idioma", "Continuar"),
    AppLanguage("ja", "JA", "日本語", "言語を選択", "続ける"),
    AppLanguage("ko", "KO", "한국어", "언어 선택", "계속"),
    AppLanguage("zh-CN", "ZH", "中文", "选择语言", "继续"),
)

/** Язык из списка по коду системы; если такого нет, английский. */
fun supportedLanguageFor(languageCode: String): AppLanguage =
    AppLanguages.firstOrNull { it.language == languageCode } ?: AppLanguages.first()
