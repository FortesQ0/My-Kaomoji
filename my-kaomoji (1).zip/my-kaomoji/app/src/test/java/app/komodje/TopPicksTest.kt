// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje

import app.komodje.domain.topPicks
import org.junit.Assert.assertEquals
import org.junit.Test

class TopPicksTest {

    private val library = listOf("a", "b", "c", "d", "e", "f")

    @Test
    fun favoritesFirstThenUsedThenLibraryStart() {
        val result = topPicks(
            library = library,
            favorites = setOf("e", "c"),
            counts = mapOf("c" to 1, "e" to 5, "b" to 9),
            limit = 4,
        )
        assertEquals(listOf("e", "c", "b", "a"), result)
    }

    @Test
    fun emptyHistoryFallsBackToLibraryStart() {
        assertEquals(listOf("a", "b", "c", "d"), topPicks(library, emptySet(), emptyMap(), 4))
    }

    @Test
    fun unknownTextsAreIgnored() {
        assertEquals(listOf("a", "b"), topPicks(library, setOf("zzz"), mapOf("yyy" to 3), 2))
    }
}
