// © 2026 FortesQ0. Все права защищены. См. LICENSE в корне проекта.
package app.komodje

import app.komodje.domain.FLAG_COMPANY
import app.komodje.domain.FLAG_EFFECTS
import app.komodje.domain.KaomojiFilter
import app.komodje.domain.KaomojiFilter.EFFECTS
import app.komodje.domain.KaomojiFilter.GROUP
import app.komodje.domain.KaomojiFilter.SINGLE
import app.komodje.domain.accepts
import app.komodje.domain.dailyPicks
import app.komodje.domain.defaultFolders
import app.komodje.domain.flagsOf
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.int
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class KaomojiFilterTest {

    private val categories: JsonArray by lazy {
        Json.parseToJsonElement(File("src/main/assets/kaomoji.json").readText()).jsonObject["categories"]!!.jsonArray
    }

    private val allTexts: List<String> by lazy {
        categories.flatMap { it.jsonObject["items"]!!.jsonArray.map { e -> e.jsonPrimitive.content } }
    }

    private fun shows(text: String, vararg tabs: KaomojiFilter) = tabs.toSet().accepts(flagsOf(text))

    @Test
    fun emptySelectionAcceptsEverything() {
        assertTrue(allTexts.all { emptySet<KaomojiFilter>().accepts(flagsOf(it)) })
    }

    @Test
    fun plainFaceIsSingleWithoutEffects() {
        val text = "( ˊ ᵕ ˋ )"
        assertTrue(shows(text, SINGLE))
        assertFalse(shows(text, GROUP))
        assertFalse(shows(text, EFFECTS))
    }

    @Test
    fun sadAuraIsAnEffect() {
        assertTrue(shows("( ¯ ︵ ¯ )|||", EFFECTS))
        assertTrue(shows("ʕ ¯ ︵ ¯ ʔ|||", EFFECTS))
    }

    @Test
    fun sparklesInsideTheFaceAreNotAnEffect() {
        assertFalse(shows("(ﾉ✧ ‿‿ ✧)ﾉ", EFFECTS))
        assertFalse(shows("✧ ᗜ ✧", EFFECTS))
    }

    @Test
    fun heartOutsideTheFaceIsAnEffect() {
        assertTrue(shows("( ˊ ᴗ ˋ )♡", EFFECTS))
    }

    @Test
    fun twoFacesAreAGroup() {
        assertTrue(shows("( ˙ ° ˙ )( ˙ ▲ ˙ )", GROUP))
        assertFalse(shows("( ˙ ° ˙ )( ˙ ▲ ˙ )", SINGLE))
    }

    /** Таблица выбора вкладок: что показывается при каком наборе включённых вкладок. */
    @Test
    fun selectionTable() {
        val clean = 0
        val fx = FLAG_EFFECTS
        val company = FLAG_COMPANY
        val companyFx = FLAG_COMPANY or FLAG_EFFECTS

        fun check(tabs: Set<KaomojiFilter>, single: Boolean, singleFx: Boolean, comp: Boolean, compFx: Boolean) {
            assertEquals("$tabs одиночный", single, tabs.accepts(clean))
            assertEquals("$tabs одиночный с эффектами", singleFx, tabs.accepts(fx))
            assertEquals("$tabs компания", comp, tabs.accepts(company))
            assertEquals("$tabs компания с эффектами", compFx, tabs.accepts(companyFx))
        }
        check(setOf(SINGLE), true, false, false, false)
        check(setOf(GROUP), false, false, true, false)
        check(setOf(EFFECTS), false, true, false, true)
        check(setOf(SINGLE, EFFECTS), false, true, false, false)
        check(setOf(GROUP, EFFECTS), false, false, false, true)
        check(setOf(SINGLE, GROUP), true, false, true, false)
        check(setOf(SINGLE, GROUP, EFFECTS), true, true, true, true)
        check(emptySet(), true, true, true, true)
    }

    @Test
    fun libraryFlagsMatchItemsAndStayInRange() {
        for (c in categories) {
            val o: JsonObject = c.jsonObject
            val items = o["items"]!!.jsonArray
            val flags = o["flags"]?.jsonArray ?: continue
            assertEquals("flags и items должны быть одной длины", items.size, flags.size)
            assertTrue(flags.all { it.jsonPrimitive.int in 0..3 })
        }
    }

    @Test
    fun picksAreStableWithinADayAndDistinct() {
        val list = (1..30).map { "k$it" }
        val a = dailyPicks(list, day = 20_000L)
        val b = dailyPicks(list, day = 20_000L)
        assertEquals(a, b)
        assertEquals(4, a.size)
        assertEquals(4, a.toSet().size)
        assertTrue(list.containsAll(a))
    }

    @Test
    fun tooShortListHasNoPicks() {
        assertTrue(dailyPicks(listOf("a", "b", "c", "d"), day = 1L).isEmpty())
    }

    @Test
    fun defaultFolderKaomojiExistInLibrary() {
        val known = allTexts.toSet()
        for (f in defaultFolders()) {
            for (t in f.items) assertTrue("Нет в библиотеке: $t", t in known)
        }
    }

    @Test
    fun threeDefaultFolders() {
        assertEquals(3, defaultFolders().size)
        assertTrue(defaultFolders().first().items.isNotEmpty())
    }
}
