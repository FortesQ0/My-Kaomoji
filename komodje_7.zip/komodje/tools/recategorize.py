#!/usr/bin/env python3
"""Пересобирает категории в komoji.json: каждое каомодзи оценивается по лицу целиком.

Запуск из корня проекта:
    python3 tools/recategorize.py --dry          # только отчёт
    python3 tools/recategorize.py --write        # переписать assets/komoji.json

Правило переноса консервативное: смайлик уходит из своей категории, только если классификатор
уверен (запас очков >= 2) и в тексте нет явных признаков текущей категории. Всё сомнительное
остаётся как было. Каждый смайлик остаётся ровно в одной категории; flags едут вместе с ним.
"""
import argparse
import collections
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import classify  # noqa: E402
import facekit  # noqa: E402

JSON_PATH = os.path.join(HERE, "..", "app", "src", "main", "assets", "komoji.json")

HAPPY_GLYPHS = set("∀▽∇◡‿ᴗᗜᗨヮ^＾≧≦♪♫♬✧☆★ꇴ▿艸ڡ")
ANGRY_GLYPHS = set("皿益凸ಠꐦ#＃╬ψ┻┴òóÒÓ◣◢")
SAD_GLYPHS = set("╥ಥ༎இ︵﹏︿⌓‸ཀཫ⍛ᾥㅠㅜᯅ〒")
TENDER_GLYPHS = set("♡♥❤ღ꒳ᵕ❥˶〃⸝")
BROWS = re.compile(r"[`｀ˋ].{0,3}[´ˊ]")
TEARS = re.compile(r"[;；].{0,3}[;；]|[TТтＴ].{0,2}[TТтＴ]|(?i:orz|otl)|[×✖].{0,3}[×✖]|[xX].{0,2}[×✖xX]")
FLAT_FINGER = re.compile(r"╭∩╮")


def has_angry(t):
    s = facekit.squash(t)
    return any(c in ANGRY_GLYPHS for c in s) or bool(BROWS.search(s)) or bool(FLAT_FINGER.search(s))


def has_sad(t):
    s = facekit.squash(t)
    return any(c in SAD_GLYPHS for c in s) or bool(TEARS.search(s))


def has_tender(t):
    s = facekit.squash(t)
    return any(c in TENDER_GLYPHS for c in s) or "//" in s or "⁄" in s or any(c in "⑅ෆ❁❣" for c in s)


def has_happy(t):
    return any(c in HAPPY_GLYPHS for c in facekit.squash(t))


CURATED_PATH = os.path.join(HERE, "curated.json")
DETERMINED = re.compile(r"[`｀ˋ][･・•‐ー-][ω_ー‿-][･・•‐ー-][´ˊ]")
ANNOYED = re.compile(r"[`｀][-‐]?[дДε皿益][-‐]?[´]")


def curated():
    with open(CURATED_PATH, encoding="utf-8") as f:
        return json.load(f)["overrides"]


_CURATED = None


SAD_TEST_GLYPHS = set("◞◟︵╥﹏；")  # те же, что в Komoji.fitsHappy


def decide(text, current):
    """Возвращает (новая категория, причина). Если менять нечего, категория та же."""
    to, why = _decide(text, current)
    if to == "HAPPY" and current != "HAPPY" and any(c in SAD_TEST_GLYPHS for c in text):
        return "NEUTRAL", "sad-glyph-guard"
    return to, why


def _decide(text, current):
    global _CURATED
    if _CURATED is None:
        _CURATED = curated()
    if text in _CURATED:
        return _CURATED[text], "curated" if _CURATED[text] != current else ""
    s = facekit.squash(text)
    # Недовольное лицо без точек-глаз и пота: (｀д´). С точками (｀･ω･´) это «решительное», оно нейтральное.
    # (｀･ω･´) это «решительный», а не злой: в «Нейтральных» таких большинство, выравниваем.
    if current == "ANGRY" and DETERMINED.search(s) and not any(c in "皿益ಠꐦ#＃╬凸" for c in s):
        return "NEUTRAL", "determined-face"
    if current == "NEUTRAL" and ANNOYED.search(s) and not re.search(r"[;；･・•]", s):
        return "ANGRY", "annoyed-brows"
    rule, cf, sc, why = classify.classify(text)
    if rule == current or cf < 2:
        return current, ""
    # --- уходят из SAD: нет ни слёз, ни грустного рта
    if current == "SAD" and not has_sad(text):
        return rule, "no-sad-evidence"
    # --- приходят в SAD: явные признаки грусти
    if rule == "SAD":
        if has_sad(text) and not has_angry(text) and not (current == "TENDER" and has_tender(text)):
            return "SAD", "sad-evidence"
        return current, ""
    if current == "ANGRY" and not has_angry(text):
        return rule, "no-angry-evidence"
    if rule == "ANGRY":
        if has_angry(text) and not has_happy(text):
            return "ANGRY", "angry-evidence"
        return current, ""
    if current == "HAPPY" and rule == "NEUTRAL" and not has_happy(text):
        return "NEUTRAL", "no-happy-evidence"
    if current == "NEUTRAL" and rule in ("HAPPY", "TENDER") and cf >= 2.5:
        return rule, "neutral-with-evidence"
    return current, ""


def load():
    with open(JSON_PATH, encoding="utf-8") as f:
        return json.load(f)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--write", action="store_true")
    ap.add_argument("--dry", action="store_true")
    ap.add_argument("--dump", help="путь для JSON-отчёта о переносах")
    args = ap.parse_args()
    data = load()
    cats = {c["mood"]: c for c in data["categories"]}
    order = [c["mood"] for c in data["categories"]]
    new_items = {m: [] for m in order}
    new_flags = {m: [] for m in order}
    moves = collections.defaultdict(list)
    for m in order:
        c = cats[m]
        flags = c.get("flags") or [-1] * len(c["items"])
        for t, fl in zip(c["items"], flags):
            to, reason = decide(t, m)
            new_items[to].append(t)
            new_flags[to].append(fl)
            if to != m:
                moves[(m, to, reason)].append(t)
    print("перенесено:", sum(len(v) for v in moves.values()))
    for k, v in sorted(moves.items(), key=lambda kv: -len(kv[1])):
        print(k, len(v))
    if args.dump:
        with open(args.dump, "w", encoding="utf-8") as f:
            json.dump({"|".join(k): v for k, v in moves.items()}, f, ensure_ascii=False, indent=0)
    print({m: len(new_items[m]) for m in order})
    if args.write:
        for c in data["categories"]:
            c["items"] = new_items[c["mood"]]
            c["flags"] = new_flags[c["mood"]]
        with open(JSON_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, separators=(",", ":"))
        print("записано", os.path.normpath(JSON_PATH))


if __name__ == "__main__":
    main()
