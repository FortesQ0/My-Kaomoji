package app.komodje

import app.komodje.domain.Komoji
import app.komodje.domain.fitsHappy
import app.komodje.domain.isComplex
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class LibraryTest {

    private val library: Map<String, List<Komoji>> by lazy {
        val raw = File("src/main/assets/komoji.json").readText()
        Json.parseToJsonElement(raw).jsonObject["categories"]!!.jsonArray.associate {
            val o = it.jsonObject
            o["mood"]!!.jsonPrimitive.content to o["items"]!!.jsonArray.map { e -> Komoji(e.jsonPrimitive.content) }
        }
    }

    @Test
    fun hasFiveCategories() {
        assertEquals(setOf("HAPPY", "SAD", "NEUTRAL", "ANGRY", "TENDER"), library.keys)
    }

    @Test
    fun noPlainAsciiSmileys() {
        val bad = library.values.flatten().filterNot { it.isComplex() }
        assertTrue("Простые смайлики: $bad", bad.isEmpty())
    }

    @Test
    fun noDuplicates() {
        val all = library.values.flatten().map { it.text }
        assertEquals("Дубликаты", all.size, all.toSet().size)
    }

    @Test
    fun happyHasNoSadGlyphs() {
        val bad = library.getValue("HAPPY").filterNot { it.fitsHappy() }
        assertTrue("Грустные глифы в весёлых: $bad", bad.isEmpty())
    }

    @Test
    fun libraryIsLargeAndEveryMoodIsFilled() {
        assertTrue("Библиотека слишком мала", library.values.sumOf { it.size } > 5_000)
        library.forEach { (mood, items) -> assertTrue("Мало каомодзи в $mood", items.size > 300) }
    }

    @Test
    fun noOversizedOrBrokenItems() {
        val bad = library.values.flatten().filter {
            it.text.count { c -> !c.isWhitespace() } > 22 || '\uFFFD' in it.text || it.text != it.text.trim()
        }
        assertTrue("Слишком длинные или битые: $bad", bad.isEmpty())
    }

    @Test
    fun noInvisibleCharacters() {
        val invisible = Regex("[\u200B-\u200F\u2060\uFEFF\u00AD]")
        val bad = library.values.flatten().filter { invisible.containsMatchIn(it.text) }
        assertTrue("Невидимые символы: $bad", bad.isEmpty())
    }

    // ---- Категории по лицу целиком (см. tools/recategorize.py) ----

    private fun moodOf(text: String): String =
        library.entries.first { (_, items) -> items.any { it.text == text } }.key

    private fun withAny(chars: String): List<Pair<String, String>> =
        library.flatMap { (mood, items) -> items.filter { k -> k.text.any { it in chars } }.map { mood to it.text } }

    @Test
    fun knownFacesLandInTheirMood() {
        val expected = mapOf(
            "(ᗜ _ ᗜ)" to "NEUTRAL", // веселые глаза, но ровный рот
            "\\( >ᗜ< )/" to "HAPPY",
            "(≧▽≦)" to "HAPPY",
            "(＾▽＾)" to "HAPPY",
            "(；ω；)" to "SAD",
            "(╥﹏╥)" to "SAD",
            "(；ﾟДﾟ；)" to "NEUTRAL", // пот и шок это не грусть
            "☆(@_@)☆" to "NEUTRAL",
            "(´ー`)" to "NEUTRAL",
            "(｀・ω・´)" to "NEUTRAL", // «решительный», не злой
            "(｀д´)" to "ANGRY",
            "(ಠ益ಠ)" to "ANGRY",
            "(╯°益°)╯⩩" to "ANGRY",
            "(〃▽〃)" to "TENDER", // румянец
        )
        val wrong = expected.filter { (text, mood) -> moodOf(text) != mood }
        assertTrue("Не в тех категориях: $wrong", wrong.isEmpty())
    }

    @Test
    fun heartsLiveOnlyInTender() {
        val bad = withAny("♡♥❤ღ").filter { it.first != "TENDER" }
        assertTrue("Сердечки вне «Нежных»: $bad", bad.isEmpty())
    }

    @Test
    fun hardAngryGlyphsLiveOnlyInAngry() {
        val bad = withAny("皿ꐦ").filter { it.first != "ANGRY" }
        assertTrue("Злые глифы вне «Злых»: $bad", bad.isEmpty())
    }

    @Test
    fun tearEyesLiveOnlyInSad() {
        val bad = withAny("╥ಥ").filter { it.first != "SAD" }
        assertTrue("Слёзы вне «Грустных»: $bad", bad.isEmpty())
    }

    @Test
    fun shockWithSweatIsNotSad() {
        val shock = Regex("[;；][ﾟ°゜]|[ﾟ°゜][;；]")
        val bad = library.getValue("SAD").filter { shock.containsMatchIn(it.text.filterNot(Char::isWhitespace)) }
        assertTrue("Шок с потом в «Грустных»: $bad", bad.isEmpty())
    }
}
