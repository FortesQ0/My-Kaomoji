package app.komodje.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.komodje.ui.theme.LocalPalette
import app.komodje.ui.theme.Onest

private val BubbleShape = RoundedCornerShape(topStart = 16.dp, topEnd = 7.dp, bottomEnd = 16.dp, bottomStart = 7.dp)

/**
 * Значок «?»: знак вопроса акцентным цветом в полупрозрачном пузырьке. Один и тот же в «Любимых»
 * и в настройках клавиатуры. [pulse] включает едва заметное «дыхание», чтобы хотелось нажать.
 * [showDot] рисует красную точку, пока подсказку ни разу не открывали.
 */
@Composable
fun HelpBubble(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    pulse: Boolean = false,
    showDot: Boolean = false,
) {
    val p = LocalPalette.current
    val tick = rememberTick()
    val interaction = remember { MutableInteractionSource() }
    val transition = rememberInfiniteTransition(label = "helpBreath")
    val breath = transition.animateFloat(
        initialValue = 1f,
        targetValue = if (pulse) 1.09f else 1f,
        animationSpec = infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "helpBreathValue",
    )
    Box(modifier) {
        Box(
            Modifier
                .size(38.dp)
                .graphicsLayer {
                    scaleX = breath.value
                    scaleY = breath.value
                }
                .pressScale(interaction, pressedScale = 0.86f)
                .clip(BubbleShape)
                .background(p.accent.copy(alpha = 0.22f))
                .border(1.dp, p.accentDeep.copy(alpha = 0.35f), BubbleShape)
                .clickable(interactionSource = interaction, indication = null) {
                    tick()
                    onClick()
                },
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = "?",
                color = p.accentDeep,
                fontFamily = Onest,
                fontWeight = FontWeight.Bold,
                fontSize = 21.sp,
            )
        }
        if (showDot) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = 3.dp, y = (-3).dp)
                    .size(13.dp)
                    .clip(CircleShape)
                    .background(p.heart)
                    .border(2.dp, p.card, CircleShape),
            )
        }
    }
}
